package tv.freewheel.utils.cookie;

import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookiePolicy;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;

public class AndroidCookieStore extends java.net.CookieManager {
    private static AndroidCookieStore androidCookieStore;

	static {
		AndroidCookieStore object = new AndroidCookieStore();
		object.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
		AndroidCookieStore.androidCookieStore = object;
		CookieHandler.setDefault(object);
		AndroidCookieStore.androidCookieStore.removeExpiredCookie();
	}

	public static AndroidCookieStore getInstance() {
		return androidCookieStore;
	}


    private static final Logger logger = Logger.getLogger(AndroidCookieStore.class);
	public static Context context;
	
	public static void initialize(Context context) {
		AndroidCookieStore.context = context;
		CookieSyncManager.createInstance(context);
		CookieManager.getInstance().removeExpiredCookie();
	}
	
	private AndroidCookieStore() {}

	public void setCookie(String url, String cookie) {
		logger.verbose("setting cookie: " + cookie + ", for url: " + url);
		
		CookieManager.getInstance().setCookie(url, cookie);
		CookieSyncManager.getInstance().sync();
	}
	
	public void removeAllCookies() {
		CookieManager.getInstance().removeAllCookie();
	}

	public void removeExpiredCookie() {
		CookieManager.getInstance().removeExpiredCookie();
	}

	public String getCookie(String url) {
		if (StringUtils.isBlank(url)) {
			return null;
		}
		return CookieManager.getInstance().getCookie(url);
	}


	/**
	 * Proxying and overwriting the usage of all java.net.CookieManager
	 *
	 * For more details, please refer to https://stackoverflow.com/questions/12731211/pass-cookies-from-httpurlconnection-java-net-cookiemanager-to-webview-android
	 */
	@Override
	public void put(URI uri, Map<String, List<String>> responseHeaders) throws IOException {
		if (uri == null || responseHeaders == null) {
			throw new IllegalArgumentException("Argument is null");
		}
		String url = uri.toString();
		for (String headerKey : responseHeaders.keySet()) {
			if ((headerKey == null) || !(headerKey.equalsIgnoreCase("Set-Cookie2") || headerKey.equalsIgnoreCase("Set-Cookie"))) {
				continue;
			}
			for (String headerValue : responseHeaders.get(headerKey)) {
				setCookie(url, headerValue);
			}
		}
	}

	@Override
	public Map<String, List<String>> get(URI uri, Map<String, List<String>> requestHeaders) {
		if (uri == null || requestHeaders == null) {
			throw new IllegalArgumentException("Argument is null");
		}
		String url = uri.toString();
		Map<String, List<String>> response = new java.util.HashMap<>();
		String cookie = this.getCookie(url);
		if (cookie != null) {
			response.put("Cookie", Arrays.asList(cookie));
		}
		return response;
	}
}
