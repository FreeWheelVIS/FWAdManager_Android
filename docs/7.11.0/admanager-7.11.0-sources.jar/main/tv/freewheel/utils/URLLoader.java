package tv.freewheel.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import tv.freewheel.ad.Constants;
import tv.freewheel.utils.cookie.AndroidCookieStore;
import tv.freewheel.utils.events.Event;
import tv.freewheel.utils.events.EventDispatcher;
import tv.freewheel.utils.http.HttpConstants;

public class URLLoader extends EventDispatcher {
	private static final String COOKIES_HEADER = "Set-Cookie";
	private static final int MAX_REDIRECT = 3;
	public static final String EVENT_LOAD_COMPLETE = "URLLoader.Load.Complete";
	public static final String EVENT_LOAD_ERROR = "URLLoader.Load.Error";
	private static int LOADER_BUFFER_SIZE = 1024;

	private static final Logger logger = Logger.getLogger(URLLoader.class);

	private HttpURLConnection client = null;

	private int timeOutMilliSeconds = HttpConstants.DEFAULT_LOAD_TIMEOUT_SECOND * 1000;

	/**
	 * This is added to support event tracking for now.
	 * Should be potentially removed when restructuring the code (Implement INJECTION based)
	 */
	public interface URLLoaderListener {
		void onRequestTriggered(URLRequest request);
		void onResponseTriggered(URLRequest request);
	}

	public static URLLoaderListener urlLoaderListener;

	private void issueHttpRequest(final URLRequest request) {
		try {
			initRequest(request);
		} catch (IOException e) {
			dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR, "IO Error: " + e.getMessage()));
			logger.error("HTTP request IO error: " + e.getMessage());
		} finally {
			logger.verbose("httpclient[" + client.hashCode() + "] for URL: " + request.url + " is reclaimed");
			this.close();
		}
	}

	private void setupHTTPClient(final URLRequest request, final int timeOutMilliSeconds) throws IOException {
		URL url = new URL(request.url);
		client = (HttpURLConnection) url.openConnection();
		this.timeOutMilliSeconds = timeOutMilliSeconds;
	}

	private void initRequest(final URLRequest request) throws IOException {
		setConnectionProperty(request);

		if (request.method == URLRequest.Method.POST) {
			if (request.data != null) {
				client.setDoOutput(true);
				DataOutputStream wr = new DataOutputStream(client.getOutputStream());
				wr.writeBytes(request.data);
				wr.flush();
				wr.close();
			}
		}

		handlerHttpStatusCode(request);

		BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()), LOADER_BUFFER_SIZE);
		String inputLine;
		StringBuilder response = new StringBuilder();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine).append("\n");
		}
		in.close();

		parseCookies();
		parseResponse(response.toString(), client.getResponseCode());
	}

	private void handlerHttpStatusCode(URLRequest request) throws IOException {
		int redirectCounter = 0;
		URLRequest currentRequest = request;

		while (redirectCounter < MAX_REDIRECT) {
			int status = client.getResponseCode();
			logger.debug("Got response with HTTP Status Code:" + status + " for request: " + currentRequest.toString());

			if (urlLoaderListener != null) {
				urlLoaderListener.onResponseTriggered(currentRequest);
			}

			if (status < 200 || status > 399) {
				dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR,"bad status code: " + status));
				return;
			} else {
				if (status >= 300) {
					// handler redirect
					redirectCounter++;
					// get redirect url from "location" header field
					String newUrl = client.getHeaderField(Constants._URL_LOCATION);

					// save cookies
					parseCookies();

					// open the new connection again with a new request
					logger.debug("Redirecting to: " + newUrl + " from: " + currentRequest);
					try {
						currentRequest = (URLRequest) currentRequest.clone();
						currentRequest.url = newUrl;
					} catch (CloneNotSupportedException e) {
						logger.warn(e);
						dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR, "Error occurred while redirecting: " + e.toString()));
					}
					client = (HttpURLConnection) new URL(newUrl).openConnection();
					setConnectionProperty(currentRequest);
				} else {
					// handle 2xx directly
					break;
				}
			}
		}
	}

	private void setConnectionProperty(URLRequest request) {
		// setTimeout
		client.setConnectTimeout(timeOutMilliSeconds);
		client.setReadTimeout(timeOutMilliSeconds);
		// set method
		try {
			client.setRequestMethod(request.method == URLRequest.Method.POST ? "POST":"GET");
		} catch (ProtocolException e) {
			dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR, "Request Method invalid: " + e.toString()));
			logger.debug("Request Method invalid: " + e.toString());
		}
		// set cookies
		String cookieString = AndroidCookieStore.getInstance().getCookie(request.url);
		logger.debug("Cookies for URL: " + request.url + " are: " + cookieString);
		if (cookieString != null) {
			client.setRequestProperty("Cookie", cookieString);
		}

		client.setRequestProperty("Content-Type", request.contentType + "; charset=UTF-8");
		client.setRequestProperty("User-Agent", request.userAgent);

	}

	private void parseCookies() {
		List<String> cookiesHeader = client.getHeaderFields().get(COOKIES_HEADER);
		String currentUrl = client.getURL().toString();
		if (cookiesHeader != null) {
			for (String cookie : cookiesHeader) {
				AndroidCookieStore.getInstance().setCookie(currentUrl, cookie);
			}
		}
	}

	private void parseResponse(String responseData, int responseCode) {
		logger.debug("parseResponse() responseData: " + responseData + ", responseCode: " + responseCode);
		if (StringUtils.isBlank(responseData)) {
			responseData = "";
		}
		dispatchEvent(new Event(URLLoader.EVENT_LOAD_COMPLETE, responseCode, responseData));
	}

	private AtomicBoolean clientAlive = new AtomicBoolean(false);

	public void load(final URLRequest request) {
		this.load(request, HttpConstants.DEFAULT_LOAD_TIMEOUT_SECOND);
	}

	public void load(final URLRequest request, final double timeOutSeconds) {
		logger.debug("getting ready to fire url: " + request.url);
		if (urlLoaderListener != null) {
			urlLoaderListener.onRequestTriggered(request);
		}
		new Thread() {
			@Override
			public void run() {
				try {
					if (request.delayMs > 0) {
						Thread.sleep(request.delayMs);
					}
					int timeOutMilliSeconds = (int) (timeOutSeconds * 1000);
					setupHTTPClient(request, timeOutMilliSeconds);
					clientAlive.set(true);
					issueHttpRequest(request);
					logger.debug("loaded url: " + request.url);
				} catch (IOException e) {
					dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR, "Failed to get content from creative url: " + e.toString()));
					logger.error("Failed to get content from creative url. " + e.toString());
				} catch (Throwable e) {
					dispatchEvent(new Event(URLLoader.EVENT_LOAD_ERROR, "RuntimeError: " + e.toString()));
					logger.error("load failed on url: " + request.url, e);
				}
			}
		}.start();
	}

	public void close() {
		new Thread() {
			@Override
			public void run() {
				try{
					if (clientAlive.getAndSet(false)) {
						client.disconnect();
						client = null;
					}
				} catch(Throwable e) {
					logger.error("close failed on client: " + client.toString(), e);
				}

			}
		}.start();
	}
}

