package tv.freewheel.utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by rvooda on 11/10/17.
 *
 * A HashMap with order
 * @param <K>
 * @param <V>
 */
public class FWOrderedHashMap<K, V> extends HashMap <K, V> {
    public ArrayList<K> keys;

    public FWOrderedHashMap() {
        this.keys = new ArrayList<>();
    }

    @Override
    public V put(K key, V value) {
        this.keys.add(key);
        return super.put(key, value);
    }
}
