package tv.freewheel.utils;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Log;

import java.lang.reflect.Method;

public class Logger {
	public static final int VERBOSE = 2;

	public static final int DEBUG = 3;

	public static final int INFO = 4;

	public static final int WARN = 5;

	public static final int ERROR = 6;

	public static final int ASSERT = 7;
	
	private static int logLevel = VERBOSE;

	private static boolean forceVerbose = false;
	
	private Method logVerboseMethod = null;
	private Method logDebugMethod = null;
	private Method logInfoMethod = null;
	private Method logWarnMethod = null;
	private Method logErrorMethod = null;
	private boolean textWithThreadIDAsPrefix = false;
	private String tag = "FW-";

	private Logger(String tag){
		this.tag = tag;
		ClassLoader cl = Logger.class.getClassLoader();
		try {
			Class<?> c = Class.forName("android.util.Log", true, cl);
			Class<?> parameterTypes[] = {String.class, String.class};
			this.logVerboseMethod = c.getMethod("v", parameterTypes);
			this.logDebugMethod = c.getMethod("d", parameterTypes);
			this.logInfoMethod = c.getMethod("i", parameterTypes);
			this.logWarnMethod = c.getMethod("w", parameterTypes);
			this.logErrorMethod = c.getMethod("e", parameterTypes);
		} catch (ClassNotFoundException e) {
			// do nothing
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
	}

	public static void overrideLogLevel(Activity activity) {
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fwdbg://"));

		if (!activity.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY).isEmpty()) {
			forceVerbose = true;
			logLevel = VERBOSE;
		}
	}

	public static Logger getLogger(String tag) {
		return getLogger(tag,false);
	}
	
	public static Logger getLogger(String tag, boolean tagWithThreadID) {
		Logger logger = new Logger(tag);
		logger.textWithThreadIDAsPrefix = tagWithThreadID;
		return logger;
	}

	public static Logger getLogger(Class<?> clazz, boolean tagWithThreadID) {
		String className = clazz.getSimpleName();
		return Logger.getLogger(className, tagWithThreadID);
	}

	public static Logger getLogger(Class<?> clazz) {
		return getLogger(clazz, false);
	}

	public static void setLogLevel(int level) {
		if (!forceVerbose) {
			Logger.logLevel = level;
		}
	}

	private void doLoggerInvoke(Method m, String s, int level) {
		if(level >= logLevel) {
			try {
				String text = "FWDBG-" + (this.textWithThreadIDAsPrefix? CommonUtil.currentThreadIdentifier() + s:s);
				Object args[] = {this.tag, text};
				m.invoke(null, args);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
	}

	public void verbose(String s) {
		doLoggerInvoke(this.logVerboseMethod, s, VERBOSE);
	}

	public void debug(String s) {
		doLoggerInvoke(this.logDebugMethod, s, DEBUG);
	}

	public void debug(String message, Throwable throwable) {
		debug(message + "\n" + Log.getStackTraceString(throwable));
	}

	public void debug(Throwable throwable) {
		debug("AdManager caught and handled an exception: " + throwable.getMessage(), throwable);
	}

	public void info(String message) {
		doLoggerInvoke(this.logInfoMethod, message, INFO);
	}

	public void warn(String message) {
		doLoggerInvoke(this.logWarnMethod, message, WARN);
	}

	public void warn(String message, Throwable throwable) {
		warn(message + "\n" + Log.getStackTraceString(throwable));
	}

	public void warn(Throwable throwable) {
		warn("AdManager caught and handled an exception: " + throwable.getMessage(), throwable);
	}

	public void error(String message) {
		doLoggerInvoke(this.logErrorMethod, message, ERROR);
	}

	public void error(String message, Throwable throwable) {
		error(message + "\n" + Log.getStackTraceString(throwable));
	}

	public void error(Throwable throwable) {
		error("AdManager caught and handled an exception: " + throwable.getMessage(), throwable);
	}
	
	public static int getLogLevel() {
		return logLevel;
	}
}
