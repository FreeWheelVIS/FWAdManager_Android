package tv.freewheel.utils.events;

import java.util.ArrayList;
import java.util.HashMap;

import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.utils.Logger;

/**
 * AS3 Style Event dispatching Implementation origins from:
 *  http://wu-media.com/2009/06/android-events-the-easy-as3-way/
 */
public class EventDispatcher {
	
	protected HashMap<String , ArrayList<IEventListener>> listenersMap;
	private static final Logger logger = Logger.getLogger(EventDispatcher.class, true);

	/**
	 * Constructor - intended for inheritance
	 */
	public EventDispatcher() {
		removeAllListeners();
	}

	public void addEventListener(String type, IEventListener listener) {
		logger.debug("addEventListener(type=" + type + ", listener=" + listener + ")");
		if(listener == null) return;
		
		removeEventListener(type, listener);
		ArrayList<IEventListener> listeners = listenersMap.get(type);
		if ( listeners == null ) {
			listeners = new ArrayList<IEventListener>();
			listenersMap.put(type, listeners);
		}
		
		listeners.add(listener);
	}
	
	public void removeEventListener(String type, IEventListener listener) {
		logger.debug("removeEventListener(type=" + type + ", listener=" + listener + ")");
		ArrayList<IEventListener> listeners = listenersMap.get(type);
		if ( listeners != null ) {
			listeners.remove(listener);
			if ( listeners.isEmpty() ) {
				listenersMap.remove(type);
			}
		}
	}

	public void removeEventListeners(String type) {
		logger.debug("removeEventListeners(type=" + type + ")");
		listenersMap.remove(type);
	}
	
	public boolean hasEventListener(String type) {
		ArrayList<IEventListener> listeners = listenersMap.get(type);
		return !(listeners == null || listeners.isEmpty());
	}
	
	public void removeAllListeners() {
		logger.debug("removeAllListeners for " + this);
		listenersMap = new HashMap<>();
	}
	
	public void dispatchEvent(IEvent event) {
		logger.debug("dispatchEvent(event=" + event.getType() + ")");
		ArrayList<IEventListener> listeners = listenersMap.get(event.getType());
		if ( listeners != null ) {
			IEventListener[] array = new IEventListener[listeners.size()];
			listeners.toArray(array);
			for (IEventListener item : array) {
				item.run(event);
			}
		}
	}
}
