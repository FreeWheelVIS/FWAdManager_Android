package tv.freewheel.utils.events;

import java.util.HashMap;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.interfaces.IEvent;

public class Event implements IEvent {
	public String type;
	public HashMap<String, Object> data;
	public int code;
	
	public Event(String type) {
		this.type = type;
		this.data = new HashMap<String, Object>();
	}
	
	public Event(String type, int code) {
		this(type);
		this.code = code;
	}

	public Event(String type, int code, String message) {
		this(type);
		this.code = code;
		this.data.put(Constants._INFO_KEY_MESSAGE, message);
	}

	public Event(String type, HashMap<String, Object> data) {
		this(type);
		this.data = data;
	}
	
	public Event(String type, String message) {
		this(type);
		this.data.put(Constants._INFO_KEY_MESSAGE, message);
	}
	
	public String getType() {
		return this.type;
	}

	public HashMap<String, Object> getData() {
		return this.data;
	}
}