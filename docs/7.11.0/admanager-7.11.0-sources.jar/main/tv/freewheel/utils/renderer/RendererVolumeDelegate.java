package tv.freewheel.utils.renderer;

import android.content.Context;
import android.media.AudioManager;

import java.util.HashMap;

import tv.freewheel.ad.Constants;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.handler.RepeatingHandler;

/**
 * Created by Yue Wang on 7/18/17.
 */

public class RendererVolumeDelegate {
	private float deviceVolume = -1;
	private float adVolume = -1;

	private RepeatingHandler deviceVolumePollingHanlder;
	private IRendererContext rendererContext;
	private static final Logger logger = Logger.getLogger(RendererVolumeDelegate.class);

	public RendererVolumeDelegate(final IRendererContext rendererContext) {
		this.rendererContext = rendererContext;
		this.adVolume = rendererContext.getInitialAdVolume();
		this.deviceVolumePollingHanlder = new RepeatingHandler();
		this.deviceVolumePollingHanlder.postRepeated(deviceVolumePollingTask, 500, 500);
	}

	private Runnable deviceVolumePollingTask = new Runnable() {
		@Override
		public void run() {
			final IRendererContext context = rendererContext;
			if (context == null || context.getActivity() == null || context.getActivity().getSystemService(Context.AUDIO_SERVICE) == null) {
				return;
			}

			float currentDeviceVolume = ((AudioManager) context.getActivity().getSystemService(Context.AUDIO_SERVICE)).getStreamVolume(AudioManager.STREAM_MUSIC);
			float oldDeviceVolume = deviceVolume;
			deviceVolume = currentDeviceVolume;
			onDeviceVolumeChanged(oldDeviceVolume, deviceVolume);
		}
	};

	private void onDeviceVolumeChanged(float oldDeviceVolume, float newDeviceVolume) {
		if (oldDeviceVolume >= 0.0 && newDeviceVolume >= 0.0 && oldDeviceVolume != newDeviceVolume) {
			logger.debug("onDeviceVolumeChanged(): Device volume changed from " + oldDeviceVolume + " to " + newDeviceVolume);
			this.handleVolumeChange(oldDeviceVolume * this.adVolume, newDeviceVolume * this.adVolume);
		}
	}

	public void onAdVolumeChanged(float newAdVolume) {
		float oldAdVolume = this.adVolume;
		this.adVolume = newAdVolume;
		if (oldAdVolume >= 0.0 && newAdVolume >= 0.0 && oldAdVolume != newAdVolume) {
			logger.debug("onAdVolumeChanged(): Ad volume changed from " + oldAdVolume + " to " + newAdVolume);
			HashMap<String, Object> info = new HashMap<>();
			info.put(Constants._INFO_KEY_VOLUME, newAdVolume);
			this.rendererContext.dispatchEvent(Constants._EVENT_AD_VOLUME_CHANGED, info);
			this.handleVolumeChange(oldAdVolume * this.deviceVolume, newAdVolume * this.deviceVolume);
		}
	}

	private void handleVolumeChange(float oldVolume, float newVolume) {
		if (this.rendererContext == null) {
			return;
		}
		logger.debug("handleVolumeChange(): oldVolume " + oldVolume + " vs newVolume " + newVolume);
		if (oldVolume < 0.02 && newVolume >= 0.02) {
			rendererContext.dispatchEvent(Constants._EVENT_AD_UNMUTE);
		} else if (oldVolume >= 0.02 && newVolume < 0.02) {
			rendererContext.dispatchEvent(Constants._EVENT_AD_MUTE);
		}
	}

	public void dispose() {
		logger.debug("dispose()");
		if (this.deviceVolumePollingHanlder != null) {
			deviceVolumePollingHanlder.removeRepeating(deviceVolumePollingTask);
		}
		this.rendererContext = null;
	}
}
