package tv.freewheel.utils.renderer;

/**
 * Created by rvooda on 4/6/17.
 */

public class RendererUtils {
    public enum MuteState {UNINITIALIZED, MUTED, UNMUTED};
}
