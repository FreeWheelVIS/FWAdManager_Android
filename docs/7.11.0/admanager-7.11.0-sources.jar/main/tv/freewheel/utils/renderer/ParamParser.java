package tv.freewheel.utils.renderer;

import android.graphics.Color;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import tv.freewheel.ad.interfaces.IParameterHolder;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;

public class ParamParser {
	private IParameterHolder context;
	private String paramNamespace;

	private static final Logger logger = Logger.getLogger(ParamParser.class, true);

	public ParamParser(IParameterHolder context, String paramNamespace) {
		this.context = context;
		this.paramNamespace = paramNamespace;
	}

	public int getPositiveIntValueFromParameter(String paramName, int defaultValue) {
		int value = parseInt(paramName, defaultValue);
		if (value < 0) {
			return defaultValue;
		}
		return value;
	}

	/**
	 * Parameters: paramName - Parameter names, could be a String or an Array of
	 * Strings. defaultValue trim - whether to trim the String, whitespace, tab,
	 * \r, \n will be removed.
	 */
	public String parseString(String paramName, String defaultValue) {
		String ret = getNamespacedParamStr(paramName);
		if (ret != null)
			return ret.trim();
		else
			return defaultValue;
	}

	/**
	 * Accept YES/TRUE/ON as true and NO/FALSE/OFF as false, case-insensitive
	 */
	public Boolean parseBoolean(String paramName, Boolean defaultValue) {
		String str = getNamespacedParamStr(paramName);
		if (str != null) {
			str = str.trim().toLowerCase();
			if (str.equals("true") || str.equals("on") || str.equals("yes") || str.equals("1")) {
				return true;
			} else if (str.equals("false") || str.equals("off") || str.equals("no") || str.equals("0")) {
				return false;
			}
		}
		return defaultValue;
	}

	/**
	 * Will return default value if the parameter string is blank after trim
	 */
	public int parseInt(String paramName, int defaultValue) {
		String str = getNamespacedParamStr(paramName);
		return StringUtils.parseInt(str, defaultValue);
	}

	public int parseInt(String paramName, int defaultValue, int radix) {
		String str = getNamespacedParamStr(paramName);
		return StringUtils.parseInt(str, defaultValue, radix);
	}

	public double parseDouble(String paramName, double defaultValue) {
		String str = getNamespacedParamStr(paramName);
		return StringUtils.parseDouble(str, defaultValue);
	}

	public int parseColor(String paramName, int defaultValue) {
		String str = getNamespacedParamStr(paramName);
		if (str != null) {
			int colorInt = defaultValue;
			try{
				colorInt = Color.parseColor(str);
			} catch (IllegalArgumentException e) {
				logger.warn("IllegalArgumentException when parsing parameter "
						+ paramName + " as color whose value is " + str);
			}
			return colorInt;
		}
		return defaultValue;
	}

	public String parseEnum(String paramName, String defaultValue,
							String[] validValues) {
		String str = getNamespacedParamStr(paramName);
		if (str != null) {
			str = str.trim();
			for (int i = 0; i < validValues.length; i++) {
				String validValue = validValues[i];
				if (str.equalsIgnoreCase(validValue))
					return validValue;
			}
		}
		return defaultValue;
	}
	public List<String> parseList(String paramName) {
		return parseList(paramName, null, ",");
	}

	public List<String> parseList(String paramName, List<String> defaultValue, String separatorExpr) {
		String str = getNamespacedParamStr(paramName);
		List<String> ret = null;
		if (str != null) {
			ret = Arrays.asList(str.split(separatorExpr));
			for (int i = 0; i < ret.size(); i++) {
				String s = ret.get(i);
				ret.set(i, s.trim());
			}
			return ret;
		}
		return defaultValue;
	}

	public ArrayList<HashMap<String, String>> parseQueryStringAsList(String paramName){
		ArrayList<HashMap<String, String>> ret = new ArrayList<HashMap<String, String>>();
		String str = getNamespacedParamStr(paramName);
		if (str != null){
			for (String kvs : str.split("&")){
				String kv[] = kvs.split("=");
				if (kv.length == 2){
					HashMap<String, String> tmp = new HashMap<String, String>();
					tmp.put(kv[0], kv[1]);
					ret.add(tmp);
				}
			}
		}
		return ret;
	}

	public HashMap<String, String> parseQueryString(String paramName){
		HashMap<String, String> ret = new HashMap<String, String>();
		String str = getNamespacedParamStr(paramName);
		if (str != null){
			for (String kvs : str.split("&")){
				String kv[] = kvs.split("=");
				if (kv.length == 2){
					ret.put(kv[0], kv[1]);
				}
			}
		}
		return ret;
	}

	public GregorianCalendar parseDate(String paramName, GregorianCalendar defaultValue) {
		return parseCalendar(paramName, defaultValue, "yyyy-MM-dd");
	}

	// Why prefer Calendar over Date, see
	// http://stackoverflow.com/questions/1404210/java-date-vs-calendar
	public GregorianCalendar parseCalendar(String paramName, GregorianCalendar defaultValue, String dateFormat) {
		Object value = getNamespacedParam(paramName);
		String str = null;
		if(value instanceof GregorianCalendar) {
			return (GregorianCalendar)value;
		}
		else if(value instanceof String) {
			str = ((String)value).trim();
			try {
				Date d = new SimpleDateFormat(dateFormat).parse(str);
				if(d != null) {
					GregorianCalendar ret = new GregorianCalendar();
					ret.setTime(d);
					return ret;
				}
			} catch(IllegalArgumentException e) {
				logger.warn("IllegalArgumentException when parsing parameter "
						+ paramName + " as date whose value is " + str);
			} catch (ParseException e2) {
				logger.warn("ParseException when parsing parameter "
						+ paramName + " as date whose value is " + str);
			}
		}
		return defaultValue;
	}

	public double getNonNegativeValueFromParameter(String paramName, double defaultValue, boolean isZeroAccepted) {
		double value = parseDouble(paramName, defaultValue);
		if (value < 0.0 || (!isZeroAccepted && value == 0.0)) {
			logger.warn("Malformed or non-positive value: " + value);
			return defaultValue;
		}
		return value;
	}

	private String getNamespacedParamStr(String paramNameWithoutNamespace) {
		try {
			Object namespaceParam  = getNamespacedParam(paramNameWithoutNamespace);
			if (namespaceParam == null){
				return null;
			}
			return String.valueOf(namespaceParam);
		}  catch (ClassCastException e) {
			logger.warn("ClassCastException when parsing parameter " + paramNameWithoutNamespace);
		}
		return null;
	}

	private Object getNamespacedParam(String paramNameWithoutNamespace) {
		Object value = context.getParameter(this.paramNamespace + "." + paramNameWithoutNamespace);
		if (value != null) return value;
		else return context.getParameter(paramNameWithoutNamespace);
	}
}
