package tv.freewheel.utils.renderer;

import java.util.Timer;
import java.util.TimerTask;

import tv.freewheel.utils.Logger;

public class RendererTimer {
	public interface IRendererTimerService {
		void timeOut();

		void playHeadTime(int headTime);
	}
	private enum RendererTimerState { INITIATED, RUNNING, PAUSED, STOPPED}

	private Timer timer;
	private IRendererTimerService timerService;
	private int duration;
	private int counter;
	private RendererTimerState rendererTimerState = RendererTimerState.INITIATED;
	private static final Logger logger = Logger.getLogger(RendererTimer.class);

	public RendererTimer(int duration, IRendererTimerService timeOut) {
		logger.debug("RendererTimer(duration=" + duration + ")");
		this.duration = duration;
		this.counter = duration;
		this.timerService = timeOut;
	}

	public synchronized void start() {
		logger.debug("start");
		if (this.timer != null) {
			logger.debug("Timer is already created. Not creating again");
			return;
		}
		this.timer = new Timer();
		this.rendererTimerState = RendererTimerState.RUNNING;
		TimerTask tick = new TimerTask() {
			public void run() {
				synchronized (RendererTimer.this) {
					logger.debug("tick duration=" + duration + ", counter=" + counter);
					if (RendererTimer.this.rendererTimerState != RendererTimerState.RUNNING)
						return;
					if (counter > 0)
						counter--;
					timerService.playHeadTime(duration - counter);
					if (counter <= 0) {
						timer.purge();
						timer.cancel();
						timer = null;
						RendererTimer.this.rendererTimerState = RendererTimerState.STOPPED;
						timerService.timeOut();
					}
				}
			}
		};

		timer.scheduleAtFixedRate(tick, 1000, 1000);
	}

	public synchronized void stop() {
		logger.debug("stop");
		this.rendererTimerState = RendererTimerState.STOPPED;
		if (this.timer != null) {
			timer.purge();
			timer.cancel();
			timer = null;
		}
	}

	public synchronized void pause() {
		logger.debug("pause");
		this.rendererTimerState = RendererTimerState.PAUSED;
	}

	public synchronized void resume() {
		logger.debug("resume");
		this.rendererTimerState = RendererTimerState.RUNNING;
	}

	public synchronized void reset() {
		logger.debug("reset");
		this.rendererTimerState = RendererTimerState.INITIATED;
		this.counter = this.duration;
	}
}
