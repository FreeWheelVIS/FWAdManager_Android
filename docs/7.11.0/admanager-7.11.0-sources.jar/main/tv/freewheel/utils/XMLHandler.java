package tv.freewheel.utils;

import android.util.Xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlSerializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class XMLHandler {
	private static final Logger logger = Logger.getLogger("XMLHandler");

	public static String createXMLDocument(XMLElement root)
		throws IllegalArgumentException, 
				IllegalStateException, 
				IOException {
		
		logger.debug("Create xml document");
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		
		serializer.setOutput(writer);
		serializer.startDocument("UTF-8", true);
		root.toXML(serializer);	
		serializer.endDocument();
		
		root = null;
		return writer.toString();
	}
	
	public static final Element getXMLElementFromString(String data, String rootName) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new Exception("new DocumentBuilder failed");
		}
		
		ByteArrayInputStream byteArrayInputStream = null;
		try {
			byteArrayInputStream = new ByteArrayInputStream(data.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			byteArrayInputStream = new ByteArrayInputStream(data.getBytes());
		}

		Document document = null;
		Element adResponseElement = null;
		try {
			document = builder.parse(byteArrayInputStream);
			NodeList rootList = document.getElementsByTagName(rootName);
			if(rootList.getLength() == 0) {
				throw new Exception("no root node " + rootName + " found in document");
			}
			adResponseElement = (Element)rootList.item(0);
		} catch (SAXException e) {
			throw new Exception("parse xml failed");
		} catch (IOException e) {
			throw new Exception("IO Error occurred");
		}finally {
			if (byteArrayInputStream != null){
				byteArrayInputStream.close();
			}
		}
		return adResponseElement;
	}
	
	public static String getTextNodeValue(Node node) {
		NodeList nList = node.getChildNodes();
		for (int j = 0; j < nList.getLength(); ++j) {
			String c = nList.item(j).getNodeValue();
			if (c != null && !c.trim().equals("")) {
				return c.trim();
			}
		}
		return "";
	}

	public static String getTextFromNestedCDATA(Node node) {
		StringBuilder sb = new StringBuilder();
		NodeList nList = node.getChildNodes();
		for (int j = 0; j < nList.getLength(); ++j) {
			String c = nList.item(j).getNodeValue();
			if (c != null && !c.trim().equals("")) {
				sb.append(c.trim());
			}
		}
		return sb.toString();
	}
}
