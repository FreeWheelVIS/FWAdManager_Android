/*
 * Copyright (c) 2016. All rights Reserved
 */

package tv.freewheel.utils;

import org.w3c.dom.CDATASection;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import tv.freewheel.ad.AdVerification;
import tv.freewheel.ad.InternalConstants;

public class StringUtils {
	private static final Logger logger = Logger.getLogger("StringUtils");

	public static int parseInt(String str) {
		return parseInt(str, 0);
	}

	public static int parseInt(String str, int defaultValue) {
		if (StringUtils.isBlank(str)) {
			return defaultValue;
		}
		if (str.length() > 2 && str.startsWith("0x")) {
			return parseInt(str.substring(2), defaultValue, 16);
		} else {
			return parseInt(str, defaultValue, 10);
		}
	}

	//	if radix is 16, str shouldn't contain 0x at the beginning
	public static int parseInt(String str, int defaultValue, int radix) {
		if (StringUtils.isBlank(str)) {
			return defaultValue;
		}
		try {
			return Integer.parseInt(str, radix);
		} catch (NumberFormatException e) {
			logger.warn(str + " is not valid int");
			return defaultValue;
		}
	}

	public static Double parseDouble(String str) {
		return parseDouble(str, 0.0D);
	}

	public static Double parseDouble(String str, Double defaultValue) {
		if (StringUtils.isBlank(str)) {
			return defaultValue;
		}
		try {
			NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
			return numberFormat.parse(str).doubleValue();
		} catch (NumberFormatException | ParseException e){
			logger.debug(e);
		}
		return defaultValue;
	}

	public static Float parseFloat(String str, Float defaultValue) {
		if (StringUtils.isBlank(str)) {
			return defaultValue;
		}
		try {
			NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
			return numberFormat.parse(str).floatValue();
		} catch (ParseException e) {
			logger.debug(e);
		}
		return defaultValue;
	}

	public static Boolean parseBoolean(String str) {
		return parseBoolean(str, false);
	}

	public static float parseFractionToFloatValue(String str) {
		if (StringUtils.isBlank(str)) {
			return Float.NaN;
		}
		float ret = Float.NaN;
		if (!str.contains("/")) {
			try {
				return Float.parseFloat(str);
			} catch (NumberFormatException e) {
				return Float.NaN;
			}
		}
		String[] number = str.split("/");
		if (number.length == 2) {
			int numerator = 0;
			int denominator = 0;
			try {
				numerator = Integer.parseInt(number[0]);
				denominator = Integer.parseInt(number[1]);
			} catch (NumberFormatException e) {
				return Float.NaN;
			}
			if (denominator == 0) {
				return Float.NaN;
			} else {
				return numerator * 1.0f / denominator;
			}
		}
		return ret;
	}

	public static Boolean parseBoolean(String str, Boolean defaultValue) {
		if (StringUtils.isBlank(str)) {
			return defaultValue;
		}
		try {
			return Boolean.valueOf(str);
		} catch (NumberFormatException e){
			logger.debug(e);
			return defaultValue;
		}
	}

	public static Boolean areEqualContentStrings(String str1, String str2) {
		if (isBlank(str1)) {
			return isBlank(str2);
		}
		return str1.equals(str2);
	}

	public static boolean isBlank(String str) {
		return str == null || str.trim().length() == 0;
	}

	public static String convertMapToURLQueryString(Map<String, String> map) {
		if (map == null) {
			return "";
		}
		StringBuffer stringBuffer = new StringBuffer("");
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (stringBuffer.length() > 0) {
				stringBuffer.append('&');
			}
			stringBuffer.append(StringUtils.encodeURIComponent(entry.getKey()));
			stringBuffer.append('=');
			if (!StringUtils.isBlank(entry.getValue())) {
				stringBuffer.append(StringUtils.encodeURIComponent(entry.getValue()));
			}
		}
		return stringBuffer.toString();
	}

	public static String encodeURIComponent(String unencodedString) {
		String result = "";
		try {
			result = URLEncoder.encode(unencodedString, "UTF-8").replaceAll("\\+", "%20");
		} catch (UnsupportedEncodingException e) {
			logger.debug("Failed to encode the string - " + unencodedString, e);
		}
		return result == null ? "" : result;
	}

	public static String patchAdRequestServerURL(String serverURL) {
		if (serverURL == null) {
			return "";
		}
		if (serverURL.startsWith("http://vi.rnd.fwmrm.net/") || serverURL.startsWith("https://vi.rnd.fwmrm.net/")) {
			return serverURL;
		}
		if (serverURL.startsWith("/")) {
			return serverURL;
		}

		if (!serverURL.startsWith("http://") && !serverURL.startsWith("https://")) {
			serverURL = "http://" + serverURL;
		}
		String urlWithoutQuery = serverURL;
		String query = "?";
		if (serverURL.contains("?")) {
			urlWithoutQuery = serverURL.substring(0, serverURL.indexOf("?"));
			query += serverURL.substring(serverURL.indexOf("?") + 1);
		}

		String pathToAppend = "";
		if (urlWithoutQuery.endsWith("ad/p/1/") || urlWithoutQuery.endsWith("ad/p/1")) {
			pathToAppend = "";
		} else if (urlWithoutQuery.endsWith("ad/p/")) {
			pathToAppend = "1";
		} else if (urlWithoutQuery.endsWith("ad/p")) {
			pathToAppend = "/1";
		} else if (urlWithoutQuery.endsWith("ad/")) {
			pathToAppend = "p/1";
		} else if (urlWithoutQuery.endsWith("ad")) {
			pathToAppend = "/p/1";
		} else if (urlWithoutQuery.endsWith("/")) {
			pathToAppend = "ad/p/1";
		} else {
			pathToAppend = "/ad/p/1";
		}

		return urlWithoutQuery + pathToAppend + query;
	}



	public static String convertNodeListToString(Element root) throws TransformerException {
		if (root == null || root.getChildNodes() == null || root.getChildNodes().getLength() == 0) {
			return null;
		}

		// unwrap the CDATA ONLY if all the children are CDATA
		boolean isAllCDATA = true;
		for (int i = 0; i < root.getChildNodes().getLength(); i++) {
			Node n = root.getChildNodes().item(i);
			if (!(n instanceof CDATASection)) {
				isAllCDATA = false;
				break;
			}
		}
		if (isAllCDATA) {
			return root.getTextContent();
		}

		DOMSource source = new DOMSource();
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		for (int i = 0; i < root.getChildNodes().getLength(); ++i) {
			source.setNode(root.getChildNodes().item(i));
			transformer.transform(source, result);
		}

		return writer.toString();
	}

	public static String inputStreamToString(InputStream inputStream) {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		String inputLine;
		StringBuffer response = new StringBuffer();
		try {
			while ((inputLine = bufferedReader.readLine()) != null) {
				response.append(inputLine).append("\n");
			}
			bufferedReader.close();
		} catch (IOException e) {
			logger.warn("Cannot read file inputstream: " + inputStream.toString(), e);
		}
		return response.toString();
	}

	public static List<AdVerification> parseAdVerifications(Node node) {
		List<AdVerification> adVerifications = new ArrayList<>();
		for (int i = 0; i < node.getChildNodes().getLength(); i++) {
			Node childNode = node.getChildNodes().item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE && childNode.getNodeName().equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_VERIFICATION)) {
				AdVerification adVerification = new AdVerification();
				adVerification.parse((Element) childNode);
				adVerifications.add(adVerification);
			}
		}
		return adVerifications;
	}

	public static String getNodeAttributeValueFromElement(Element node, String attribute) {
		if (node == null) {
			return "";
		}
		return node.hasAttribute(attribute) ? node.getAttribute(attribute) : "";
	}

	public static Integer validPercentageOffset(String offsetString) {
		if (isBlank(offsetString)) {
			logger.warn("offsetString is blank.");
			return null;
		}
		Pattern pattern = Pattern.compile("(\\d+)%");
		Matcher matcher = pattern.matcher(offsetString);
		if (matcher.find()) {
			try {
				return Integer.parseInt(matcher.group(1));
			} catch (NumberFormatException e) {
				logger.warn("offset is malformed with value " + offsetString + ", the expected format is either HH:MM:SS(:mmm) or percentage%.");
				return null;
			}
		}
		return null;
	}

	public static Integer validSecondOffset(String offsetString) {
		if (isBlank(offsetString)) {
			logger.warn("offsetString is blank.");
			return null;
		}
		Pattern pattern = Pattern.compile("(\\d+):(\\d+):(\\d+)(.(\\d+))?");
		Matcher matcher = pattern.matcher(offsetString);
		if (matcher.find()) {
			try {
				int hh = Integer.parseInt(matcher.group(1));
				int mm = Integer.parseInt(matcher.group(2));
				int ss = Integer.parseInt(matcher.group(3));
				return hh * 3600 + mm * 60 + ss * 1;
			} catch (NumberFormatException e) {
				logger.warn("offset is malformed with value " + offsetString + ", the expected format is either HH:MM:SS(:mmm) or percentage%.");
				return null;
			}
		}
		return null;
	}

	public static int offsetPercentageToSecond(int percentage, double duration) {
		if (percentage == -1) {
			logger.warn("offset percentage is not valid.");
			return -1;
		}

		if (duration > 0) {
			return (int)(duration * percentage / 100);
		} else {
			logger.warn("duration is less than or equal to zero, so offset default to -1.");
			return -1;
		}
	}
}
