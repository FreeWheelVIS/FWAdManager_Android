package tv.freewheel.utils;

import java.util.Date;

// Notice this function use Date to Calculate elapse time, this may be change by user's device set
// If have related problem, maybe can change to android.os.SystemClock.elapsedRealtime
public class RecordTimer {
	private Date lastDate;
	private long record;
	private boolean paused;
	
	public RecordTimer() {
		this.lastDate = new Date();
		this.record = 0;
		this.paused = false;
	}
	
	public void pause() {
		if (this.paused) {
			return;
		}
		this.record = this.lastDate.getTime();
		this.lastDate = new Date();
		this.record = this.lastDate.getTime() - this.record;
		this.paused = true;
	}
	
	public void resume() {
		if (this.paused) {
			this.lastDate = new Date();
			this.paused = false;
		}
	}
	
	// return value will be seconds
	public long tick() {
		long ret;
		if (this.paused) {
			ret = this.record;
			this.record = 0;
		} else {
			ret = this.lastDate.getTime();
			this.lastDate = new Date();
			ret = this.lastDate.getTime() - ret;
			ret += this.record;
			this.record = 0;
		}
		return ret / 1000;
	}
}
