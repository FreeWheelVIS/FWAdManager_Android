package tv.freewheel.utils.http;

public class HttpConstants {
	public static final int DEFAULT_LOAD_TIMEOUT_SECOND = 20;
}
