package tv.freewheel.utils.handler;

import android.os.Handler;

import java.util.HashMap;

/**
 * Created by rvooda on 3/14/18.
 */

public class RepeatingHandler extends Handler {
	private HashMap <Runnable, Runnable> proxyRepeatedRunnablesMap = new HashMap<>();

	public final boolean postRepeated(final Runnable r, final long initialDelayInMillis, final long repeatIntervalInMillis) {
		final Runnable repeatingProxyRunnable = new Runnable() {
			@Override
			public void run() {
				try {
					r.run();
				} finally {
					// guarantee that this always happens, even if runnable throws exception
					synchronized(RepeatingHandler.this) {
						if (proxyRepeatedRunnablesMap.containsKey(r)) {
							RepeatingHandler.this.postDelayed(this, repeatIntervalInMillis);
						}
					}
				}
			}
		};
		synchronized(this) {
			this.proxyRepeatedRunnablesMap.put(r, repeatingProxyRunnable);
		}
		return this.postDelayed(repeatingProxyRunnable, initialDelayInMillis);
	}

	public final void removeRepeating(Runnable r) {
		if (this.proxyRepeatedRunnablesMap.containsKey(r)) {
			Runnable repeatingProxyRunnable = this.proxyRepeatedRunnablesMap.get(r);
			synchronized(this) {
				this.proxyRepeatedRunnablesMap.remove(r);
			}
			this.removeCallbacks(repeatingProxyRunnable);
		} else {
			super.removeCallbacks(r);
		}
	}
}
