package tv.freewheel.utils.URL;

import android.net.Uri;

import tv.freewheel.ad.InternalConstants;
import tv.freewheel.utils.FWOrderedHashMap;
import tv.freewheel.utils.StringUtils;

/**
 * Created by rvooda on 11/10/17.
 */

public class FWURL {
    private String urlString;
    public String baseUrlString;
    public FWOrderedHashMap<String, String> parameters;

    public FWURL(String urlString) {
        this.urlString = urlString;

        String[] mainParts = this.urlString.split("\\?", 2);
        this.baseUrlString = mainParts[0];
        this.parameters = new FWOrderedHashMap<>();

        if (this.baseUrlString.length() + 1 > urlString.length()) {
            return;
        }

        for (String queryPart : mainParts[1].split("&")) {
            String[] queryParts = queryPart.split("=", 2);
            if (queryParts.length < 1) {
                continue;
            }

            String decodedKey = Uri.decode(queryParts[0]);
            if (StringUtils.isBlank(decodedKey)) {
                continue;
            }
            String decodedValue = queryParts.length > 1 ? Uri.decode(queryParts[1]) : "";
            this.parameters.put(decodedKey, decodedValue);
        }
    }

    public void setParameter(String key, String value) {
        this.parameters.put(key, value);
        this.urlString = null; // To make sure that the url is constructed manually in toString() function
    }

    public String getParameter(String key) {
        return this.parameters.get(key);
    }

    @Override
    public String toString() {
        if (this.urlString != null) {
            return this.urlString;
        }

        if (StringUtils.isBlank(this.baseUrlString)) {
            return "";
        }

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.baseUrlString).append("?");

        String crValue = null;
        for (String key : this.parameters.keys) {
            String value = this.parameters.get(key);
            if (key.equalsIgnoreCase(InternalConstants.URL_PARAMETER_KEY_CR)) {
                crValue = value;
                continue;
            }
            stringBuilder.append(StringUtils.encodeURIComponent(key)).append("=").append(StringUtils.encodeURIComponent(value)).append("&");
        }

        // Append CR at the end
        if (crValue != null) {
            stringBuilder.append(InternalConstants.URL_PARAMETER_KEY_CR).append("=").append(StringUtils.encodeURIComponent(crValue));
        }

        this.urlString = stringBuilder.toString();

        return this.urlString;
    }
}
