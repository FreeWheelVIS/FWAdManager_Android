package tv.freewheel.utils;

public class URLRequest implements Cloneable {
	public String url;
	public String data;
	
	public String contentType;
	public Method method = Method.POST;
	public String userAgent;

	// delay before submitting request, in milliseconds
	public long delayMs = 0;
	
	public static final String CONTENT_TYPE_FORM_ENCODED = "application/x-www-form-urlencoded";
	public static final String CONTENT_TYPE_TEXT_PLAIN = "text/plain";
	public static final String CONTENT_TYPE_TEXT_XML = "text/xml";

	public enum Method {
		GET,
		POST
	}

	public URLRequest (final String url, String userAgent) {
		this.url = url;
		this.userAgent = userAgent;
	}

	public URLRequest(final String url, String userAgent, Method method, String contentType, String requestBody) {
		this.url = url;
		this.userAgent = userAgent;
		this.method = method;
		this.contentType = contentType;
		this.data = requestBody;
	}

	@Override
	public String toString() {
		return String.format("[URLRequest url:%s, method:%s, user agent: %s]", this.url, this.method == Method.POST ? "POST" : "GET", this.userAgent);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
