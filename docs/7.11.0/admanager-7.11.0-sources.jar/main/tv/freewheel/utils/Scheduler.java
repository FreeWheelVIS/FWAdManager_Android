package tv.freewheel.utils;

import android.os.Handler;
import android.os.Looper;

public class Scheduler {
	private final Handler scheduleHandler;
	private Runnable runnable;
	private Runnable runnableProxy;
	private RecordTimer recordTimer;
	private volatile long lastRunDuration;
	private long taskIntervalSeconds;
	private boolean paused;
	private static final Logger logger = Logger.getLogger(Scheduler.class);

	public Scheduler() {
		this.scheduleHandler = new Handler(Looper.getMainLooper());
		this.lastRunDuration = 0;
		this.paused = false;
	}

	public synchronized void setRunnable(Runnable runnable) {
		this.runnable = runnable;
	}

	private void clearRunnable() {
		if (this.runnableProxy != null) {
			this.scheduleHandler.removeCallbacks(runnableProxy);
		}
		this.runnableProxy = null;
	}

	private void scheduleRunnable(long delayInMilliSeconds) {
		this.runnableProxy = new Runnable() {
			@Override
			public void run() {
				synchronized (Scheduler.this) {
					if (recordTimer != null) {
						lastRunDuration = recordTimer.tick();
						runnable.run();
					}
				}
			}
		};
		this.scheduleHandler.postDelayed(runnableProxy, delayInMilliSeconds);
	}

	public synchronized void start(double intervalSeconds) {
		if (this.runnable == null) {
			logger.error("runnable set is null");
			return;
		}
		if (this.paused) {
			this.resume();
			return;
		}
		long intervalMilliSeconds = (long) (intervalSeconds * 1000);
		this.recordTimer = new RecordTimer();
		this.taskIntervalSeconds = (long) intervalSeconds;
		this.clearRunnable();

		this.scheduleRunnable(intervalMilliSeconds);
	}

	public synchronized void pause() {
		if (this.paused || this.runnable == null || this.recordTimer == null) {
			return;
		}
		this.paused = true;
		this.recordTimer.pause();
		this.clearRunnable();
		this.lastRunDuration = this.recordTimer.tick();
	}

	public synchronized void resume() {
		if (this.paused) {
			
			/* lock the thread to make sure the this.taskIntervalSeconds - this.lastRunDuration value
				won't be changed during the condition expression
			 */
			long delay = (this.taskIntervalSeconds - this.lastRunDuration < 0 ? 0 : this.taskIntervalSeconds - this.lastRunDuration) * 1000;

			this.recordTimer.resume();
			this.clearRunnable();
			this.scheduleRunnable(delay);
			this.paused = false;
		}
	}

	public synchronized void stop() {
		this.clearRunnable();
		this.recordTimer = null;
		this.lastRunDuration = 0;
		this.paused = false;
		this.runnable = null;
		this.taskIntervalSeconds = 0;
	}

	// return value will be seconds
	public synchronized long getLastRunDuration() {
		return this.lastRunDuration;
	}
}
