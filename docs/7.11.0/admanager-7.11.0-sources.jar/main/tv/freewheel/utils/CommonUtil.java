package tv.freewheel.utils;

import android.view.View;
import android.view.ViewParent;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

public class CommonUtil {
	private static final Logger logger = Logger.getLogger("StringUtils");

	public static String currentThreadIdentifier() {
		return	String.format("[0x%x]",android.os.Process.myTid());
	}

	public static Double convertVastDurationStringToSeconds(String str) {
		Double ret = -1.0;
		final String[] hms = str.split(":");
		if (hms.length == 3) {
			int hour = StringUtils.parseInt(hms[0], -1);
			int minute = StringUtils.parseInt(hms[1], -1);

			String[] secondStrings = hms[2].split("\\.");
			int second = StringUtils.parseInt(secondStrings[0], -1);

			if (hour == -1 || minute == -1 || second == -1) {
				return -1.0;
			} else {
				return (double) second + minute * 60 + hour * 60 * 60;
			}
		}
		return ret;
	}

	public static String secondsToHHMMSS(double seconds) {
		if (seconds <= 0) {
			return "00:00:00";
		}
		seconds=Math.round(seconds);
		int hours = (int) (seconds / 3600);
		int remainder = (int) (seconds % 3600);
		int minutes = remainder / 60;
		int secs = remainder % 60;
		return String.format("%02d:%02d:%02d", hours, minutes, secs);
	}

	public static String md5(final String s) {
		try {
			// Create MD5 Hash
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(s.getBytes());
			byte messageDigest[] = digest.digest();

			// Create Hex String
			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < messageDigest.length; i++) {
				String h = Integer.toHexString(0xFF & messageDigest[i]);
				while (h.length() < 2)
					h = "0" + h;
				hexString.append(h);
			}
			return hexString.toString();

		} catch (NoSuchAlgorithmException e) {
			logger.debug(e);
		}
		return "";
	}
	public static void appendQueryToMap(HashMap<String, String> map, String key, String value) {
		if (value == null || value.isEmpty())
			return;

		map.put(key, value);
	}

	public static void appendQueryToMap(HashMap<String, String> map, String key, double value) {
		map.put(key, Double.toString(value));
	}

	public static void appendQueryToMap(HashMap<String, String> map, String key, int value) {
		map.put(key, Integer.toString(value));
	}

	public static boolean viewHasComposeParent(View view) {
		ViewParent parent = view.getParent();
		while (parent != null) {
			if (parent.toString().contains("androidx.compose")) {
				return true;
			}
			parent = parent.getParent();
		}
		return false;
	}
}
