package tv.freewheel.utils;

import android.util.Pair;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

public class URIUtil {

	private static final Logger logger = Logger.getLogger(URIUtil.class);
	/**
	 * Try to fix the string with URI's own encode.
	 * @param input
	 * @return
	 */
	public static String getFixedString(String input) {
		if (input == null) {
			return null;
		}

		try {
			URL url = new URL(input);
			return new URI(url.getProtocol(),
					url.getAuthority(),
					url.getPath(),
					url.getQuery(),
					url.getRef()).toString();
		} catch (MalformedURLException | URISyntaxException e) {
			logger.debug(e);
			return null;
		}
	}

	public static List<Pair<String, String>> splitQuery(URI url) throws UnsupportedEncodingException {
		List<Pair<String, String>> query_pairs = new ArrayList<>();
		String query = url.getRawQuery();
		if (!StringUtils.isBlank(query)) {
			String[] pairs = query.split("&");
			for (String pair : pairs) {
				int idx = pair.indexOf("=");
				query_pairs.add(new Pair<>(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8")));
			}
		}
		return query_pairs;
	}
}
