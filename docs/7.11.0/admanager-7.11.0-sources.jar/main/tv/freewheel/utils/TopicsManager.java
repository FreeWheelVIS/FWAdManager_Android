package tv.freewheel.utils;

import android.adservices.topics.GetTopicsRequest;
import android.adservices.topics.GetTopicsResponse;
import android.content.Context;
import android.os.Build;
import android.os.OutcomeReceiver;
import android.os.ext.SdkExtensions;

import androidx.annotation.NonNull;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import tv.freewheel.ad.BuildConfig;

public class TopicsManager {

	private String topicsString = "";
	private static final Logger logger = Logger.getLogger(TopicsManager.class, true);
	private static final int MIN_SDK_EXTENSION_VERSION = 5;

	public TopicsManager(Context appContext) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SdkExtensions.getExtensionVersion(SdkExtensions.AD_SERVICES) >= MIN_SDK_EXTENSION_VERSION) {
			OutcomeReceiver mCallback = new OutcomeReceiver<GetTopicsResponse, Exception>() {
				@Override
				public void onResult(@NonNull GetTopicsResponse result) {
					if (result.getTopics().size() == 0) {
						logger.info("No topics returned");
						return;
					}

					topicsString = result.getTopics().stream()
							.map(topic -> String.format("android:%d:%d:%d", topic.getTaxonomyVersion(), topic.getModelVersion(), topic.getTopicId()))
							.collect(Collectors.joining(","));
					logger.debug("Topics string generated: " + topicsString);
				}

				@Override
				public void onError(@NonNull Exception error) {
					logger.warn("Experienced an error getting topics: " + error.getLocalizedMessage());
				}
			};

			try {
				android.adservices.topics.TopicsManager topicsManager = appContext.getSystemService(android.adservices.topics.TopicsManager.class);
				Executor mExecutor = Executors.newCachedThreadPool();
				GetTopicsRequest.Builder mTopicsRequestBuilder = new GetTopicsRequest.Builder();
				mTopicsRequestBuilder.setAdsSdkName(BuildConfig.LIBRARY_PACKAGE_NAME);
				mTopicsRequestBuilder.setShouldRecordObservation(true);
				topicsManager.getTopics(mTopicsRequestBuilder.build(), mExecutor, mCallback);
			} catch (Exception error) {
				logger.warn("Error getting TopicsManager: " + error.getLocalizedMessage());
			}
		} else {
			logger.warn("TopicsManager not supported by SDK/extension version");
		}
	}

	public String getTopicsString() {
		return topicsString;
	}
}
