package tv.freewheel.extension;

import tv.freewheel.ad.interfaces.IAdContext;

/**
 *	Interface for Player Extension Module. 
 */
public interface IExtension {
	/**
	 *	Initialize the extension with an IAdContext instance.
	 *	@param adContext	An IAdContext instance.
	 */
	void init(IAdContext adContext);

	/**
	 *	Dispose the extension when AdContext disposes.
	 */
	void stop();
}
