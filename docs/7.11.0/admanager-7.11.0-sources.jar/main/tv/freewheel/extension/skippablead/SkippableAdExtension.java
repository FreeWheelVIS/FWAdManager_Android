package tv.freewheel.extension.skippablead;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.R;
import tv.freewheel.ad.interfaces.IAdContext;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.extension.IExtension;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.renderer.ParamParser;

public class SkippableAdExtension implements IExtension {
	private IAdContext adContext;
	private AdInstance currentPlayingAd;
	private SkipButtonWebView skipButton;
	private IConstants constants;
	private static final Logger logger = Logger.getLogger(SkippableAdExtension.class);
	private Handler handler;
	private ParamParser paramParser;

	@Override
	public void init(IAdContext adContext) {
		logger.debug("init");
		this.adContext = adContext;
		this.adContext.addEventListener(Constants._EVENT_VIDEO_DISPLAY_BASE_CHANGED, onVideoDisplayBaseChanged);
		this.constants = adContext.getConstants();
		this.paramParser = new ParamParser(adContext, "");
		adContext.getActivity().runOnUiThread(this::prepareExtension);
	}

	public Activity getActivity() {
		return this.adContext.getActivity();
	}

	private int getPXHeightOfButton() {
		// -2 will WRAP_CONTENT which is equivalent to not setting it
		int PX_HEIGHT = -2;
		int height = paramParser.parseInt(constants.PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HEIGHT(), PX_HEIGHT);
		if (height != PX_HEIGHT) {
			return DisplayUtils.dpToPixel(getActivity().getApplicationContext(), height);
		}
		return height;
	}

	private int getPXWidthOfButton() {
		int PX_WIDTH = DisplayUtils.dpToPixel(getActivity().getApplicationContext(),80);
		int width = paramParser.parseInt(constants.PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_WIDTH(), PX_WIDTH);
		if (width != PX_WIDTH) {
			return DisplayUtils.dpToPixel(getActivity().getApplicationContext(), width);
		}
		return width;
	}

	private void onClick() {
		if (currentPlayingAd.getAdSkippableState()) {
			logger.debug("onClick");
			currentPlayingAd.getSlot().skipCurrentAd();
		}
	}

	private void pollForAdProgress() {
		logger.debug("pollForAdProgress");
		double playheadTime = currentPlayingAd.getPlayheadTime();
		int skipOffset = currentPlayingAd.getSkipOffset();
		long timeRemaining = Math.round(skipOffset - playheadTime);
		if (timeRemaining > 0 && skipButton != null) {
			skipButton.setText(Long.toString(timeRemaining));
			handler.postDelayed(this::pollForAdProgress, 1000);
		}
	}

	private void prepareExtension() {
		logger.debug("prepareExtension");
		handler = new Handler();
		adContext.addEventListener(constants.EVENT_AD_PREINIT(), onAdInitiated);
		String htmlStr = paramParser.parseString(constants.PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HTML(), "");
		if (!htmlStr.equals("")) {
			// Custom WebView html
			this.skipButton = new SkipButtonWebView(htmlStr, getActivity().getApplicationContext());
		} else {
			this.skipButton = new SkipButtonWebView(getActivity().getApplicationContext());
		}
		this.skipButton.setId(R.id.btn_fw_skip);
		this.skipButton.setVisibility(View.INVISIBLE);
		this.skipButton.setEnabled(false);

		FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
		layoutParams.rightMargin = 8;
		layoutParams.bottomMargin = 16;
		layoutParams.width = this.getPXWidthOfButton();
		layoutParams.height = this.getPXHeightOfButton();
		this.skipButton.setLayoutParams(layoutParams);
		skipButton.setBackgroundColor(Color.TRANSPARENT);
		((AdContext)adContext).getTemporalSlotBase().addView(this.skipButton);
	}

	@Override
	public void stop() {
		logger.debug("stop");
		if (adContext != null) {
			adContext.removeEventListener(constants.EVENT_AD_PREINIT(), onAdInitiated);
			adContext.removeEventListener(Constants._EVENT_VIDEO_DISPLAY_BASE_CHANGED, onVideoDisplayBaseChanged);
			((AdContext)adContext).getTemporalSlotBase().removeView(skipButton);
			adContext = null;
		}
		handler = null;
		skipButton = null;
	}

	IEventListener onAdInitiated = new IEventListener() {
		@Override
		public void run(IEvent event) {
			AdInstance adInstance = (AdInstance) event.getData().get(constants.INFO_KEY_ADINSTANCE());
			if (adInstance != null && adInstance.getSkipOffset() > -1) {
				logger.debug("onAdInitiated");
				adContext.addEventListener(constants.EVENT_AD_IMPRESSION(), onAdImpression);
				adContext.addEventListener(constants.EVENT_AD_SKIPPABLE_STATE_CHANGED(), onAdSkippableStateChanged);
				adContext.addEventListener(constants.EVENT_AD_IMPRESSION_END(), onAdEnded);
				adContext.addEventListener(constants.EVENT_ERROR(), onAdEnded);

				currentPlayingAd = adInstance;
				pollForAdProgress();
			}
		}
	};

	IEventListener onAdImpression = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("onAdImpression");
			skipButton.setOnClickListener(v -> onClick());
			skipButton.setOnTouchListener((v, evt) -> skipButton.performClick());
			skipButton.setEnabled(true);
			skipButton.bringToFront();
			skipButton.setVisibility(View.VISIBLE);
		}
	};

	IEventListener onAdSkippableStateChanged = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("onAdSkippableStateChanged");
			if (currentPlayingAd.getAdSkippableState()) {
				handler.removeCallbacksAndMessages(null);
				String buttonText = paramParser.parseString(constants.PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_TEXT(), "Skip Ad");
				skipButton.setClickable(true);
				skipButton.setText(buttonText);
			}
		}
	};

	IEventListener onAdEnded = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("onAdEnded");
			if (handler != null) {
				handler.removeCallbacksAndMessages(null);
			}
			skipButton.setEnabled(false);
			skipButton.setClickable(false);
			skipButton.setVisibility(View.INVISIBLE);
			skipButton.setOnTouchListener(null);
			skipButton.setOnClickListener(null);
			adContext.removeEventListener(constants.EVENT_AD_IMPRESSION(), onAdImpression);
			adContext.removeEventListener(constants.EVENT_AD_SKIPPABLE_STATE_CHANGED(), onAdSkippableStateChanged);
			adContext.removeEventListener(constants.EVENT_AD_IMPRESSION_END(), onAdEnded);
			adContext.removeEventListener(constants.EVENT_ERROR(), onAdEnded);
			currentPlayingAd = null;
		}
	};

	IEventListener onVideoDisplayBaseChanged = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("onVideoDisplayBaseChanged");
			FrameLayout videoDisplayBase = ((AdContext)adContext).getTemporalSlotBase();
			if (videoDisplayBase != null && skipButton != null) {
				((FrameLayout)skipButton.getParent()).removeView(skipButton);
				skipButton.setBackgroundColor(Color.TRANSPARENT);
				videoDisplayBase.addView(skipButton);
				skipButton.bringToFront();
			}
		}
	};
}
