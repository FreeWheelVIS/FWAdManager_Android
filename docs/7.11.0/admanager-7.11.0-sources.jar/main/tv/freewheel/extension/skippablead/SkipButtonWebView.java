package tv.freewheel.extension.skippablead;

import android.annotation.SuppressLint;
import android.content.Context;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import tv.freewheel.utils.Logger;

/**
 * Created by sfloam on 07/15/22.
 */

public class SkipButtonWebView extends WebView {
    private static final Logger logger = Logger.getLogger(SkipButtonWebView.class);
    private static final String DEFAULT_SKIP_BUTTON_HTML = "" +
            "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01//EN' 'http://www.w3.org/TR/html4/strict.dtd'>"+
            "<html><head><meta name='viewport' content='initial-scale=1.0' />" +
            "</head>"+
            "<body style='padding:0; margin:0; text-align:center'>"+
            "<button id='_fw_skip_button' style='background-color:#01020185; border:none; padding:8px; color:white; font-size:16px; text-align:center; text-decoration:none'>"+
            "</button>"+
            "</body></html>";

    public SkipButtonWebView(Context context) {
        this(DEFAULT_SKIP_BUTTON_HTML, context);
    }

    @SuppressLint("SetJavaScriptEnabled")
    public SkipButtonWebView(String htmlStr, Context context) {
        super(context);

        this.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                logger.debug("SkipButtonWebView console log: " + consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber() + " of "
                        + consoleMessage.sourceId());
                return super.onConsoleMessage(consoleMessage);
            }
        });
        this.getSettings().setAllowContentAccess(false);
        this.getSettings().setAllowFileAccess(false);
        this.getSettings().setAllowFileAccessFromFileURLs(false);
        this.getSettings().setAllowUniversalAccessFromFileURLs(false);
        this.getSettings().setJavaScriptEnabled(true);
        this.loadDataWithBaseURL(null, htmlStr, "text/html; charset=utf-8", "UTF-8", null);
    }

    public void setText(String text) {
        logger.debug("Setting the button text for the skip button: " + text);
        this.evaluateJavascript("document.getElementById(\"_fw_skip_button\").innerHTML=\"" + text + "\";", null);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
