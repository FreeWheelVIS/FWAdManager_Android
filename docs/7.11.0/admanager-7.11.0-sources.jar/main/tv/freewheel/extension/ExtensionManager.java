package tv.freewheel.extension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.AdContext;
import tv.freewheel.extension.pausead.PauseAdExtension;
import tv.freewheel.utils.Logger;

public class ExtensionManager {
	public static Map<String, Class<? extends IExtension>> extensions = Collections.synchronizedMap(new HashMap<String, Class<? extends IExtension> >());
	public static List<String> internalExtensions;
	private static final Logger logger;
	
	static {
		logger = Logger.getLogger("ExtensionManager");

		extensions.put("PauseAdExtension", PauseAdExtension.class);
		internalExtensions = new ArrayList<>();
		internalExtensions.add("PauseAdExtension");
	}
	
	public static void registerExtension(String name, Class<? extends IExtension> cls) {
		extensions.put(name,  cls);
	}
	
	public static void unregisterAdContext(AdContext adContext) {
		for (String name : adContext.loadedExtensions.keySet()) {
			IExtension ext = adContext.loadedExtensions.get(name);
			try {
				ext.stop();
			} catch (Exception e) {
				logger.warn("Exception happened when stop " + name);
			}
		}
		adContext.loadedExtensions.clear();
	}
	
	public static boolean hasExtensionLoaded(String extensionName) {
		return true;
	}
	
	public static IExtension loadExtension(String name, final AdContext context) throws IllegalAccessException, InstantiationException,ClassNotFoundException {
		Class<?> cls = extensions.get(name) != null ? extensions.get(name): Class.forName(name);
		if (cls == null) {
			logger.error("can not get extension class for name:" + name);
			return null;
		}
		
		IExtension ext = (IExtension)cls.newInstance();
		ext.init(context);
		context.loadedExtensions.put(name, ext);
		return ext;
	}
}
