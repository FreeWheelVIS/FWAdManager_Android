package tv.freewheel.extension.pausead;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import tv.freewheel.ad.interfaces.IAdContext;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.extension.IExtension;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.events.Event;
import tv.freewheel.utils.renderer.ParamParser;

public class PauseAdExtension implements IExtension {
	private IAdContext adContext;
	private IConstants constants;
	private static final Logger logger = Logger.getLogger(PauseAdExtension.class);
	private Boolean enabled;
	private String toBePlayedPauseSlotCustomId;
	private String currentPlayingPauseSlotCustomId;
	
	private Boolean needDispatchContentResumeEvent = false;
	private HashMap<String, ArrayList<String>> linearSlotToPauseSlotsMap;
	
	public void init(IAdContext adContext) {
		this.adContext = adContext;
		this.constants = adContext.getConstants();
		logger.debug("init");
		this.linearSlotToPauseSlotsMap = new HashMap<>();
		this.adContext.addEventListener(constants.EVENT_REQUEST_COMPLETE(), requestCompleteListener);
	}
	
	private IEventListener requestCompleteListener = new IEventListener(){
		public void run(final IEvent event) {
			if("false".equalsIgnoreCase((String)(event.getData().get(constants.INFO_KEY_SUCCESS())))) {
				logger.debug("RequestComplete: false, return.");
				return;
			}
			
			if (adContext == null) {
				// protection for the case that player may dispose adContext in requestComplete event handler
				return;
			}
			
			ParamParser paramParer = new ParamParser(adContext, "extension.pausead");
			enabled = paramParer.parseBoolean("enable", true);
			if(!enabled) {
				logger.debug("PauseAdExtension is not enabled, return.");
				return;
			}
			logger.debug("requestCompleteListener()");
			// map temporal slots to followed pause slots.
			List<ISlot> temporalSlots = adContext.getTemporalSlots();
			List<ISlot> pauseSlots = adContext.getSlotsByTimePositionClass(IConstants.TimePositionClass.PAUSE_MIDROLL);
			Iterator<ISlot> iter = temporalSlots.iterator();
			while(iter.hasNext()) {
				ISlot slot = iter.next();
				if(slot.getSlotTimePositionClass() == IConstants.TimePositionClass.PREROLL
					|| slot.getSlotTimePositionClass() == IConstants.TimePositionClass.MIDROLL) {
					ArrayList<String> followedPauseSlotIds = new ArrayList<String>(); 
					for(int i = 0; i < pauseSlots.size(); i++) {
						ISlot pauseSlot = pauseSlots.get(i);
						if(pauseSlot.getTimePosition() == slot.getTimePosition()) {
							followedPauseSlotIds.add(pauseSlot.getCustomId());
						}
					}
					if(!followedPauseSlotIds.isEmpty()) {
						linearSlotToPauseSlotsMap.put(slot.getCustomId(), followedPauseSlotIds);
					}
				}
			}
			
			iter = pauseSlots.iterator();
			while(iter.hasNext()) {
				ISlot slot = iter.next();
				if(slot.getTimePosition() == 0) {
					toBePlayedPauseSlotCustomId = slot.getCustomId();
					break;
				}
			}
			logger.debug("toBePlayedPauseSlotCustomId:" + toBePlayedPauseSlotCustomId);
			adContext.addEventListener(constants.EVENT_USER_ACTION_NOTIFIED(), userActionNotified);
			adContext.addEventListener(constants.EVENT_SLOT_STARTED(), slotStartedListener);
			adContext.addEventListener(constants.EVENT_SLOT_ENDED(), slotEndedListener);
			adContext.addEventListener(constants.EVENT_AD_IMPRESSION(), adImpressionListener);
			adContext.addEventListener(constants.EVENT_ERROR(), adErrorListener);
		}
	};
	
	private IEventListener userActionNotified = new IEventListener(){
		public void run(final IEvent event) {
			IConstants.UserAction userAction = (IConstants.UserAction) event.getData().get(constants.INFO_KEY_USER_TRIGGERED_ACTION());
			switch (userAction) {
				case PauseButtonClicked:
					logger.debug("pauseButtonClicked");
					if(toBePlayedPauseSlotCustomId != null) {
						ISlot slot = adContext.getSlotByCustomId(toBePlayedPauseSlotCustomId);
						if(slot != null) {
							logger.debug("play slot:" + toBePlayedPauseSlotCustomId);
							slot.play();
						}
					}
					break;
				case ResumeButtonClicked:
					logger.debug("resumeButtonClicked");
					if(currentPlayingPauseSlotCustomId != null) {
						ISlot slot = adContext.getSlotByCustomId(currentPlayingPauseSlotCustomId);
						if(slot != null) {
							logger.debug("stop slot:" + currentPlayingPauseSlotCustomId);
							needDispatchContentResumeEvent = false; // for event from player, shouldn't dispatch this event.
							currentPlayingPauseSlotCustomId = null; // to avoid a rare case: AdImpression is dispatched before slotEnded event
							slot.stop();
						}
					}
					break;
			}
		}
	};
	
	private IEventListener slotStartedListener = new IEventListener(){
		public void run(final IEvent event) {
			logger.debug("slotStartedListener");
			ISlot slot = adContext.getSlotByCustomId((String)(event.getData().get(constants.INFO_KEY_SLOT_CUSTOM_ID())));
			if(linearSlotToPauseSlotsMap.containsKey(slot.getCustomId())) {
				ArrayList<String> followedPauseSlotIds = linearSlotToPauseSlotsMap.get(slot.getCustomId());
				toBePlayedPauseSlotCustomId = followedPauseSlotIds.get((int)Math.floor(Math.random() * followedPauseSlotIds.size()));
				logger.debug("slotStartedListener, toBePlayedPauseSlotCustomId:" + toBePlayedPauseSlotCustomId);
			} else if(slot.getSlotTimePositionClass() == IConstants.TimePositionClass.PAUSE_MIDROLL) {
				currentPlayingPauseSlotCustomId = slot.getCustomId();
				logger.debug("slotStartedListener, currentPlayingPauseSlotCustomId:" + currentPlayingPauseSlotCustomId);
			}
		}
	};
	
	private IEventListener slotEndedListener = new IEventListener(){
		public void run(final IEvent event) {
			logger.debug("slotEndedListener");
			if(needDispatchContentResumeEvent && isEventFromCurrentPlayingPauseSlot(event)) {
				logger.debug("slotEndedListener, post EVENT_REQUEST_CONTENT_VIDEO_RESUME");
				HashMap<String, Object> data = new HashMap<String, Object>();
				data.put(constants.INFO_KEY_MESSAGE(), toBePlayedPauseSlotCustomId);
				data.put(constants.INFO_KEY_SLOT_CUSTOM_ID(), toBePlayedPauseSlotCustomId);
				adContext.dispatchEvent(new Event(constants.EVENT_REQUEST_CONTENT_VIDEO_RESUME(), data));
				needDispatchContentResumeEvent = false;
				currentPlayingPauseSlotCustomId = null;
			}
		}
	};
	
	private IEventListener adImpressionListener = new IEventListener(){
		public void run(final IEvent event) {
			logger.debug("adImpressionListener");
			if(isEventFromCurrentPlayingPauseSlot(event)) {
				logger.debug("adImpressionListener, ad played successfully");
				needDispatchContentResumeEvent = true;
			}
		}
	};
	
	private IEventListener adErrorListener = new IEventListener(){
		public void run(final IEvent event) {
			logger.debug("adErrorListener");
			if(isEventFromCurrentPlayingPauseSlot(event)) {
				logger.debug("adErrorListener, ad failed");
				needDispatchContentResumeEvent = false;
			}
		}
	};
	
	private Boolean isEventFromCurrentPlayingPauseSlot(IEvent event) {
		return currentPlayingPauseSlotCustomId != null
				&& currentPlayingPauseSlotCustomId.equals(event.getData().get(constants.INFO_KEY_SLOT_CUSTOM_ID()));
	}
	
	public IAdContext getAdContext() {
		return this.adContext;
	}

	public void stop() {
		logger.debug("stop");
		if(this.adContext != null) {
			this.adContext.removeEventListener(constants.EVENT_REQUEST_COMPLETE(), requestCompleteListener);
			this.adContext.removeEventListener(constants.EVENT_USER_ACTION_NOTIFIED(), userActionNotified);
			this.adContext.removeEventListener(constants.EVENT_SLOT_STARTED(), slotStartedListener);
			this.adContext.removeEventListener(constants.EVENT_SLOT_ENDED(), slotEndedListener);
			this.adContext.removeEventListener(constants.EVENT_AD_IMPRESSION(), adImpressionListener);
			this.adContext.removeEventListener(constants.EVENT_ERROR(), adErrorListener);
			this.adContext = null;
		}
	}
}
