package tv.freewheel.extension.openmeasurement;

public class OpenMeasurementConstants {
	public static final String EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION		= "omsdk_friendlyObstruction_update";
	public static final String INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_CONFIG		= "omsdk_friendlyObstruction_config";
	public static final String INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_REMOVE		= "omsdk_friendlyObstruction_remove";
}
