package tv.freewheel.extension.openmeasurement;

import android.os.Handler;
import android.view.View;

import com.iab.omid.library.freewheeltv.Omid;
import com.iab.omid.library.freewheeltv.adsession.AdEvents;
import com.iab.omid.library.freewheeltv.adsession.AdSession;
import com.iab.omid.library.freewheeltv.adsession.AdSessionConfiguration;
import com.iab.omid.library.freewheeltv.adsession.AdSessionContext;
import com.iab.omid.library.freewheeltv.adsession.CreativeType;
import com.iab.omid.library.freewheeltv.adsession.ErrorType;
import com.iab.omid.library.freewheeltv.adsession.ImpressionType;
import com.iab.omid.library.freewheeltv.adsession.Owner;
import com.iab.omid.library.freewheeltv.adsession.Partner;
import com.iab.omid.library.freewheeltv.adsession.VerificationScriptResource;
import com.iab.omid.library.freewheeltv.adsession.media.InteractionType;
import com.iab.omid.library.freewheeltv.adsession.media.PlayerState;
import com.iab.omid.library.freewheeltv.adsession.media.Position;
import com.iab.omid.library.freewheeltv.adsession.media.VastProperties;
import com.iab.omid.library.freewheeltv.adsession.media.MediaEvents;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.AdVerification;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IAdContext;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.extension.IExtension;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.vast.model.AdVerificationResource;
import tv.freewheel.utils.Logger;

public class OpenMeasurementExtension implements IExtension {
	private IAdContext adContext;
	private static final Logger logger = Logger.getLogger(OpenMeasurementExtension.class);
	private IConstants constants;
	private Owner mediaEventsOwner;
	private HashMap<AdInstance, AdSessionWrapper> adSessionMap;

	private final List<String> TEMPORAL_AD_RENDERERS = Arrays.asList(new String[]{
			"class://tv.freewheel.renderers.temporal.VideoRenderer",
			"class://tv.freewheel.renderers.temporal.VPAIDRenderer",
			"class://tv.freewheel.renderers.temporal.CustomPlayerRenderer",
			"class://tv.freewheel.renderers.temporal.SIMIDRenderer"
	});

	private class AdSessionWrapper {
		private AdInstance adInstance;
		private AdSession adSession;
		private AdEvents adEvents;
		private boolean impressionFired = false;
		private MediaEvents mediaEvents;
		private View adView;

		private AdSessionWrapper(AdInstance adInstance, List<VerificationScriptResource> verificationScriptResources) {
			this.adInstance = adInstance;
			createAdSession(verificationScriptResources);
			createAdEvents();
			createMediaEvents();
		}

		private void createAdEvents() {
			if (adSession != null) {
				this.adEvents = AdEvents.createAdEvents(adSession);
			}
		}

		private void createMediaEvents() {
			if (adSession != null && mediaEventsOwner == Owner.NATIVE) {
				this.mediaEvents = MediaEvents.createMediaEvents(adSession);
			}
		}

		private void registerAdView(View view) {
			if (view == null) {
				logger.warn("The ad view of current renderer is empty.");
				return;
			}
			if (view != adView) {
				adView = view;
				logger.debug("Registering ad view: " + adView);
				adSession.registerAdView(view);
			}
		}

		private void createAdSession(List<VerificationScriptResource> verificationScriptResources) {
			AdSessionConfiguration adSessionConfiguration;
			String renderer = adInstance.renderer.getClass().toString();
			CreativeType creativeType;
			if (renderer.contains("ImageRenderer")) {
				creativeType = CreativeType.NATIVE_DISPLAY;
				mediaEventsOwner = Owner.NONE;
			} else if (renderer.contains("HTMLRenderer")) {
				creativeType = CreativeType.HTML_DISPLAY;
				mediaEventsOwner = Owner.NONE;
			} else {
				creativeType = CreativeType.VIDEO;;
				mediaEventsOwner = Owner.NATIVE;
			}

			adSessionConfiguration = AdSessionConfiguration.createAdSessionConfiguration(
					creativeType, ImpressionType.BEGIN_TO_RENDER, Owner.NATIVE, mediaEventsOwner, false);

			Partner partner = Partner.createPartner(InternalConstants.OMSDK_PARTNER_NAME, adContext.getAdManager().getOMSDKPartnerVersion());
			AdSessionContext adSessionContext = AdSessionContext.createNativeAdSessionContext(
					partner, OpenMeasurementJS.OMSDK_JS, verificationScriptResources, null, null);

			this.adSession = AdSession.createAdSession(adSessionConfiguration, adSessionContext);
		}

		private void finish() {
			adInstance  = null;
			adEvents = null;
			mediaEvents = null;
			adView = null;
			adSession.removeAllFriendlyObstructions();
			adSession.finish();
			adSession = null;
			impressionFired = false;
		}
	}

	@Override
	public void init(IAdContext adContext) {
		this.adContext = adContext;
		this.constants = adContext.getConstants();
		logger.debug("init");
		this.adSessionMap = new HashMap<>();
		this.adContext.addEventListener(constants.EVENT_REQUEST_COMPLETE(), requestCompleteListener);
	}

	IEventListener requestCompleteListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("requestComplete");
			if ("false".equalsIgnoreCase((String) (event.getData().get(constants.INFO_KEY_SUCCESS())))) {
				logger.debug("RequestComplete: false, return.");
				return;
			}

			if (adContext == null || adContext.getActivity() == null) {
				logger.warn("activity is invalid, can not initialize OMSDK");
				return;
			}

			// Check for OMID compatibility and library activation
			try {
				Omid.activate(adContext.getActivity().getApplicationContext());
				if (!Omid.isActive()) {
					logger.warn("OM SDK failed to activate");
					return;
				}
				Omid.updateLastActivity();
			} catch (IllegalArgumentException e) {
				logger.warn("Invalid OM SDK version number", e);
				return;
			}

			adContext.addEventListener(OpenMeasurementConstants.EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION, updateFriendlyObstructionListener);
			adContext.addEventListener(constants.EVENT_AD_PREINIT(), adPreInitListener);
			adContext.addEventListener(constants.EVENT_ERROR(), errorEventListener);
			adContext.addEventListener(constants.EVENT_AD_LOADED(), adEventListener);
			adContext.addEventListener(constants.EVENT_AD_IMPRESSION(), adEventListener);
			adContext.addEventListener(constants.EVENT_AD_IMPRESSION_END(), adEventListener);
			adContext.addEventListener(constants.EVENT_VIDEO_DISPLAY_BASE_CHANGED(), adEventListener);
			adContext.addEventListener(constants.EVENT_AD_FIRST_QUARTILE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_MIDPOINT(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_THIRD_QUARTILE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_COMPLETE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_PAUSE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_RESUME(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_BUFFERING_START(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_BUFFERING_END(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_EXPAND(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_COLLAPSE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_MINIMIZE(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_VOLUME_CHANGED(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_CLICK(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_ACCEPT_INVITATION(), mediaEventListener);
			adContext.addEventListener(constants.EVENT_AD_SKIPPED_BY_USER(), mediaEventListener);
			adContext.addEventListener(constants.IAB_OMSDK_UPDATE_LAST_ACTIVITY(), updateOMSDKLastActivityListener);

		}
	};

	IEventListener updateOMSDKLastActivityListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("updateOMSDKLastActivityListener");
			try {
				Omid.updateLastActivity();
			} catch (IllegalArgumentException e) {
				logger.warn("updateLastActivity() called before OMSDK activated, " + e.getMessage());
			}

		}
	};

	IEventListener updateFriendlyObstructionListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("updateFriendlyObstructionListener");
			AdInstance adInstance = (AdInstance) event.getData().get(constants.INFO_KEY_ADINSTANCE());
			if (adSessionMap.containsKey(adInstance)) {
				AdSessionWrapper adSessionWrapper = adSessionMap.get(adInstance);
				AdSession adSession = adSessionWrapper.adSession;
				FWOMSDKFriendlyObstructionConfiguration config = (FWOMSDKFriendlyObstructionConfiguration) event.getData().get(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_CONFIG);
				Boolean isRemoving = (Boolean) event.getData().get(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_REMOVE);
				try {
					if (isRemoving) {
						adSession.removeFriendlyObstruction(config.getView());
					} else {
						adSession.addFriendlyObstruction(config.getView(), config.getPurpose(), config.getDetailedReason());
					}
				} catch (IllegalArgumentException e) {
					logger.debug("Error:" + e.getMessage());
				}
			}
		}
	};

	private boolean isTranslator (IRenderer renderer) {
		return renderer.getClass().getName().equalsIgnoreCase("tv.freewheel.renderers.vast.VastTranslator");
	}

	IEventListener adPreInitListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("adPreInitListener");
			AdInstance adInstance = (AdInstance) event.getData().get(constants.INFO_KEY_ADINSTANCE());
			if (adInstance.renderer != null && !isTranslator(adInstance.renderer)) {
				createAdSession((AdInstance) event.getData().get(constants.INFO_KEY_ADINSTANCE()));
			}
		}
	};

	// Ad Tracking Events
	IEventListener adEventListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("adEventListener: " + event.getType());
			String eventType = event.getType();
			AdSessionWrapper adSessionWrapper = getAdSessionWrapperByEvent(event);
			if (adSessionWrapper == null) {
				logger.warn("adSessionWrapper is null when get ad event: " + event.getType());
				return;
			}
			try {
				switch (eventType) {
					case Constants._EVENT_AD_LOADED:
						onAdLoaded(adSessionWrapper);
						break;
					case Constants._EVENT_AD_IMPRESSION:
						onDefaultImpression(adSessionWrapper);
						break;
					case Constants._EVENT_AD_IMPRESSION_END:
						finishAdSession(adSessionWrapper);
						break;
					case Constants._EVENT_VIDEO_DISPLAY_BASE_CHANGED:
						onVideoDisplayBaseChanged(adSessionWrapper);
						break;
				}
			} catch (Exception e) {
				logger.warn("Ad Event not fired because Exception: " + e.getLocalizedMessage(), e);
			}
		}
	};

	private void onAdLoaded(AdSessionWrapper adSessionWrapper) {
		AdInstance adInstance = adSessionWrapper.adInstance;
		IRenderer renderer = adSessionWrapper.adInstance.renderer;

		adSessionWrapper.registerAdView(renderer.getAdView());
		IConstants.TimePositionClass timePositionClass = adInstance.getSlot().getSlotTimePositionClass();
		Position position;
		if (timePositionClass == IConstants.TimePositionClass.PREROLL) {
			position = Position.PREROLL;
		} else if (timePositionClass == IConstants.TimePositionClass.MIDROLL) {
			position = Position.MIDROLL;
		} else if (timePositionClass == IConstants.TimePositionClass.POSTROLL) {
			position = Position.POSTROLL;
		} else {
			position = Position.STANDALONE;
		}
		IConstants.VideoAssetAutoPlayType autoPlayType = ((AdContext) adContext).getAutoplayType();
		boolean isAutoPlay = autoPlayType != IConstants.VideoAssetAutoPlayType.NONE && autoPlayType != IConstants.VideoAssetAutoPlayType.CLICK_TO_PLAY;
		if (adInstance.getSkipOffset() > -1) {
			adSessionWrapper.adEvents.loaded(VastProperties.createVastPropertiesForSkippableMedia(adInstance.getSkipOffset(), isAutoPlay, position));
		} else {
			adSessionWrapper.adEvents.loaded(VastProperties.createVastPropertiesForNonSkippableMedia(isAutoPlay, position));
		}
	}

	private void onDefaultImpression(AdSessionWrapper adSessionWrapper) {
		IRenderer renderer = adSessionWrapper.adInstance.renderer;
		if (renderer != null) {
			adSessionWrapper.registerAdView(renderer.getAdView());
			if (renderer.getFriendlyObstructions() != null) {
				for (FWOMSDKFriendlyObstructionConfiguration config : renderer.getFriendlyObstructions()) {
					try {
						adSessionWrapper.adSession.addFriendlyObstruction(config.getView(), config.getPurpose(), config.getDetailedReason());
					} catch (IllegalArgumentException e) {
						logger.warn("Got exception on calling addFriendlyObstruction on adSession: " + e.getMessage());
					}
				}
			} else {
				logger.warn("No friendly obstruction views are registered by the renderer.");
			}
		} else {
			logger.warn("Renderer null");
		}

		for (FWOMSDKFriendlyObstructionConfiguration config : ((AdContext) adContext).getFriendlyObstructions()) {
			try {
				adSessionWrapper.adSession.addFriendlyObstruction(config.getView(), config.getPurpose(), config.getDetailedReason());
			} catch (IllegalArgumentException e) {
				logger.warn("Got exception on calling addFriendlyObstruction on context: " + e.getMessage());
			}
		}
		new Handler().postDelayed(() -> {
			try {
				adSessionWrapper.adEvents.impressionOccurred();
				adSessionWrapper.impressionFired = true;
				logger.debug(String.format("AdSession: %s fired impression.", adSessionWrapper.adSession.getAdSessionId()));
				if (adSessionWrapper.mediaEvents != null) {
					adSessionWrapper.mediaEvents.start((float) adSessionWrapper.adInstance.getDuration(), adContext.getAdVolume());
				}
			} catch (Exception e) {
				logger.warn("Got exception on firing impression event: " + e.getMessage());
			}
		}, 500);
	}

	private void onVideoDisplayBaseChanged(AdSessionWrapper adSessionWrapper) {
		IRenderer renderer = adSessionWrapper.adInstance.renderer;
		if (renderer != null) {
			adSessionWrapper.registerAdView(renderer.getAdView());
			logger.debug(String.format("AdSession: %s AdView updated on VideoDisplayBaseChanged.", adSessionWrapper.adSession.getAdSessionId()));
		} else {
			logger.warn("Renderer null on VideoDisplayBaseChanged.");
		}
	}

	// Media events tracking
	IEventListener mediaEventListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("mediaEventListener: " + event.getType());
			String eventType = event.getType();
			HashMap<String, Object> eventData = event.getData();
			AdSessionWrapper adSessionWrapper = getAdSessionWrapperByEvent(event);
			if (adSessionWrapper == null) {
				logger.warn("adSessionWrapper is null when get media event: " + event.getType());
				return;
			}
			if (adSessionWrapper.mediaEvents == null) {
				logger.warn(String.format("media event %s is fired for display ad", event.getType()));
				return;
			}
			try {
				switch (eventType) {
					case Constants._EVENT_AD_FIRST_QUARTILE:
						adSessionWrapper.mediaEvents.firstQuartile();
						break;
					case Constants._EVENT_AD_MIDPOINT:
						adSessionWrapper.mediaEvents.midpoint();
						break;
					case Constants._EVENT_AD_THIRD_QUARTILE:
						adSessionWrapper.mediaEvents.thirdQuartile();
						break;
					case Constants._EVENT_AD_COMPLETE:
						adSessionWrapper.mediaEvents.complete();
						break;
					case Constants._EVENT_AD_PAUSE:
						adSessionWrapper.mediaEvents.pause();
						break;
					case Constants._EVENT_AD_RESUME:
						adSessionWrapper.mediaEvents.resume();
						break;
					case Constants._EVENT_AD_BUFFERING_START:
						adSessionWrapper.mediaEvents.bufferStart();
						break;
					case Constants._EVENT_AD_BUFFERING_END:
						adSessionWrapper.mediaEvents.bufferFinish();
						break;
					case Constants._EVENT_AD_VOLUME_CHANGED:
						adSessionWrapper.mediaEvents.volumeChange((float) eventData.get(constants.INFO_KEY_VOLUME()));
						break;
					case Constants._EVENT_AD_CLICK:
						adSessionWrapper.mediaEvents.adUserInteraction(InteractionType.CLICK);
						break;
					case Constants._EVENT_AD_ACCEPT_INVITATION:
						adSessionWrapper.mediaEvents.adUserInteraction(InteractionType.INVITATION_ACCEPTED);
						break;
					case Constants._EVENT_AD_MINIMIZE:
						adSessionWrapper.mediaEvents.playerStateChange(PlayerState.MINIMIZED);
						break;
					case Constants._EVENT_AD_EXPAND:
						adSessionWrapper.mediaEvents.playerStateChange(PlayerState.EXPANDED);
						break;
					case Constants._EVENT_AD_COLLAPSE:
						adSessionWrapper.mediaEvents.playerStateChange(PlayerState.COLLAPSED);
						break;
					case Constants._EVENT_AD_SKIPPED_BY_USER:
						adSessionWrapper.mediaEvents.skipped();
						break;
				}
			} catch (Exception e) {
				logger.warn("Media Event not fired because Exception: " + e, e);
			}
		}
	};

	IEventListener errorEventListener = new IEventListener() {
		@Override
		public void run(IEvent event) {
			logger.debug("errorEventListener");
			HashMap<String, Object> errorData = event.getData();
			final AdSessionWrapper adSessionWrapper = getAdSessionWrapperByEvent(event);
			try {
				if (adSessionWrapper != null) {
					if (TEMPORAL_AD_RENDERERS.contains(errorData.get(((Constants) constants).INFO_KEY_ERROR_MODULE()))) {
						logger.debug("Reporting VIDEO error to omsdk. Error code: " + errorData.get(constants.INFO_KEY_ERROR_CODE()) +
								", Module: " + errorData.get(constants.INFO_KEY_MODULE_NAME()) +
								", Info: " + errorData.get(constants.INFO_KEY_ERROR_INFO()));
						adSessionWrapper.adSession.error(ErrorType.VIDEO, errorData.get(constants.INFO_KEY_ERROR_INFO()).toString());
					} else {
						logger.debug("Reporting GENERIC error to omsdk. Error code: " + errorData.get(constants.INFO_KEY_ERROR_CODE()) +
								", Module: " + errorData.get(constants.INFO_KEY_MODULE_NAME()) +
								", Info: " + errorData.get(constants.INFO_KEY_ERROR_INFO()));
						adSessionWrapper.adSession.error(ErrorType.GENERIC, errorData.get(constants.INFO_KEY_ERROR_INFO()).toString());
					}
				} else {
					logger.debug("cannot find ad session");
				}
			} catch (Exception exception) {
				logger.error("Cannot report error to omsdk.", exception);
			}
			if (adSessionWrapper != null) {
				finishAdSession(adSessionWrapper);
			}
		}
	};

	@Override
	public void stop() {
		logger.debug("stop");
		if (adContext != null) {
			adContext.removeEventListener(constants.EVENT_REQUEST_COMPLETE(), requestCompleteListener);
			adContext.removeEventListener(OpenMeasurementConstants.EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION, updateFriendlyObstructionListener);
			adContext.removeEventListener(constants.EVENT_AD_PREINIT(), adPreInitListener);
			adContext.removeEventListener(constants.EVENT_AD_LOADED(), adEventListener);
			adContext.removeEventListener(constants.EVENT_AD_IMPRESSION(), adEventListener);
			adContext.removeEventListener(constants.EVENT_AD_IMPRESSION_END(), adEventListener);
			adContext.removeEventListener(constants.EVENT_ERROR(), errorEventListener);
			adContext.removeEventListener(constants.EVENT_AD_FIRST_QUARTILE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_MIDPOINT(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_THIRD_QUARTILE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_COMPLETE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_PAUSE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_RESUME(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_BUFFERING_START(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_BUFFERING_END(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_EXPAND(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_COLLAPSE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_MINIMIZE(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_VOLUME_CHANGED(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_CLICK(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_ACCEPT_INVITATION(), mediaEventListener);
			adContext.removeEventListener(constants.EVENT_AD_SKIPPED_BY_USER(), mediaEventListener);
		}
		for (AdSessionWrapper adSessionWrapper: adSessionMap.values()) {
			finishAdSession(adSessionWrapper);
		}
	}

	private void createAdSession(AdInstance adInstance) {
		logger.debug("createAdSession");
		// check if adSession already exist
		if (adSessionMap.containsKey(adInstance)) {
			try {
				adSessionMap.get(adInstance).finish();
				adSessionMap.remove(adInstance);
			} catch (IllegalStateException e) {
				logger.verbose("AdSession already finished");
			}
		}
		List<AdVerification> adVerifications = adInstance.getAdVerifications();
		List<VerificationScriptResource> verificationScriptResources = new ArrayList<>();

		int sizeOfVerificationScriptResources = 0;
		for (AdVerification adVerification : adVerifications) {
			ArrayList<AdVerificationResource> adVerificationResources = new ArrayList<>();
			adVerificationResources.addAll(adVerification.getJavaScriptResources());
			adVerificationResources.addAll(adVerification.getExecutableResources());
			String verificationParameters = adVerification.getVerificationParameters();
			String vendorKey = adVerification.getVendorKey();
			for (AdVerificationResource resource : adVerificationResources) {
				try {
					URL url = new URL(resource.getResourceURL());
					VerificationScriptResource verificationScriptResource;
					if (verificationParameters == null || verificationParameters.length() == 0) {
						verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithoutParameters(url);
					} else {
						verificationScriptResource = VerificationScriptResource.createVerificationScriptResourceWithParameters(vendorKey, url, verificationParameters);
					}
					verificationScriptResources.add(verificationScriptResource);
				} catch (MalformedURLException error) {
					logger.error("failed to parse adVerification due to malformed url exception: " + error.getLocalizedMessage());
					continue;
				} catch (IllegalArgumentException error) {
					logger.warn("Got illegal argument exception when creating a VerificationScriptResource with message: " + error.getLocalizedMessage());
					continue;
				} catch (Exception error) {
					logger.warn("An error occurred when creating a VerificationScriptResource with message: " + error.getLocalizedMessage());
					continue;
				}
			}

			/*
			If the number of VerificationScriptResources does not change, this implies that the AdVerification
			did not add any new VerificationScriptResources to the combined list of VerificationScriptResources.
			Thus, no VerificationScriptResource for that AdVerification would load. As a result, we should call
			adVerification.dispatchVerificationNotExecutedCallback(context, VERIFICATION_RESOURCE_LOAD_ERROR).
			*/
			boolean wereVerificationScriptResourcesAdded = verificationScriptResources.size() > sizeOfVerificationScriptResources;
			if (!wereVerificationScriptResourcesAdded) {
				adVerification.dispatchVerificationNotExecutedCallback((AdContext) adContext, AdVerification.VerificationNotExecutedReason.VERIFICATION_RESOURCE_LOAD_ERROR);
			}
			sizeOfVerificationScriptResources = verificationScriptResources.size();
		}
		AdSessionWrapper adSessionWrapper = new AdSessionWrapper(adInstance, verificationScriptResources);
		adSessionMap.put(adInstance, adSessionWrapper);
		adSessionWrapper.adSession.start();
	}

	private void finishAdSession(AdSessionWrapper adSessionWrapper) {
		adSessionMap.remove(adSessionWrapper.adInstance);
		if (adSessionWrapper.impressionFired == true) {
			try {
				adSessionWrapper.finish();
			} catch (Exception e) {
				logger.warn("Exception thrown when calling adSessionWrapper.finish(): " + e.getMessage());
			}
		} else {
			new Handler().postDelayed(() -> {
				try {
					adSessionWrapper.finish();
				} catch (Exception e) {
					logger.warn("Exception thrown when calling adSessionWrapper.finish(): " + e.getMessage());
				}
			}, 500);
		}
	}

	private AdSessionWrapper getAdSessionWrapperByEvent(IEvent event) {
		AdSessionWrapper ret = null;

		boolean isAdInstanceDataInEvent = event.getData().containsKey(constants.INFO_KEY_ADINSTANCE());
		boolean isAdInstanceLinkedToSession = adSessionMap.containsKey(event.getData().get(constants.INFO_KEY_ADINSTANCE()));
		if (isAdInstanceDataInEvent && isAdInstanceLinkedToSession) {
			ret = adSessionMap.get(event.getData().get(constants.INFO_KEY_ADINSTANCE()));
		}
		return ret;
	}
}
