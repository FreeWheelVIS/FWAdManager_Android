package tv.freewheel.extension.openmeasurement;

import android.view.View;

import com.iab.omid.library.freewheeltv.adsession.FriendlyObstructionPurpose;

import tv.freewheel.ad.interfaces.IConstants;

/**
 *	A configuration object for registering friendly obstructions with OMSDK.
 */
public class FWOMSDKFriendlyObstructionConfiguration {
	private View view;
	private FriendlyObstructionPurpose purpose;
	private String detailedReason;

	/**
	 *	@param view	The View to be excluded from all ad session viewability calculations.
	 *	@param purpose	An IConstants.FWFriendlyObstructionPurpose for why this obstruction was necessary.
	 *	@param detailedReason A String explanation for why this obstruction is part of the ad experience if not already obvious from the FWFriendlyObstructionPurpose selected. Must be 50 characters or less and only contain characters `A-z`,`0-9` or space.
	 */
	public FWOMSDKFriendlyObstructionConfiguration(View view, IConstants.FWFriendlyObstructionPurpose purpose, String detailedReason) {
		this.view = view;
		this.detailedReason = detailedReason;
		switch (purpose) {
			case VIDEO_CONTROLS:
				this.purpose = FriendlyObstructionPurpose.VIDEO_CONTROLS;
				break;
			case CLOSE_AD:
				this.purpose = FriendlyObstructionPurpose.CLOSE_AD;
				break;
			case NOT_VISIBLE:
				this.purpose = FriendlyObstructionPurpose.NOT_VISIBLE;
				break;
			default:
				this.purpose = FriendlyObstructionPurpose.OTHER;
				break;
		}
	}

	/**
	 * Get the View to be excluded from all ad session viewability calculations.
	 *
	 *  @return the View used to instantiate the FWOMSDKFriendlyObstructionConfiguration.
	 */
	public View getView() {
		return view;
	}

	/**
	 * Get the purpose for why this obstruction was necessary.
	 *
	 *  @return the IConstants.FWFriendlyObstructionPurpose used to instantiate the FWOMSDKFriendlyObstructionConfiguration.
	 */
	public FriendlyObstructionPurpose getPurpose() {
		return purpose;
	}

	/**
	 * Get the detailedReason for why this obstruction is part of the ad experience.
	 *
	 *  @return the detailed reason String used to instantiate the FWOMSDKFriendlyObstructionConfiguration.
	 */
	public String getDetailedReason() {
		return detailedReason;
	}

	/**
	 *
	 * @return a String representation of the FWOMSDKFriendlyObstructionConfiguration.
	 */
	@Override
	public String toString() {
		return "FWOMSDKFriendlyObstructionConfiguration{" +
				"view=" + view +
				", purpose=" + purpose +
				", detailedReason='" + detailedReason + '\'' +
				'}';
	}
}
