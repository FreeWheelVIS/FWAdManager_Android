package tv.freewheel.renderers.image;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import tv.freewheel.utils.Logger;

class BaseLayout extends FrameLayout {
	protected Activity activity;
	private static final Logger logger = Logger.getLogger(BaseLayout.class);
	protected FrameLayout adViewHolder;
	protected FrameLayout.LayoutParams layoutParams;
	protected int adWidthInPixel;
	protected int adHeightInPixel;
	protected View adView;
	protected int baseWidthInPixel;
	protected int baseHeightInPixel;
	protected boolean allowsUpscaling;
	protected ViewGroup slotbase;
	protected int maxWidth = 0;
	protected int maxHeight = 0;

	public BaseLayout(Activity activity) {
		super(activity);
		this.activity = activity;
		logger.debug("new BaseLayout()");
		this.setBackgroundColor(Color.TRANSPARENT);
		this.addOnLayoutChangeListener(new OnLayoutChangeListener() {
			@Override
			public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
				BaseLayout.logger.debug("onLayoutChange()");
				if (BaseLayout.this.adViewHolder != null && BaseLayout.this.adView != null && !BaseLayout.this.allowsUpscaling) {
					BaseLayout.this.relocateAdView();
				}
			}
		});

	}

	public BaseLayout(Activity activity,int maxWidth,int maxHeight){
		this(activity);
		this.maxHeight = maxHeight;
		this.maxWidth = maxWidth;
	}

	protected void updateBaseSize() {
		baseWidthInPixel = this.slotbase.getWidth();
		baseHeightInPixel = this.slotbase.getHeight();
	}

	protected void relocateAdView() {
		logger.debug("relocateAdView()");
		this.updateBaseSize();
		this.layoutParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		if (!this.allowsUpscaling) {
			if (baseWidthInPixel > adWidthInPixel) {
				this.layoutParams.width = adWidthInPixel;
			}
			if (baseHeightInPixel > adHeightInPixel) {
				this.layoutParams.height = adHeightInPixel;
			}
		}
		this.adViewHolder.setLayoutParams(this.layoutParams);
		logger.debug("Base size in pixels: " + baseWidthInPixel + "x" + baseHeightInPixel + " image size in pixels:" + adWidthInPixel + "x" + adHeightInPixel);
	}

	public void addAdView(View adView, ViewGroup slotbase, int adWidthInPixel, int adHeightInPixel, boolean allowsUpscaling) {
		logger.debug("addAdView()");
		this.adView = adView;
		this.adWidthInPixel = adWidthInPixel;
		this.adHeightInPixel = adHeightInPixel;
		this.allowsUpscaling = allowsUpscaling;
		this.slotbase = slotbase;

		adViewHolder = new FrameLayout(this.getContext());
		adViewHolder.addView(adView, FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);
		this.addView(adViewHolder, 0);
		this.relocateAdView();
		
		adViewHolder.bringToFront();
		adView.requestFocus();
	}

	public void removeAdView(View adView) {
		logger.debug("removeAdView()");
		this.removeView(this.adViewHolder);
		this.adViewHolder.removeView(adView);
		this.adViewHolder = null;
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// Adjust width as necessary
		int measuredWidth = MeasureSpec.getSize(widthMeasureSpec);
		if(maxWidth > 0 && maxWidth < measuredWidth) {
			int measureMode = MeasureSpec.getMode(widthMeasureSpec);
			widthMeasureSpec = MeasureSpec.makeMeasureSpec(maxWidth, measureMode);
		}
		// Adjust height as necessary
		int measuredHeight = MeasureSpec.getSize(heightMeasureSpec);
		if(maxHeight > 0 && maxHeight < measuredHeight) {
			int measureMode = MeasureSpec.getMode(heightMeasureSpec);
			heightMeasureSpec = MeasureSpec.makeMeasureSpec(maxHeight, measureMode);
		}
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}
}
