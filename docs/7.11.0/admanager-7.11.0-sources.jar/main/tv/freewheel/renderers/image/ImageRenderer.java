package tv.freewheel.renderers.image;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IActivityStateChangeCallbackListener;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.renderer.ParamParser;
import tv.freewheel.utils.renderer.RendererTimer;

public class ImageRenderer implements IRenderer, RendererTimer.IRendererTimerService {
	private static final String BASE_UNIT_INTERSTITIAL = "app-interstitial";
	private static final int OVERLAY_SLOT_WIDTH = 240;
	private static final int OVERLAY_SLOT_HEIGHT = 50;

	private Activity activity;

	private boolean isInterstitial;
	private boolean isClickable = true;

	private IRendererContext rendererContext = null;
	private IConstants constants = null;
	private ISlot slot = null;
	private Parameters parameters = null;

	private Handler mainLoopHandler = null;
	private static final Logger logger = Logger.getLogger(ImageRenderer.class);
	private boolean isStopped = false;

	private boolean shouldEndAfterDuration = false;
	private boolean shouldPauseResumeMainVideoOnActivityStateChange = false;
	private boolean shouldPauseContentWhenStart = false;
	private boolean pauseNotificationSentWhenStart = false;
	private boolean pauseNotificationSentWhenActivityPaused = false;
	private boolean allowsUpscaling = true;
	private double duration = -1;
	private AtomicInteger headTime = new AtomicInteger(-1);
	private RendererTimer rendererTimer = null;
	private Bitmap bitmap = null;
	private FWImageView imageView = null;
	private IActivityStateChangeCallbackListener activityCallbackListener;
	private Matrix imageInverse = null;
	private int imageWidthInPixel = -1;
	private int imageHeightInPixel = -1;
	public BaseLayout baselayout = null;
	private AsyncTask<String, Void, Bitmap> downloadImageTask;


	private int width;
	private int height;

	public ImageRenderer() {
		logger.info("Android SDK Version: " + Build.VERSION.SDK + ", API Version: " + Build.VERSION.SDK_INT);
	}

	public FWImageView getImageView() {
		return this.imageView;
	}

	private void failWithError(String errorCode, String errorMessage) {
		logger.error("failWithError errorCode:" + errorCode + ", errorMessage:" + errorMessage);
		Bundle info = new Bundle();
		info.putString(this.constants.INFO_KEY_ERROR_CODE(), errorCode);
		info.putString(this.constants.INFO_KEY_ERROR_INFO(), errorMessage);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(this.constants.INFO_KEY_EXTRA_INFO(), info);
		this.rendererContext.dispatchEvent(this.constants.EVENT_ERROR(), map);
	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		private String description;

		private Bitmap.Config getPreferredBitmapConfig() {
			String preferredConfigValue = rendererContext.getParameter(Constants._PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG) + "";
			switch (preferredConfigValue) {
				case "ALPHA_8":
					return Bitmap.Config.ALPHA_8;
				case "RGB_565":
					return Bitmap.Config.RGB_565;
				case "ARGB_4444":
					return Bitmap.Config.ARGB_4444;
				case "ARGB_8888":
					return Bitmap.Config.ARGB_8888;
				case "RGBA_F16":
				case "HARDWARE":
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
						return preferredConfigValue.equalsIgnoreCase("RGBA_F16") ? Bitmap.Config.RGBA_F16 : Bitmap.Config.HARDWARE;
					}
					logger.warn(preferredConfigValue + "is not supported with this Android version.");
					return null;
				case "RGBA_1010102":
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
						return Bitmap.Config.RGBA_1010102;
					}
					logger.warn("RGBA_1010102 config is not supported on this Android version.");
					return null;

				default:
					logger.warn("Invalid value for " + Constants._PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG + ".");
					break;
			}
			return null;
		}

		private void setInPreferredConfig(BitmapFactory.Options options) {
			Bitmap.Config preferredConfig = getPreferredBitmapConfig();
			if (preferredConfig != null) {
				options.inPreferredConfig = preferredConfig;
			} else {
				logger.debug(Constants._PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG + " is not set");
			}
		}

		private int calculateSampleSize(long width, long height) {
			int slotWidth = slot.getBase().getWidth();
			int slotHeight = slot.getBase().getHeight();
			int inSampleSize = 1;
			if (width > slotWidth || height > slotHeight) {
				while ((width / inSampleSize) > slotWidth || (height / inSampleSize) > slotHeight) {
					inSampleSize *= 2;
				}
			}
			return inSampleSize;
		}

		private Bitmap decodeSampledBitmapFromStream(InputStream inputStream) {
			// First decode with inJustDecodeBounds=true to check dimensions
			BufferedInputStream stream = new BufferedInputStream(inputStream);
			final BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			setInPreferredConfig(options);

			// BufferedInputStream always supports mark/reset
			stream.mark(Integer.MAX_VALUE);
			BitmapFactory.decodeStream(stream, null, options);
			try {
				stream.reset();
			} catch (IOException e) {
				logger.warn("Failed to reset stream", e);
				return null;
			}

			// Calculate inSampleSize
			options.inSampleSize = calculateSampleSize(options.outWidth, options.outHeight);

			logger.debug("Decoding image with inSampleSize=" + options.inSampleSize +
					", original size=" + options.outWidth + "x" + options.outHeight +
					", required size=" + slot.getBase().getWidth() + "x" + slot.getBase().getHeight());

			// Decode bitmap with inSampleSize set
			options.inJustDecodeBounds = false;
			return BitmapFactory.decodeStream(stream, null, options);
		}

		@Override
		protected Bitmap doInBackground(String... urls) {
			String assetUrl = urls[0];
			Bitmap bm = null;
			if (URLUtil.isValidUrl(assetUrl)) {
				HttpURLConnection conn = null;
				int redirectCount = 0;
				try {
					do {
						URL url = new URL(assetUrl);
						conn = (HttpURLConnection) (url.openConnection());
						conn.setInstanceFollowRedirects(false);
						conn.connect();
						if (conn.getResponseCode() != 302) {
							bm = decodeSampledBitmapFromStream(conn.getInputStream());
							break;
						} else {
							assetUrl = conn.getHeaderField(Constants._URL_LOCATION);
							redirectCount ++;
							logger.debug("redirect to new location: " + assetUrl);
						}
						conn.disconnect();
						conn = null;
					} while (redirectCount <= 3);

					if (redirectCount > 3) {
						description = "redirect too many times";
					}
				} catch (MalformedURLException e) { // URL threw
					description = e.toString();
				} catch (IOException e) { // getContent IO exception
					description = "Failed to get content from creative url." + e.toString();
					if (conn != null) {
						conn.disconnect();
					}
				}
			} else {
				description = "Invalid url:" + assetUrl;
			}

			return bm;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			if (isStopped) {
				if (result != null) {
					result.recycle();
					result = null;
				}
				return;
			}
			ImageRenderer.this.bitmap = result;
			if (result != null) {
				ImageRenderer.this.imageWidthInPixel = result.getWidth();
				ImageRenderer.this.imageHeightInPixel = result.getHeight();
				onImagePrepared();
			} else {
				failWithError(constants.ERROR_IO(), description);
			}
		}
	}


	@Override
	public void load(IRendererContext rendererContext) {
		logger.info("load()");
		final IRendererContext rendererContextFinalRef = rendererContext;
		rendererContext.getActivity().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				ImageRenderer.this.rendererContext = rendererContextFinalRef;
				constants = ImageRenderer.this.rendererContext.getConstants();
				slot = ImageRenderer.this.rendererContext.getAdInstance().getSlot();
				activity = ImageRenderer.this.rendererContext.getActivity();
				mainLoopHandler = new Handler(Looper.getMainLooper());
				ImageRenderer.this.rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());
			}
		});
	}

	private void prepareImage() {
		logger.debug("prepareImage()");
		DisplayMetrics dm = this.activity.getResources().getDisplayMetrics();
		logger.debug("Display size: " + dm.widthPixels + "x" + dm.heightPixels + ", app size: " + this.getAppView().getWidth() + "x" + this.getAppView().getHeight());

		String baseUnit = rendererContext.getAdInstance().getActiveCreativeRendition().getBaseUnit();
		isInterstitial = BASE_UNIT_INTERSTITIAL.equalsIgnoreCase(baseUnit);
		logger.debug("isInterstitial:" + isInterstitial);

		if (((Slot) slot).isLinear()) {
			ParamParser paramParser = new ParamParser(rendererContext, "");
			if (DisplayUtils.isAndroidTV(this.activity)) {
				isClickable = false;
				this.rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), false);
			} else {
				isClickable = paramParser.parseBoolean(constants.PARAMETER_CLICK_DETECTION(), true);
				this.rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), true);
			}
		}
		logger.debug("isClickable:" + isClickable);

		IConstants.TimePositionClass tpc = slot.getSlotTimePositionClass();
		if (this.isInterstitial && tpc == IConstants.TimePositionClass.OVERLAY) {
			this.failWithError(constants.ERROR_INVALID_SLOT(), "The interstitial ad is not supported in overlay slot");
			return;
		}
		rendererContext.setSupportedAdEvent(constants.EVENT_AD_PAUSE(), false);
		rendererContext.setSupportedAdEvent(constants.EVENT_AD_RESUME(), false);

		this.parameters = new Parameters(rendererContext);
		if (this.parameters.allowsUpscaling != null) {
			this.allowsUpscaling = this.parameters.allowsUpscaling.booleanValue();
		} else {
			this.allowsUpscaling = true;
		}
		logger.debug("allowsUpscaling: " + this.allowsUpscaling);

		Boolean pval = this.parameters.shouldEndAfterDuration;
		this.shouldEndAfterDuration = pval && (isInterstitial || (tpc != IConstants.TimePositionClass.DISPLAY));
		if (this.shouldEndAfterDuration) {
			this.duration = rendererContext.getAdInstance().getActiveCreativeRendition().getDuration();
			if (this.duration > 0) {
				headTime = new AtomicInteger(0);
				this.rendererTimer = new RendererTimer((int) this.duration, this);
			}
		}

		if (tpc == IConstants.TimePositionClass.DISPLAY || tpc == IConstants.TimePositionClass.OVERLAY){
			shouldPauseResumeMainVideoOnActivityStateChange = true;
		}
		logger.debug("shouldPauseResumeMainVideoOnActivityStateChange:" + shouldPauseResumeMainVideoOnActivityStateChange);

		this.shouldPauseContentWhenStart = (tpc == IConstants.TimePositionClass.DISPLAY && this.isInterstitial);
		logger.debug("shouldPauseContentWhenStart:" + shouldPauseContentWhenStart);

		ICreativeRenditionAsset creativeRenditionAsset = rendererContext.getAdInstance().getActiveCreativeRendition()
				.getPrimaryCreativRenditionAsset();
		String url = (creativeRenditionAsset != null) ? creativeRenditionAsset.getURL() : null;
		if (url != null && url.length() != 0) {
			downloadImageTask = new DownloadImageTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{url});
		} else {
			this.failWithError(constants.ERROR_NULL_ASSET(), "Asset url is empty");
		}
	}

	private void onImagePrepared() {
		this.mainLoopHandler.post(new Runnable() {
			public void run() {
				activityCallbackListener = new IActivityStateChangeCallbackListener() {
					@Override
					public void onActivityStateChanged(IConstants.ActivityState activityState) {
						logger.debug("onActivityStateChange " + activityState);
						if (activityState == IConstants.ActivityState.PAUSED) {
							logger.info("context activity paused");
							if (rendererTimer != null) {
								rendererTimer.pause();
							}
							if (shouldPauseResumeMainVideoOnActivityStateChange && !pauseNotificationSentWhenStart && !pauseNotificationSentWhenActivityPaused) {
								logger.debug("Request content video to pause when activity is paused");
								rendererContext.requestTimelinePause();
								pauseNotificationSentWhenActivityPaused = true;
							}
						} else if (activityState == IConstants.ActivityState.RESUMED) {
							logger.info("context activity resumed");
							if (rendererTimer != null) {
								rendererTimer.resume();
							}
							if (shouldPauseResumeMainVideoOnActivityStateChange
									&& pauseNotificationSentWhenActivityPaused) {
								logger.debug("Request content video to resume when activity is resumed");
								rendererContext.requestTimelineResume();
								pauseNotificationSentWhenActivityPaused = false;
							}

							if (imageView != null && slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY){
								imageView.bringToFront();
							}
						}
					}
				};
				if (shouldPauseContentWhenStart && !pauseNotificationSentWhenStart) {
					logger.debug("Request content video to pause when the ad starts");
					rendererContext.requestTimelinePause();
					pauseNotificationSentWhenStart = true;
				}
				rendererContext.addOnActivityStateChangedListener(activityCallbackListener);
				showImage();
			}
		});
	}

	@Override
	public void start() {
		logger.info("start()");

		this.mainLoopHandler.post(new Runnable() {
			public void run() {
				prepareImage();
			}
		});
	}

	@Override
	public void stop() {
		logger.info("stop()");
		this.mainLoopHandler.post(new Runnable() {
			public void run() {
				isStopped = true;
				if (rendererTimer != null) {
					rendererTimer.stop();
					rendererTimer = null;
				}
				if (baselayout != null) {
					baselayout.removeAdView(imageView);
					if (baselayout.getParent() != null) {
						((ViewGroup)baselayout.getParent()).removeView(baselayout);
					}
					baselayout = null;
				} else if (slot.getBase() != null) {
					slot.getBase().removeView(imageView);
				}
				if (imageView != null) {
					imageView.setOnTouchListener(null);
					imageView = null;
				}
				if (bitmap != null) {
					bitmap.recycle();
					bitmap = null;
				}
				if (shouldPauseContentWhenStart && pauseNotificationSentWhenStart) {
					logger.debug("Request content video to resume when the ad completes");
					rendererContext.requestTimelineResume();
					pauseNotificationSentWhenStart = false;
				}

				if (downloadImageTask != null) {
					downloadImageTask.cancel(true);
					downloadImageTask = null;
				}
				rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
			}
		});
	}

	@Override
	public void pause() {
		logger.info("pause()");
		if (this.rendererTimer != null) {
			this.rendererTimer.pause();
		}
	}

	@Override
	public void resume() {
		logger.info("resume()");
		if (this.rendererTimer != null) {
			this.rendererTimer.resume();
		}
	}

	@Override
	public void dispose() {
		logger.info("dispose()");
		this.stop();
	}

	@Override
	public double getDuration() {
		return this.duration;
	}

	@Override
	public double getPlayheadTime() {
		return this.headTime.get();
	}

	@Override
	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<String, String>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	// IRendererTimerService methods
	@Override
	public void playHeadTime(int headTime) {
		this.headTime.set(headTime);
	}

	@Override
	public void timeOut() {
		this.stop();
	}

	@Override
	public void resize() {
		logger.info("resize()");
		if (! this.isInterstitial) {
			if (this.baselayout != null) {
				this.baselayout.removeAdView(imageView);
				ViewParent parent = this.baselayout.getParent();
				if (parent != null) {
					((ViewGroup)parent).removeView(baselayout);
				}
				this.baselayout = null;
			} else {
				ViewParent parent = this.imageView.getParent();
				if (parent != null) {
					((ViewGroup)parent).removeView(imageView);
				}
			}
			this.showInlineImage();
		}
	}

	@Override
	public void setVolume(float value) {

	}
	@Override
	public View getAdView(){
		return this.imageView;
	}
	private View getAppView() {
		return this.activity.getWindow().findViewById(Window.ID_ANDROID_CONTENT);
	}
	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}

	private void calculateImageViewSize() {
		ICreativeRendition creativeRendition = rendererContext.getAdInstance().getActiveCreativeRendition();
		logger.debug("calculateImageViewSize(), slot width: " + this.slot.getWidth() + "dp, rendition width:" + creativeRendition.getWidth() + "dp");
		DisplayMetrics dm = activity.getResources().getDisplayMetrics();

		if (creativeRendition.getWidth() > 0 && creativeRendition.getHeight() > 0) {
			width = (int)(creativeRendition.getWidth() * dm.density);
			height = (int)(creativeRendition.getHeight() * dm.density);
		} else if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
			width = (int)(OVERLAY_SLOT_WIDTH * dm.density);
			height = (int)(OVERLAY_SLOT_HEIGHT * dm.density);
		} else {
			width = this.imageWidthInPixel;
			height = this.imageHeightInPixel;
		}
		logger.debug("ad width = " + width + "px height = " + height + "px");
	}

	private void showInterstitialImage() {
		this.baselayout = new InterstitialLayout(activity);
		this.baselayout.addAdView(imageView, null, this.width, this.height, this.allowsUpscaling);
	}

	private void showInlineImage() {
		DisplayMetrics dm = activity.getResources().getDisplayMetrics();
		final ViewGroup.LayoutParams pFinalRef;
		baselayout = new BaseLayout(activity,this.width,this.height);
		if (slot.getSlotType() == IConstants.SlotType.TEMPORAL) {
			if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
				FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
				p.gravity = Gravity.NO_GRAVITY;

				String ar = this.parameters.primaryAnchor;
				Integer mw = this.parameters.marginWidth;
				Integer mh = this.parameters.marginHeight;

				if (ar == null) {
					ar = "bc";
				}
				if (ar.contains("t")) {
					p.gravity |= Gravity.TOP;
					if (mh != null) {
						p.topMargin = (int)(mh.doubleValue() * dm.density);
					}
				}
				if (ar.contains("l")) {
					p.gravity |= Gravity.LEFT;
					if (mw != null) {
						p.leftMargin = (int)(mw.doubleValue() * dm.density);
					}
				}
				if (ar.contains("r")) {
					p.gravity |= Gravity.RIGHT;
					if (mw != null) {
						p.rightMargin = (int)(mw.doubleValue() * dm.density);
					}
				}
				if (ar.contains("b")) {
					p.gravity |= Gravity.BOTTOM;
					if (mh != null) {
						p.bottomMargin = (int)(mh.doubleValue() * dm.density);
					}
				}
				if (ar.contains("c")) {
					p.gravity |= Gravity.CENTER_HORIZONTAL;
				}
				if (ar.contains("m")) {
					p.gravity |= Gravity.CENTER_VERTICAL;
				}
				if (ar.equals("c") || ar.equals("m") || ar.equals("cm") || ar.equals("mc")) {
					p.gravity = Gravity.CENTER;
				}

				logger.debug("show, overlay layout width: " + width + "px, height: " + height + "px ar:" + ar + ", marginWidth: " + mw * dm.density + "px, marginHeight: " + mh * dm.density + "px");

				slot.getBase().setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
					@Override
					public void onChildViewAdded(View parent, View child) {
						logger.debug("onChildViewAdded");
						if (imageView != null && imageView != child) {
							imageView.bringToFront();
						}
					}

					@Override
					public void onChildViewRemoved(View parent, View child) {
						logger.debug("onChildViewRemoved, do nothing");
					}
				});
				pFinalRef = p;
			} else {
				FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
				p.gravity = Gravity.CENTER;
				pFinalRef = p;
			}
		} else { // Display
			RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
			p.addRule(RelativeLayout.CENTER_IN_PARENT);
			pFinalRef = p;
		}
		slot.getBase().addView(baselayout, pFinalRef);
		baselayout.addAdView(imageView, slot.getBase(), this.width, this.height, this.allowsUpscaling);
		imageView.bringToFront();
	}

	private void showImage() {
		this.calculateImageViewSize();

		imageView = new FWImageView(activity, this.rendererContext, this.rendererTimer);
		imageView.setImageBitmap(bitmap);
		this.imageInverse = new Matrix();
		imageView.setScaleType(ScaleType.FIT_CENTER);
		imageView.setBackgroundColor(0x000000);
		imageView.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View view, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {
					imageView.getImageMatrix().invert(imageInverse);
					float[] touchPoint = new float[]{event.getX(), event.getY()};
					imageInverse.mapPoints(touchPoint);
					float touchX = touchPoint[0];
					float touchY = touchPoint[1];
					logger.debug("onTouch (" + touchX + ", " + touchY + ")");
					if (touchX > 0 && touchY > 0 && touchX < imageWidthInPixel && touchY < imageHeightInPixel) {
						rendererContext.dispatchEvent(constants.EVENT_AD_CLICK());
						return true;
					} else {
						logger.debug("touch event not in the image area.");
					}
				}
				return false;
			}
		});
		imageView.setClickable(isClickable);

		if (this.isInterstitial) {
			this.showInterstitialImage();
		} else {
			this.showInlineImage();
		}
	}
}
