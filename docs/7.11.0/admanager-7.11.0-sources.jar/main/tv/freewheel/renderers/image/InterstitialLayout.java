package tv.freewheel.renderers.image;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;

import tv.freewheel.utils.Logger;

class InterstitialLayout extends BaseLayout {
	private ViewGroup superRootFrame;
	private int titleParentVisibility;
	private static final Logger logger = Logger.getLogger(InterstitialLayout.class);

	public InterstitialLayout(Activity activity) {
		super(activity);
		this.activity = activity;
		logger.debug("InterstitialLayout");
		this.setBackgroundColor(Color.argb(255, 0, 0, 0));
		Object superRoot = activity.getWindow().getDecorView();
		if (superRoot != null) {
			superRootFrame = (ViewGroup) superRoot;
		} else {
			logger.error("The DecorView of the activity window is not available, full screen is not supported!");
		}
	}

	@Override
	protected void updateBaseSize() {
		this.baseWidthInPixel = this.activity.getResources().getDisplayMetrics().widthPixels;
		this.baseHeightInPixel = this.activity.getResources().getDisplayMetrics().heightPixels;
	}

	public void addAdView(View adView, ViewGroup slotbase, int width, int height, boolean allowsUpscaling) {
		this.showFullscreenBackground();
		super.addAdView(adView, slotbase, width, height, allowsUpscaling);
	}

	public void removeAdView(View adView) {
		this.hideFullscreenBackground();
		super.removeAdView(adView);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		logger.debug("onTouchEvent");
		return true;
	}

	void showFullscreenBackground() {
		logger.debug("showFullScreenBackground");
		if ((activity.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_FULLSCREEN) != WindowManager.LayoutParams.FLAG_FULLSCREEN) {
			activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}
		activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

		View title = activity.getWindow().findViewById(android.R.id.title);
		if (title != null && title.getParent() != null) {
			ViewGroup par = (ViewGroup) title.getParent();
			this.titleParentVisibility = par.getVisibility();
			par.setVisibility(View.GONE);
		}
		ViewGroup.LayoutParams fllp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT);
		superRootFrame.addView(this, fllp);
	}

	void hideFullscreenBackground() {
		View title = activity.getWindow().findViewById(android.R.id.title);
		if (title != null && title.getParent() != null) {
			ViewGroup par = (ViewGroup) title.getParent();
			par.setVisibility(this.titleParentVisibility);
		}

		activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		superRootFrame.removeView(this);
	}
}
