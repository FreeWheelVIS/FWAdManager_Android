package tv.freewheel.renderers.image;


import android.content.Context;
import android.os.Bundle;
import android.widget.ImageView;
import android.graphics.Canvas;

import java.util.HashMap;

import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.ad.Constants;
import tv.freewheel.utils.renderer.RendererTimer;

public class FWImageView extends ImageView {
    private static final Logger logger = Logger.getLogger(FWImageView.class, true);
    private IRendererContext rendererContext;
    private RendererTimer rendererTimer;
    private boolean wasAdStarted = false;
    public FWImageView(Context context) {
        super(context);
    }

    public FWImageView(Context context, IRendererContext rendererContext, RendererTimer rendererTimer) {
        this(context);
        this.rendererContext = rendererContext;
        this.rendererTimer = rendererTimer;
    }

    @Override
    public void onDraw(Canvas canvas) {
        try {
            if (this.rendererContext == null) {
                logger.warn("FWImageView rendererContext is null");
                return;
            }
            if (!this.wasAdStarted) {
                this.wasAdStarted = true;
                this.rendererContext.dispatchEvent(Constants._EVENT_AD_STARTED);
                if (this.rendererTimer != null) {
                    this.rendererTimer.start();
                }
            }
            super.onDraw(canvas);
        } catch (Exception e) {
            logger.warn("Error drawing FWImageView", e);
            if (this.rendererContext == null) {
                logger.warn("FWImageView rendererContext is null, cannot dispatch error event");
                return;
            }
            HashMap<String, Object> info = new HashMap<>();
            Bundle bundle = new Bundle();
            bundle.putString(Constants._INFO_KEY_ERROR_CODE, Constants._ERROR_IO);
            bundle.putString(Constants._INFO_KEY_ERROR_INFO, e.getMessage());
            info.put(Constants._INFO_KEY_EXTRA_INFO, bundle);
            this.rendererContext.dispatchEvent(Constants._EVENT_ERROR, info);
        }
    }
}
