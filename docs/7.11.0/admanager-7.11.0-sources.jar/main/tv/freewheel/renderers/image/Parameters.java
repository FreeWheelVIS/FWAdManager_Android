package tv.freewheel.renderers.image;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Calendar;
import org.json.JSONObject;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.renderer.ParamParser;

class Parameters {
	String primaryAnchor;
	Integer marginWidth;
	Integer marginHeight;
	Boolean allowsUpscaling;
	Boolean shouldEndAfterDuration;
	private static final Logger logger = Logger.getLogger(Parameters.class);
	ParamParser paramParser;

	public Parameters(IRendererContext context) {
		paramParser = new ParamParser((AdInstance)(context.getAdInstance()), "renderer.image");
		Object pval = null;
		pval = context.getParameter("renderer.image.primaryAnchor");
		if (pval == null) {
			primaryAnchor = "bc";
		} else {
			primaryAnchor = pval.toString();
		}

		pval = context.getParameter("renderer.image.marginWidth");
		if (pval == null) {
			marginWidth = 0;
		} else {
			marginWidth = StringUtils.parseInt(pval.toString());
		}
		pval = context.getParameter("renderer.image.marginHeight");
		if (pval == null) {
			marginHeight = 0;
		} else {
			marginHeight = StringUtils.parseInt(pval.toString());
		}

		allowsUpscaling = paramParser.parseBoolean("allowsUpscaling", true);
		shouldEndAfterDuration = paramParser.parseBoolean("shouldEndAfterDuration", true);
		logger.debug(this.toJSONString());
	}

	public String toJSONString() {
		JSONObject json = new JSONObject();
		for (int i = 0; i < Parameters.class.getDeclaredFields().length; i++) {
			Field field = Parameters.class.getDeclaredFields()[i];
			if (!Modifier.isStatic(field.getModifiers())) {
				try {
					Object value = field.get(this);
					if (value instanceof Calendar) {
						value = ((Calendar) value).getTime().toString();
					}
					if (value instanceof Integer && field.getName().contains("Color")) {
						value = Integer.toHexString(((Integer) value));
					}
					json.put(field.getName(), value);
				} catch (Exception e) {
					logger.error(e.toString());
				}
			}
		}
		return json.toString();
	}
}