package tv.freewheel.renderers.interfaces;

import android.app.Activity;
import android.location.Location;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IParameterHolder;
import tv.freewheel.ad.interfaces.ISlot;

/**
 *	Interface for a renderer to obtain information from AdManager.
 */
public interface IRendererContext extends IParameterHolder {
	/**
	 *	Get current ad instance.
	 *
	 *	@return an IAdInstance object
	 *
	 */
	public IAdInstance getAdInstance();

	/**
	 *  Get constants look up table.
	 *
	 *  @return an IConstants object
	 */
	public IConstants getConstants();

	/**
	 * Get the volume for ad playback
	 *
	 * Renderer, while starting an ad playback, should use this API to set the initial volume of the ad
	 *
	 * @return A float in the range [0,1]
	 */
	public float getInitialAdVolume();

	/**
	 *	Return application's current Activity which create and hold the reference of this AdContext.
	 *
	 *	@return the Activity object
	 */
	public Activity getActivity();

	/**
	 * Declare capability of the renderer.
	 * @param adEventName one of EVENT_AD_* (NOT including EVENT_AD_FIRST_QUARTILE, EVENT_AD_THIRD_QUARTILE, EVENT_AD_IMPRESSION) in IConstants
	 * @param supported true, if the renderer is able to process the specified ad event
	 */
	void setSupportedAdEvent(String adEventName, boolean supported);

	/**
	 *	Dispatch renderer event.
	 *
	 *	@param	eventName event to be processed, one of EVENT_AD_* and EVENT_REQUEST_CONTENT_VIDEO_* in IConstants
	 */
	public void dispatchEvent(String eventName);

	/**
	 *	Dispatch renderer event.
	 *
	 *	@param	eventName event to be processed, one of EVENT_AD_* and EVENT_REQUEST_CONTENT_VIDEO_* in IConstants
	 *  @param  extraInfo additional information need to be processed by AdManager. Available keys:
	 * 					<br>- INFO_KEY_ERROR_CODE Optional.
	 * 					<br>When eventName is EVENT_ERROR, use this key to specify the error code.
	 * 					<br>- INFO_KEY_ERROR_INFO Optional.
	 * 					<br>When eventName is EVENT_ERROR, use this key to specify the description of the error.
	 * 					<br>- INFO_KEY_VAST_ERROR_CODE Optional.
	 * 					<br>When eventName is EVENT_ERROR, use this key to specify the VAST error code.
	 * 					<br>- INFO_KEY_SHOW_BROWSER Optional.
	 * 					<br>Only valid when the eventName is EVENT_AD_CLICK, the value should be boolean
	 * 					<br>use this key to specify whether the click event should open a browser if possible
	 * 					<br>the default value is true
	 * 					<br>- INFO_KEY_URL Optional.
	 * 					<br>Only valid when the eventName is EVENT_AD_CLICK, the value should be String.
	 * 					<br>use this key to specify redirect URL.
	 * 					<br>the default value is the one specified on MRM UI.
	 * 					<br>- INFO_KEY_MESSAGE Optional.
	 * 					<br>When eventName is EVENT_CLICK, use this key to specify the name of custom click
	 * 				    <br>- INFO_KEY_OFFSET Optional.
	 * 					<br>When eventName is EVENT_PROGRESS, use this key to specify the offset value in second
	 * 				    <br>- INFO_KEY_AD_SKIPPABLE_STATE Optional.
	 * 	 * 				<br>When eventName is EVENT_AD_SKIPPABLE_STATE_CHANGED, use this key to specify the ad skippable state
	 */
	public void dispatchEvent(String eventName, HashMap<String, Object> extraInfo);

	/**
	 *	Get the location of device. This value was set by IAdManager.setLocation and will not be change in the AdContext's lifetime.
	 *
	 *	@return	the location value which App set through IAdManager.setLocation. will be null if not set
	 */
	public Location getLocation();

	/**
	 * Register event callback listener for Activity's state changes
	 *
	 * @param activityStateChangeCallbackListener the callback listener responding to activity's state changes. activityStateChangeCallbackListener will be called with activity state's IConstants.ActivityState.PAUSED, IConstants.ActivityState.RESUMED
	 */
	public void addOnActivityStateChangedListener(IActivityStateChangeCallbackListener activityStateChangeCallbackListener);

	/**
	 * Schedule ad instances for slots passed in as parameter. Usually slots consists of current slot and its companion slots.
	 *
	 * @param slots slots to be scheduled for ads
	 * @return List of scheduled IAdInstance
	 */
	public List<IAdInstance> scheduleAdInstances(List<ISlot> slots);

	/**
	 * Return the companion slots which are able to schedule companion.
	 *
	 * @return List of companion ISlot
	 */
	public List<ISlot> getCompanionSlots();

	/**
	 * Get SDK version.
	 *
	 * @return Current version as int, e.g., 0x02060000 for v2.6
	 */
	public int getVersion();

	/**
	 * Request timeline to pause. The timeline consists of the content video and all linear slots.
	 * When the renderer or extension requires the timeline to be temporarily paused, e.g. when expanding to a fullscreen view that covers the whole player and other ads, calling this method will result in the event EVENT_REQUEST_CONTENT_VIDEO_PAUSE() being dispatched from the current FWContext instance if content video is currently playing, and pause requests sent to all active temporal slots.
	 */
	public void requestTimelinePause();

	/**
	 * Request timeline to resume. The timeline consists of the content video and all linear slots.
	 * When the renderer or extension requires the timeline to be resumed, e.g. when dismissing a fullscreen view that covers the whole player and other ads, calling this method will result in the event EVENT_REQUEST_CONTENT_VIDEO_RESUME() being dispatched from the current FWContext instance if content video is currently paused, and send resume requests to all active temporal slots.
	 */
	public void requestTimelineResume();
}
