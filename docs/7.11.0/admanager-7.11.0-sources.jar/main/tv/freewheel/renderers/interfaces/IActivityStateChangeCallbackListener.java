package tv.freewheel.renderers.interfaces;

import tv.freewheel.ad.interfaces.IConstants;
/**
 * Interface for listening to activity state changes.
 */
public interface IActivityStateChangeCallbackListener {
	/**
	 * Called when the activity state changes.
	 * @param activityState the new activity state.
	 */
	public void onActivityStateChanged(IConstants.ActivityState activityState);
}
