package tv.freewheel.renderers.interfaces;

import java.util.List;
import java.util.Map;
import android.view.View;

import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;

/**
 * Interface for renderer to implement.
 */
public interface IRenderer {
	/**
	 * Notify the renderer to initialize and to load the creative.
	 * 
	 * @param rendererContext reference to IRendererContext
	 * <br>Note: AdManager expect the EVENT_AD_LOADED be dispatched when the ad has been loaded.
	 */
	public void load(IRendererContext rendererContext);
	
	/**
	 * Notify the renderer to start ad playback.
	 * <br>Note: AdManager expect the EVENT_AD_STARTED be dispatched when ad showed on UI.
	 */
	public void start();
	
	/**
	 * Notify the renderer to start pause playback.
	 * <br>Note: AdManager expect the EVENT_AD_PAUSE be dispatched when ad paused.
	 */
	public void pause();
	
	/**
	 * Notify the renderer to start resume playback.
	 * <br>Note: AdManager expect the EVENT_AD_RESUME be dispatched when ad resumed.
	 */
	public void resume();
	
	/**
	 * Notify the renderer to stop ad playback.
	 * <br>Usage: AdManager expect the EVENT_AD_STOPPED be dispatched when ad complete stopped.
	 */
	public void stop();
	
	/**
	 * Notify the renderer to dispose and release resources.
	 * <br> Note: After this call AdManager will not use this renderer anymore.
	 */
	public void dispose();
	
	/**
	 * Get duration of the ad.
	 * 
	 * @return a number in seconds, which is greater than or equal to 0, but if not available return -1
	 */
	public double getDuration();
	
	/**
	 * Get playheadTime of the ad.
	 * 
	 * @return a number in seconds, which is greater than or equal to 0, but if not available return -1
	 */
	public double getPlayheadTime();
	
	/**
	 * Get module info. The returned dictionary should contain key INFO_KEY_MODULE_TYPE with enumerated IConstants.ModuleType string value.
	 * 
	 * @return a map with the module info.
	 */
	public Map<String, String> getModuleInfo();
	
	/**
	 * This method will be invoked when player changes the size of temporal ad container.
	 * This will also be invoked when player changes the temporal ad container to another one, which is returned by ISlot.getBase().
	 * Renderer should change the ad size according to the new display base via  slot.getWidth() and slot.getHeight().
	 */
	public void resize();

	/**
	 * Set the ad playback volume on the renderer
	 * @param value A float in the range of [0,1]
	 */
	public void setVolume(float value);

	/**
	 * Get the actual view used to renderer the Ad.
	 * 
	 * @return a view object.
	 */
	public View getAdView();

	/**
	 * Get a list of friendly obstruction configurations which should be excluded from all ad session viewability calculations for Open Measurement SDK.
	 * Please note, you need to instantiate all the obstructions that could be added anytime during the ad playback before dispatching AD_LOADED and return them with this API.
	 * 
	 * @return a list of FWOMSDKFriendlyObstructionConfiguration objects.
	 */
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions();

}
