package tv.freewheel.renderers.nullnull;

import android.os.Handler;
import android.view.View;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;

public class NullAdRenderer implements IRenderer {

	private static final Logger logger = Logger.getLogger(NullAdRenderer.class);
	private IRendererContext rendererContext;
	private IConstants constants;
	
	public NullAdRenderer() {
	}
	
	public void load(IRendererContext rendererContext) {
		logger.debug("NullAdRenderer init");
		this.rendererContext = rendererContext;
		this.constants = this.rendererContext.getConstants();
		this.rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), false);
		this.rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());
	}

	public void start() {
		logger.debug("start");
		this.rendererContext.dispatchEvent(constants.EVENT_AD_STARTED());

		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				NullAdRenderer.this.rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
			}
		}, 500);
	}

	public void pause() {
		logger.warn("pause() ignore");
	}

	public void resume() {
		logger.warn("resume() ignore");
	}

	public void stop() {
		logger.warn("stop() ignore");
	}

	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<String, String>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		return ret;
	}

	public double getDuration() {
		return -1;
	}

	public double getPlayheadTime() {
		return -1;
	}

	public void dispose() {
		logger.verbose("dispose() ignore");
	}

	@Override
	public void resize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setVolume(float value) {

	}

	@Override
	public View getAdView(){
		return null;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}
}
