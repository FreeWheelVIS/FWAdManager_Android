package tv.freewheel.renderers.html;

import org.json.JSONException;
import org.json.JSONObject;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.renderer.ParamParser;

class Parameters {
	String placementType;
	String primaryAnchor;
	Integer marginWidth;
	Integer marginHeight;
	String bootstrap;
	Boolean shouldEndAfterDuration;
	Boolean shouldBackgroundTransparent;
	private static final Logger logger = Logger.getLogger(Parameters.class);
	ParamParser paramParser;

	public Parameters(IRendererContext context) {
		paramParser = new ParamParser((AdInstance)(context.getAdInstance()), "renderer.html");
		Object pval = null;
		pval = context.getParameter("renderer.html.placementType");
		placementType = (pval != null? pval.toString() : null);

		pval = context.getParameter("renderer.html.primaryAnchor");
		if (pval == null) {
			primaryAnchor = "bc";
		} else {
			primaryAnchor = pval.toString();
		}

		pval = context.getParameter("renderer.html.marginWidth");
		if (pval == null) {
			marginWidth = 0;
		} else {
			marginWidth = StringUtils.parseInt(pval.toString());
		}
		pval = context.getParameter("renderer.html.marginHeight");
		if (pval == null) {
			marginHeight = 0;
		} else {
			marginHeight = StringUtils.parseInt(pval.toString());
		}

		pval = context.getParameter("renderer.html.bootstrap");
		bootstrap = (pval != null? pval.toString() : null);

		shouldEndAfterDuration = paramParser.parseBoolean("shouldEndAfterDuration", true);
		shouldBackgroundTransparent = paramParser.parseBoolean("isBackgroundTransparent", true);
		logger.debug(this.toJSONString());
	}

	public String toJSONString() {
		JSONObject json = new JSONObject();
		try {
			json.put("placementType", placementType);
			json.put("primaryAnchor", primaryAnchor);
			json.put("marginWidth", marginWidth);
			json.put("marginHeight", marginHeight);
			json.put("bootstrap", bootstrap);
			json.put("shouldEndAfterDuration", shouldEndAfterDuration);
			json.put("shouldBackgroundTransparent", shouldBackgroundTransparent);
		} catch (JSONException e) {
			logger.debug(e);
		}
		return json.toString();
	}
}
