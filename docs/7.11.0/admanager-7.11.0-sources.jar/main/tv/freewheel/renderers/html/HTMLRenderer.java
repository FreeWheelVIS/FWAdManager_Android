package tv.freewheel.renderers.html;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IActivityStateChangeCallbackListener;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.renderer.RendererTimer;

public class HTMLRenderer implements IRenderer, RendererTimer.IRendererTimerService {
	private static final String PLACEMENT_TYPE_INTERSTITIAL = "interstitial";
	private static final String PLACEMENT_TYPE_INLINE = "inline";
	private static final String BASE_UNIT_INTERSTITIAL = "app-interstitial";

	private enum MRAIDState {
		LOADING, DEFAULT, EXPANDED, RESIZED, HIDDEN
	}

	private Parameters parameters = null;
	private String placementType = null;
	private MRAIDState state = MRAIDState.LOADING;
	private boolean isViewable = true;
	private boolean isUseCustomClose = false;
	private IActivityStateChangeCallbackListener activityCallbackListener; // it will be weak referenced, has to be a field variable
	private IMRAIDPresentation presentation;
	private String expandURL;

	private boolean pauseNotificationSentWhenExternalBrowserOpened = false;
	private boolean showedPresentation = false;

	private RendererTimer rendererTimer;
	private double duration = -1;
	private AtomicInteger headTime = new AtomicInteger(-1);

	//MRAID ad only
	//state of external web browser and followed close
	//	0: init state, no opened
	//	1: opened
	//  2: opened and followed close was called, but the close operation will delay until activity resume
	// state change graph : 0 <-> 1 -> 2 -> 0 , 2 will cause delayed close operation continue after activity resume
	private int stateOfExternalWebBrowserActivity = 0;

	private View getAppView() {
		return this.activity.getWindow().findViewById(Window.ID_ANDROID_CONTENT);
	}

	// get the app content size every time, in case of orientation change
	private int getAppWidth() {
		return this.getAppView().getWidth();
	}

	private int getAppHeight() {
		return this.getAppView().getHeight();
	}

	private int getScreenWidth() {
		return this.activity.getResources().getDisplayMetrics().widthPixels;
	}

	private int getScreenHeight() {
		return this.activity.getResources().getDisplayMetrics().heightPixels;
	}

	private int creativeRequiredExpandWidth = -1; // -1 or [0,getScreenWidth()]
	private int creativeRequiredExpandHeight = -1; // -1 or [0,getScreenHeight()]

	private int expandWidth() {
		return (creativeRequiredExpandWidth > 0 && creativeRequiredExpandWidth < getScreenWidth()) ? creativeRequiredExpandWidth : getScreenWidth();
	}

	private int expandHeight() {
		return (creativeRequiredExpandHeight > 0 && creativeRequiredExpandHeight < getScreenHeight()) ? creativeRequiredExpandHeight : getScreenHeight();
	}

	private String getPrintableState() {
		return this.getPrintableState(this.state);
	}

	// resize properties
	private static final Set<String> closePositionOptions = new HashSet<String>(Arrays.asList(
			"top-left",
			"top-right",
			"center",
			"bottom-left",
			"bottom-right",
			"top-center",
			"bottom-center"
	));

	private int creativeRequiredResizeWidth = -1;
	private int creativeRequiredResizeHeight = -1;
	private int creativeRequiredResizeOffsetX = -1;
	private int creativeRequiredResizeOffsetY = -1;
	private String customClosePosition = "top-right";
	private boolean allowOffscreen = true;

	private String getPrintableState(MRAIDState state) {
		switch (state) {
		case LOADING:
			return "loading";
		case DEFAULT:
			return "default";
		case EXPANDED:
			return "expanded";
		case RESIZED:
			return "resized";
		case HIDDEN:
			return "hidden";
		default:
			return null;// impossible, for compiler friendly
		}
	}

	private String getPrintableTimePositionClass() {
		return slot != null ? slot.getSlotTimePositionClass().toString().toLowerCase() : "";
	}

	private String CLASSTAG() {
		return "@" + this.hashCode() + "-" + placementType + "|" + getPrintableTimePositionClass() + "|";
	}

	private String MRAIDTAG() {
		return this.CLASSTAG() + ":=STATE(" + this.getPrintableState() + ")";
	}

	private Activity activity;

	private boolean isInterstitial;
	private boolean isMRAIDAd = false;
	private boolean shouldEndAfterDuration = false;
	private boolean shouldPauseResumeMainVideoWhenExpand = false; // inline ad
																	// only
	private boolean shouldPauseResumeMainVideoOnActivityStateChange = false;

	private IRendererContext rendererContext = null;
	private IConstants constants = null;
	private ISlot slot = null;

	private Handler mainLoopHandler = null;
	private static final Logger logger = Logger.getLogger(HTMLRenderer.class);

	public HTMLRenderer() {
		logger.info("Android SDK Version: " + Build.VERSION.SDK + ", API Version: " + Build.VERSION.SDK_INT);
	}

	private boolean isInState(MRAIDState state) {
		return this.state.equals(state);
	}

	private void pingBack(String type) {
		logger.debug(MRAIDTAG() + " pingBack(" + type + ")");
		if (!this.isInterstitial)
			rendererContext.dispatchEvent(type);
	}

	private void transferTo(MRAIDState toState) {
		logger.debug(MRAIDTAG() + " transferTo:" + this.getPrintableState(toState));
		if (isInState(toState) && !isInState(MRAIDState.RESIZED))
			return;
		boolean isValidTransfer = true;
		if (toState.equals(MRAIDState.EXPANDED)) {
			if (this.rendererTimer != null)
				this.rendererTimer.pause();
			if (shouldPauseResumeMainVideoWhenExpand)
				rendererContext.requestTimelinePause();
			if (this.expandURL == null) {
				pingBack(constants.EVENT_AD_EXPAND());
			} else
				pingBack(constants.EVENT_AD_ACCEPT_INVITATION());
			String absoluteExpandURL = (this.expandURL == null) ? null : presentation.getAbsoluteURL(this.expandURL);
			presentation.setCloseButtonVisibility(!this.isUseCustomClose);
			presentation.expand(absoluteExpandURL, this.expandWidth(), this.expandHeight());
		} else if (toState.equals(MRAIDState.DEFAULT)) {
			if (isInState(MRAIDState.LOADING)) {
				this.setMraidFeatures();
				if (this.rendererTimer != null)
					this.rendererTimer.start();
				this.state = toState;
				this._synchStateToPresentation(false);
				return;
			} else if (isInState(MRAIDState.EXPANDED)) {
				if (shouldPauseResumeMainVideoWhenExpand)
					rendererContext.requestTimelineResume();
				if (this.rendererTimer != null)
					this.rendererTimer.resume();

				if (this.expandURL == null) {
					pingBack(constants.EVENT_AD_COLLAPSE());
					presentation.collapse();
				} else {
					pingBack(constants.EVENT_AD_CLOSE());
					presentation.close();
				}
			} else if (isInState(MRAIDState.RESIZED)) {
				presentation.close();
			} else {
				isValidTransfer = false;
				logger.debug(MRAIDTAG() + " Invalid transfer");
			}
		} else if (toState.equals(MRAIDState.HIDDEN)) {
			if (this.rendererTimer != null)
				this.rendererTimer.stop();
			if (!isInState(MRAIDState.LOADING) || showedPresentation) {
				presentation.close();
			}
			presentation.dispose();
			rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
			if (isInState(MRAIDState.LOADING) && this.isInterstitial) {
				this.state = toState;
				return;
			}
		} else if (toState.equals(MRAIDState.RESIZED)) {
			if (isInState(MRAIDState.EXPANDED)) {
				dispatchMraidError("resize called in expanded state", "resize");
				isValidTransfer = false;
			} else if (isInState(MRAIDState.RESIZED) || isInState(MRAIDState.DEFAULT)) {
				presentation.resize(creativeRequiredResizeOffsetX, creativeRequiredResizeOffsetY,
						creativeRequiredResizeWidth, creativeRequiredResizeHeight,
						customClosePosition, allowOffscreen);
			} else {
				isValidTransfer = false;
				logger.debug(MRAIDTAG() + " resize called in " + getPrintableState() + " state, no effect");
			}
		} else {
			isValidTransfer = false;
			logger.debug(MRAIDTAG() + " Invalid transfer");
		}

		if (isValidTransfer && !this.isInterstitial) {
			this.state = toState;
		}
	}

	private void _loadFail(int errorCode, String description) {
		logger.debug(MRAIDTAG() + " errorCode:" + errorCode + ",description:" + description);
		this.failWithError(constants.ERROR_IO(), "Load failed");
	}

	private void _loaded() {
		logger.info(MRAIDTAG() + " _loaded()");
		if (isInState(MRAIDState.LOADING))
			this.transferTo(MRAIDState.DEFAULT);
		else if (isInState(MRAIDState.DEFAULT))
			logger.info(MRAIDTAG() + " expanded view loaded.");
		else
			logger.error(MRAIDTAG() + " Invalid state to have been loaded");
	}

	private void _open(String url) {
		logger.info(MRAIDTAG() + " _open(" + url + ")");
		if (url != null && url.length() != 0) {
			this.startWebBrowser(presentation.getAbsoluteURL(url));
		} else
			logger.error(MRAIDTAG() + " url is required");
	}

	private void _resize() {
		logger.info(MRAIDTAG() + " _resize()");
		if (creativeRequiredResizeWidth < 0 || creativeRequiredResizeHeight < 0) {
			dispatchMraidError("setResizeProperties not called", "resize");
			return;
		}

		if (isInterstitial) {
			logger.error(MRAIDTAG() + " Cannot resize on interstitial ad");
			return;
		}

		transferTo(MRAIDState.RESIZED);
	}

	private void _close() {
		logger.info(MRAIDTAG() + " _close()");
		if (this.isMRAIDAd){
			if (stateOfExternalWebBrowserActivity == 1){
				logger.debug(MRAIDTAG() + " An external web browser opened. It will delay close operation to resume from browser activity.");
				stateOfExternalWebBrowserActivity = 2;
				return;
			}
		}
		if (isInState(MRAIDState.EXPANDED) || isInState(MRAIDState.RESIZED))
			transferTo(MRAIDState.DEFAULT);
		else if (isInState(MRAIDState.DEFAULT) || isInState(MRAIDState.LOADING))
			_stop();
		else
			logger.error(MRAIDTAG() + " Invalid state to close");
	}

	private void _useCustomClose(boolean use) {
		logger.info(MRAIDTAG() + "_useCustomClose(" + use + ")");
		this.isUseCustomClose = use;
		this.presentation.setCloseButtonVisibility(!this.isUseCustomClose);
	}

	private void _expand() {
		logger.info(MRAIDTAG() + " _expand()");
		this._expand(null);
	}

	private void _expand(String url) {
		logger.info(MRAIDTAG() + " _expand(" + url + ")");
		if (!isInterstitial) {
			if (isInState(MRAIDState.DEFAULT) || isInState(MRAIDState.RESIZED)) {
				this.expandURL = (url != null && url.length() == 0) ? null : url;// empty
																					// url
																					// should
																					// become
																					// null
				transferTo(MRAIDState.EXPANDED);
			} else
				logger.error(MRAIDTAG() + " Invalid state to expand");
		} else
			logger.error(MRAIDTAG() + " The expand operation of interstitial ad is not supported");
	}

	private void _setExpandProperties(String propJsonString) {
		logger.info(MRAIDTAG() + " _setExpandProperties(" + propJsonString + ")");
		if (propJsonString == null || propJsonString.isEmpty()) {
			logger.error(MRAIDTAG() + " Empty parameter, ignored");
			dispatchMraidError("Empty properties", "setExpandProperties");
			return;
		}

		try {
			JSONObject expandProperties = new JSONObject(propJsonString);
			DisplayMetrics dm = this.activity.getResources().getDisplayMetrics();
			int w = (int)(expandProperties.optInt("width") * dm.density);
			int h = (int)(expandProperties.optInt("height") * dm.density);

			if (w > 0 && h > 0) {
				if (w < this.getScreenWidth())
					this.creativeRequiredExpandWidth = w;
				else {
					this.creativeRequiredExpandWidth = -1;
					logger.warn(MRAIDTAG() + " The width parameter is equal or greater than screen width, using screen width instead");
				}
				if (h < this.getScreenHeight())
					this.creativeRequiredExpandHeight = h;
				else {
					this.creativeRequiredExpandHeight = -1;
					logger.warn(MRAIDTAG() + " The height parameter is equal or greater than screen height, using screen height instead");
				}
			} else if (w == 0 || h == 0) {
				this.creativeRequiredExpandWidth = -1;
				this.creativeRequiredExpandHeight = -1;
				logger.warn(MRAIDTAG() + " There are zero value in width or height, using screen width and height instead");
			} else {
				dispatchMraidError("Negative width or height", "setExpandProperties");
				return;
			}

			this.isUseCustomClose = expandProperties.optBoolean("useCustomClose");
		} catch (JSONException jex) {
			dispatchMraidError("Failed to parse JSON", "setExpandProperties");
		}
	}

	private void _setResizeProperties(String propJsonString) {
		logger.info(MRAIDTAG() + " _setResizeProperties(" + propJsonString + ")");
		if (propJsonString == null || propJsonString.isEmpty()) {
			logger.error(MRAIDTAG() + " Empty parameter, ignored");
			dispatchMraidError("Empty properties", "setResizeProperties");
			return;
		}

		try {
			JSONObject resizeProperties = new JSONObject(propJsonString);
			DisplayMetrics dm = this.activity.getResources().getDisplayMetrics();
			int w = (int)(resizeProperties.getInt("width") * dm.density);
			int h = (int)(resizeProperties.getInt("height") * dm.density);
			int x = (int)(resizeProperties.getInt("offsetX") * dm.density);
			int y = (int)(resizeProperties.getInt("offsetY") * dm.density);

			if (w < 50 || h < 50) {
				dispatchMraidError("Invalid width or height value", "setResizeProperties");
				return;
			}

			String closePosition = resizeProperties.optString("customClosePosition", "top-right");
			if (!closePositionOptions.contains(closePosition)) {
				logger.warn("Unknonw customClosePosition " + closePosition + ", set to default top-right");
				closePosition = "top-right";
			}

			creativeRequiredResizeWidth = w;
			creativeRequiredResizeHeight = h;
			creativeRequiredResizeOffsetX = x;
			creativeRequiredResizeOffsetY = y;

			this.customClosePosition = closePosition;
			this.allowOffscreen = resizeProperties.optBoolean("allowOffscreen", true);
		} catch (JSONException jex) {
			dispatchMraidError("Failed to parse JSON, maybe missing required parameters", "setExpandProperties");
		}
	}

	public void synchStateToPresentation(final boolean isResized) {
		mainLoopHandler.post(new Runnable() {
			@Override
			public void run() {
				HTMLRenderer.this._synchStateToPresentation(isResized);
			}
		});
	}

	private void _synchStateToPresentation(boolean isResized) {
		if (!isMRAIDAd) return;

		DisplayMetrics dm = this.activity.getResources().getDisplayMetrics();
		JSONObject expandProperties = new JSONObject();
		JSONObject resizeProperties = new JSONObject();
		JSONObject maxSize = new JSONObject();
		JSONObject screenSize = new JSONObject();
		JSONObject defaultPosition = new JSONObject();
		JSONObject currentPosition = new JSONObject();
		try {
			expandProperties.put("width", (int)(expandWidth()/dm.density))
					.put("height", (int)(expandHeight()/dm.density))
					.put("useCustomClose", this.isUseCustomClose)
					.put("isModal", true);

			if (creativeRequiredResizeWidth > 0 && creativeRequiredResizeHeight > 0) {
				resizeProperties.put("width", (int)(creativeRequiredResizeWidth/dm.density))
						.put("height", (int)(creativeRequiredResizeHeight/dm.density))
						.put("offsetX", (int)(creativeRequiredResizeOffsetX/dm.density))
						.put("offsetY", (int)(creativeRequiredResizeOffsetY/dm.density))
						.put("customClosePosition", customClosePosition)
						.put("allowOffscreen", allowOffscreen);
			}

			maxSize.put("width", (int) (getAppWidth() / dm.density))
					.put("height", (int)(getAppHeight()/dm.density));

			screenSize.put("width", (int)(getScreenWidth()/dm.density))
					.put("height", (int)(getScreenHeight()/dm.density));

			int[] appViewLocation = new int[2];
			this.getAppView().getLocationOnScreen(appViewLocation);

			int[] defaultLocation = new int[4];
			presentation.getDefaultPositionOnScreen(defaultLocation);
			defaultPosition.put("x", (int)((defaultLocation[0]-appViewLocation[0])/dm.density))
					.put("y", (int)((defaultLocation[1]-appViewLocation[1])/dm.density))
					.put("width", (int) (defaultLocation[2]/dm.density))
					.put("height", (int) (defaultLocation[3] / dm.density));

			MRAIDWebView currentView = presentation.getCurrentView();
			if (currentView != null) {
				int[] currentViewLocation = new int[2];
				currentView.getLocationOnScreen(currentViewLocation);
				currentPosition.put("x", (int)((currentViewLocation[0]-appViewLocation[0])/dm.density))
						.put("y", (int)((currentViewLocation[1]-appViewLocation[1])/dm.density))
						.put("width", (int) (currentView.getWidth()/dm.density))
						.put("height", (int)(currentView.getHeight()/dm.density));
			} else {
				currentPosition.put("x", 0).put("y", 0).put("width", 0).put("height", 0);
			}
		} catch (JSONException e) {
			logger.error(MRAIDTAG() + " error in sync MRAID state " + e.getMessage());
		}
		String jsupdate = String.format("window.mraid._Update('%s', %s, '%s', '%s', '%s', '%s', '%s', '%s', '%s', %s);",
				getPrintableState(),
				this.isViewable,
				this.placementType,
				expandProperties,
				resizeProperties,
				maxSize,
				screenSize,
				defaultPosition,
				currentPosition,
				isResized);
		logger.debug(MRAIDTAG() + " synchStateToPresentation(script='" + jsupdate + "'");
		presentation.runJavaScript(jsupdate);
	}

	private void failWithError(String errorCode, String errorMessage) {
		logger.error(CLASSTAG() + " failWithError errorCode:" + errorCode + ", errorMessage:" + errorMessage);
		Bundle info = new Bundle();
		info.putString(this.constants.INFO_KEY_ERROR_CODE(), errorCode);
		info.putString(this.constants.INFO_KEY_ERROR_INFO(), errorMessage);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(this.constants.INFO_KEY_EXTRA_INFO(), info);
		this.rendererContext.dispatchEvent(this.constants.EVENT_ERROR(), map);
	}

	@Override
	public void load(IRendererContext rendererContext) {
		final IRendererContext rendererContextFinalRef = rendererContext;
		rendererContext.getActivity().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				_load(rendererContextFinalRef);
			}
		});
	}

	private void _load(IRendererContext rendererContext) {
		logger.info("load");

		this.rendererContext = rendererContext;
		this.constants = rendererContext.getConstants();
		this.slot = rendererContext.getAdInstance().getSlot();
		this.activity = rendererContext.getActivity();
		this.mainLoopHandler = new Handler(Looper.getMainLooper());

		DisplayMetrics dm = this.activity.getResources().getDisplayMetrics();
		logger.debug("Display size: " + dm.widthPixels + "x" + dm.heightPixels + " px, app size: " + getAppWidth() + "x" + getAppHeight());

		String createApi = rendererContext.getAdInstance().getActiveCreativeRendition().getCreativeAPI();
		isMRAIDAd = createApi.toLowerCase().contains(Constants.MOBILE_RICH_MEDIA_AD_INTERFACE_DEFINITIONS);
		logger.debug("creativeApi: " + createApi + ", isMRAIDAd:" + isMRAIDAd);

		parameters = new Parameters(rendererContext);
		placementType = parameters.placementType;
		if (placementType == null) {
			String baseUnit = rendererContext.getAdInstance().getActiveCreativeRendition().getBaseUnit();
			if (BASE_UNIT_INTERSTITIAL.equalsIgnoreCase(baseUnit)) {
				placementType = PLACEMENT_TYPE_INTERSTITIAL;
			} else {
				placementType = PLACEMENT_TYPE_INLINE;
			}
		}

		if (PLACEMENT_TYPE_INTERSTITIAL.equalsIgnoreCase(placementType)) {
			isInterstitial = true;
		} else if (PLACEMENT_TYPE_INLINE.equalsIgnoreCase(placementType)) {
			isInterstitial = false;
		} else {
			logger.debug("Invalid placement type:" + placementType + ", use inline type as default");
			isInterstitial = false;
			placementType = PLACEMENT_TYPE_INLINE;
		}
		logger.debug("isInterstitial:" + isInterstitial);

		if (isInterstitial) {
			presentation = new MRAIDPresentationInterstitial(activity, this, this.isMRAIDAd);
		} else {
			presentation = new MRAIDPresentationInLine(activity, this, this.rendererContext, this.isMRAIDAd);
		}

		IConstants.TimePositionClass tpc = slot.getSlotTimePositionClass();
		if (!this.isInterstitial && this.isMRAIDAd) {
			rendererContext.setSupportedAdEvent(constants.EVENT_AD_ACCEPT_INVITATION(), true);
			rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLOSE(), true);
			rendererContext.setSupportedAdEvent(constants.EVENT_AD_EXPAND(), true);
			rendererContext.setSupportedAdEvent(constants.EVENT_AD_COLLAPSE(), true);
		} else if (this.isInterstitial && tpc == IConstants.TimePositionClass.OVERLAY) {
			this.failWithError(constants.ERROR_INVALID_SLOT(), "The interstitial ad is not supported in overlay slot");
			return;
		}
		if (tpc == IConstants.TimePositionClass.DISPLAY || tpc == IConstants.TimePositionClass.OVERLAY){
			shouldPauseResumeMainVideoOnActivityStateChange = true;
			if (!this.isInterstitial && this.isMRAIDAd) {
				shouldPauseResumeMainVideoWhenExpand = true;
			}
		}
		logger.debug("shouldPauseResumeMainVideoOnActivityStateChange:" + shouldPauseResumeMainVideoOnActivityStateChange
				+ ", shouldPauseResumeMainVideoWhenExpand:" + shouldPauseResumeMainVideoWhenExpand);

		Boolean pval = parameters.shouldEndAfterDuration;
		this.shouldEndAfterDuration = pval && (isInterstitial || (tpc != IConstants.TimePositionClass.DISPLAY));

		if (this.shouldEndAfterDuration) {
			this.duration = rendererContext.getAdInstance().getActiveCreativeRendition().getDuration();
			headTime = new AtomicInteger(0);
			this.rendererTimer = new RendererTimer((int) this.duration, this);
		}

		ICreativeRenditionAsset creativeRenditionAsset = rendererContext.getAdInstance().getActiveCreativeRendition()
				.getPrimaryCreativRenditionAsset();
		String url = (creativeRenditionAsset != null) ? creativeRenditionAsset.getURL() : null;
		if (url != null && url.length() != 0) {
			// load content using url as a creative
			presentation.loadCreativeWithScript(url, null, null);
		} else {
			String content = (creativeRenditionAsset != null) ? creativeRenditionAsset.getContent() : null;
			if (content != null && content.length() != 0) {
				content = content.replaceFirst("[\\s,]*target-densitydpi = device-dpi[\\s]*", "");
				presentation.loadCreativeWithScript(null, content, null);
			} else { // no creative asset
				this.failWithError(constants.ERROR_NULL_ASSET(), "No creative asset");
				return;
			}
		}
		rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());
	}

	@Override
	public void start() {
		logger.info(CLASSTAG() + "start");
		mainLoopHandler.post(new Runnable() {
			public void run() {
				activityCallbackListener = new IActivityStateChangeCallbackListener() {
					@Override
					public void onActivityStateChanged(IConstants.ActivityState activityState) {
						logger.debug("onActivityStateChange " + activityState);
						if (activityState == IConstants.ActivityState.PAUSED) {
							logger.info("context activity paused");
							if (rendererTimer != null)
								rendererTimer.pause();
						} else if (activityState == IConstants.ActivityState.RESUMED) {
							logger.info("context activity resumed");
							if ( (isInState(MRAIDState.DEFAULT) || isInState(MRAIDState.RESIZED)) && rendererTimer != null) {
								rendererTimer.resume();
							}
							if (shouldPauseResumeMainVideoOnActivityStateChange
									&& pauseNotificationSentWhenExternalBrowserOpened) {
								logger.debug("Request timeline to resume");
								rendererContext.requestTimelineResume();
								pauseNotificationSentWhenExternalBrowserOpened = false;
							}
							// For enhancing user experience, show overlay as
							// quickly as possible
							if (presentation != null
									&& slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY
									&& isInState(MRAIDState.DEFAULT)){
								presentation.refresh();
							}
							if (isMRAIDAd){
								switch(stateOfExternalWebBrowserActivity){
									case 0:
										logger.debug("No opened external web browser");
										break;
									case 1:
										logger.debug("External web browser resumed without followed MRAID.close, the renderer will be going on.");
										stateOfExternalWebBrowserActivity = 0;
										break;
									case 2:
										logger.debug("External web browser resumed after MRAID.close, so it will continue MRAID.close.");
										stateOfExternalWebBrowserActivity = 0;
										mraidClose();
										break;
									default:
										logger.warn("Impossible state of external web browser:" + stateOfExternalWebBrowserActivity);
										break;
								}
							}
						}
					}
				};
				rendererContext.addOnActivityStateChangedListener(activityCallbackListener);
				if (isInterstitial) {
					rendererContext.requestTimelinePause();
				}
				presentation.show();
				showedPresentation = true;
				rendererContext.dispatchEvent(constants.EVENT_AD_STARTED());
			}
		});
		if (this.rendererTimer != null && !this.isMRAIDAd) {
			this.rendererTimer.start();
		}
	}

	@Override
	public void pause() {
		logger.info(CLASSTAG() + " pause");
		if (this.rendererTimer != null)
			this.rendererTimer.pause();
	}

	@Override
	public void resume() {
		logger.info(CLASSTAG() + " resume");
		if (this.rendererTimer != null)
			this.rendererTimer.resume();
	}

	private boolean isStopped = false;

	private void _stop() {
		logger.info(CLASSTAG() + " _stop, isStopped=" + isStopped);
		if (isInterstitial) {
			rendererContext.requestTimelineResume();
		}
		if (isStopped)
			return;
		isStopped = true;
		HTMLRenderer.this.transferTo(MRAIDState.HIDDEN);
	}

	@Override
	public void stop() {
		logger.info(CLASSTAG() + " stop");
		mainLoopHandler.post(new Runnable() {
			public void run() {
				if (isInState(MRAIDState.EXPANDED) || isInState(MRAIDState.RESIZED)) {
					transferTo(MRAIDState.DEFAULT);
				}
				_stop();
			}
		});
	}

	@Override
	public void dispose() {
		logger.info(CLASSTAG() + " dispose");
		this.stop();
	}

	// MRAID bridge methods
	public void mraidLoaded() {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._loaded();
			}
		});
	}

	@JavascriptInterface
	public void mraidOpen(final String url) {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._open(url);
			}
		});
	}

	@JavascriptInterface
	public void mraidClose() {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._close();
			}
		});
	}

	@JavascriptInterface
	public void mraidUseCustomClose(final boolean use) {
		mainLoopHandler.post(new Runnable() {
			@Override
			public void run() {
				HTMLRenderer.this._useCustomClose(use);
			}
		});
	}

	@JavascriptInterface
	public void mraidExpand() {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._expand();
			}
		});
	}

	@JavascriptInterface
	public void mraidExpand(final String url) {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._expand(url);
			}
		});
	}

	@JavascriptInterface
	public void setExpandProperties(final String propJsonString) {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._setExpandProperties(propJsonString);
			}
		});
	}

	@JavascriptInterface
	public void setResizeProperties(final String propJsonString) {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._setResizeProperties(propJsonString);
			}
		});
	}

	@JavascriptInterface
	public void mraidResize() {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._resize();
			}
		});
	}

	@JavascriptInterface
	public void playVideo(String uri) {
		if (uri == null || uri.isEmpty()) {
			this.dispatchMraidError("Empty uri", "playVideo");
			return;
		}

		Uri u = Uri.parse(uri);
		Intent intent = new Intent(Intent.ACTION_VIEW, u);
		try {
			this.activity.startActivity(intent);
		} catch (ActivityNotFoundException e) {
			this.dispatchMraidError("No external player for playing video " + uri, "playVideo");
		}
	}

	@JavascriptInterface
	public void storePicture(String uri) {
		// If the device does not have a native “add photo” confirmation handler,
		// the SDK should treat the device as though it does not support storePicture.
	}

	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZ");
	private Long parseDateString(String dateString) {
		String s;
		if (dateString.charAt(dateString.length() - 1) == 'Z') {
			s = dateString;
		} else {
			s = dateString.substring(0, dateString.length() - 5) + dateString.substring(dateString.length() - 5).replace(":", "");
		}
		try {
			Date date = dateFormat.parse(s);
			return date.getTime();
		} catch (ParseException e) {
			return System.currentTimeMillis();
		}
	}

	@JavascriptInterface
	public void createCalendarEvent(String eventJsonString) {
		logger.info(MRAIDTAG() + " createCalendarEvent(" + eventJsonString + ")");
		try {
			JSONObject eventJson = new JSONObject(eventJsonString);
			Intent intent;
			intent = new Intent(Intent.ACTION_INSERT, Uri.parse("content://com.android.calendar/events"));
			// replace string values with constants when target >= API 14
			intent.putExtra("title", eventJson.optString("description"))
					.putExtra("eventLocation", eventJson.optString("location"))
					.putExtra("description", eventJson.optString("summary"))
					.putExtra("beginTime", parseDateString(eventJson.optString("start")))
					.putExtra("endTime", parseDateString(eventJson.optString("end")))
					.putExtra("rrule", eventJson.optString("recurrence"));
			this.activity.startActivity(intent);
		} catch (JSONException e) {
			this.dispatchMraidError("Parse error", "createCalendarEvent");
		} catch (ActivityNotFoundException e) {
			this.dispatchMraidError("Not supported", "createCalendarEvent");
		}
	}

	public void mraidLoadFail(final int errorCode, final String description) {
		mainLoopHandler.post(new Runnable() {
			public void run() {
				HTMLRenderer.this._loadFail(errorCode, description);
			}
		});
	}

	public Parameters parameters() {
		return this.parameters;
	}

	public boolean shouldOverrideUrlLoading(WebView view, String url) {
		logger.debug("shouldOverrideUrlLoading for url: " + url);
		// logic follows iOS HTMLRenderer shouldStartLoadWithRequest:
		if (view.getHitTestResult() != null && view.getHitTestResult().getType() > 0 && !this.isMRAIDAd) {
			// From a user click, handle it yourself.
			// FIXME: but if href is "javascript:...." it returns 0

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_URL(), url);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(constants.INFO_KEY_EXTRA_INFO(), info);
			rendererContext.dispatchEvent(constants.EVENT_AD_CLICK(), map);
			return true;
		} else {
			// Nothing clicked, assumed to be a redirect, let it
			// redirect.
			return false;
		}
	}

	@Override
	public double getDuration() {
		return this.duration;
	}

	@Override
	public double getPlayheadTime() {
		return this.headTime.get();
	}

	@Override
	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<String, String>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	// IRendererTimerService methods
	@Override
	public void playHeadTime(int headTime) {
		this.headTime.set(headTime);
	}

	@Override
	public void timeOut() {
		this.stop();
	}

	@Override
	public View getAdView(){
		return presentation.getCurrentView();
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}
	// Open external web browser
	private void startWebBrowser(String url) {
		logger.debug(CLASSTAG() + " startWebBrowser(" + url + ")");
		if (url == null || url.length() == 0){
			return;
		}
		if (this.isMRAIDAd){
			if(stateOfExternalWebBrowserActivity != 0) {
				logger.debug(CLASSTAG() + " It's already opened an external web browser.");
				return;
			}
			stateOfExternalWebBrowserActivity = 1;
		}

		if (shouldPauseResumeMainVideoOnActivityStateChange) {
			logger.debug("Request timeline to pause");
			rendererContext.requestTimelinePause();
			pauseNotificationSentWhenExternalBrowserOpened = true;
		}

		Bundle info = new Bundle();
		info.putString(constants.INFO_KEY_URL(), url);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		this.rendererContext.dispatchEvent(this.constants.EVENT_AD_CLICK(), map);
	}

	@Override
	public void resize() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setVolume(float value) {

	}

	public static boolean isIntentAvailable(Context context, Intent intent) {
		return !context.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY).isEmpty();
	}

	private void setMraidFeatures() {
		String js = "window.mraid._setSupportingFeatures("
				+ isIntentAvailable(this.activity, new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))) + ", "
				+ isIntentAvailable(this.activity, new Intent(Intent.ACTION_VIEW, Uri.parse("tel:"))) + ", "
				+ "false, "
				+ "false, "
				+ presentation.supportsInlineVideo()
				+ ");";
		logger.debug(MRAIDTAG() + " setMraidFeatures(script='" + js + "'");
		presentation.runJavaScript(js);
	}

	public void dispatchMraidError(String message, String action) {
		logger.debug(MRAIDTAG() + " Dispatch MRAID error (" + message + ", " + action + ")");
		String js = "window.mraid.dispatchEvent('error', '" + message + "', '" + action + "');";
		presentation.runJavaScript(js);
	}
}
