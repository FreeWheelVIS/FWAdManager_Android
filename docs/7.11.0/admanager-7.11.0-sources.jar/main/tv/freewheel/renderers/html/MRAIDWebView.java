package tv.freewheel.renderers.html;

import tv.freewheel.ad.Constants;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.URIUtil;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.io.IOException;
import java.net.HttpURLConnection;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Message;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.media.MediaPlayer;
import android.widget.VideoView;
import android.graphics.Bitmap;
import android.webkit.JavascriptInterface;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.InputStreamReader;

final class MRAIDWebView extends WebView implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
	private final String bridgeNameInJs = "FW_MRAID_RENDERER";
	private final String loggerBridgeNameInJs = "FW_LOGGER";
	private static final int ERROR_CODE_ON_LOAD_CHECK = 100;
	private String baseURL = "";

	private HTMLRenderer bridge = null;

	// for inline beta view, it is false
	private boolean withLoadedCallBack = true;

	// used only for onKeyDown
	private boolean isFullScreen = false;
	private boolean enableMRAID = true;
	private boolean pageLoaded = false;
	private boolean pageShown = false;
	private Activity activity = null;
	private WebChromeClient webChromeClient = null;
	private MRAIDBackgroundView fullScreenBackgroundView = null;
	private View customView = null;
	private VideoView customVideoView = null;

	private static final Logger logger = Logger.getLogger(MRAIDWebView.class);

	void setFullScreen(boolean isFullScreen) {
		this.isFullScreen = isFullScreen;
	}

	private interface ILoggerBridge {
		@JavascriptInterface
		public void log(String s);

		@JavascriptInterface
		public void debug(String s);
	}

	private final ILoggerBridge loggerBridge = new ILoggerBridge() {
		private static final String LOGGER_PREFIX = "-console-";

		@Override
		@JavascriptInterface
		public void log(String s) {
			logger.info(LOGGER_PREFIX + s);
		}

		@Override
		@JavascriptInterface
		public void debug(String s) {
			logger.debug(LOGGER_PREFIX + s);
		}
	};

	public boolean supportsInlineVideo() {
		String description = null;
		boolean isInAccel = false;
		try {
			Method accel = this.getClass().getMethod("isHardwareAccelerated", (Class<?>[]) null);
			try {
				Object retObj = accel.invoke(this, (Object[]) null);
				if (retObj instanceof Boolean) {
					isInAccel = ((Boolean) retObj);
				}
			} catch (IllegalArgumentException e) {
				description = e.toString();
			} catch (IllegalAccessException e) {
				description = e.toString();
			} catch (InvocationTargetException e) {
				description = e.toString();
			}
		} catch (SecurityException e) {
			description = e.toString();
		} catch (NoSuchMethodException e) {
			description = e.toString();
		} finally {
			if (description != null) {
				logger.debug(description);
			}
			if (isInAccel) {
				logger.debug("using HardWare Acceleration");
			} else {
				logger.warn("No HardWare Acceleration, the inline video is not supported");
			}
		}

		return isInAccel;
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		logger.debug("onCompletion ot the video");
		this.webChromeClient.onHideCustomView();
	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		logger.debug("onError ot the video what=" + what + ",extra=" + extra);
		this.webChromeClient.onHideCustomView();
		return false;
	}

	private void init(final HTMLRenderer bridge) {
		this.bridge = bridge;
		this.setFocusable(true);
		this.setFocusableInTouchMode(true);
		this.getSettings().setJavaScriptEnabled(true);
		this.getSettings().setSaveFormData(false);
		this.getSettings().setSavePassword(false);
		this.getSettings().setSupportZoom(false);
		this.getSettings().setBuiltInZoomControls(false);
		this.getSettings().setAllowContentAccess(false);
		this.getSettings().setAllowFileAccess(false);
		this.getSettings().setAllowFileAccessFromFileURLs(false);
		this.getSettings().setAllowUniversalAccessFromFileURLs(false);
		this.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
		this.getSettings().setGeolocationEnabled(false);
		this.webChromeClient = new WebChromeClient() {
			@Override
			public View getVideoLoadingProgressView() {
				logger.debug("getVideoLoadingProgressView");
				ProgressBar bar = new ProgressBar(MRAIDWebView.this.getContext());
				return bar;
			}

			@Override
			public void onConsoleMessage(String message, int lineNumber, String sourceID) {
				logger.debug(message + " -- From line " + lineNumber + " of " + sourceID);
			}

			private ViewGroup holder = null;
			private CustomViewCallback customViewCallback = null;
			private SurfaceView customSurfaceView = null;

			@Override
			public void onShowCustomView(final View view, CustomViewCallback callback) {
				logger.debug("onShowCustomView");
				super.onShowCustomView(view, callback);
				if (customVideoView != null) {
					logger.debug("The custom video is alive, no need to show it again");
					return;
				}

				if (view instanceof FrameLayout) {
					FrameLayout layout = (FrameLayout) view;
					View player = layout.getFocusedChild();
					if (player instanceof VideoView) {
						customVideoView = (VideoView) layout.getFocusedChild();
						customVideoView.setOnCompletionListener(MRAIDWebView.this);
						customVideoView.setOnErrorListener(MRAIDWebView.this);
					} else {
						if (player instanceof SurfaceView) {
							logger.debug("The custom view is surface view.");
							customSurfaceView = (SurfaceView) player;
							customSurfaceView.setZOrderMediaOverlay(true);
						} else {
							customSurfaceView = null;
						}
						customVideoView = null;
					}
				} else
					customVideoView = null;

				customView = view;
				customViewCallback = callback;

				holder = (ViewGroup) MRAIDWebView.this.getParent();
				int idx = 0;
				fullScreenBackgroundView.showFullScreenBackground();
				holder = fullScreenBackgroundView;

				FrameLayout.LayoutParams p;
				p = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT,
						FrameLayout.LayoutParams.FILL_PARENT);
				MRAIDWebView.this.setVisibility(INVISIBLE);
				holder.addView(view, idx, p); // position 0 was held by webView
				holder.bringToFront();
			}

			@Override
			public void onHideCustomView() {
				logger.debug("onHideCustomView");
				if (customView == null)
					return;
				MRAIDWebView.this.setVisibility(VISIBLE);
				customViewCallback.onCustomViewHidden();
				if (holder != null) {
					holder.removeView(customView);
				}
				customView = null;
				customVideoView = null;
				holder = null;

				customViewCallback = null;
				fullScreenBackgroundView.hideFullScreenBackground();

				MRAIDWebView.this.requestFocus();
			}
		};

		this.setWebChromeClient(this.webChromeClient);

		if (this.enableMRAID) {
			this.fullScreenBackgroundView = new MRAIDCustomViewBackgroundView(activity, webChromeClient);
		} else {
			this.fullScreenBackgroundView = new MRAIDBackgroundView(activity);
		}

		if (this.enableMRAID) {
			logger.debug("enabling MRAID for the webView");
			this.addJavascriptInterface(this.loggerBridge, loggerBridgeNameInJs);
			this.addJavascriptInterface(this.bridge, bridgeNameInJs);
		}

		Boolean pval = bridge.parameters().shouldBackgroundTransparent;
		if (pval != null && pval) {
			logger.debug("enabling transparent: " + bridge.parameters().bootstrap);
			this.setBackgroundColor(Color.TRANSPARENT);
			this.setBackgroundDrawable(null);

			try {
				Method method = View.class.getMethod("setLayerType", int.class, Paint.class);
				method.invoke(this, 1, new Paint()); // 1 = LAYER_TYPE_SOFTWARE (API11)
			} catch (Exception e) {
				logger.error(e.toString());
			}
			// NOTICE: http://stackoverflow.com/questions/5003156/android-webview-style-background-colortransparent-ignored-on-android-2-2
			// NOTICE: http://stackoverflow.com/questions/9282333/transparent-webview-not-working-on-android-v4-0
		}

		this.setWebViewClient(new WebViewClient() {
			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				logger.error("onReceivedError, failingUrl:" + failingUrl + ", description:" + description);
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (!pageLoaded) {
					bridge.mraidLoadFail(errorCode, description);
				}
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				logger.debug("onPageStarted, url=" + url);
				pageLoaded = false;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				logger.debug("onPageFinished, url=" + url + ", withLoadedCallBack=" + withLoadedCallBack);
				super.onPageFinished(view, url);
				pageLoaded = true;
				setBaseURL(url);
				tryTriggerLoaded();
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				logger.debug("shouldOverrideUrlLoading, url=" + url);
				return bridge.shouldOverrideUrlLoading(view, url);
			}

			@Override
			public void onScaleChanged(WebView view, float oldScale, float newScale) {
				logger.debug("onScaleChanged, oldScale=" + oldScale + ", newScale=" + newScale);
				super.onScaleChanged(view, oldScale, newScale);
			}

			@Override
			public void onTooManyRedirects(WebView view, Message cancelMsg, Message continueMsg) {
				logger.debug("onTooManyRedirects, cancel message:" + cancelMsg);
				super.onTooManyRedirects(view, cancelMsg, continueMsg);
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				logger.debug("onLoadResource, url:" + url);
				super.onLoadResource(view, url);
			};
		});

		if (this.withLoadedCallBack) {
			this.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {
					MRAIDWebView.this.getViewTreeObserver().removeGlobalOnLayoutListener(this);
					pageShown = true;
					tryTriggerLoaded();
				}
			});
		}
	}

	public MRAIDWebView(Activity activity, HTMLRenderer delegate, boolean withLoadedCallBack, boolean enableMRAID) {
		super(activity);

		this.activity = activity;
		this.withLoadedCallBack = withLoadedCallBack;
		this.enableMRAID = enableMRAID;
		this.init(delegate);
	}

	public void runJavaScript(final String script) {
		logger.debug("runJavaScript(" + script + ")");
		if (script != null && script.length() != 0)
			super.loadUrl("javascript:" + script);
	}

	public void resize(int width, int height) {
		logger.debug("resize(" + width + "," + height + ")");
		ViewGroup.LayoutParams lp = getLayoutParams();
		lp.width = width;
		lp.height = height;
		requestLayout();
	}

	public void dispose() {
		logger.debug("dispose");
		this.setWebChromeClient(null);
		this.setWebViewClient(null);
		this.runJavaScript("window.mraid.detachBridgeInterface();");
		super.loadUrl("about:blank");
	}

	private void setBaseURL(String urlString) {
		logger.debug("setBaseURL(" + urlString + ")");
		if (urlString == null || urlString.trim().length() == 0)
			return;
		if (!URLUtil.isHttpUrl(urlString) && !URLUtil.isHttpsUrl(urlString))
			return;

		URL url = null;
		try {
			url = new URL(urlString);
		} catch (MalformedURLException e) {
			logger.debug(e.toString());
			return;
		}

		if (url != null && url.getProtocol() != null) {
			baseURL = url.getProtocol();
			baseURL += "://";
			baseURL += url.getAuthority() != null ? url.getAuthority() : "";
			String path = url.getPath();
			if (path == null) {
				path = "";
			} else {
				int idx = path.lastIndexOf("/");
				if (idx >= 0) {
					path = path.substring(0, idx);
				}
			}
			baseURL += path + "/";
		}
		logger.debug("base url:" + baseURL);
		return;
	}

	String URLWithBaseURL(String url) {
		if (url == null || url.trim().length() == 0)
			return baseURL;
		logger.debug("URLWithBaseURL: url passed in: " + url);
		url = url.trim();

		URI uri = null; // use URI because open can use a few kind of uri
		try {
			uri = new URI(url);
		} catch (URISyntaxException e) {
			try {
				String tmp = URIUtil.getFixedString(url);
				// "http://www.freewheel.tv/ test" will be fixed with %20
				// while "/ test" will be null
				if (tmp == null) {
					// most of the time, it's just path part.
					tmp = new URI(null, null, url, null).toString();
				}
				uri = new URI(tmp);
			} catch (URISyntaxException f) {
				logger.debug(f.getMessage());
			}
		}

		if (uri == null) {
			return null;
		} else if (uri.isAbsolute()) {
			return uri.toString();
		} else {
			try {
				return new URL(new URL(baseURL), uri.toString()).toString();
			} catch (MalformedURLException e) {
				logger.debug(e.getMessage());
				return null;
			}
		}
	}

	@Override
	public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String failUrl) {
		logger.debug("loadDataWithBaseURL");
		if (baseUrl == null || baseUrl.trim().length() == 0) {
			baseUrl = IMRAIDPresentation.FW_ASSET_CONTENT_HTML_BASE_URL;
		}
		this.baseURL = baseUrl + "/";
		super.loadDataWithBaseURL(baseUrl, data, mimeType, encoding, failUrl);
	}

	private String injectScriptToHTML(String html, String script) {
		logger.debug("Inject script into html: " + html);
		String js = "";
		if (script == null) {
			script = "";
		}
		if (this.enableMRAID) {
			js = MRAIDConstants.MRAID_JS + "\n" + script + "\n";
		}
		if (this.bridge.parameters().bootstrap != null && bridge.parameters().bootstrap.length() > 0) {
			logger.debug("bootstrap js code: " + this.bridge.parameters().bootstrap);
			js += this.bridge.parameters().bootstrap;
		}
		js = "<script type=\"text/javascript\">" + js + "</script>\n";

		int insertPos = html.indexOf("<head>");
		if(insertPos < 0) {
			insertPos = html.indexOf("<script>");
			insertPos = insertPos < 0? 0 : insertPos - 1;
		} else {
			insertPos += 6;
		}
		return insertPos == 0? js + html : html.substring(0, insertPos) + js + html.substring(insertPos);
	}

	private class DownloadHTMLContentTask extends AsyncTask<String, Void, String> {
		private Boolean fail = true;
		private String script = "";
		private String url = "";

		@Override
		protected String doInBackground(String... urls) {
			script = urls[1];
			String urlString = urls[0];
			String description = "";
			String htmlContent = "";
			if (URLUtil.isValidUrl(urlString)) {
				this.url = urlString;
				HttpURLConnection conn = null;
				int redirectCount = 0;
				try {
					do {
						URL urlObject = new URL(urlString);
						conn = (HttpURLConnection) (urlObject.openConnection());
						conn.setInstanceFollowRedirects(false);
						conn.connect();
						if (conn.getResponseCode() != 302) {
							BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
							String line = "";
							while ((line = reader.readLine()) != null) {
								htmlContent += line + "\n";
							}
							reader.close();
							fail = false;
							break;
						} else {
							urlString = conn.getHeaderField(Constants._URL_LOCATION);
							redirectCount ++;
						}
						conn.disconnect();
						conn = null;
					} while (redirectCount <= 3);
				} catch (MalformedURLException e) { // URL threw
					description = e.toString();
				} catch (IOException e) { // getContent IO exception
					description = "Failed to get content from creative url." + e.toString();
					if (conn != null) {
						conn.disconnect();
					}
				}
			} else {
				description = "Invalid url:" + urlString;
			}

			return fail? description : htmlContent;
		}

		@Override
		protected void onPostExecute(String result) {
			if (fail) {
				MRAIDWebView.logger.error(result);
				MRAIDWebView.this.bridge.mraidLoadFail(ERROR_CODE_ON_LOAD_CHECK, result);
			} else {
				String htmlcontent = MRAIDWebView.this.injectScriptToHTML(result, "");
				MRAIDWebView.this.loadDataWithBaseURL(this.url, htmlcontent, "text/html", "utf8", null);
			}
		}
	}

	public void loadCreativeWithScript(final String creativeUrl, final String creativeContent, final String script) {
		logger.debug("load creative url: " + creativeUrl + " or content: " + creativeContent + " with script:" + script);

		if (creativeUrl == null || creativeUrl.trim().length() == 0) {
			String htmlcontent = MRAIDWebView.this.injectScriptToHTML(creativeContent, script);
			this.loadDataWithBaseURL(null, htmlcontent, "text/html", "utf8", null);
		} else {
			new DownloadHTMLContentTask().execute(new String[]{creativeUrl, script});
		}
	}

	public void closeCustomView() {
		logger.debug("closeCustomView");
		try {
			if (customVideoView != null) {
				customVideoView.stopPlayback();
			}
			if (customView != null) {
				webChromeClient.onHideCustomView();
			}
		} catch (Throwable e) {
			logger.debug(e.toString());
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		logger.debug("onKeyDown,keyCode:" + keyCode + ", isFullScreen:" + isFullScreen);
		if (!isFullScreen) {
			return false;
		}
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			bridge.mraidClose();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onAttachedToWindow() {
		logger.debug("onAttachedToWindow");
		super.onAttachedToWindow();
		boolean flag = this.supportsInlineVideo();
		logger.info("Android API level " + Build.VERSION.SDK_INT + ", hardware acceleration " + flag);
	}

	private synchronized void tryTriggerLoaded() {
		if (withLoadedCallBack && enableMRAID && pageLoaded && pageShown) {
			bridge.mraidLoaded();
		}
	}
}
