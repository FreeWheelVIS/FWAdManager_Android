package tv.freewheel.renderers.html;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import tv.freewheel.utils.Logger;

abstract class MRAIDBasePresentation implements IMRAIDPresentation{
	protected Activity activity;
	protected HTMLRenderer bridge;
	protected Boolean enableMRAID = true;
	protected MRAIDBackgroundView fullScreenBaseView = null;

	private View viewOnFullScreen;
	private FrameLayout viewHolder;

	// in case of orientation change
	protected int getFullScreenWidth() {
		return this.activity.getResources().getDisplayMetrics().widthPixels;
	}

	protected int getFullScreenHeight() {
		return this.activity.getResources().getDisplayMetrics().heightPixels;
	}

	private static final int CLOSE_BUTTON_ALPHA_VALUE_INVISIBLE = 0;
	private static final int CLOSE_BUTTON_ALPHA_VALUE_VISIBLE = 255;

	private boolean isCloseButtonVisible = true;
	protected ImageButton closeButton = null;

	private static final Logger logger = Logger.getLogger(MRAIDBasePresentation.class);

	public void setCloseButtonVisibility(boolean isVisible) {
		logger.info("setCloseButtonVisibility(" + isVisible + ")");
		if (this.enableMRAID) {
			if (isCloseButtonVisible != isVisible) {
				isCloseButtonVisible = isVisible;
				if (isCloseButtonVisible) {
					closeButton.setAlpha(CLOSE_BUTTON_ALPHA_VALUE_VISIBLE);
					closeButton.invalidate();
				} else {
					closeButton.setAlpha(CLOSE_BUTTON_ALPHA_VALUE_INVISIBLE);
					closeButton.invalidate();
				}
			} else {
				logger.debug("The closeButtonVisibility is the same as the value set by outside, ignored.");
			}
		} else {
			logger.info("setCloseButtonVisibility doesn't work when MRAID disabled.");
		}
	}

	MRAIDBasePresentation(Activity activity, HTMLRenderer bridge, boolean enableMRAID) {
		this.activity = activity;
		this.bridge = bridge;
		this.enableMRAID = enableMRAID;
		this.fullScreenBaseView = new MRAIDBackgroundView(activity);
		this.viewHolder = new FrameLayout(this.fullScreenBaseView.getContext());
		if (bridge.parameters().shouldBackgroundTransparent != null && bridge.parameters().shouldBackgroundTransparent) {
			this.viewHolder.setBackgroundColor(Color.TRANSPARENT);
		}
		if (this.enableMRAID) {
			this.closeButton = new ImageButton(activity);
			closeButton.setImageResource(android.R.drawable.ic_notification_clear_all);
			closeButton.setBackgroundColor(Color.TRANSPARENT);
			closeButton.setPadding(0, 0, 0, 0);
		}
	}

	protected void addView(View view, int width, int height) {
		logger.debug("addView");
		fullScreenBaseView.showFullScreenBackground();
		FrameLayout.LayoutParams fl = null;
		int w = (width >= getFullScreenWidth()) ? FrameLayout.LayoutParams.FILL_PARENT : width;
		int h = (height >= getFullScreenHeight()) ? FrameLayout.LayoutParams.FILL_PARENT : height;
		fl = new FrameLayout.LayoutParams(w, h);
		fl.gravity = Gravity.CENTER;
		this.fullScreenBaseView.addView(viewHolder, 0, fl);
		viewHolder.addView(view, FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);

		if (enableMRAID) {
			closeButton.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					MRAIDBasePresentation.this.bridge.mraidClose();
				}
			});
			FrameLayout.LayoutParams cbfl = new FrameLayout.LayoutParams(50, 50);
			cbfl.gravity = Gravity.TOP | Gravity.RIGHT;
			viewHolder.addView(closeButton, cbfl);
		}
		viewHolder.bringToFront();
		view.requestFocus();
		this.viewOnFullScreen = view;
	}

	protected void addView(MRAIDWebView view) {
		this.addView(view, this.getFullScreenWidth(), this.getFullScreenHeight());
	}

	protected void removeView() {
		logger.debug("removeView");
		fullScreenBaseView.hideFullScreenBackground();
		this.fullScreenBaseView.removeView(this.viewHolder);
		if (enableMRAID) {
			this.closeButton.setOnClickListener(null);
			this.viewHolder.removeView(closeButton);
		}
		this.viewHolder.removeView(this.viewOnFullScreen);
	}

	@Override
	public boolean supportsInlineVideo() {
		MRAIDWebView currentView = this.getCurrentView();
		if (currentView == null) {
			return false;
		}

		return currentView.supportsInlineVideo();
	}

	@Override
	public void resize(int offsetX, int offsetY, int width, int height, String customClosePosition, boolean allowOffscreen) {
		this.bridge.dispatchMraidError("Not supported", "resize");
	}

	protected void setEnableSync(final View view, final boolean isResized) {
		view.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
			@Override
			public void onGlobalLayout() {
				view.getViewTreeObserver().removeGlobalOnLayoutListener(this);
				bridge.synchStateToPresentation(isResized);
			}
		});
	}
}
