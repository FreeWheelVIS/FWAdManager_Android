package tv.freewheel.renderers.html;

import android.app.Activity;
import tv.freewheel.utils.Logger;

class MRAIDPresentationInterstitial extends MRAIDBasePresentation {
	private MRAIDWebView interstitialView;
	private static final Logger logger = Logger.getLogger(MRAIDPresentationInterstitial.class);
	
	public MRAIDPresentationInterstitial(Activity activity,HTMLRenderer bridge, boolean enableMRAID) {
		super(activity,bridge, enableMRAID);
		this.interstitialView = new MRAIDWebView(activity,bridge, true, enableMRAID);
		this.interstitialView.setFullScreen(true);//for handling back key event
	}

	@Override
	public void loadCreativeWithScript(String url, String content, String script) {
		logger.info("loadCreativeWithScript(" + url + ", " + content + "," + script + ")");
		this.interstitialView.loadCreativeWithScript(url, content, script);
	}

	@Override 
	public void refresh() {
		logger.info("refresh, do nothing in interstitial presentation");
	}
	
	@Override
	public void show() {
		logger.info("show");
		this.addView(this.interstitialView);

	}

	@Override
	public void expand(String url, int width, int height) {
		logger.info("expand, do nothing in interstitial presentation");
	}

	@Override
	public void collapse() {
		logger.info("collapse, do nothing in interstitial presentation");
	}

	@Override
	public void close() {
		logger.info("close");
		this.interstitialView.closeCustomView();
		this.removeView();
	}

	@Override
	public void runJavaScript(String script) {
		interstitialView.runJavaScript(script);
	}

	@Override
	public String getAbsoluteURL(String url) {
		return interstitialView.URLWithBaseURL(url);
	}

	@Override
	public MRAIDWebView getCurrentView() {
		return interstitialView;
	}

	@Override
	public void getDefaultPositionOnScreen(int[] location) {
		location[0] = 0;
		location[1] = 0;
		location[2] = this.getFullScreenWidth();
		location[3] = this.getFullScreenHeight();
	}

	@Override
	public void dispose() {
		interstitialView.dispose();
	}
}
