package tv.freewheel.renderers.html;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.app.Activity;
import android.graphics.Color;
import tv.freewheel.utils.Logger;

class MRAIDBackgroundView extends FrameLayout {
	protected Activity activity;
	private ViewGroup superRootFrame;
	private int titleParentVisibility;
	private static final Logger logger = Logger.getLogger(MRAIDBackgroundView.class);

	public MRAIDBackgroundView(Activity activity) {
		super(activity);
		this.activity = activity;
		logger.debug("MRAIDBackgroundView");
		this.setBackgroundColor(Color.argb((int)(255*0.8), 0, 0, 0));
		Object superRoot = activity.getWindow().getDecorView();
		if (superRoot != null) {
			superRootFrame = (ViewGroup) superRoot;
		} else {
			logger.error("The DecorView of the activity window is not available, full screen is not supported!");
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		logger.debug("onTouchEvent");
		return true;
	}

	void showFullScreenBackground() {
		logger.debug("showFullScreenBackground");
		if ((activity.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_FULLSCREEN) != WindowManager.LayoutParams.FLAG_FULLSCREEN) {
			activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}
		activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

		View title = activity.getWindow().findViewById(android.R.id.title);
		if (title != null && title.getParent() != null) {
			ViewGroup par = (ViewGroup) title.getParent();
			this.titleParentVisibility = par.getVisibility();
			par.setVisibility(View.GONE);
		}
		ViewGroup.LayoutParams fllp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.FILL_PARENT);
		superRootFrame.addView(this, fllp);
	}

	void hideFullScreenBackground() {
		View title = activity.getWindow().findViewById(android.R.id.title);
		if (title != null && title.getParent() != null) {
			ViewGroup par = (ViewGroup) title.getParent();
			par.setVisibility(this.titleParentVisibility);
		}

		activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		superRootFrame.removeView(this);
	}
}
