package tv.freewheel.renderers.html;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import java.util.HashMap;
import java.util.Map;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;

class MRAIDPresentationInLine extends MRAIDBasePresentation {

	private static int overlaySlotWidth = 240;
	private static int overlaySlotHeight = 50;

	private IRendererContext rendererContext;
	private ISlot slot;
	private ICreativeRendition creativeRendition;

	private FrameLayout alphaHolder;// base of alphaView
	private MRAIDWebView alphaView; // main view which also can resize or expand if URL is null
	private MRAIDWebView betaView; // expanded view with new URL

	private String expandedURL;
	private MRAIDWebView expandedViewRef;

	private int[] defaultLocation;
	private int width;
	private int height;

	private View appView;
	private FrameLayout resizeHelperView; // used for position on appView. If API level>=11, use View.setX() and View.setY().
	private FrameLayout resizeBaseView;
	private static Map<String, Integer> gravityMap = new HashMap<String, Integer>();

	static {
		gravityMap.put("top-left", Gravity.TOP | Gravity.LEFT);
		gravityMap.put("top-right", Gravity.TOP | Gravity.RIGHT);
		gravityMap.put("center", Gravity.CENTER);
		gravityMap.put("bottom-left", Gravity.BOTTOM | Gravity.LEFT);
		gravityMap.put("bottom-right", Gravity.BOTTOM | Gravity.RIGHT);
		gravityMap.put("top-center", Gravity.TOP | Gravity.CENTER_HORIZONTAL);
		gravityMap.put("bottom-center", Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
	}

	private static final Logger logger = Logger.getLogger(MRAIDPresentationInLine.class);

	public MRAIDPresentationInLine(Activity activity, HTMLRenderer bridge, IRendererContext rendererContext,
			Boolean enableMRAID) {
		super(activity, bridge, enableMRAID);
		this.rendererContext = rendererContext;
		this.slot = rendererContext.getAdInstance().getSlot();
		this.creativeRendition = rendererContext.getAdInstance().getActiveCreativeRendition();
		this.alphaView = new MRAIDWebView(activity, bridge, true, enableMRAID);
		this.alphaHolder = new FrameLayout(activity);
		if (bridge.parameters().shouldBackgroundTransparent != null && bridge.parameters().shouldBackgroundTransparent) {
			this.alphaHolder.setBackgroundColor(Color.TRANSPARENT);
		}
		this.betaView = new MRAIDWebView(activity, bridge, false, enableMRAID);

		calculateAdSize();
		defaultLocation = new int[2];
		resizeHelperView = new FrameLayout(activity) {
			@Override
			public boolean onTouchEvent(MotionEvent event) {
				return false;
			}
		};
		resizeBaseView = new FrameLayout(activity);
		resizeHelperView.addView(resizeBaseView, new FrameLayout.LayoutParams(10, 10));
		appView = activity.getWindow().findViewById(Window.ID_ANDROID_CONTENT);
	}

	private void calculateAdSize() {
		logger.debug("calculateAdSize, slot width: " + this.slot.getWidth() + ", rendition width:" + creativeRendition.getWidth());
		DisplayMetrics dm = activity.getResources().getDisplayMetrics();
		if (creativeRendition.getWidth() > 0 && creativeRendition.getHeight() > 0) {
			width = (int)(creativeRendition.getWidth() * dm.density);
			height = (int)(creativeRendition.getHeight() * dm.density);
		} else if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
			width = (int)(overlaySlotWidth * dm.density);
			height = (int)(overlaySlotHeight * dm.density);
		} else {
			width = (int)(slot.getWidth() * dm.density);
			height = (int)(slot.getHeight()* dm.density);
		}
		logger.debug("ad width = " + width + " height = " + height);
	}

	@Override
	public void loadCreativeWithScript(String url, String content, String script) {
		logger.info("loadCreativeWithScript(" + url + ", " + content + "," + script + ")");
		alphaView.loadCreativeWithScript(url, content, script);
	}

	@Override
	public void refresh() {
		logger.debug("refresh");
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
			public void run() {
				alphaHolder.bringToFront();
			}
		});
	}

	@Override
	public void show() {
		logger.debug("show");
		alphaHolder.addView(alphaView, FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);
		final ViewGroup.LayoutParams pFinalRef;
		if (slot.getSlotType() == IConstants.SlotType.TEMPORAL) {
			if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
				FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(width, height);
				p.gravity = Gravity.NO_GRAVITY;

				String ar = bridge.parameters().primaryAnchor;
				Integer mw = bridge.parameters().marginWidth;
				Integer mh = bridge.parameters().marginHeight;
				DisplayMetrics dm = activity.getResources().getDisplayMetrics();

				if (ar == null) {
					ar = "bc";
				}
				if (ar.contains("t")) {
					p.gravity |= Gravity.TOP;
					if (mh != null) {
						p.topMargin = (int)(mh * dm.density);
					}
				}
				if (ar.contains("l")) {
					p.gravity |= Gravity.LEFT;
					if (mw != null) {
						p.leftMargin = (int)(mw * dm.density);
					}
				}
				if (ar.contains("r")) {
					p.gravity |= Gravity.RIGHT;
					if (mw != null) {
						p.rightMargin = (int)(mw * dm.density);
					}
				}
				if (ar.contains("b")) {
					p.gravity |= Gravity.BOTTOM;
					if (mh != null) {
						p.bottomMargin = (int)(mh * dm.density);
					}
				}
				if (ar.contains("c")) {
					p.gravity |= Gravity.CENTER_HORIZONTAL;
				}
				if (ar.contains("m")) {
					p.gravity |= Gravity.CENTER_VERTICAL;
				}
				if (ar.equals("c") || ar.equals("m") || ar.equals("cm") || ar.equals("mc")) {
					p.gravity = Gravity.CENTER;
				}

				pFinalRef = p;
				
				logger.debug("show, overlay layout width: " + width + ", height: " + height + " ar:" + ar + ", marginWidth: " + mw + ", marginHeight: " + mh);
				
				slot.getBase().setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
					@Override
					public void onChildViewAdded(View parent, View child) {
						logger.debug("onChildViewAdded");
						if (alphaHolder != child) {
							// the video is on the overlay so bring it to front
							refresh();
						}
					}

					@Override
					public void onChildViewRemoved(View parent, View child) {
						logger.debug("onChildViewRemoved, do nothing");
					}
				});
			} else {
				FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);
				p.gravity = Gravity.CENTER;
				pFinalRef = p;
			}
		} else { // Display
			RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(width > 0 ? width : RelativeLayout.LayoutParams.WRAP_CONTENT, 
					height > 0 ? height : RelativeLayout.LayoutParams.WRAP_CONTENT);
			p.addRule(RelativeLayout.CENTER_IN_PARENT);
			pFinalRef = p;
		}
		setEnableSync(alphaHolder, false);
		slot.getBase().addView(alphaHolder, pFinalRef);
		alphaHolder.bringToFront();
	}

	@Override
	public void expand(String url, int width, int height) {
		logger.debug("expand(url:" + url + ",w=" + width + ",h=" + height + ")");
		this.expandedURL = url;
		if (url == null) {
			alphaView.setFullScreen(true);
			expandedViewRef = alphaView;
		} else {
			betaView.setFullScreen(true);
			betaView.loadCreativeWithScript(url, null, "mraid.state='expanded';");
			expandedViewRef = betaView;
		}
		if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY)
			slot.getBase().setOnHierarchyChangeListener(null);
		alphaView.closeCustomView();
		if (alphaView.getParent() == alphaHolder) {
			alphaHolder.removeView(alphaView);
		} else if (alphaView.getParent() == resizeBaseView) {
			this.closeButton.setOnClickListener(null);
			this.resizeBaseView.removeView(this.closeButton);
			this.resizeBaseView.removeView(this.alphaView);
			((ViewGroup)this.appView).removeView(resizeHelperView);
		}
		slot.getBase().removeView(alphaHolder);
		setEnableSync(expandedViewRef, false);
		super.addView(expandedViewRef, width, height);
	}

	@Override
	public void collapse() {
		logger.debug("collapse");
		if (expandedURL == null) {
			alphaView.closeCustomView();
			this.removeView();
			alphaView.setFullScreen(false);
			this.show();
			this.expandedViewRef = null;
		} else {
			logger.warn("The collapse shouldn't be called.");
		}
	}

	@Override
	public void close() {
		logger.debug("close");
		if (expandedViewRef != null) {
			logger.debug("close expanded ad view");
			betaView.closeCustomView();
			this.removeView();
			this.show();
			this.betaView.dispose();
			this.betaView = new MRAIDWebView(activity, bridge, false, enableMRAID);
			this.expandedViewRef = null;
		} else if (alphaView.getParent() == resizeBaseView) {
			logger.debug("close resized ad view");
			this.closeButton.setOnClickListener(null);
			this.resizeBaseView.removeView(this.closeButton);
			this.resizeBaseView.removeView(this.alphaView);
			((ViewGroup)this.appView).removeView(resizeHelperView);
			setEnableSync(alphaView, false);
			alphaHolder.addView(alphaView, FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);
		} else {
			logger.debug("close inline ad view");
			if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY)
				slot.getBase().setOnHierarchyChangeListener(null);
			alphaView.closeCustomView();
			alphaHolder.removeView(alphaView);
			slot.getBase().removeView(alphaHolder);
		}
	}

	@Override
	public void runJavaScript(String script) {
		alphaView.runJavaScript(script);
	}

	@Override
	public String getAbsoluteURL(String url) {
		if (this.expandedViewRef != null)
			return expandedViewRef.URLWithBaseURL(url);
		else
			return alphaView.URLWithBaseURL(url);
	}

	@Override
	public MRAIDWebView getCurrentView() {
		if (expandedViewRef != null) {
			return expandedViewRef;
		}

		if (alphaView != null) {
			return alphaView;
		}

		return null;
	}

	@Override
	public void getDefaultPositionOnScreen(int[] location) {
		if (this.alphaHolder.getWindowVisibility() != View.GONE) {
			this.alphaHolder.getLocationOnScreen(defaultLocation);
		}
		location[0] = defaultLocation[0];
		location[1] = defaultLocation[1];
		location[2] = width;
		location[3] = height;
	}

	@Override
	public void dispose() {
		this.alphaView.dispose();
		this.betaView.dispose();
	}

	@Override
	public void resize(int requestedOffsetX, int requestedOffsetY, int requestedWidth, int requestedHeight, String customClosePosition, boolean allowOffscreen) {
		ViewGroup parent = (ViewGroup)alphaView.getParent();
		if (parent == null || this.alphaHolder.getWindowVisibility() == View.GONE) {
			this.bridge.dispatchMraidError("Resize called at incorrect state", "resize");
			return;
		}

		if (appView == null || !(appView instanceof ViewGroup)) {
			this.bridge.dispatchMraidError("Could not attach view to app root view", "resize");
			return;
		}

		if (!allowOffscreen && (requestedWidth > appView.getWidth() || requestedHeight > appView.getHeight())) {
			this.bridge.dispatchMraidError("Resize parameter out of range", "resize");
			return;
		}

		int[] appLocationArr = new int[2];
		int[] defaultLocationArr = new int[2];
		this.appView.getLocationOnScreen(appLocationArr);
		this.alphaHolder.getLocationOnScreen(defaultLocationArr);

		int x = defaultLocationArr[0] - appLocationArr[0] + requestedOffsetX;
		int y = defaultLocationArr[1] - appLocationArr[1] + requestedOffsetY;

		if (!allowOffscreen) {
			if (x < 0) {
				x = 0;
			} else if (x + requestedWidth > appView.getWidth()) {
				x = appView.getWidth() - requestedWidth;
			}

			if (y < 0) {
				y = 0;
			} else if (y + requestedHeight > appView.getHeight()) {
				y = appView.getHeight() - requestedHeight;
			}
		} else {
			// allow off-screen, check close region
			int centerX = x + requestedWidth / 2;
			int centerY = x + requestedHeight / 2;

				if ( (customClosePosition.startsWith("center") && (centerY < 25 || centerY + 25 > appView.getHeight()))
						||(customClosePosition.startsWith("top") && y < 0)
						|| (customClosePosition.startsWith("bottom") && y + requestedHeight > appView.getHeight())
						|| (customClosePosition.endsWith("center") && (centerX < 25 || centerX + 25 > appView.getWidth()))
						|| (customClosePosition.endsWith("left") && x < 0)
						|| (customClosePosition.endsWith("right") && x + requestedWidth > appView.getWidth()) )
				{
					this.bridge.dispatchMraidError("Close region out of screen", "resize");
					return;
				}
		}

		parent.removeView(alphaView);

		if (this.resizeHelperView.getParent() == null) {
			((ViewGroup) this.appView).addView(resizeHelperView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
		}

		logger.debug("Resize to: (" + x + "," + y + "), size (" + requestedWidth + "x" + requestedHeight + ") pixels");
		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(requestedWidth, requestedHeight);
		lp.leftMargin = x;
		lp.topMargin = y;
		resizeBaseView.setLayoutParams(lp);

		setEnableSync(alphaView, true);
		this.resizeBaseView.addView(alphaView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));

		if (this.closeButton.getParent() != null) {
			((ViewGroup)this.closeButton.getParent()).removeView(closeButton);
		}
		setCloseButtonVisibility(true);
		this.closeButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				bridge.mraidClose();
			}
		});
		FrameLayout.LayoutParams cbfl = new FrameLayout.LayoutParams(50, 50);
		Integer gravity = gravityMap.get(customClosePosition);
		if (gravity == null) {
			gravity = Gravity.TOP | Gravity.RIGHT;
		}
		cbfl.gravity = gravity;
		this.resizeBaseView.addView(closeButton, cbfl);
		resizeHelperView.bringToFront();
	}
}
