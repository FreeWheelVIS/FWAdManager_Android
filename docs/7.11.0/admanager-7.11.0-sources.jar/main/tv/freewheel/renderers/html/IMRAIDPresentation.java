package tv.freewheel.renderers.html;

public interface IMRAIDPresentation {
	static final String FW_ASSET_CONTENT_HTML_BASE_URL ="http://m1.fwmrm.net/ad/mraid/start/";
	public void loadCreativeWithScript(String url, String content, String script);
	public void refresh();
	public void show();
	public void expand(String url, int width, int height);
	public void collapse();
	public void close();
	public void dispose();
	public void setCloseButtonVisibility(boolean visible);
	public void runJavaScript(String script);
	public String getAbsoluteURL(String url);
	public boolean supportsInlineVideo();
	public MRAIDWebView getCurrentView();
	public void getDefaultPositionOnScreen(int location[]);
	public void resize(int offsetX, int offsetY, int width, int height, String customClosePosition, boolean allowOffscreen);
}
