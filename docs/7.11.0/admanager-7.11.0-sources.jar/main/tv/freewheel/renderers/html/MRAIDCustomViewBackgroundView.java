package tv.freewheel.renderers.html;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;

import tv.freewheel.utils.Logger;

public class MRAIDCustomViewBackgroundView extends MRAIDBackgroundView {
	private ImageButton closeButton = null;
	private WebChromeClient webChromeClient = null;
	private static final Logger logger = Logger.getLogger(MRAIDCustomViewBackgroundView.class);

	public MRAIDCustomViewBackgroundView(Activity activity, WebChromeClient webChromeClient ) {
		super(activity);
		this.webChromeClient = webChromeClient;
		this.closeButton  = new ImageButton(activity);
		closeButton.setImageResource(android.R.drawable.ic_notification_clear_all);
		closeButton.setBackgroundColor(Color.TRANSPARENT);
		closeButton.setPadding(0, 0, 0, 0);
		FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(50,50);
		fl.gravity = Gravity.TOP | Gravity.RIGHT;
		this.addView(closeButton,fl);
		closeButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				logger.debug("onClick");
				MRAIDCustomViewBackgroundView.this.webChromeClient.onHideCustomView();
			}
		});
	}
}
