package tv.freewheel.renderers.temporal;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.BaseMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;

public class ExoVideoAdView extends SurfaceView
		implements IVideoAdView, SurfaceHolder.Callback {
	private ExoPlayer exoPlayer;
	private float volume = -1;
	private VideoRenderer hostRenderer;
	private String adUrl;
	protected IConstants constants;
	private SurfaceHolder surfaceHolder = null;
	private int mSurfaceWidth;
	private int mSurfaceHeight;
	private long mDuration;
	private long mSeekWhenPrepared;
	private long mLastPlayheadTime;
	private int mVideoWidth;
	private int mVideoHeight;
	private boolean preloading = false;
	private static final Logger logger = Logger.getLogger(ExoVideoAdView.class);
	private GestureDetector clickDetector;
	private int timeoutMillisecondsBeforeStart = 10000;
	private boolean errorOccurred = false;
	private boolean isPlayingTargetState = false;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		logger.debug("onTouchEvent");
		if (this.clickDetector != null && this.clickDetector.onTouchEvent(event)) {
			return true;
		}
		return super.onTouchEvent(event);
	}

	class VideoAdViewClickDetector extends GestureDetector.SimpleOnGestureListener {
		@Override
		public boolean onSingleTapConfirmed(MotionEvent e) {
			logger.debug("onSingleTapConfirmed");
			if (isInPlaybackState()) {
				hostRenderer.onAdViewClicked();
			} else if (exoPlayer != null) {
				logger.debug("ignore click if not in playback state, current state " + exoPlayer.getPlaybackState());
			}
			return true;
		}

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
			logger.debug("onFling");
			return false;
		}

		@Override
		public boolean onDown(MotionEvent e) {
			logger.debug("onDown");
			return true;
		}
	}

	public ExoVideoAdView(Context context, VideoRenderer hostRenderer, boolean shouldRequestFocus, int timeoutMillisecondsBeforeStart) {
		super(context);
		this.hostRenderer = hostRenderer;
		this.constants = hostRenderer.constants;
		this.timeoutMillisecondsBeforeStart = timeoutMillisecondsBeforeStart;

		this.initVideoView(shouldRequestFocus);
		if (!DisplayUtils.isAndroidTV(context)) {
			clickDetector = new GestureDetector(context, new VideoAdViewClickDetector());
		}

		mVideoWidth = 0;
		mVideoHeight = 0;

		this.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT, Gravity.CENTER));
	}

	private void initVideoView(boolean shouldRequestFocus) {
		logger.debug("initVideoView");
		getHolder().addCallback(this);
		getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		setFocusable(true);
		setFocusableInTouchMode(true);
		if (shouldRequestFocus) {
			requestFocus();
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		logger.debug("surfaceChanged w:" + w + " h:" + h + " mVideoWidth:" + mVideoWidth + " mVideoHeight:" + mVideoHeight);
		mSurfaceWidth = w;
		mSurfaceHeight = h;
		boolean hasValidSize = (mVideoWidth == w && mVideoHeight == h);
		if (exoPlayer != null && !exoPlayer.isPlaying() && isPlayingTargetState && hasValidSize) {
			if (mSeekWhenPrepared != 0) {
				seekTo(mSeekWhenPrepared);
			}
			start();
		}
	}

	private final Player.Listener eventListener = new Player.Listener() {

		private boolean isBuffering = false;

		@OptIn(markerClass = UnstableApi.class) public void onPlaybackStateChanged(int playbackState) {
			logger.debug("onPlaybackStateChanged(" + playbackState + ")");
			if (playbackState == Player.STATE_READY && isBuffering) {
				logger.debug("buffering end");
				isBuffering = false;
				hostRenderer.onAdViewBuffered(true);
			} else if (playbackState == Player.STATE_READY) {
				logger.debug("OnPrepared");

				if (preloading) {
					hostRenderer.onAdViewLoaded();
					return;
				}

				if (exoPlayer == null || exoPlayer.isPlaying()) {
					return;
				}

				long seekToPosition = mSeekWhenPrepared;
				if (seekToPosition != 0) {
					seekTo(seekToPosition);
				}

				Format format = exoPlayer.getVideoFormat();
				mVideoWidth = format.width;
				mVideoHeight = format.height;
				logger.debug("videoWidth: " + mVideoWidth + ", videoHeight: " + mVideoHeight);

				if (mVideoWidth != 0 && mVideoHeight != 0) {
					int targetWidth = mVideoWidth;
					int targetHeight = mVideoHeight;

					if (CommonUtil.viewHasComposeParent(ExoVideoAdView.this)) {
						ViewGroup parent = (ViewGroup) getParent();
						if (parent != null) {
							targetWidth = parent.getWidth();
							targetHeight = parent.getHeight();
						}
					}

					logger.debug("Setting surface size to: " + targetWidth + "x" + targetHeight);
					getHolder().setFixedSize(targetWidth, targetHeight);
					if (mSurfaceWidth == mVideoWidth && mSurfaceHeight == mVideoHeight && isPlayingTargetState) {
						start();
					}
				} else if (isPlayingTargetState) {
					start();
				}
				hostRenderer.onAdViewMediaPrepared();
			} else if (playbackState == Player.STATE_BUFFERING && exoPlayer.isPlaying()) {
				logger.debug("buffering start");
				isBuffering = true;
				hostRenderer.onAdViewBuffered(false);
			} else if (playbackState == Player.STATE_ENDED) {
				logger.debug("video completion");
				// the following code's order must not be changed
				isPlayingTargetState = false;
				hostRenderer.onAdVideoViewComplete();
			}
		}

		@OptIn(markerClass = UnstableApi.class) public void onPlayerError(PlaybackException error) {
			logger.debug("onError: " + error);
			errorOccurred = true;
			isPlayingTargetState = false;
			Bundle info = new Bundle();
			String msg = "errorCode: " + error.getErrorCodeName() + " error:" + error.getCause() + " adUrl: " + adUrl;
			if (error.getErrorCodeName().contains("_IO_")) {
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
			} else {
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
			}
			info.putString(constants.INFO_KEY_ERROR_INFO(), msg);
			hostRenderer.onAdVideoViewError(info);
		}
	};

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		logger.debug("surfaceCreated");
		this.surfaceHolder = holder;
		//add guard to avoid crash
		if (this.exoPlayer == null) {
			this.preloading = false;
		}
		if (this.preloading) {
			this.preloading = false;
			startPreloadedVideo();
		} else {
			this.openVideo();
		}
	}

	private void startPreloadedVideo() {
		logger.debug("startPreloadedVideo");
		mDuration = -1;
		exoPlayer.setVideoSurfaceHolder(this.surfaceHolder);
		surfaceHolder.setKeepScreenOn(true);
		if (exoPlayer.getPlaybackState() == Player.STATE_READY) {
			eventListener.onPlaybackStateChanged(Player.STATE_READY);
		} else {
			errorOccurred = true;
			isPlayingTargetState = false;
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "ExoPlayer should in prepared state when start play");

			this.hostRenderer.onAdVideoViewError(info);
		}
	}

	@OptIn(markerClass = UnstableApi.class)
	private MediaSource buildMediaSource() {
		Uri adUri = Uri.parse(this.adUrl);
		int timeout = this.timeoutMillisecondsBeforeStart;
		DataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
				.setAllowCrossProtocolRedirects(true)
				.setReadTimeoutMs(timeout)
				.setConnectTimeoutMs(timeout);
		BaseMediaSource.Factory mediaSourceFactory = null;

		int contentType = Util.inferContentType(adUri);
		try {
			if (contentType == C.CONTENT_TYPE_DASH) {
				mediaSourceFactory = new DashMediaSource.Factory(dataSourceFactory);
			} else if (contentType == C.CONTENT_TYPE_HLS) {
				mediaSourceFactory = new HlsMediaSource.Factory(dataSourceFactory);
			} else if (contentType == C.CONTENT_TYPE_OTHER) {
				mediaSourceFactory = new ProgressiveMediaSource.Factory(dataSourceFactory);
			}
		} catch (Exception e) {
			logger.debug("error occurred when building media source from adUrl: " + e.getMessage());
		}

		if (mediaSourceFactory != null) {
			MediaItem mediaItem = MediaItem.fromUri(Uri.parse(this.adUrl));
			return mediaSourceFactory.createMediaSource(mediaItem);
		}
		return null;
	}

	@OptIn(markerClass = UnstableApi.class)
	private void prepareExoPlayer() {
		logger.debug("prepareExoPlayer");
		try {
			mDuration = -1;

			MediaSource videoSource = buildMediaSource();
			if (videoSource == null) {
				errorOccurred = true;
				isPlayingTargetState = false;
				Bundle info = new Bundle();
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
				info.putString(constants.INFO_KEY_ERROR_INFO(), "Media file format is not supported: " + this.adUrl);

				this.hostRenderer.onAdVideoViewError(info);
				return;
			}
			exoPlayer = new ExoPlayer.Builder(getContext()).build();
			if (this.volume >= 0) {
				exoPlayer.setVolume(this.volume);
			}
			exoPlayer.addListener(eventListener);
			exoPlayer.setMediaSource(videoSource);
			exoPlayer.prepare();
		} catch (IllegalArgumentException e) {
			logger.debug(e.getMessage());
			errorOccurred = true;
			isPlayingTargetState = false;
			Bundle info = new Bundle();
			info.putString(this.constants.INFO_KEY_ERROR_CODE(), this.constants.ERROR_INVALID_VALUE());
			info.putString(this.constants.INFO_KEY_ERROR_INFO(), e.getMessage());

			this.hostRenderer.onAdVideoViewError(info);
		}
	}

	private void openVideo() {
		logger.debug("openVideo");
		if(this.surfaceHolder == null) {
			return;
		}
		release(false);
		prepareExoPlayer();
		exoPlayer.setVideoSurfaceHolder(this.surfaceHolder);
		surfaceHolder.setKeepScreenOn(true);
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		logger.debug("surfaceDestroyed");
		surfaceHolder = null;
		if (this.hostRenderer != null) {
			this.hostRenderer.onAdViewSurfaceDestroyed();
		}
		// Needed to handle rapid view changes
		if (exoPlayer != null) {
			pause();
			mSeekWhenPrepared = exoPlayer.getCurrentPosition();
			logger.debug("surfaceDestroyed: storing position " + mSeekWhenPrepared);
			exoPlayer.setVideoSurfaceHolder(null); // Disconnect surface like MediaPlayer setDisplay(null)
		}
	}

	public void startPlayback() {
		logger.debug("startPlayback");
		start();
		hostRenderer.onAdViewStart();
	}

	public void stop() {
		logger.debug("stop");
		if (isInPlaybackState()) {
			release(true);
		}
	}

	public void dispose() {
		logger.debug("dispose");
		release(true);
	}

	public void pause() {
		logger.debug("pause");
		// isPlaying() method added https://developer.android.com/media/media3/exoplayer/listening-to-player-events
		if (isInPlaybackState() && exoPlayer.isPlaying()) {
			mSeekWhenPrepared = (long) getPlayheadTime();
			mLastPlayheadTime = mSeekWhenPrepared;
			exoPlayer.setPlayWhenReady(false);
		}
		isPlayingTargetState = false;
	}

	public void start() {
		logger.debug("start");
		if (isInPlaybackState()) {
			exoPlayer.setPlayWhenReady(true);
		}
		isPlayingTargetState = true;
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int measuredWidth = getDefaultSize(mVideoWidth, widthMeasureSpec);
		int measuredHeight = getDefaultSize(mVideoHeight, heightMeasureSpec);

		if (mVideoWidth > 0 && mVideoHeight > 0) {
			if (mVideoWidth * measuredHeight > measuredWidth * mVideoHeight) {
				measuredHeight = measuredWidth * mVideoHeight / mVideoWidth;
			} else if (mVideoWidth * measuredHeight < measuredWidth * mVideoHeight) {
				measuredWidth = measuredHeight * mVideoWidth / mVideoHeight;
			}
		}

		logger.debug("onMeasure width: " + measuredWidth + " height: " + measuredHeight);
		setMeasuredDimension(measuredWidth, measuredHeight);
	}

	public double getPlayheadTime() {
		if (isInPlaybackState()) {
			try {
				long playheadTime = exoPlayer.getCurrentPosition();
				if (mLastPlayheadTime > 0) {
					if (playheadTime == 0) {
						playheadTime = mLastPlayheadTime;
					} else {
						mLastPlayheadTime = 0;
					}
				}
				return playheadTime;
			} catch (Throwable t) {
				logger.debug("getPlayheadTime: " +  t.getMessage());
			}
		} else if (mLastPlayheadTime > 0) {
			return mLastPlayheadTime;
		}
		return -1;
	}

	public double getDuration() {
		if (isInPlaybackState()) {
			try {
				if (mDuration > 0) {
					return mDuration;
				}
				mDuration = exoPlayer.getDuration();
				return mDuration;
			} catch (Throwable t) {
				logger.debug("getDuration: " + t.getMessage());
			}
		}
		mDuration = -1;
		return mDuration;
	}

	/*
	 * release the media player in any state
	 */
	private void release(boolean clearTargetState) {
		logger.debug("release");
		// release can be called by dispose and stop so we should check if exoPlayer is null here too
		if (exoPlayer != null) {
			exoPlayer.removeListener(eventListener);
			exoPlayer.release();
			exoPlayer = null;
			if (clearTargetState) {
				isPlayingTargetState = false;
			}
		}
	}

	protected boolean isInPlaybackState() {
		return (exoPlayer != null &&
				surfaceHolder != null &&
				!errorOccurred &&
				Player.STATE_READY == exoPlayer.getPlaybackState() &&
				!this.preloading);
	}

	public void seekTo(long msec) {
		logger.debug("seekTo : " + msec);
		if (isInPlaybackState()) {
			exoPlayer.seekTo(msec);
			mSeekWhenPrepared = 0;
		} else {
			mSeekWhenPrepared = msec;
		}
	}

	@Override
	public void setVolume(float volume) {
		this.volume = volume;
		if (this.exoPlayer != null) {
			exoPlayer.setVolume(volume);
		}
	}

	@Override
	public float getVolume() {
		return this.volume;
	}

	@Override
	public void loadUrl(String adUrl) {
		logger.debug("loadUrl " + adUrl);
		this.adUrl = adUrl;
		prepareExoPlayer();
		this.preloading = true;
	}
}