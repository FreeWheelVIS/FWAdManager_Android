package tv.freewheel.renderers.temporal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.URIUtil;
import tv.freewheel.utils.handler.RepeatingHandler;
import tv.freewheel.utils.renderer.RendererVolumeDelegate;

public class CustomPlayerRenderer implements IRenderer {
	private static final long QUARTILE_CHECK_INTERVAL = 500;
	private static final String SEND_QUARTILES_LOG = "sendQuartiles ";
	private IRendererContext rendererContext;
	private CustomPlayer customPlayer;
	protected IConstants constants;
	private AdListener adListener = new AdListener(this);

	private RepeatingHandler pollingQuartileHandler;
	private Runnable repeatingQuartileRunnable;
	private boolean defaultImpressionSent = false;
	private int quartilesSent = 0;
	private boolean isPaused = false;
	private double estimatedDuration = -1;
	private int impressionCountBeforeStart = 0;
	private double timeoutMillisecondsBeforeStart = 10000;
	private int timeoutCountBeforeStart = 0;
	private int freezeCount = 0;
	private double timeoutMillisecondsForAdFreeze = 10000;
	private double timeoutCountForAdFreeze = 0;
	private double lastPlayheadTime = 0.0;

	private RendererVolumeDelegate volumeDelegate = null;
	private static final Logger logger = Logger.getLogger(CustomPlayerRenderer.class);

	public CustomPlayerRenderer() {
	}

	@Override
	public void load(IRendererContext rendererContext) {
		logger.debug("CustomPlayerRenderer.init");
		this.rendererContext = rendererContext;
		this.customPlayer = ((AdInstance) this.rendererContext.getAdInstance()).getCustomPlayer();
		this.constants = this.rendererContext.getConstants();
		if (this.customPlayer == null) {
			logger.warn("custom player was null");
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "custom player was null");
			this.onRendererFailed(info);
			return;
		}

		Object timeoutParam = this.rendererContext.getParameter(Constants._PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START);
		Object freezeParam = this.rendererContext.getParameter(constants.PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT());
		if (timeoutParam != null) {
			String timeoutStr = timeoutParam.toString();
			double val = Double.parseDouble(timeoutStr);
			if (val > 0) {
				this.timeoutMillisecondsBeforeStart = val;
			}
		}
		if (freezeParam != null) {
			String freezeStr = freezeParam.toString();
			double val = Double.parseDouble(freezeStr);
			if (val > 0) {
				this.timeoutMillisecondsForAdFreeze = val;
			}
		}
		this.timeoutCountBeforeStart = (int) (this.timeoutMillisecondsBeforeStart / QUARTILE_CHECK_INTERVAL);
		this.timeoutCountForAdFreeze = (int) (this.timeoutMillisecondsForAdFreeze / QUARTILE_CHECK_INTERVAL);

		// renderer doesn't dispatch EVENT_AD_CLICK()
		rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), !DisplayUtils.isAndroidTV(rendererContext.getActivity()));

		VideoAdRenditionSelector renditionSelector = new VideoAdRenditionSelector(this.rendererContext);

		ICreativeRendition rendition = renditionSelector.getBestFitRendition();
		if (rendition == null) {
			Bundle info = new Bundle();
			// all creative renditions are dropped because of no asset
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "No asset");
			this.onRendererFailed(info);
			return;
		}

		logger.debug("Best fit rendition: " + rendition);

		this.rendererContext.getAdInstance().setActiveCreativeRendition(rendition);
		this.estimatedDuration = rendition.getDuration();

		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_QUARTILE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_MUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_UNMUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_PAUSE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_RESUME(), true);

		String assetUrl;
		if (rendition.getPrimaryCreativRenditionAsset() != null) {
			assetUrl = rendition.getPrimaryCreativRenditionAsset().getURL();
		} else {
			assetUrl = "";
		}

		String s = assetUrl;
		try {// test if assetUrl is valid
			logger.debug("assetUrl passed in: " + assetUrl);
			URI uri = new URI(assetUrl);
			if (!uri.isAbsolute()) {
				Bundle info = new Bundle();
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
				info.putString(constants.INFO_KEY_ERROR_INFO(), "original assetUrl: " + s);
				this.onRendererFailed(info);
			} else {
				logger.debug("converted to URI: " + uri);
				customPlayer.load((CreativeRendition) rendererContext.getAdInstance().getActiveCreativeRendition(), adListener);
			}
		} catch (URISyntaxException e) {
			assetUrl = URIUtil.getFixedString(assetUrl);
			logger.debug("assetUrl fixed: " + assetUrl);
			if (assetUrl == null) {
				Bundle info = new Bundle();
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
				info.putString(constants.INFO_KEY_ERROR_INFO(), "original assetUrl: " + s + " can not be fixed");
				this.onRendererFailed(info);
			} else {
				customPlayer.load((CreativeRendition) rendererContext.getAdInstance().getActiveCreativeRendition(), adListener);
			}
		}
	}

	@Override
	public void start() {
		((AdInstance) this.rendererContext.getAdInstance()).adjustOffsetWithRendererDuration();
		logger.debug("CustomPlayerRenderer.start");
		this.defaultImpressionSent = false;
		startQuartileImpressionPoller();

		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(() -> customPlayer.start((CreativeRendition) rendererContext.getAdInstance().getActiveCreativeRendition(), adListener));

		if (customPlayer != null) {
			customPlayer.setVolume(rendererContext.getInitialAdVolume());
		}
		this.volumeDelegate = new RendererVolumeDelegate(this.rendererContext);
	}

	private void onQuartilePollCallback() {
		double playhead = this.getPlayheadTime();
		if (playhead <= 0) {
			logger.debug("playhead <= 0");
			this.checkAndFailIfTimeout();
			return;
		} else if (!isPaused) {
			if (playhead - this.lastPlayheadTime < 0.1) {
				this.checkAndFailIfFreeze();
			} else {
				this.freezeCount = 0;
			}
		}
		this.impressionCountBeforeStart = 0;
		this.lastPlayheadTime = playhead;

		// playhead > 0, check defaultImpression
		if (!this.defaultImpressionSent) {
			this.defaultImpressionSent = true;
			rendererContext.dispatchEvent(constants.EVENT_AD_STARTED());
		}

		double duration = this.getDuration();
		if (duration <= 0 && this.estimatedDuration > 0) {
			logger.debug("use estimatedDuration " + this.estimatedDuration);
			duration = this.estimatedDuration;
		}
		if (duration > 0) {
			this.sendQuartiles(playhead / duration);
			((AdInstance) this.rendererContext.getAdInstance()).sendProgress(playhead);
			((AdInstance) this.rendererContext.getAdInstance()).processSkippableStateChangedEvent(playhead);
		} else {
			logger.debug("unknown duration");
		}
	}

	private void sendQuartiles(double percent) {
		if (percent >= 0.25 && this.quartilesSent < 1) {
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_FIRST_QUARTILE());
			this.quartilesSent = 1;
		}
		if (percent >= 0.5 && this.quartilesSent < 2) {
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_MIDPOINT());
			this.quartilesSent = 2;
		}
		if (percent >= 0.75 && this.quartilesSent < 3) {
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_THIRD_QUARTILE());
			this.quartilesSent = 3;
		}
		if (percent >= 0.99 && this.quartilesSent < 4) {
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_COMPLETE());
			this.quartilesSent = 4;
		}
	}

	private void sendMissingQuartiles() {
		logger.debug("sendMissingQuartiles");
		this.sendQuartiles(1.0);
	}

	/**
	 * AdManager should invoke this.dispose() after received STOPPED event
	 */
	@Override
	public void stop() {
		logger.debug("CustomPlayerRenderer.stop");
		this.stopQuartilePoller();
		if (this.customPlayer != null) {
			this.customPlayer.stop();
		}
		rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
	}

	@Override
	public void pause() {
		logger.debug("CustomPlayerRenderer.pause");
		this.stopQuartilePoller();
		if (this.customPlayer != null) {
			this.isPaused = true;
			this.customPlayer.playPause(true);
		}
		rendererContext.dispatchEvent(constants.EVENT_AD_PAUSE());
	}

	@Override
	public void resume() {
		logger.debug("CustomPlayerRenderer.resume");
		if (this.customPlayer != null) {
			this.isPaused = false;
			this.customPlayer.playPause(false);
		}
		rendererContext.dispatchEvent(constants.EVENT_AD_RESUME());
		startQuartileImpressionPoller();
	}

	@Override
	public void dispose() {
		logger.debug("CustomPlayerRenderer.dispose");

		if (customPlayer == null) {
			return;
		}

		if (this.volumeDelegate != null) {
			this.volumeDelegate.dispose();
			this.volumeDelegate = null;
		}
		this.stopQuartilePoller();
	}

	@Override
	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_MODULE_NAME(), this.getClass().getName());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	@Override
	public double getDuration() {
		if (customPlayer != null && customPlayer.getDuration() > 0) {
			return customPlayer.getDuration() / 1000;
		} else {
			return -1;
		}
	}

	@Override
	public double getPlayheadTime() {
		if (customPlayer != null) {
			return customPlayer.getPlayheadTime() / 1000;
		} else {
			return -1;
		}
	}

	private void startQuartileImpressionPoller() {
		logger.debug("CustomPlayerRenderer.startQuartileImpressionPoller");
		if (this.pollingQuartileHandler != null) {
			logger.debug("Polling Quartile Handler exists, not creating again");
			return;
		}

		this.pollingQuartileHandler = new RepeatingHandler();
		this.repeatingQuartileRunnable = this::onQuartilePollCallback;
		this.pollingQuartileHandler.postRepeated(repeatingQuartileRunnable, QUARTILE_CHECK_INTERVAL, QUARTILE_CHECK_INTERVAL);
	}

	private void stopQuartilePoller() {
		logger.debug("CustomPlayerRenderer.stopQuartilePoller");
		if (this.pollingQuartileHandler != null) {
			this.pollingQuartileHandler.removeRepeating(repeatingQuartileRunnable);
			this.repeatingQuartileRunnable = null;
			this.pollingQuartileHandler = null;
		}
	}

	private void checkAndFailIfTimeout() {
		if (this.impressionCountBeforeStart >= this.timeoutCountBeforeStart) {
			logger.warn("ad content can not start in " + this.timeoutMillisecondsBeforeStart + "ms, just fail!");
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_TIMEOUT());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "ad content can not start in " + (int) (this.timeoutMillisecondsBeforeStart / 1000) + "s");
			this.onRendererFailed(info);
		} else {
			++this.impressionCountBeforeStart;
		}
	}

	private void checkAndFailIfFreeze() {
		if (this.freezeCount >= this.timeoutCountForAdFreeze) {
			logger.warn("ad content is unexpected paused for " + this.timeoutMillisecondsForAdFreeze + "ms, just fail!");
			this.freezeCount = 0;
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_TIMEOUT());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "ad content is unexpected paused for " + this.timeoutMillisecondsForAdFreeze / 1000 + "s");
			this.onRendererFailed(info);
		} else {
			++this.freezeCount;
		}
	}

	@Override
	public void resize() {
		logger.debug("CustomPlayerRenderer.resize stub");
	}

	@Override
	public void setVolume(float volumeValue) {
		logger.debug("CustomPlayerRenderer.Set volume to " + volumeValue);
		if (this.customPlayer == null) {
			logger.debug("custom player is null, ignore");
			return;
		}

		if (this.volumeDelegate == null) {
			logger.debug("volumeDelegate is null, ignore");
			return;
		}

		this.volumeDelegate.onAdVolumeChanged(volumeValue);
	}

	public void onAdLoaded() {
		logger.debug("CustomPlayerRenderer.onAdLoaded");
		if (customPlayer != null) {
			rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());
		}
	}

	public void onAdBuffered(boolean end) {
		logger.debug("CustomPlayerRenderer.onAdBuffered");
		rendererContext.dispatchEvent(end ? constants.EVENT_AD_BUFFERING_END() : constants.EVENT_AD_BUFFERING_START());
	}

	public void onAdClicked() {
		logger.debug("CustomPlayerRenderer.onAdClicked");
		rendererContext.dispatchEvent(constants.EVENT_AD_CLICK());
	}

	public void onAdEnded() {
		logger.debug("CustomPlayerRenderer.onAdEnded");
		this.stopQuartilePoller();
		this.sendMissingQuartiles();
		rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
	}

	protected void onRendererFailed(Bundle info) {
		logger.debug("CustomPlayerRenderer.onRendererFailed");
		this.stopQuartilePoller();
		HashMap<String, Object> map = new HashMap<>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_ERROR(), map);
	}

	@Override
	public View getAdView() {
		if (defaultImpressionSent) {
			return this.customPlayer.getAdView();
		}
		return null;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return this.customPlayer.getFriendlyObstructions();
	}
}
