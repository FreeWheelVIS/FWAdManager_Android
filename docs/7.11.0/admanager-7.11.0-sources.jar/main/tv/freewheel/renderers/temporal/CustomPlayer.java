package tv.freewheel.renderers.temporal;

import android.view.View;

import java.util.List;

import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;

/**
 * CustomPlayer is common interface of APIs required to work with the CustomPlayerRenderer.
 */
public interface CustomPlayer {
	/**
	 * @param creativeRendition the creative rendition of the ad video.
	 * @param adListener an AdListener object used to communicate with the CustomPlayerRenderer. adListener.onAdLoaded should be called once playback is able to begin. If there is an error during loading, adListener.onAdError should be called.
	 */
	public void load(CreativeRendition creativeRendition, AdListener adListener);

	/**
	 * Starts the ad playback.
	 * @param creativeRendition the creative rendition of the ad video.
	 * @param adListener an AdListener object used to communicate with the CustomPlayerRenderer. adListener.onAdEvents should be called for corresponding ad events during the ad playback.
	 */
	public void start(CreativeRendition creativeRendition, AdListener adListener);

	/**
	 * Sets the float value for the volume of the player.
	 *
	 * @param volume a float value in the range [0,1]
	 */
	public void setVolume(float volume);

	/**
	 * Gets the duration of the ad.
	 *
	 * @return the duration of the ad, in seconds.
	 */
	public double getDuration();

	/**
	 * Gets the playhead time of the video player during ad playback, in milliseconds.
	 *
	 * @return the double value associated with the time of the playhead
	 */
	public double getPlayheadTime();

	/**
	 * Pauses or resumes the player.
	 *
	 * @param isPaused a boolean value If true, indicates that the call to this method should pause the video. Otherwise the call should play the video.
	 */
	public void playPause(boolean isPaused);

	/**
	 * Stops the player.
	 */
	public void stop();

	/**
	 * Gets the view that renderers the ad. This method is used by the OMSDK extension for viewability tracking.
	 * This method is only used if OMSDK is enabled. This can return null if OMSDK is not supported.
	 *
	 * @return - a View object used for viewability tracking
	 */
	public View getAdView();

	/**
	 * Gets a list of configuration objects used for registering friendly obstructions with OMSDK.
	 * This method will return null if OMSDK is not used or there is no friendly obstruction.
	 * @return - a List of FWOMSDKFriendlyObstructionConfiguration objects
	 */
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions();
}
