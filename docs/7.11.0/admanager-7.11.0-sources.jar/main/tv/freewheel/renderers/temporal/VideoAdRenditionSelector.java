package tv.freewheel.renderers.temporal;

import android.os.Build;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.renderer.ParamParser;

/**
 * Created by xuanwang on 4/17/17.
 */

public class VideoAdRenditionSelector {
    private static final Double DEFAULT_DESIRED_BITRATE = 1000.00;
    private static final Double DEFAULT_ASPECT_RATIO_WEIGHT = 1.0;
    private static final Double DEFAULT_PIXELATION_WEIGHT = 1.0;
    private static final Double DEFAULT_CONVERSION_FACTOR = 0.2;

    private ISlot slot;
    private Constants constants;

    private static final Logger logger = Logger.getLogger(VideoAdRenditionSelector.class);
    private IRendererContext rendererContext;

    public VideoAdRenditionSelector(IRendererContext rendererContext) {
        this.rendererContext = rendererContext;
        this.slot = this.rendererContext.getAdInstance().getSlot();
        this.constants = (Constants) this.rendererContext.getConstants();
    }

    public ICreativeRendition getBestFitRendition () {
        ArrayList<ICreativeRendition> hlsRenditions = new ArrayList<ICreativeRendition>();
        ArrayList<ICreativeRendition> nonHLSRenditions = new ArrayList<ICreativeRendition>();
        ArrayList<ICreativeRendition> h264BaselineRenditions, filteredRenditionsByTargetBitrate;
        ArrayList<ICreativeRendition> resultRenditions;

        // step 0: HLS rendition
        logger.debug("Android version " + Build.VERSION.RELEASE
                + ", API " + Build.VERSION.SDK_INT);

        for (ICreativeRendition rendition : this.rendererContext.getAdInstance().getRenderableCreativeRenditions()) {
            if (rendition.getPrimaryCreativRenditionAsset() == null) {
                logger.debug("Drop rendition " + rendition.toString() + " that has no asset");
            } else if (rendition.getContentType().equalsIgnoreCase("application/x-mpegurl")) {
                hlsRenditions.add(rendition);
            } else {
                nonHLSRenditions.add(rendition);
            }
        }

        if (!hlsRenditions.isEmpty()) {
            return hlsRenditions.get(0);
        }
        if (nonHLSRenditions.isEmpty()) {
            return null;
        }

        // step 1: filter h264-baseline renditions
        h264BaselineRenditions = getFilteredH264BaselineRenditions(nonHLSRenditions);

        // step 2: filter bit rate
        ParamParser paramParser = new ParamParser(rendererContext,"");
        double desiredBitRate = paramParser.getNonNegativeValueFromParameter(this.constants.PARAM_DESIRED_BITRATE(), DEFAULT_DESIRED_BITRATE, false);
        logger.debug("Set bit rate to " + desiredBitRate + " kbps");

        // get filtered Renditions By Target Bitrate
        filteredRenditionsByTargetBitrate = getSortedFilteredRenditionsByTargetBitrate(
                h264BaselineRenditions.isEmpty()? nonHLSRenditions : h264BaselineRenditions,
                desiredBitRate
        );

        // step 3: calculate aspect ratio
        resultRenditions = getSortedRenditionsByDimensions(filteredRenditionsByTargetBitrate);

        if (resultRenditions.isEmpty()) {
            return null;
        } else {
            return resultRenditions.get(0);
        }
    }

    private ArrayList<ICreativeRendition> getSortedRenditionsByDimensions(ArrayList<ICreativeRendition> renditions) {
        ArrayList<ICreativeRendition> sortedRenditions = new ArrayList<ICreativeRendition>();
        ArrayList<ICreativeRendition> renditionsWithKnownDimensions = new ArrayList<ICreativeRendition>();
        ArrayList<ICreativeRendition> renditionsWithUnknownDimensions = new ArrayList<ICreativeRendition>(); // unknown width/height means compatible

        if (renditions.isEmpty()) {
            return sortedRenditions;
        }

        // get the display dpi
        final ViewGroup slotBase = slot.getBase();
        final int slotWidth = slot.getWidth();
        final int slotHeight = slot.getHeight();
        logger.debug("Slot size " + slotWidth + "x" + slotHeight);
        if (slotWidth > 0 && slotHeight > 0) {
            logger.debug("Slot aspect ratio " + 1.0 * slotWidth / slotHeight);
            for (ICreativeRendition rendition: renditions) {
                if (rendition.getWidth() > 0 && rendition.getHeight() > 0) {
                    renditionsWithKnownDimensions.add(rendition);
                } else {
                    renditionsWithUnknownDimensions.add(rendition);
                }
            }
            final float dpi = slotBase.getContext().getResources().getDisplayMetrics().density;
            Collections.sort(renditionsWithKnownDimensions, new Comparator<ICreativeRendition>() {
                @Override
                public int compare(ICreativeRendition cr1, ICreativeRendition cr2) {
                    double d1 = getVisualRatioDistanceForRendition(cr1, slotWidth * dpi, slotHeight * dpi);
                    double d2 = getVisualRatioDistanceForRendition(cr2, slotWidth * dpi, slotHeight * dpi);
                    return Double.compare(d1, d2);
                }
            });
            sortedRenditions.addAll(renditionsWithKnownDimensions);
            sortedRenditions.addAll(renditionsWithUnknownDimensions);
        } else {
            logger.warn("Unknown slot dimension, keep all renditions");
            sortedRenditions = renditions;
        }
        return sortedRenditions;
    }

    private ArrayList<ICreativeRendition> getSortedFilteredRenditionsByTargetBitrate(ArrayList<ICreativeRendition> renditions, double desiredBitRate) {
        // store renditions with least higher bit rate than desiredBitRate
        ArrayList<ICreativeRendition> renditionsWithBitRateEqualToOrLowerThanDesired = new ArrayList<ICreativeRendition>(); // unknown bit rate is considered desired
        ArrayList<ICreativeRendition> renditionsWithBitRateHigherThanDesired = new ArrayList<ICreativeRendition>();
        ArrayList<ICreativeRendition> filteredRenditions = new ArrayList<ICreativeRendition>();

        if (renditions.isEmpty()) {
            return filteredRenditions;
        }

        for (ICreativeRendition rendition : renditions) {
            double br = ((CreativeRendition)rendition).getBitRate();
            if (br <= desiredBitRate) {
                renditionsWithBitRateEqualToOrLowerThanDesired.add(rendition);
            } else {
                renditionsWithBitRateHigherThanDesired.add(rendition);
            }
        }
        // Order: from lower bit rate rendition to higher one
        Comparator<? super ICreativeRendition> comparator = new Comparator<ICreativeRendition>() {
            @Override
            public int compare(ICreativeRendition cr1, ICreativeRendition cr2) {
                return Double.compare(((CreativeRendition)cr1).getBitRate(), ((CreativeRendition)cr2).getBitRate());
            }
        };
        if (!renditionsWithBitRateEqualToOrLowerThanDesired.isEmpty()) {
            logger.debug("Exists renditions with bit rate lower or equal to desired");
            Collections.sort(renditionsWithBitRateEqualToOrLowerThanDesired, comparator);
            Collections.reverse(renditionsWithBitRateEqualToOrLowerThanDesired);
            return renditionsWithBitRateEqualToOrLowerThanDesired;
        }
        logger.debug("All renditions have higher bit rates than desired, "
                + "choose from renditions with lowest bit rate available");
        Collections.sort(renditionsWithBitRateHigherThanDesired, comparator);
        double minBitrate = ((CreativeRendition) renditionsWithBitRateHigherThanDesired.get(0)).getBitRate();
        for (ICreativeRendition icr: renditionsWithBitRateHigherThanDesired) {
            CreativeRendition rendition = (CreativeRendition)icr;
            if (rendition.getBitRate() == minBitrate) {
                filteredRenditions.add(icr);
            }
        }
        return filteredRenditions;
    }

    private ArrayList<ICreativeRendition> getFilteredH264BaselineRenditions(ArrayList<ICreativeRendition> allRenditions){
        ArrayList<ICreativeRendition> filteredRenditions = new ArrayList<ICreativeRendition>();
        for (ICreativeRendition rendition : allRenditions) {
            if (rendition.getContentType().equals("video/mp4-h264-baseline")) {
                logger.debug("Kept h264-baseline rendition" +rendition.toString());
                filteredRenditions.add(rendition);
            } else if (!rendition.getContentType().startsWith("video/mp4")) {
                logger.debug("Kept non-video/mp4 rendition" + rendition.toString());
                filteredRenditions.add(rendition);
            }
        }
        return filteredRenditions;
    }

    private double getVisualRatioDistanceForRendition(ICreativeRendition rendition, float targetWidth, float targetHeight){
        int renditionWidth = rendition.getWidth();
        int renditionHeight = rendition.getHeight();
        double renditionAspectRatio = 1.0 * renditionWidth / renditionHeight;
        double targetAspectRatio = 1.0 * targetWidth / targetHeight;
        long renditionAreaSize = renditionWidth * renditionHeight;
        ParamParser paramParser=new ParamParser(rendererContext,"");

        double aspectRatioWeight = paramParser.getNonNegativeValueFromParameter(this.constants.PARAM_VIDEO_RENDITION_SELECTION_ASPECT_RATIO_RATIO_WEIGHT(), DEFAULT_ASPECT_RATIO_WEIGHT, true);
        logger.debug("Aspect Ratio Weight: " + aspectRatioWeight);

        double pixelationWeight = paramParser.getNonNegativeValueFromParameter(this.constants.PARAM_VIDEO_RENDITION_SELECTION_PIXELATION_WEIGHT(), DEFAULT_PIXELATION_WEIGHT, true);
        logger.debug("Pixelation Weight: " + pixelationWeight);

        double conversionFactor = paramParser.getNonNegativeValueFromParameter(this.constants.PARAM_VIDEO_RENDITION_SELECTION_CONVERSION_FACTOR(), DEFAULT_CONVERSION_FACTOR, false);
        logger.debug("Conversion Factor: " + conversionFactor);

        double scaledAreaSize;
        if (renditionAspectRatio > targetAspectRatio) {
            scaledAreaSize = targetWidth * (targetWidth / renditionAspectRatio);
        } else {
            scaledAreaSize = targetHeight * targetHeight * renditionAspectRatio;
        }

        double aspectRatioRatio = conversionFactor * aspectRatioWeight * Math.log(renditionAspectRatio / targetAspectRatio);
        double pixelation = pixelationWeight * Math.log(renditionAreaSize / scaledAreaSize);
        double distance = Math.sqrt(aspectRatioRatio * aspectRatioRatio + pixelation * pixelation);

        return distance;
    }
}
