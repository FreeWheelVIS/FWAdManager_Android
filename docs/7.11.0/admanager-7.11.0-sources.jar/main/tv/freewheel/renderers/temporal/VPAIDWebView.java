package tv.freewheel.renderers.temporal;

import android.app.Activity;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import tv.freewheel.utils.Logger;
import android.webkit.ValueCallback;

/**
 * Created by plade on 12/13/16.
 */

public class VPAIDWebView extends WebView {
    private static final Logger logger = Logger.getLogger(VPAIDRenderer.class);
    private VPAIDRenderer bridge;
    public VPAIDWebView(Activity activity, VPAIDRenderer renderer) {
        super(activity);
        bridge = renderer;

        this.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                logger.debug("JS Console log " + consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber()+ " of "
                        + consoleMessage.sourceId());
                return true;
            }
        });
        this.getSettings().setAllowContentAccess(false);
        this.getSettings().setAllowFileAccess(false);
        this.getSettings().setAllowFileAccessFromFileURLs(false);
        this.getSettings().setAllowUniversalAccessFromFileURLs(false);
    }
    public String generateVPAIDWebViewHTML(int width, int height) {
         String js = VPAIDConstants.VPAID_JS;
         String wrappedJs = "<script type = \"text/javascript\">" + js + "</script>\n";
         String environmentString0 = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "      <head>\n";
         String environmentString1 =
                 "            <meta name = \"viewport\" content = \"initial-scale = 1.0\" />\n" +
                 "            <meta charset=\"utf-8\">\n" +
                 "            <title>FWVPAIDRenderer</title>\n" +
                 "            <style type=\"text/css\">body {background-color:black;}</style>\n" +
                "      </head>\n" +
                "      <body style=\"margin:0px;padding:0px;\">\n" +
                "\t\t<div id=\"fwVPAIDSlotBase\" style=\"width:"+ width + "px;height:" + height + "px\">\n" +
                "\t\t<video id=\"fwVPAIDPlayer\" style=\"background:black;width:100%;height:100%\"></video>\n" +
                "\t\t</div>\n" +
                "      </body>\n" +
                "</html>";
         logger.debug(environmentString0 + environmentString1);
         return environmentString0 + wrappedJs + environmentString1;
    }

    @Override
    public void evaluateJavascript(final String script, final ValueCallback<String> resultCallback) {
        bridge.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                logger.debug("Execute: "  + script +" on WebView: " + VPAIDWebView.this);
                VPAIDWebView.super.evaluateJavascript(script, new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        logger.debug("Script call: " + script + " returned value: " + value);
                        if (resultCallback != null) {
                            resultCallback.onReceiveValue(value);
                        }
                    }
                });
            }
        });
    }

    public void setVolumeOnVPAIDCreative(float volume) {
        logger.debug("Setting Volume on VPAID Creative " + volume);
        this.evaluateJavascript("fw_vast_wrapper.setAdVolume(" + volume + ");", null);
    }
}
