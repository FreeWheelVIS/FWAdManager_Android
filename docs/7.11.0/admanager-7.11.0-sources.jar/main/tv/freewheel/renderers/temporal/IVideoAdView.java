package tv.freewheel.renderers.temporal;

interface IVideoAdView {
	void start();
	void startPlayback();
	void pause();
	void stop();
	void dispose();
	double getPlayheadTime();
	double getDuration();
	void setVolume(float volume);
	float getVolume();
	void loadUrl(String adUrl);
}
