package tv.freewheel.renderers.temporal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdContextScoped;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.slot.TemporalSlot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.handler.RepeatingHandler;

public class SIMIDRenderer implements IRenderer {
	private VideoRenderer videoRenderer;
	private static final Logger logger = Logger.getLogger(SIMIDRenderer.class);
	private IRendererContext rendererContext;
	private Activity activity;
	private SIMIDWebView simidWebView;
	private IConstants constants;
	private ISlot slot;
	private double duration = -1;
	private double playheadTime = -1;
	private Handler mainLoopHandler;
	private RepeatingHandler playheadTimeHandler;
	private Runnable playheadTimeRunnable;
	private boolean isMuted = false;
	private float adVolume = 0;
	private String simidCreativeUrl = "";
	private Boolean simidVariableDurationAllowed = false;
	private IAdInstance adInstance;
	private AdContext adContext;
	private static final int VIDEO_TIME_OUT_ERROR = 1207;
	private static final int VIDEO_COULD_NOT_LOAD_ERROR = 1206;
	private static final int UNSPECIFIED_ERROR = 1200;
	private static final String jsonExceptionStr = "SIMIDRenderer JSONException";
	private static final int PLAYER_INITIATED_STOP_CODE = 3;

	public SIMIDRenderer() {
		mainLoopHandler = new Handler(Looper.getMainLooper());
	}

	private void startPlayheadTimeCheck() {
		if (playheadTimeRunnable != null && playheadTimeHandler != null) {
			playheadTimeHandler.postRepeated(playheadTimeRunnable, 0, 250);
		}
	}

	private void stopPlayheadTimeCheck() {
		if (playheadTimeHandler != null && playheadTimeRunnable != null) {
			playheadTimeHandler.removeRepeating(playheadTimeRunnable);
		}
	}

	@SuppressLint("JavascriptInterface")
	@Override
	public void load(IRendererContext rendererContext) {
		logger.debug("SIMIDRenderer load");

		this.videoRenderer = new VideoRenderer();
		this.rendererContext = rendererContext;
		this.activity = rendererContext.getActivity();
		this.constants = this.rendererContext.getConstants();
		this.adInstance = this.rendererContext.getAdInstance();
		this.slot = this.adInstance.getSlot();
		AdContextScoped adContextScoped = (AdContextScoped) this.adInstance;
		this.adContext = adContextScoped.getAdContext();
		this.adVolume = this.adContext.getAdVolume();
		this.isMuted = this.adVolume == 0;

		// Start ad video playback following uninterrupted initialization workflow: https://interactiveadvertisingbureau.github.io/SIMID/#workflow-uninterupted-initialization
		videoRenderer.load(rendererContext);
		playheadTimeHandler = new RepeatingHandler();
		playheadTimeRunnable = () -> {
			try {
				playheadTime = videoRenderer.getPlayheadTime();
				duration = videoRenderer.getDuration();
				if (playheadTime > 0 && duration > 0) {
					simidWebView.evaluateJavascript(String.format("fw_simid_wrapper.onAdVideoTimeUpdate('%s','%s');", playheadTime, duration), null);
				}
			} catch (Exception e) {
				SIMIDRenderer.logger.debug(e);
			}
		};

		// register ad complete event so even the SIMID fails can still trigger rendition complete
		this.adContext.addEventListener(constants.EVENT_AD_COMPLETE(), mediaEventListener);
		this.adContext.addEventListener(constants.EVENT_ERROR(), errorEventListener);

		// get details of the rendition and the asset.
		CreativeRendition rendition = (CreativeRendition) this.rendererContext.getAdInstance().getActiveCreativeRendition();

		if (rendition.getSimidCreativeUrl() != null && !StringUtils.isBlank(rendition.getSimidCreativeUrl())) {
			this.simidCreativeUrl = rendition.getSimidCreativeUrl();
			this.simidVariableDurationAllowed = rendition.getSimidVariableDurationAllowed();
		} else {
			logger.debug("The SIMID creative url is missing.");
			// if simidCreativeUrl is empty, stop creating simidWebView.
			return;
		}
		this.adContext.addEventListener(constants.EVENT_AD_IMPRESSION(), adEventListener);
		this.adContext.addEventListener(constants.EVENT_AD_SKIPPED_BY_USER(), mediaEventListener);
		this.adContext.addEventListener(constants.EVENT_AD_VOLUME_CHANGED(), mediaEventListener);
		this.adContext.addEventListener(constants.EVENT_AD_BUFFERING_START(), mediaEventListener);

		simidWebView = new SIMIDWebView(activity, this);
		simidWebView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		simidWebView.setBackgroundColor(Color.TRANSPARENT);
		WebSettings webSettings = simidWebView.getSettings();

		simidWebView.clearCache(true);

		String simidHTML = simidWebView.generateSIMIDWebViewHTML();
		webSettings.setJavaScriptEnabled(true);

		// Enable auto play without user gesture
		webSettings.setMediaPlaybackRequiresUserGesture(false);

		// Mixed content (HTTP over HTTPS) does not work for LOLLIPOP and higher by default
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

			//MIXED_CONTENT_COMPATIBILITY_MODE is recommended but causes issues with some ads
			webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		}

		simidWebView.addJavascriptInterface(this, "JSInterface");
		simidWebView.loadDataWithBaseURL(null, simidHTML, "text/html", "utf8", null);
	}

	IEventListener errorEventListener = event -> {
		logger.debug("errorEventListener");
		HashMap<String, Object> errorData = event.getData();
		int simidErrorCode;
		// VideoRenderer throws following error code: ERROR_UNKNOWN, ERROR_TIMEOUT, ERROR_NULL_ASSET
		if (errorData.get(constants.INFO_KEY_ERROR_CODE()) == constants.ERROR_TIMEOUT()) {
			simidErrorCode = VIDEO_TIME_OUT_ERROR;
		} else if (errorData.get(constants.INFO_KEY_ERROR_CODE()) == constants.ERROR_NULL_ASSET()) {
			simidErrorCode = VIDEO_COULD_NOT_LOAD_ERROR;
		} else if (errorData.get(constants.INFO_KEY_ERROR_CODE()) == constants.ERROR_UNKNOWN()) {
			simidErrorCode = VIDEO_COULD_NOT_LOAD_ERROR;
		} else {
			simidErrorCode = UNSPECIFIED_ERROR;
		}
		if (simidWebView != null) {
			String errorMsg = String.format("{errorCode:\"%s\",message:\"%s\"}", simidErrorCode, errorData.get(constants.INFO_KEY_ERROR_INFO()));
			simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Player:fatalError\"," + errorMsg + ");", null);
		}
		stop();
	};

	IEventListener adEventListener = event -> {
		logger.debug("adEventListener: " + event.getType());
		String eventType = event.getType();
		try {
			if (eventType.equals(Constants._EVENT_AD_IMPRESSION)) {
				simidWebView.evaluateJavascript("fw_simid_wrapper.onAdVideoStarted()", null);
			}
		} catch (Exception e) {
			logger.warn("Ad Event not fired because Exception: " + e.getLocalizedMessage(), e);
		}
	};

	IEventListener mediaEventListener = event -> {
		logger.debug("mediaEventListener: " + event.getType());
		String eventType = event.getType();
		HashMap<String, Object> eventData = event.getData();
		try {
			switch (eventType) {
				case Constants._EVENT_AD_COMPLETE:
					stopPlayheadTimeCheck();
					if (simidWebView != null) {
						simidWebView.evaluateJavascript("fw_simid_wrapper.onAdVideoEnded()", null);
					} else {
						final Handler handler = new Handler(Looper.getMainLooper());
						handler.post(() -> stop());
					}
					break;
				case Constants._EVENT_AD_BUFFERING_START:
					simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Media:stalled\");", null);
					break;
				case Constants._EVENT_AD_VOLUME_CHANGED:
					if (eventData.get(constants.INFO_KEY_VOLUME()) != null) {
						this.adVolume = (float) eventData.get(constants.INFO_KEY_VOLUME());
						this.isMuted = this.adVolume == 0;
						String volumeChangeString = String.format("{volume:\"%s\",muted:\"%s\"}", this.adVolume, this.isMuted);
						simidWebView.evaluateJavascript("fw_simid_wrapper.onAdVideoVolumeUpdate(" + volumeChangeString + ")", null);
					}
					break;
				case Constants._EVENT_AD_SKIPPED_BY_USER:
					simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Player:adSkipped\");", null);
					break;
			}
		} catch (Exception e) {
			logger.warn("Media Event not fired because Exception: " + e, e);
		}
	};

	private JSONObject getFullDimentions() throws JSONException {
		int x = (int) slot.getBase().getX();
		int y = (int) slot.getBase().getY();
		JSONObject dimention = new JSONObject();
		dimention.put("x", x);
		dimention.put("y", y);
		dimention.put("width", DisplayUtils.pixelToDp(activity, slot.getBase().getWidth()));
		dimention.put("height", DisplayUtils.pixelToDp(activity, slot.getBase().getHeight()));
		return (dimention);
	}

	// Called when the simid webview is loaded and Javascript wrapper
	@JavascriptInterface
	public void onWrapperLoaded() {
		logger.debug("SIMID Wrapper loaded");
		initializeSimidCreative();
	}

	@JavascriptInterface
	public void _fw_log(String s) {
		logger.debug("SIMID log: " + s);
	}

	@JavascriptInterface
	public void onCreativeFatalError(String errorCode) {
		Bundle info = new Bundle();
		info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_3P_COMPONENT());
		info.putString(constants.INFO_KEY_ERROR_INFO(), "SIMID Creative reported a fatal error.");
		info.putString(constants.INFO_KEY_VAST_ERROR_CODE(), errorCode);
		HashMap<String, Object> map = new HashMap<>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_ERROR(), map);
	}

	@Override
	public void start() {
		logger.debug("SIMIDRenderer start");
		this.videoRenderer.start();
		if (simidWebView != null) {
			startPlayheadTimeCheck();
			simidWebView.evaluateJavascript("fw_simid_wrapper._isPaused=false;", null);
			addView(simidWebView);
		}
	}

	private void initializeSimidCreative() {
		logger.debug("SIMIDRenderer initializeSimidCreative()");
		JSONObject creativeData = new JSONObject();
		try {
			String clickThroughUri = "";
			List<String> urls = this.adInstance.getEventCallbackURLs(constants.EVENT_AD_CLICK(), constants.EVENT_TYPE_CLICK());
			if (urls != null && !urls.isEmpty()) {
				clickThroughUri = urls.get(0);
			}
			creativeData.put("adParameters", this.adInstance.getParameter("creativeData"));
			creativeData.put("clickThroughUri", clickThroughUri);
		} catch (JSONException e) {
			logger.debug(jsonExceptionStr + e);
		}
		JSONObject environmentData = new JSONObject();
		try {
			JSONObject dimensions = this.getFullDimentions();
			String appPackageName = this.adContext.getAppPackageName();
			environmentData.put("videoDimensions", dimensions);
			environmentData.put("creativeDimensions", dimensions);
			environmentData.put("fullscreen", false);
			environmentData.put("fullscreenAllowed", false);
			environmentData.put("variableDurationAllowed", this.simidVariableDurationAllowed);
			environmentData.put("skippableState", this.adInstance.getAdSkippableState());
			environmentData.put("version", "1.1");
			environmentData.put("appId", appPackageName);
			environmentData.put("useragent", this.adContext.getUserAgent());
			environmentData.put("muted", this.isMuted);
			environmentData.put("volume", this.adVolume);
			TemporalSlot temporalSlot = (TemporalSlot) this.slot;
			environmentData.put("maxDuration", temporalSlot.maxDuration);
		} catch (JSONException e) {
			logger.debug(jsonExceptionStr + e);
		}
		String initiateSimidAdString = String.format("fw_simid_wrapper.initiateSimidAd('%s', '%s', '%s');", this.simidCreativeUrl, environmentData, creativeData);
		simidWebView.evaluateJavascript(initiateSimidAdString, null);
	}

	protected void addView(final View view) {
		this.mainLoopHandler.post(() -> {
			logger.debug("SIMIDRenderer addView");
			final ViewGroup slotBase = this.slot.getBase();
			slotBase.addView(view);
			simidWebView.bringToFront();
		});
	}

	@JavascriptInterface
	@Override
	public void pause() {
		mainLoopHandler.post(() -> {
			logger.debug("SIMIDRenderer pause");
			if (videoRenderer.getPlayheadTime() > 0) {
				videoRenderer.pause();
			}
			if (simidWebView != null) {
				stopPlayheadTimeCheck();
				simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Media:pause\");", null);
				simidWebView.evaluateJavascript("fw_simid_wrapper._isPaused=true", null);
			}
		});
	}

	@JavascriptInterface
	@Override
	public void resume() {
		mainLoopHandler.post(() -> {
			logger.debug("SIMIDRenderer resume");
			if (videoRenderer.getPlayheadTime() > 0) {
				videoRenderer.resume();
			}
			if (simidWebView != null) {
				startPlayheadTimeCheck();
				simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Media:play\");", null);
				simidWebView.evaluateJavascript("fw_simid_wrapper._isPaused=false", null);
			}
		});
	}

	@JavascriptInterface
	public void processError(String errorCode) {
		logger.debug("SIMIDRenderer processError " + errorCode);
		this.adInstance.processSimidError(errorCode);
	}

	@JavascriptInterface
	public void stopFromCreative() {
		logger.debug("SIMIDRenderer stop");
		mainLoopHandler.post(() -> videoRenderer.stop());
		rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
		stopPlayheadTimeCheck();
	}

	@JavascriptInterface
	public void onCreativeClickThrough(String url, String showBrowser) {
		logger.debug("SIMIDRenderer: onCreativeClickThrough with url: " + url + " showBrowser: " + showBrowser);
		Bundle info = new Bundle();
		HashMap<String, Object> map = new HashMap<>();
		info.putBoolean(constants.INFO_KEY_SHOW_BROWSER(), StringUtils.parseBoolean(showBrowser, false));
		if (url != null && url.length() > 0) {
			// use the URL provided by SIMID
			info.putString(constants.INFO_KEY_URL(), url);
		}
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_AD_CLICK(), map);
	}

	@JavascriptInterface
	public void onRequestNavigation(String to) {
		logger.debug("SIMIDRenderer: onRequestNavigation with uri: " + to);

		if (((AdInstance) this.adInstance).getActivity() != null) {
			logger.debug("will open: " + to);
			Uri uri = Uri.parse(to);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			((AdInstance) this.adInstance).getActivity().startActivity(intent);
		}
	}

	@Override
	public void stop() {
		logger.debug("SIMIDRenderer stop from native");
		if (simidWebView != null) {
			String stopMsg = String.format("{code:\"%s\"}", PLAYER_INITIATED_STOP_CODE);
			simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Player:adStopped\", " + stopMsg + ");", null);
		}
		stopFromCreative();
	}

	@JavascriptInterface
	public void skip() {
		logger.debug("SIMIDRenderer skip");
		this.slot.skipCurrentAd();
	}

	@Override
	public void dispose() {
		logger.debug("SIMIDRenderer dispose");
		this.adContext.removeEventListener(constants.EVENT_AD_COMPLETE(), mediaEventListener);
		this.adContext.removeEventListener(constants.EVENT_ERROR(), errorEventListener);
		this.adContext.removeEventListener(constants.EVENT_AD_IMPRESSION(), adEventListener);
		this.adContext.removeEventListener(constants.EVENT_AD_SKIPPED_BY_USER(), mediaEventListener);
		this.adContext.removeEventListener(constants.EVENT_AD_VOLUME_CHANGED(), mediaEventListener);
		this.adContext.removeEventListener(constants.EVENT_AD_BUFFERING_START(), mediaEventListener);
		this.mainLoopHandler.post(() -> {
			videoRenderer.dispose();
			if (simidWebView != null) {
				if (slot != null && slot.getBase() != null) {
					slot.getBase().removeView(simidWebView);
				}
				simidWebView.destroy();
			}
		});
	}

	@Override
	public double getDuration() {
		logger.debug("getDuration " + duration);
		return duration;
	}

	@Override
	public double getPlayheadTime() {
		logger.debug("getPlayheadTime " + playheadTime);
		return playheadTime;
	}

	@Override
	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	@Override
	public void resize() {
		this.videoRenderer.resize();
		if (simidWebView != null) {
			simidWebView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
			JSONObject resizeData = new JSONObject();
			try {
				JSONObject dimentions = this.getFullDimentions();
				resizeData.put("videoDimensions", dimentions);
				resizeData.put("creativeDimensions", dimentions);
				resizeData.put("fullscreen", false);
			} catch (JSONException e) {
				logger.debug(jsonExceptionStr + e);
			}
			simidWebView.evaluateJavascript("fw_simid_wrapper._evaluateSendMessage(\"Player:resize\", " + resizeData + ");", null);
		}
	}

	@JavascriptInterface
	@Override
	public void setVolume(float value) {
		mainLoopHandler.post(() -> videoRenderer.setVolume(value));
	}

	@Override
	public View getAdView() {
		return this.slot.getBase();
	}

	public Activity getActivity() {
		return activity;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}
}
