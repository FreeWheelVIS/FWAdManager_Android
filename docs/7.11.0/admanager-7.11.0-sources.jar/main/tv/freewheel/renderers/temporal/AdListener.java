package tv.freewheel.renderers.temporal;

import android.os.Bundle;

import tv.freewheel.ad.Constants;
import tv.freewheel.utils.Logger;

/**
 * AdListener is an class that provides methods to listen to ad events.
 */
public class AdListener {
	private static final Logger logger = Logger.getLogger(AdListener.class);
	private CustomPlayerRenderer hostRenderer;
	/**
	 * Creates an AdListener object.
	 * @param hostRenderer a CustomPlayerRenderer object that is used to communicate with the player.
	 */
	public AdListener(CustomPlayerRenderer hostRenderer) {
		this.hostRenderer = hostRenderer;
	}

	/**
	 * Called when player experiences buffering during ad playback.
	 *
	 * @param end a boolean value indicating when the player is no longer buffering.
	 */
	public void onAdBuffered(boolean end) {
		logger.debug("AdListener.onAdBuffered");
		if (hostRenderer != null) {
			hostRenderer.onAdBuffered(end);
		}
	}

	/**
	 * Called when the player loads the ad before playing it.
	 */
	public void onAdLoaded() {
		logger.debug("AdListener.onAdLoaded");
		if (hostRenderer != null) {
			hostRenderer.onAdLoaded();
		}
	}

	/**
	 * Called when the player is clicked during ad playback. AdManager will call startActivity with new Intent(Intent.ACTION_VIEW, uri) for the registered app to open the URL.
	 */
	public void onAdClicked() {
		logger.debug("AdListener.onAdClicked");
		if (hostRenderer != null) {
			hostRenderer.onAdClicked();
		}
	}

	/**
	 * Called when the player finishes the ad to completion.
	 */
	public void onAdEnded() {
		logger.debug("AdListener.onAdEnded");
		if (hostRenderer != null) {
			hostRenderer.onAdEnded();
			hostRenderer = null;
		}
	}

	/**
	 * Called when the player experiences an error during ad playback.
	 * @param errorCode a String value containing the error code provided by the player.
	 * @param errorMessage a String value containing the error message provided by the player.
	 */
	public void onAdError(String errorCode, String errorMessage) {
		logger.debug("AdListener.onAdError failWithError errorCode:" + errorCode + ", errorMessage:" + errorMessage);
		Bundle info = new Bundle();
		info.putString(Constants._INFO_KEY_ERROR_CODE, errorCode);
		info.putString(Constants._INFO_KEY_ERROR_INFO, errorMessage);
		if (hostRenderer != null) {
			hostRenderer.onRendererFailed(info);
			hostRenderer = null;
		}
	}
}
