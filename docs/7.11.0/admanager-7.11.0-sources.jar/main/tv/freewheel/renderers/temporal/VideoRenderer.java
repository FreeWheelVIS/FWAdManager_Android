package tv.freewheel.renderers.temporal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.URIUtil;
import tv.freewheel.utils.handler.RepeatingHandler;
import tv.freewheel.utils.renderer.ParamParser;
import tv.freewheel.utils.renderer.RendererVolumeDelegate;

public class VideoRenderer implements IRenderer {
	private static final long QUARTILE_CHECK_INTERVAL = 500;
	private static final String SEND_QUARTILES_LOG = "sendQuartiles ";
	private IRendererContext rendererContext;
	private IVideoAdView videoAdView;
	protected IConstants constants;
	private int renditionWidth;
	private int renditionHeight;
	private String assetUrl;
	private ISlot slot;

	private RepeatingHandler pollingQuartileHandler;
	private Runnable repeatingQuartileRunnable;
	private boolean defaultImpressionSent = false;
	private int quartilesSent = 0;
	private boolean isPaused = false;
	private int impressionCountBeforeStart = 0;
	private double timeoutMillisecondsBeforeStart = 10000;
	private int timeoutCountBeforeStart = 0;
	private double estimatedDuration = -1;
	private int freezeCount = 0;
	private double timeoutMillisecondsForAdFreeze = 10000;
	private double timeoutCountForAdFreeze = 0;
	private double lastPlayheadTime = 0.0;

	private RendererVolumeDelegate volumeDelegate = null;

	/* internal state : calls
	 * started: pause(), resume(), stop(), dispose(), getDuration(), getPlayheadTime()
	 * stopped: dispose()
	 * disposed:
	 */
	private AtomicInteger internalState;
	private static int STATE_STARTED = 0;
	private static int STATE_STOPPED = 1;
	private static int STATE_DISPOSED = 2;

	private boolean clickHandledByPlayer = false;
	private boolean checkRedirectUrl = false;
	private static final Logger logger = Logger.getLogger(VideoRenderer.class);

	public VideoRenderer() {
		internalState = new AtomicInteger(STATE_STARTED);
	}

	@Override
	public void load(IRendererContext rendererContext) {
		logger.debug("init");
		this.rendererContext = rendererContext;

		this.constants = this.rendererContext.getConstants();
		this.slot = this.rendererContext.getAdInstance().getSlot();

		Object timeoutParam = this.rendererContext.getParameter(Constants._PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START);
		Object freezeParam = this.rendererContext.getParameter(constants.PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT());
		if (timeoutParam != null) {
			String timeoutStr = timeoutParam.toString();
			double val = Double.parseDouble(timeoutStr);
			if (val > 0) {
				this.timeoutMillisecondsBeforeStart = val;
			}
		}
		if (freezeParam != null) {
			String freezeStr = freezeParam.toString();
			double val = Double.parseDouble(freezeStr);
			if (val > 0) {
				this.timeoutMillisecondsForAdFreeze = val;
			}
		}
		this.timeoutCountBeforeStart = (int) (this.timeoutMillisecondsBeforeStart / QUARTILE_CHECK_INTERVAL);
		this.timeoutCountForAdFreeze = (int) (this.timeoutMillisecondsForAdFreeze / QUARTILE_CHECK_INTERVAL);

		// renderer doesn't dispatch EVENT_AD_CLICK()
		ParamParser paramParser = new ParamParser(rendererContext, "");
		if (DisplayUtils.isAndroidTV(rendererContext.getActivity())) {
			this.clickHandledByPlayer = true;
			this.rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), false);
		} else {
			this.clickHandledByPlayer = !paramParser.parseBoolean(constants.PARAMETER_CLICK_DETECTION(), true);
			this.rendererContext.setSupportedAdEvent(constants.EVENT_AD_CLICK(), true);
		}

		this.checkRedirectUrl = paramParser.parseBoolean("renderer.video.checkRedirectURL", false);

		VideoAdRenditionSelector renditionSelector = new VideoAdRenditionSelector(this.rendererContext);

		ICreativeRendition rendition = renditionSelector.getBestFitRendition();
		if (rendition == null) {
			Bundle info = new Bundle();
			// all creative renditions are dropped because of no asset
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "No asset");
			this.onRendererFailed(info);
			return;
		}

		logger.debug("Best fit rendition: " + rendition.toString());

		this.rendererContext.getAdInstance().setActiveCreativeRendition(rendition);
		this.estimatedDuration = rendition.getDuration();
		this.renditionWidth = rendition.getWidth();
		this.renditionHeight = rendition.getHeight();
		if (this.renditionWidth <= 0) {
			this.renditionWidth = this.slot.getWidth();
		}
		if (this.renditionHeight <= 0) {
			this.renditionHeight = this.slot.getHeight();
		}

		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_QUARTILE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_MUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_UNMUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_PAUSE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_RESUME(), true);

		if (rendition.getPrimaryCreativRenditionAsset() != null) {
			this.assetUrl = rendition.getPrimaryCreativRenditionAsset().getURL();
		} else {
			this.assetUrl = "";
		}

		String s = this.assetUrl;
		try {// test if assetUrl is valid
			logger.debug("assetUrl passed in: " + this.assetUrl);
			URI uri = new URI(this.assetUrl);
			if (!uri.isAbsolute()) {
				Bundle info = new Bundle();
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
				info.putString(constants.INFO_KEY_ERROR_INFO(), "original assetUrl: " + s);
				this.onRendererFailed(info);
			} else {
				logger.debug("converted to URI: " + uri.toString());
				this.startQuartileImpressionAndTimeoutPoller();
				this.preload();
			}
		} catch (URISyntaxException e) {
			this.assetUrl = URIUtil.getFixedString(this.assetUrl);
			logger.debug("assetUrl fixed: " + this.assetUrl);
			if (this.assetUrl == null) {
				Bundle info = new Bundle();
				info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_NULL_ASSET());
				info.putString(constants.INFO_KEY_ERROR_INFO(), "original assetUrl: " + s + " can not be fixed");
				this.onRendererFailed(info);
			} else {
				this.startQuartileImpressionAndTimeoutPoller();
				this.preload();
			}
		}
	}

	private void setVideoAdView(ViewGroup slotBase) {
		ParamParser paramParser = new ParamParser(rendererContext, "");
		boolean isVideoAdViewEnabled = paramParser.parseBoolean(Constants._PARAMETER_VIDEO_RENDERER_FORCE_MEDIA_PLAYER, false);
		if (isVideoAdViewEnabled) {
			videoAdView = new VideoAdView(slotBase.getContext(), this, shouldRequestFocus());
		} else {
			try {
				videoAdView = new ExoVideoAdView(slotBase.getContext(), this, shouldRequestFocus(), (int)this.timeoutMillisecondsBeforeStart);
				logger.debug("Created ExoVideoAdView");
			} catch (NoClassDefFoundError e) {
				logger.debug("Cannot create ExoVideoAdView, creating VideoAdView");
				videoAdView = new VideoAdView(slotBase.getContext(), this, shouldRequestFocus());
			}
		}
	}

	private void preload() {
		logger.debug("preload");
		try {
			final ViewGroup slotBase = slot.getBase();

			if (slotBase == null) {
				throw new RuntimeException("video display base is null, maybe forget to call registerVideoDisplay()?");
			}

			logger.debug("slotBase: " + slotBase);
			setVideoAdView(slotBase);
			// videoAdView.setId(2011120714);
			if (this.checkRedirectUrl) {
				this.tryToGetRedirectedUrl(assetUrl, (int)this.timeoutMillisecondsBeforeStart);
			} else {
				this.onRedirectUrlChecked(assetUrl, null);
			}
		} catch (RuntimeException e){
			logger.debug(e);
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
			info.putString(constants.INFO_KEY_ERROR_INFO(), e.getMessage());
			this.onRendererFailed(info);
		}
	}

	public void onRedirectUrlChecked(String url, Exception error) {
		logger.debug("onRedirectUrlChecked url " + url);
		if (error != null) {
			Bundle info = new Bundle();
			String errorCode = constants.ERROR_UNKNOWN();
			if (error instanceof SocketTimeoutException) {
				errorCode = constants.ERROR_TIMEOUT();
			}
			info.putString(constants.INFO_KEY_ERROR_CODE(), errorCode);
			info.putString(constants.INFO_KEY_ERROR_INFO(), error.getMessage());
			this.onRendererFailed(info);
		} else {
			this.assetUrl = url;
			videoAdView.loadUrl(url);
		}
	}

	private boolean shouldRequestFocus() {
		boolean shouldRequestFocus = true;
		Object param = rendererContext.getParameter(Constants._PARAMETER_VIDEO_RENDERER_REQUEST_FOCUS);
		if (param != null && param.toString().equalsIgnoreCase("false")) {
			shouldRequestFocus = false;
		}
		logger.debug("shouldRequestFocus: " + shouldRequestFocus);
		return shouldRequestFocus;
	}

	@Override
	/**
	 * AdManager will invoke start method to start video ad rendering.
	 */
	public void start() {
		logger.debug("start");
		this.defaultImpressionSent = false;
		this.startQuartileImpressionAndTimeoutPoller();


		final ViewGroup slotBase = slot.getBase();
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
			public void run() {
				if (slotBase == null) {
					VideoRenderer.logger.debug("video display base is null, maybe forget to call registerVideoDisplay()?");
					Bundle info = new Bundle();
					info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
					info.putString(constants.INFO_KEY_ERROR_INFO(), "Video slot base is null");
					VideoRenderer.this.onRendererFailed(info);
					return;
				}

				slotBase.addView((View) videoAdView);
				((View) videoAdView).bringToFront();
				if (shouldRequestFocus()) {
					((View) videoAdView).requestFocus();
				}
				videoAdView.start();
			}
		});

		if (videoAdView != null) {
			videoAdView.setVolume(rendererContext.getInitialAdVolume());
		}
		this.volumeDelegate = new RendererVolumeDelegate(this.rendererContext);
	}

	/**
	 *  AdManager should invoke this.dispose() after received STOPPED event
	 */
	public void onAdVideoViewComplete() {
		logger.debug("onAdVideoViewComplete");

		this.stopQuartilePoller();
		this.sendMissingQuartiles();
		String creativeAPI = this.rendererContext.getAdInstance().getActiveCreativeRendition().getCreativeAPI();
		if (!creativeAPI.equalsIgnoreCase("SIMID")) {
			rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
		}
	}

	/**
	 *  AdManager should invoke this.dispose() after received ERROR event
	 */
	public void onAdVideoViewError(Bundle info) {
		logger.debug("onAdVideoViewError: " + info.getString(constants.INFO_KEY_ERROR_INFO()));
		this.onRendererFailed(info);
	}

	public void onAdViewClicked() {
		logger.debug("onAdViewClicked, clickHandleByPlayer " + this.clickHandledByPlayer);
		if (!this.clickHandledByPlayer) {
			rendererContext.dispatchEvent(constants.EVENT_AD_CLICK());
		}
	}

	public void onAdViewStart() {
		logger.debug("onAdViewStart");

		((AdInstance) this.rendererContext.getAdInstance()).adjustOffsetWithRendererDuration();

		/*
		 * Must start once here, because one possible start path maybe:
		 * videoAdView.surfaceCreated -> videoAdView.surfaceChanged -> videoAdView.OnPrepared -> VideoRenderer.onAdViewLoaded -> videoAdView.startPlayback ->
		 * videoAdView.start -> VideoRenderer.onAdViewStart
		 * this will ensure in any start path, the quartile poller will be started
		 */
		this.startQuartileImpressionAndTimeoutPoller();
	}

	public void onAdPaused() {
		logger.debug("onAdPaused");
		rendererContext.dispatchEvent(constants.EVENT_AD_PAUSE());
	}

	public void onAdResumed() {
		logger.debug("onAdResumed");
		rendererContext.dispatchEvent(constants.EVENT_AD_RESUME());
	}

	public void onAdRewind() {
		logger.debug("onAdRewind");
		rendererContext.dispatchEvent(constants.EVENT_AD_REWIND());
	}

	/**
	 * invoked when videoAdView is prepared
	 */
	public void onAdViewLoaded() {
		logger.debug("onAdViewLoaded");
		stopQuartilePoller();

		if(videoAdView != null) {
			rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());
		}
	}

	public void onAdViewMediaPrepared() {
		logger.debug("onAdViewMediaPrepared. Renderer paused " + isPaused);
		if (videoAdView != null && !this.isPaused) {
			videoAdView.startPlayback();
		}
	}

	private void onQuartilePollCallback(){
		double playhead = this.getPlayheadTime();
		if (playhead <= 0){
			logger.debug("playhead <= 0");
			this.checkAndFailIfTimeout();
			return;
		} else if(!isPaused){
			if( playhead - this.lastPlayheadTime < 0.1){
				this.checkAndFailIfFreeze();
			}else{
				this.freezeCount = 0;
			}
		}
		this.impressionCountBeforeStart = 0;
		this.lastPlayheadTime = playhead;

		// playhead > 0, check defaultImpression
		if (! this.defaultImpressionSent) {
			rendererContext.dispatchEvent(constants.EVENT_AD_STARTED());
			this.defaultImpressionSent = true;
		}

		double duration = this.getDuration();
		if (duration <= 0 && this.estimatedDuration > 0) {
			logger.debug("use estimatedDuration " + this.estimatedDuration);
			duration = this.estimatedDuration;
		}
		if (duration > 0) {
			this.sendQuartiles(playhead / duration);
			((AdInstance) this.rendererContext.getAdInstance()).sendProgress(playhead);
			((AdInstance) this.rendererContext.getAdInstance()).processSkippableStateChangedEvent(playhead);
		} else {
			logger.debug("unknown duration");
		}
	}

	private void sendQuartiles(double percent){
		if (percent >= 0.25 && this.quartilesSent < 1){
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_FIRST_QUARTILE());
			this.quartilesSent = 1;
		}
		if (percent >= 0.5 && this.quartilesSent < 2){
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_MIDPOINT());
			this.quartilesSent = 2;
		}
		if (percent >= 0.75 && this.quartilesSent < 3){
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_THIRD_QUARTILE());
			this.quartilesSent = 3;
		}
		if (percent >= 0.99 && this.quartilesSent < 4){
			logger.debug(SEND_QUARTILES_LOG + percent);
			this.rendererContext.dispatchEvent(this.constants.EVENT_AD_COMPLETE());
			this.quartilesSent = 4;
		}
	}

	private void sendMissingQuartiles(){
		logger.debug("sendMissingQuartiles");
		this.sendQuartiles(1.0);
	}

	/**
	 *  AdManager should invoke this.dispose() after received STOPPED event
	 */
	@Override
	public void stop() {
		if (!internalState.compareAndSet(STATE_STARTED, STATE_STOPPED)) {
			logger.warn("stop in incorrect state");
			return;
		}

		logger.debug("stop");
		this.stopQuartilePoller();
		if(this.videoAdView != null) {
			this.videoAdView.stop();
		}

		String creativeAPI = this.rendererContext.getAdInstance().getActiveCreativeRendition().getCreativeAPI();
		if (!creativeAPI.equalsIgnoreCase("SIMID")) {
			rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
		}
	}

	@Override
	public void pause() {
		if (internalState.get() != STATE_STARTED) {
			logger.warn("pause in incorrect state");
			return;
		}

		logger.debug("pause");
		this.stopQuartilePoller();
		if (this.videoAdView != null) {
			this.isPaused = true;
			this.videoAdView.pause();
			this.onAdPaused();
		}
	}

	@Override
	public void resume() {
		if (internalState.get() != STATE_STARTED) {
			logger.warn("resume in incorrect state");
			return;
		}

		logger.debug("resume");
		this._resume();
	}

	private void _resume() {
		logger.debug("_resume");
		if (this.videoAdView != null) {
			this.isPaused = false;
			this.videoAdView.start();
			this.onAdResumed();
		}
		this.startQuartileImpressionAndTimeoutPoller();
	}

	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<String, String>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_MODULE_NAME(), this.getClass().getName());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	protected int getHeight() {
		return this.slot.getHeight();
	}

	protected int getWidth() {
		return this.slot.getWidth();
	}

	public double getDuration() {
		if (internalState.get() != STATE_STARTED) {
			logger.warn("getDuration in incorrect state");
			return -1;
		}

		if (videoAdView != null && videoAdView.getDuration() > 0) {
			return videoAdView.getDuration()/1000;
		} else {
			return -1;
		}
	}

	public double getPlayheadTime() {
		if (internalState.get() != STATE_STARTED) {
			logger.warn("getPlayheadTime in incorrect state");
			return -1;
		}

		if (videoAdView != null) {
			return videoAdView.getPlayheadTime()/1000;
		} else {
			return -1;
		}
	}

	@Override
	public void dispose() {
		if (!internalState.compareAndSet(STATE_STARTED, STATE_DISPOSED)
				&& !internalState.compareAndSet(STATE_STOPPED, STATE_DISPOSED)) {
			logger.warn("dispose in incorrect state");
			return;
		}

		logger.debug("dispose");
		if(videoAdView == null) {
			return;
		}

		if (this.volumeDelegate != null) {
			this.volumeDelegate.dispose();
			this.volumeDelegate = null;
		}

		final ViewGroup slotBase = slot.getBase();
		Handler handler = new Handler(Looper.getMainLooper());

		videoAdView.dispose();

		handler.post(new Runnable() {
			public void run () {
				((View) videoAdView).setVisibility(View.GONE);
				if (slotBase != null) {
					slotBase.removeView((View) videoAdView);
				}
				videoAdView = null;
			}
		});
	}

	public void onRestartVideo() {
		startQuartileImpressionAndTimeoutPoller();
	}

	private void startQuartileImpressionAndTimeoutPoller() {
		logger.debug("startQuartileImpressionAndTimeoutPoller");
		if (this.pollingQuartileHandler != null) {
			logger.debug("Polling Quartile Handler exists, not creating again");
			return;
		}

		this.pollingQuartileHandler = new RepeatingHandler();
		this.repeatingQuartileRunnable = new Runnable() {
			@Override
			public void run() {
				onQuartilePollCallback();
			}
		};
		this.pollingQuartileHandler.postRepeated(repeatingQuartileRunnable, QUARTILE_CHECK_INTERVAL, QUARTILE_CHECK_INTERVAL);
	}

	private void stopQuartilePoller() {
		logger.debug("stopQuartilePoller");
		if (this.pollingQuartileHandler != null) {
			this.pollingQuartileHandler.removeRepeating(repeatingQuartileRunnable);
			this.repeatingQuartileRunnable = null;
			this.pollingQuartileHandler = null;
		}
	}

	public void onAdViewSurfaceDestroyed() {
		this.stopQuartilePoller();
	}

	private void checkAndFailIfTimeout() {
		if (this.impressionCountBeforeStart >= this.timeoutCountBeforeStart) {
			logger.warn("ad content can not start in " + this.timeoutMillisecondsBeforeStart + "ms, just fail!");
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_TIMEOUT());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "ad content can not start in " + (int)(this.timeoutMillisecondsBeforeStart / 1000) + "s");
			this.onRendererFailed(info);
		} else {
			++this.impressionCountBeforeStart;
		}
	}

	private void checkAndFailIfFreeze() {
		if (this.freezeCount >= this.timeoutCountForAdFreeze){
			logger.warn("ad content is unexpected paused for " + this.timeoutMillisecondsForAdFreeze + "ms, just fail!");
			this.freezeCount = 0;
			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_TIMEOUT());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "ad content is unexpected paused for " + this.timeoutMillisecondsForAdFreeze / 1000 + "s");
			this.onRendererFailed(info);
		} else {
			++this.freezeCount;
		}
	}

	@Override
	public void resize() {
		if (this.videoAdView != null) {
			FrameLayout displayBase = (FrameLayout) ((View) this.videoAdView).getParent();
			if (displayBase != null && displayBase != this.slot.getBase()) {
				logger.debug("video display base changed");
				this.videoAdView.pause();
				displayBase.removeView((View) this.videoAdView);
				this.slot.getBase().addView((View) this.videoAdView);
				this.videoAdView.start();
			}
		}
	}

	@Override
	public void setVolume(float volumeValue) {
		logger.debug("Set volume to " + volumeValue);
		if (this.videoAdView == null) {
			logger.debug("video ad view is null, ignore");
			return;
		}

		if (this.volumeDelegate == null) {
			logger.debug("volumeDelegate is null, ignore");
			return;
		}

		if (videoAdView.getVolume() != volumeValue) {
			videoAdView.setVolume(volumeValue);
			this.volumeDelegate.onAdVolumeChanged(volumeValue);
		}
	}

	public void onAdViewBuffered(boolean end) {
		rendererContext.dispatchEvent(end ? constants.EVENT_AD_BUFFERING_END() : constants.EVENT_AD_BUFFERING_START());
	}

	private void onRendererFailed(Bundle info) {
		this.stopQuartilePoller();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_ERROR(), map);
	}

	@Override
	public View getAdView(){
		return (View) this.videoAdView;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}


	public void tryToGetRedirectedUrl(final String url, final int timeoutMs) {
		new Thread(() -> {
			Exception error = null;
			String adUrl = url;
			HttpURLConnection urlConnection = null;
			try {
				URL urlString = new URL(url);
				urlConnection = (HttpURLConnection) urlString.openConnection();
				urlConnection.setConnectTimeout(timeoutMs);
				urlConnection.setReadTimeout(timeoutMs);
				urlConnection.setInstanceFollowRedirects(false);
				int code = urlConnection.getResponseCode();
				if (code == 302) {
					logger.debug("tryToGetRedirectedUrl asset url is a redirect url");
					adUrl = urlConnection.getHeaderField("Location");
				}
			} catch (MalformedURLException e) {
				error = e;
				logger.warn("tryToGetRedirectedUrl MalformedURLException for url:" + url);
			} catch (IOException e) {
				error = e;
				logger.warn("tryToGetRedirectedUrl IOException for url:" + url);
			} finally {
				if (urlConnection != null) {
					urlConnection.disconnect();
				}
			}
			if (adUrl == null) {
				adUrl = url;
			}
			onRedirectUrlChecked(adUrl, error);
		}).start();
	}
}
