package tv.freewheel.renderers.temporal;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.io.IOException;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.renderer.RendererUtils;

public class VideoAdView extends SurfaceView implements IVideoAdView,
		SurfaceHolder.Callback, OnCompletionListener, OnVideoSizeChangedListener {
	// all possible internal states
	private static final int STATE_ERROR              = -1;
	private static final int STATE_IDLE               = 0;
	private static final int STATE_PREPARING          = 1;
	private static final int STATE_PREPARED           = 2;
	private static final int STATE_PLAYING            = 3;
	private static final int STATE_PAUSED             = 4;
	private static final int STATE_PLAYBACK_COMPLETED = 5;

	// mCurrentState is a VideoView object's current state.
	// mTargetState is the state that a method caller intends to reach.
	// For instance, regardless the VideoView object's current state,
	// calling pause() intends to bring the object to a target state
	// of STATE_PAUSED.
	private int mCurrentState = STATE_IDLE;
	private int mTargetState  = STATE_IDLE;

	private MediaPlayer mediaPlayer;
	private float volume = -1;
	private VideoRenderer hostRenderer;
	private String adUrl;
	protected IConstants constants;
	private SurfaceHolder surfaceHolder = null;
	private int mSurfaceWidth;
	private int mSurfaceHeight;
	private int mDuration;
	private int mSeekWhenPrepared;
	private int mLastPlayheadTime;
	private int mVideoWidth;
	private int mVideoHeight;
	private RendererUtils.MuteState isMuted;
	private boolean preloading = false;
	private static final Logger logger = Logger.getLogger(VideoAdView.class);
	private GestureDetector clickDetector;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		logger.debug("onTouchEvent");
		if (this.clickDetector != null && this.clickDetector.onTouchEvent(event)) {
			return true;
		}
		return super.onTouchEvent(event);
	}

	class VideoAdViewClickDetector extends GestureDetector.SimpleOnGestureListener {

		@Override
		public boolean onSingleTapConfirmed(MotionEvent e) {
			logger.debug("onSingleTapConfirmed");
			if (isInPlaybackState()) {
				if (hostRenderer != null) {
					hostRenderer.onAdViewClicked();
				}
			} else {
				logger.debug("ignore click if not in playback state, current state " + mCurrentState);
			}
			return true;
		}

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
			logger.debug("onFling");
			return false;
		}

		@Override
		public boolean onDown(MotionEvent e) {
			logger.debug("onDown");
			return true;
		}
	}

	public VideoAdView(Context context, VideoRenderer hostRenderer, boolean shouldRequestFocus) {
		super(context);
		this.hostRenderer = hostRenderer;
		this.constants = hostRenderer.constants;

		this.initVideoView(shouldRequestFocus);
		if (!DisplayUtils.isAndroidTV(context)) {
			clickDetector = new GestureDetector(context, new VideoAdViewClickDetector());
		}

		mVideoWidth = 0;
		mVideoHeight = 0;

		this.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT, Gravity.CENTER));
	}

	private void initVideoView(boolean shouldRequestFocus) {
		getHolder().addCallback(this);
		getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		setFocusable(true);
		setFocusableInTouchMode(true);
		if (shouldRequestFocus) {
			requestFocus();
		}

		mCurrentState = STATE_IDLE;
		mTargetState  = STATE_IDLE;
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		logger.debug("surfaceChanged w:" + w + " h:" + h);
		mSurfaceWidth = w;
		mSurfaceHeight = h;
		boolean isValidState = (mTargetState == STATE_PLAYING);
		boolean hasValidSize = (mVideoWidth == w && mVideoHeight == h);
		if (mediaPlayer != null && isValidState && hasValidSize) {
			if (mSeekWhenPrepared != 0) {
				seekTo(mSeekWhenPrepared);
			}
			start();
		}
	}

	private MediaPlayer.OnErrorListener errorListener = new MediaPlayer.OnErrorListener() {
		public boolean onError(MediaPlayer mp, int frameworkErr, int implErr) {
			logger.debug("onError: " + frameworkErr + "," + implErr);
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			if (hostRenderer != null) {
				Bundle info = new Bundle();
				String msg;
				if(frameworkErr == MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK) { //invalid format
					info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
					msg = "The video is streamed and its container is not valid for progressive playback " +
							"i.e the video's index (e.g moov atom) is not at the start of the file.";
				} else if (frameworkErr == MediaPlayer.MEDIA_ERROR_UNKNOWN) {
					//thrown out when plays flv
					info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
					msg = "media file format is not recognized.";
				} else if (frameworkErr == MediaPlayer.MEDIA_ERROR_SERVER_DIED) {
					info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
					msg = "media server has gone away.";
				} else {
					info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
					msg = "unknown common IO error.";
				}

				info.putString(constants.INFO_KEY_ERROR_INFO(), msg);

				hostRenderer.onAdVideoViewError(info);
			}
			return true;
		}
	};

	MediaPlayer.OnPreparedListener preparedListener = new MediaPlayer.OnPreparedListener() {
		public void onPrepared(MediaPlayer mp) {
			logger.debug("OnPrepared");

			mCurrentState = STATE_PREPARED;
			if (preloading) {
				if (hostRenderer != null) {
					hostRenderer.onAdViewLoaded();
				}
				return;
			}

			int seekToPosition = mSeekWhenPrepared;
			if (seekToPosition != 0) {
				seekTo(seekToPosition);
			}
			mVideoWidth = mp.getVideoWidth();
			mVideoHeight = mp.getVideoHeight();
			logger.debug("videoWidth: " + mVideoWidth + ", videoHeight: " + mVideoHeight);
			if (mVideoWidth != 0 && mVideoHeight != 0) {
				int targetWidth = mVideoWidth;
				int targetHeight = mVideoHeight;

				if (CommonUtil.viewHasComposeParent(VideoAdView.this)) {
					ViewGroup parent = (ViewGroup) getParent();
					if (parent != null) {
						targetWidth = parent.getWidth();
						targetHeight = parent.getHeight();
					}
				}

				logger.debug("Setting surface size to: " + targetWidth + "x" + targetHeight);
				getHolder().setFixedSize(targetWidth, targetHeight);
				if (mSurfaceWidth == mVideoWidth && mSurfaceHeight == mVideoHeight) {
					if (mTargetState == STATE_PLAYING) {
						start();
					}
				}
			} else {
				if (mTargetState == STATE_PLAYING) {
					start();
				}
			}
			if (hostRenderer != null) {
				hostRenderer.onAdViewMediaPrepared();
			}
		}
	};

	MediaPlayer.OnInfoListener onInfoListener =  new MediaPlayer.OnInfoListener() {
		@Override
		public boolean onInfo(MediaPlayer mp, int what, int extra) {
			logger.debug("onInfo(" + what + "," + extra + ")");
			switch (what) {
				case MediaPlayer.MEDIA_INFO_BUFFERING_START:
					if (hostRenderer != null) {
						hostRenderer.onAdViewBuffered(false);
					}
					break;
				case MediaPlayer.MEDIA_INFO_BUFFERING_END:
					if (hostRenderer != null) {
						hostRenderer.onAdViewBuffered(true);
					}
					break;
				default:
					break;
			}

			return true;
		}
	};

	MediaPlayer.OnBufferingUpdateListener onBufferingUpdateListener = new MediaPlayer.OnBufferingUpdateListener() {
		@Override
		public void onBufferingUpdate(MediaPlayer mp, int percent) {
		}
	};

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		logger.debug("surfaceCreated");
		this.surfaceHolder = holder;
		//add guard to avoid crash
		if (this.mediaPlayer == null) {
			this.preloading = false;
		}
		if (this.preloading) {
			this.preloading = false;
			startPreloadedVideo();
		} else if (this.mediaPlayer != null) {
			this.restartVideo();
		} else {
			this.openVideo();
		}
	}

	private void restartVideo() {
		logger.debug("restartVideo");
		mediaPlayer.setDisplay(this.surfaceHolder);
		if (hostRenderer != null) {
			hostRenderer.onRestartVideo();
		}
	}

	private void startPreloadedVideo() {
		mDuration = -1;
		mediaPlayer.setDisplay(this.surfaceHolder);
		mediaPlayer.setOnErrorListener(errorListener);
		mediaPlayer.setOnCompletionListener(this);
		mediaPlayer.setOnVideoSizeChangedListener(this);
		mediaPlayer.setScreenOnWhilePlaying(true);
		if (mCurrentState == STATE_PREPARED && preparedListener != null) {
			preparedListener.onPrepared(mediaPlayer);
		} else {
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_UNKNOWN());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "MediaPlayer should in prepared state when start play");
			if (hostRenderer != null) {
				hostRenderer.onAdVideoViewError(info);
			}
		}
	}

	private void openVideo() {
		if(this.surfaceHolder == null) {
			return;
		}

		release(false);
		try {
			mediaPlayer = new MediaPlayer();
			mDuration = -1;
			if (this.volume >= 0) {
				mediaPlayer.setVolume(this.volume, this.volume);
			}
			mediaPlayer.setDisplay(this.surfaceHolder);
			mediaPlayer.setDataSource(this.adUrl);
			mediaPlayer.setOnErrorListener(errorListener);
			mediaPlayer.setOnPreparedListener(preparedListener);
			mediaPlayer.setOnInfoListener(onInfoListener);
			mediaPlayer.setOnBufferingUpdateListener(onBufferingUpdateListener);
			mediaPlayer.setOnCompletionListener(this);
			mediaPlayer.setOnVideoSizeChangedListener(this);
			mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaPlayer.setScreenOnWhilePlaying(true);
			mediaPlayer.prepareAsync();
			mCurrentState = STATE_PREPARING;
		} catch (IllegalArgumentException e) {
			logger.debug(e.getMessage());
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_INVALID_VALUE());
			info.putString(constants.INFO_KEY_ERROR_INFO(), e.getMessage());
			if (hostRenderer != null) {
				hostRenderer.onAdVideoViewError(info);
			}
		} catch (IOException e) {
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "Unable to open content: "
					+ this.adUrl + ", error: " + e.toString());
			if (hostRenderer != null) {
				hostRenderer.onAdVideoViewError(info);
			}
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		logger.debug("surfaceDestroyed");
		surfaceHolder = null;
		if (this.hostRenderer != null) {
			this.hostRenderer.onAdViewSurfaceDestroyed();
		}
		if (this.mediaPlayer != null) {
			pause();
			this.mSeekWhenPrepared = this.mediaPlayer.getCurrentPosition();
			this.mediaPlayer.setDisplay(null);
		}
	}

	public void startPlayback() {
		logger.debug("startPlayback");
		start();
		if (hostRenderer != null) {
			hostRenderer.onAdViewStart();
		}
	}

	public void stop() {
		logger.debug("stop");
		if (isInPlaybackState()) {
			this.mediaPlayer.stop();
			this.mediaPlayer.release();
			this.mediaPlayer = null;
			mCurrentState = STATE_IDLE;
			mTargetState  = STATE_IDLE;
		}
	}

	public void dispose() {
		logger.debug("dispose");
		release(true);
		clickDetector = null;
		hostRenderer = null;
		surfaceHolder = null;
		constants = null;
	}

	public void pause() {
		logger.debug("pause");
		if (isInPlaybackState()) {
			if (mediaPlayer.isPlaying()) {
				mSeekWhenPrepared = mediaPlayer.getCurrentPosition();
				mLastPlayheadTime = mSeekWhenPrepared;
				mediaPlayer.pause();
				mCurrentState = STATE_PAUSED;
			}
		}
		mTargetState = STATE_PAUSED;
	}

	public void start() {
		logger.debug("start");
		if (isInPlaybackState()) {
			mediaPlayer.start();
			mCurrentState = STATE_PLAYING;
		}
		mTargetState = STATE_PLAYING;
	}

	@Override
	public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
		logger.debug("onVideoSizeChanged width: " + width + " height: " + height);
		mVideoWidth = mp.getVideoWidth();
		mVideoHeight = mp.getVideoHeight();
		if (mVideoWidth != 0 && mVideoHeight != 0) {
			getHolder().setFixedSize(mVideoWidth, mVideoHeight);
		}
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		logger.debug("video completion");
		// the following code's order must not be changed
		mCurrentState = STATE_PLAYBACK_COMPLETED;
		mTargetState = STATE_PLAYBACK_COMPLETED;
		if (hostRenderer != null) {
			hostRenderer.onAdVideoViewComplete();
		}
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int measuredWidth = getDefaultSize(mVideoWidth, widthMeasureSpec);
		int measuredHeight = getDefaultSize(mVideoHeight, heightMeasureSpec);

		if (mVideoWidth > 0 && mVideoHeight > 0) {
			if (mVideoWidth * measuredHeight > measuredWidth * mVideoHeight) {
				measuredHeight = measuredWidth * mVideoHeight / mVideoWidth;
			} else if (mVideoWidth * measuredHeight < measuredWidth * mVideoHeight) {
				measuredWidth = measuredHeight * mVideoWidth / mVideoHeight;
			}
		}

		logger.debug("onMeasure width: " + measuredWidth + " height: " + measuredHeight);
		setMeasuredDimension(measuredWidth, measuredHeight);
	}

	public double getPlayheadTime() {
		if (isInPlaybackState()) {
			try {
				int playheadTime = mediaPlayer.getCurrentPosition();
				if (mLastPlayheadTime > 0) {
					if (playheadTime == 0) {
						playheadTime = mLastPlayheadTime;
					} else {
						mLastPlayheadTime = 0;
					}
				}
				return playheadTime;
			} catch (Throwable t) {
				logger.debug("getPlayheadTime: " +  t.getMessage());
			}
		} else if (mLastPlayheadTime > 0) {
			return mLastPlayheadTime;
		}
		return -1;
	}

	public double getDuration() {
		if (isInPlaybackState()) {
			try {
				if (mDuration > 0) {
					return mDuration;
				}
				mDuration = mediaPlayer.getDuration();
				return mDuration;
			} catch (Throwable t) {
				logger.debug("getDuration: " + t.getMessage());
			}
		}
		mDuration = -1;
		return mDuration;
	}

	/*
	 * release the media player in any state
	 */
	private void release(boolean cleartargetstate) {
		if (mediaPlayer != null) {
			mediaPlayer.release();
			mediaPlayer = null;
			preparedListener = null;
			mCurrentState = STATE_IDLE;
			if (cleartargetstate) {
				mTargetState  = STATE_IDLE;
			}
		}
	}

	protected boolean isInPlaybackState() {
		return (mediaPlayer != null &&
				surfaceHolder != null &&
				mCurrentState != STATE_ERROR &&
				mCurrentState != STATE_IDLE &&
				mCurrentState != STATE_PREPARING &&
				!this.preloading);
	}

	public void seekTo(int msec) {
		logger.debug("seekTo : " + msec);
		if (isInPlaybackState()) {
			mediaPlayer.seekTo(msec);
			mSeekWhenPrepared = 0;
		} else {
			mSeekWhenPrepared = msec;
		}
	}

	public void setVolume(float volume) {
		this.volume = volume;
		mediaPlayer.setVolume(volume, volume);
	}

	public float getVolume() {
		return this.volume;
	}

	public void loadUrl(String adUrl) {
		logger.debug("loadUrl");
		mediaPlayer = new MediaPlayer();
		this.adUrl = adUrl;
		try {
			mediaPlayer.setDataSource(this.adUrl);
			mediaPlayer.setOnErrorListener(errorListener);
			mediaPlayer.setOnInfoListener(onInfoListener);
			mediaPlayer.setOnBufferingUpdateListener(onBufferingUpdateListener);
			mediaPlayer.setOnPreparedListener(preparedListener);
			mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaPlayer.prepareAsync();
			mCurrentState = STATE_PREPARING;
			this.preloading = true;
		} catch (IllegalArgumentException e) {
			logger.debug(e.getMessage());
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_INVALID_VALUE());
			info.putString(constants.INFO_KEY_ERROR_INFO(), e.getMessage());
			if (hostRenderer != null) {
				hostRenderer.onAdVideoViewError(info);
			}
		} catch (IOException e) {
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;

			Bundle info = new Bundle();
			info.putString(constants.INFO_KEY_ERROR_CODE(), constants.ERROR_IO());
			info.putString(constants.INFO_KEY_ERROR_INFO(), "Unable to open content: "
					+ this.adUrl + ", error: " + e.toString());
			if (hostRenderer != null) {
				hostRenderer.onAdVideoViewError(info);
			}
		}
	}
}
