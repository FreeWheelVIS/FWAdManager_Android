package tv.freewheel.renderers.temporal;

import android.app.Activity;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import tv.freewheel.utils.Logger;

public class SIMIDWebView extends WebView {
	private static final Logger logger = Logger.getLogger(SIMIDWebView.class);
	private SIMIDRenderer bridge;

	public SIMIDWebView(Activity activity, SIMIDRenderer renderer) {
		super(activity);
		bridge = renderer;
		this.getSettings().setAllowContentAccess(false);
		this.getSettings().setAllowFileAccess(false);
		this.getSettings().setAllowFileAccessFromFileURLs(false);
		this.getSettings().setAllowUniversalAccessFromFileURLs(false);

		this.setWebChromeClient(new WebChromeClient() {
			@Override
			public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
				logger.debug("JS Console log " + consoleMessage.message() + " -- From line "
						+ consoleMessage.lineNumber() + " of "
						+ consoleMessage.sourceId());
				return true;
			}
		});
	}

	public String generateSIMIDWebViewHTML() {
		String js = SIMIDConstants.SIMID_JS;
		String wrappedJs = "<script type = \"text/javascript\">" + js + "</script>\n";
		String environmentString0 = "<!DOCTYPE html>\n" +
				"<html>\n" +
				"      <head>\n";
		String environmentString1 =
				"            <meta name = \"viewport\" content = \"initial-scale = 1.0\" />\n" +
						"            <meta charset=\"utf-8\">\n" +
						"            <title>FWSIMIDRenderer</title>\n" +
						"      </head>\n" +
						"      <body style=\"margin:0px;padding:0px;\">\n" +
						"      </body>\n" +
						"</html>";
		logger.debug(environmentString0 + environmentString1);
		return environmentString0 + wrappedJs + environmentString1;
	}

	@Override
	public void evaluateJavascript(final String script, final ValueCallback<String> resultCallback) {
		bridge.getActivity().runOnUiThread(() -> {
			logger.debug("Execute: " + script + " on SIMID WebView: " + SIMIDWebView.this);
			SIMIDWebView.super.evaluateJavascript(script, new ValueCallback<String>() {
				@Override
				public void onReceiveValue(String value) {
					logger.debug("SIMID Script call: " + script + " returned value: " + value);
					if (resultCallback != null) {
						resultCallback.onReceiveValue(value);
					}
				}
			});
		});
	}

}
