package tv.freewheel.renderers.temporal;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.URIUtil;
import tv.freewheel.utils.handler.RepeatingHandler;
import tv.freewheel.utils.renderer.ParamParser;
import tv.freewheel.utils.renderer.RendererVolumeDelegate;

/**
 * Created by plade on 11/30/16.
 */

public class VPAIDRenderer implements IRenderer {
	private static final String PARAM_DESIRED_BITRATE = "desiredBitrate";
	private static final String VIEW_MODE = "normal";
	private static final Logger logger = Logger.getLogger(VPAIDRenderer.class);
	private IRendererContext rendererContext;
	private Activity activity;
	private VPAIDWebView vpaidWebView;
	private IConstants constants;
	private ISlot slot;
	private double timeoutMillisecondsBeforeStart;
	private String vpaidHTML;
	private double duration = -1;
	private double playheadTime = -1;
	private CreativeRendition rendition;
	private Handler mainLoopHandler;
	// boolean variable to track whether stop ad was requested
	private boolean stopRequested = false;
	private String assetUrl;
	private int quartilesSent;
	private Runnable loadingRunnable;
	private RepeatingHandler playheadTimeHandler;
	private Runnable playheadTimeRunnable;
	private double DEFAULT_TIMEOUT = 5000;

	private boolean rendererStarted = false;
	private boolean isPaused = false;
	private static final double DEFAULT_DESIRED_BITRATE = 1000.0;
	private double desiredBitRate = DEFAULT_DESIRED_BITRATE;

	private float vpaidVolume = 1;
	private RendererVolumeDelegate volumeDelegate = null;
	private View.OnLayoutChangeListener onResizeListener;

	private boolean adSkippableState = false;
	private boolean hasAdSkippableStateInitiatedValue = false;

	public VPAIDRenderer() {
		mainLoopHandler = new Handler(Looper.myLooper());
	}

	private void startPlayheadTimeCheck() {
		if (playheadTimeRunnable != null && playheadTimeHandler != null) {
			playheadTimeHandler.postRepeated(playheadTimeRunnable, 0,250);
		}
	}

	private void stopPlayheadTimeCheck() {
		if (playheadTimeHandler != null && playheadTimeRunnable != null) {
			playheadTimeHandler.removeRepeating(playheadTimeRunnable);
		}
	}

	@Override
	public void load(IRendererContext rendererContext) {
		logger.debug("load");

		this.rendererContext = rendererContext;
		this.activity = rendererContext.getActivity();
		this.constants = this.rendererContext.getConstants();
		this.slot = this.rendererContext.getAdInstance().getSlot();

		Object timeoutParam = this.rendererContext.getParameter(Constants._PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START);
		if (timeoutParam != null) {
			String timeoutStr = timeoutParam.toString();
			timeoutMillisecondsBeforeStart = StringUtils.parseDouble(timeoutStr, DEFAULT_TIMEOUT);
		} else {
			timeoutMillisecondsBeforeStart = DEFAULT_TIMEOUT;
		}

		// get details of the rendition and the asset.
		rendition = (CreativeRendition) this.rendererContext.getAdInstance().getActiveCreativeRendition();

		String desiredBitrateStr = (String)this.rendererContext.getParameter(PARAM_DESIRED_BITRATE);
		if (desiredBitrateStr != null) {
			desiredBitRate = StringUtils.parseDouble(desiredBitrateStr, DEFAULT_DESIRED_BITRATE);
			if (desiredBitRate < 0.0) {
				desiredBitRate = DEFAULT_DESIRED_BITRATE;
			}
			logger.debug("Desired bit rate " + desiredBitRate + " kbps");
		}

		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_QUARTILE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_MUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_UNMUTE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_PAUSE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_RESUME(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_EXPAND(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_COLLAPSE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_ACCEPT_INVITATION(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_MINIMIZE(), true);
		this.rendererContext.setSupportedAdEvent(this.constants.EVENT_AD_CLOSE(), true);

		if (rendition.getPrimaryCreativRenditionAsset() != null && !StringUtils.isBlank(rendition.getPrimaryCreativRenditionAsset().getURL())) {
			this.assetUrl = rendition.getPrimaryCreativRenditionAsset().getURL();
		} else {
			failWithError(constants.ERROR_NULL_ASSET(), "Primary creative rendition not found");
			return;
		}

		// verify the asset url
		String s = this.assetUrl;
		try {// test if assetUrl is valid
			logger.debug("assetUrl passed in: " + this.assetUrl);
			URI uri = new URI(this.assetUrl);
			if (!uri.isAbsolute()) {
				// assetUrl is not absolute
				failWithError(constants.ERROR_INVALID_VALUE(), "original assetUrl: " + s);
				return;
			} else {
				logger.debug("converted to URI: " + uri.toString());
			}
		} catch (Exception e) {
			this.assetUrl = URIUtil.getFixedString(this.assetUrl);
			logger.debug("assetUrl fixed: " + this.assetUrl);
			if (this.assetUrl == null) {
				// assetUrl cannot be fixed
				failWithError(constants.ERROR_INVALID_VALUE(), "original assetUrl: " + s + " can not be fixed");
				return;
			}
		}

		ParamParser paramParser = new ParamParser(rendererContext, "");
		if (paramParser.parseBoolean(constants.PARAMETER_DOUBLE_DECODE_VPAID_URL(), false)) {
			logger.debug("Double decoding the VPAID URL");
			try {
				this.assetUrl = URLDecoder.decode(assetUrl, "UTF-8");
			} catch (UnsupportedEncodingException e1) {
				logger.debug("Could not double decode URL: " + this.assetUrl, e1);
			}
		}

		vpaidWebView = new VPAIDWebView(activity, this);
		WebSettings webSettings = vpaidWebView.getSettings();

		vpaidWebView.clearCache(true);


		vpaidHTML = vpaidWebView.generateVPAIDWebViewHTML(getSlotWidth(), getSlotHeight());
		webSettings.setJavaScriptEnabled(true);

		// Enable auto play without user gesture
		webSettings.setMediaPlaybackRequiresUserGesture(false);

		// Mixed content (HTTP over HTTPS) does not work for LOLLIPOP and higher by default
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

			//MIXED_CONTENT_COMPATIBILITY_MODE is recommended but causes issues with some ads
			webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		}
		logger.debug("Asset URL: " + assetUrl);
		vpaidWebView.addJavascriptInterface(this, "JSInterface");

		vpaidWebView.loadDataWithBaseURL(assetUrl, vpaidHTML, "text/html", "utf8", null);

		playheadTimeHandler = new RepeatingHandler();
		playheadTimeRunnable = new Runnable() {
			@Override
			public void run() {
				try {
					_getPlayheadTime();
				} catch (Exception e) {
					VPAIDRenderer.logger.debug(e);
				}
			}
		};
	}

	public void failWithError(String errorCode, String errorInfo) {
		Bundle info = new Bundle();
		info.putString(constants.INFO_KEY_ERROR_CODE(), errorCode);
		info.putString(constants.INFO_KEY_ERROR_INFO(), errorInfo);
		HashMap<String, Object> map = new HashMap<>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_ERROR(), map);
	}

	public void loadVPAIDCreative(final String assetUrl) {
		logger.debug("Loading creative asset at: " + assetUrl);
		loadingRunnable = new Runnable() {
			@Override
			public void run() {
				//Creative asset did not load or start. Go to error.
				logger.debug("Creative asset did not finish task in time");
				failWithError(constants.ERROR_TIMEOUT(), "Creative asset did not start in time");
			}
		};

		logger.debug("Time out period in ms: "+timeoutMillisecondsBeforeStart);
		mainLoopHandler.postDelayed(loadingRunnable, (long) timeoutMillisecondsBeforeStart);
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.loadCreativeAsset(\"" + assetUrl + "\");", null);
	}

	public void cancelVPAIDTimeout(){
		logger.debug("cancelVPAIDTimeout");
		if (loadingRunnable != null) {
			mainLoopHandler.removeCallbacks(loadingRunnable);
		}
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.cancelTimeoutEvent();", null);
	}

	@JavascriptInterface
	public void onAssetLoadFinished() {
		logger.debug("onAssetLoadFinished");
		this.cancelVPAIDTimeout();
		// check handshake version
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.handshakeVersion(2.0);", null);
	}

	@JavascriptInterface
	public void vpaidVersionResult(String result) {
		logger.debug("VPAID creative version is " + result);

		if (Constants.SUPPORTED_CREATIVE_VPAID_VERSION_MIN <= StringUtils.parseDouble(result, -1.D)) {
			vpaidWebView.evaluateJavascript("fw_vast_wrapper.subscribeToCreativeEvents();", null);

			String creativeData = (String) this.rendererContext.getParameter("creativeData");
			if(creativeData == null) {
				creativeData = (String) this.rendererContext.getParameter("VPAID_creativeData");
			}
			if(creativeData == null) {
				creativeData = "";
			}

			creativeData = creativeData.replace("\\", "\\\\");
			String escapedCreativeData = creativeData.replace("\"", "\\\"").replace("\n", "\\n");
			String adParameterJSObject = String.format("{AdParameters: \"%s\"}", escapedCreativeData);
			String initParameters = String.format("%d,%d,\"%s\",\"%s\",%s", getSlotWidth(), getSlotHeight(), VIEW_MODE, desiredBitRate, adParameterJSObject);
			logger.debug("InitParameters are: " + initParameters);
			String initAdJavascriptCall = "fw_vast_wrapper.initAd(" + initParameters + ");";
			vpaidWebView.evaluateJavascript(initAdJavascriptCall, null);
		} else {
			logger.debug("Error because handshake version wasn't correct: ");
			failWithError(constants.ERROR_UNSUPPORTED_3P_FEATURE(), "VPAID version " + result + " is not supported.");
			//TODO fail with error
		}
	}

	private int getSlotWidth() {
		int slotWidth = slot.getBase() != null ? DisplayUtils.pixelToDp(activity, slot.getBase().getWidth()): -1;
		return slotWidth;
	}

	private int getSlotHeight() {
		int slotHeight = slot.getBase() != null ? DisplayUtils.pixelToDp(activity, slot.getBase().getHeight()): -1;
		return slotHeight;
	}
	@JavascriptInterface
	public void onAdLog(String message) {
		logger.debug("VPAID Ad Log: " + message);
	}

	@JavascriptInterface
	public void onAdError(String message) {
		logger.debug("VPAID Ad Error: " + message);
		failWithError(constants.ERROR_UNKNOWN(), message);
		this.stop();
	}

	@JavascriptInterface
	public void timeout(String timeoutOperation) {
		logger.debug("Timeout occurred for operation: " + timeoutOperation);
		String errorMessage = timeoutOperation.equalsIgnoreCase("loadCreativeAsset") ? "load creative asset timeout" : "Creative function " + timeoutOperation + " timed out";
		failWithError(constants.ERROR_TIMEOUT(), errorMessage);
		//Stop the renderer. Clear out the webView.
		this.stop();
	}

	@JavascriptInterface
	public void _fw_log(String s) {
		logger.debug("VPAID log: " + s);
	}


	// Called when the webview is loaded and Javascript wrapper
	@JavascriptInterface
	public void onWrapperLoaded() {
		logger.debug("Wrapper loaded");
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.setTimeoutValueInMs(" + timeoutMillisecondsBeforeStart + ");", null);
		loadVPAIDCreative(assetUrl);
	}

	@JavascriptInterface
	public void onVPAIDEvent(String s) {
		logger.debug("VPAID EVENT: " + s);
		switch(s) {
			case "AdLoaded":
				this.cancelVPAIDTimeout();
				resize();
				// Result received in adDurationCallback
				vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdDuration();", null);
				rendererContext.dispatchEvent(constants.EVENT_AD_LOADED());

				// Setting the volume on the VPAID Creative.
				this.vpaidVolume = rendererContext.getInitialAdVolume();
				vpaidWebView.setVolumeOnVPAIDCreative(this.vpaidVolume);
				break;
			case "AdStarted":
			case "AdImpression":
				if(!rendererStarted) {
					rendererStarted = true;
					// check whether ad started in specified time, otherwise error out.
					this.cancelVPAIDTimeout();
					// Result received in adDurationCallback
					vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdDuration();", null);

					// Start observing remaining time
					startPlayheadTimeCheck();
					this.volumeDelegate = new RendererVolumeDelegate(this.rendererContext);
					rendererContext.dispatchEvent(constants.EVENT_AD_STARTED());
				}
				break;
			case "AdSkipped":
				rendererContext.dispatchEvent(constants.EVENT_AD_SKIPPED_BY_USER());
				stopPlayheadTimeCheck();
				this.dispose();
				break;
			case "AdSkippableStateChange":
				_getAdSkippableState();
				break;
			case "AdStopped":
				rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
				stopPlayheadTimeCheck();
				this.dispose();
				break;
			case "AdPaused":
				rendererContext.dispatchEvent(constants.EVENT_AD_PAUSE());
				stopPlayheadTimeCheck();
				this.isPaused = true;
				break;
			case "AdPlaying":
				if (this.isPaused == true) {
					rendererContext.dispatchEvent(constants.EVENT_AD_RESUME());
				}
				startPlayheadTimeCheck();
				this.isPaused = false;
				break;
			case "AdUserAcceptInvitation":
				rendererContext.dispatchEvent(constants.EVENT_AD_ACCEPT_INVITATION());
				break;
			case "AdUserMinimize":
				rendererContext.dispatchEvent(constants.EVENT_AD_MINIMIZE());
				break;
			case "AdUserClose":
				rendererContext.dispatchEvent(constants.EVENT_AD_CLOSE());
				break;
			case "AdLinearChange":
				vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdLinear();", null);
			case "AdVideoFirstQuartile":
				if (quartilesSent < 1) {
					this.rendererContext.dispatchEvent(constants.EVENT_AD_FIRST_QUARTILE());
					quartilesSent = 1;
				}
				break;
			case "AdVideoMidpoint":
				if (quartilesSent < 2) {
					this.rendererContext.dispatchEvent(constants.EVENT_AD_MIDPOINT());
					quartilesSent = 2;
				}
				break;
			case "AdVideoThirdQuartile":
				if (quartilesSent < 3) {
					this.rendererContext.dispatchEvent(constants.EVENT_AD_THIRD_QUARTILE());
					quartilesSent = 3;
				}
				break;
			case "AdVideoComplete":
				if (quartilesSent < 4) {
					this.rendererContext.dispatchEvent(constants.EVENT_AD_COMPLETE());
					quartilesSent = 4;
				}
				break;
			case "AdDurationChange":
				//result received in adDurationCallback()
				vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdDuration();", null);
				break;
			case "AdSizeChange":
				logger.debug("OnAdSizeChange");
				break;
			case "AdExpandedChange":
				//result received in getAdExpandedCallback
				vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdExpanded();", null);
				break;
			case "AdVolumeChange":
				//result received in adVolumeCallback
				vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdVolume();", null);
				break;
			default:
				logger.debug("VPAID EVENT: unrecognized");
		}
	}

	@JavascriptInterface
	public void onAdClickThru(String url, String id, String playerHandles) {
		logger.debug("VPAID EVENT AdClickthru: " + url + "   :  " + id + "   :    " + playerHandles);
		Bundle info = new Bundle();
		HashMap<String, Object> map = new HashMap<>();
		if (StringUtils.parseBoolean(playerHandles, false)) {
			// Open the page in a browser
			if (url != null && url.length() > 0) {
				// use the URL provided by VPAID
				info.putString(constants.INFO_KEY_URL(), url);
			} // else use the default clickthru url
			info.putBoolean(constants.INFO_KEY_SHOW_BROWSER(), true);
		} else {
			// Do not open page, just send the click event
			info.putBoolean(constants.INFO_KEY_SHOW_BROWSER(), false);
		}
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		rendererContext.dispatchEvent(constants.EVENT_AD_CLICK(), map);
	}

	@JavascriptInterface
	public void getAdExpandedCallback(String message) {
		logger.debug("VPAID EVENT AdExpandedChange: " + message);
		if (message.equals("true")) {
			rendererContext.dispatchEvent(constants.EVENT_AD_EXPAND());
		} else if (message.equals("false")) {
			rendererContext.dispatchEvent(constants.EVENT_AD_COLLAPSE());
		} else {
			logger.debug("getAdExpanded function not supported.");
		}
	}

	@JavascriptInterface
	public void adLinearCallback(String message) {
		logger.debug("VPAID EVENT AdLinearChange: " + message);
		if (message.equals("true")) {
			logger.debug("non-linear click to linear -> request content video to pause");
			rendererContext.requestTimelinePause();
		} else {
			logger.debug("linear back to non-linear -> request content video to resume");
			rendererContext.requestTimelineResume();
		}
	}

	@Override
	public void start() {
		logger.debug("start");
		addView(vpaidWebView);
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.startAd();", null);
		// get the initial skippable state from vpaid ad, before the EVENT_AD_SKIPPABLE_STATE_CHANGED
		_getAdSkippableState();
		// reset skipoffset for vpaid ad
		((AdInstance) this.rendererContext.getAdInstance()).resetSkipOffset();
	}

	@Override
	public void pause() {
		logger.debug("pause");
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.pauseAd();", null);
	}

	@Override
	public void resume() {
		logger.debug("resume");
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.resumeAd();", null);
	}

	@Override
	public void stop() {
		logger.debug("VPAIDRenderer stop");
		if (stopRequested) {
			logger.debug("Ad stopped due to timeout after calling stop(). Did not receive AdStopped event");
			rendererContext.dispatchEvent(constants.EVENT_AD_STOPPED());
			this.dispose();
		} else {
			stopRequested = true;
			stopPlayheadTimeCheck();
			vpaidWebView.evaluateJavascript("fw_vast_wrapper.stopAd();", null);
		}
	}

	@Override
	public void dispose() {
		logger.debug("VPAIDRenderer dispose");
		this.mainLoopHandler.post(new Runnable() {
			@Override
			public void run() {
				if (vpaidWebView != null) {
					if(slot != null && slot.getBase() != null) {
						slot.getBase().removeView(vpaidWebView);
						slot.getBase().removeOnLayoutChangeListener(onResizeListener);
					}
					vpaidWebView.destroy();
				}
				if (volumeDelegate != null) {
					volumeDelegate.dispose();
					volumeDelegate = null;
				}
			}
		});
	}

	@Override
	public double getDuration() {
		logger.debug("getDuration " + duration);
		return duration;
	}

	@Override
	public double getPlayheadTime() {
		logger.debug("getPlayheadTime " + playheadTime);
		return playheadTime;
	}

	@Override
	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.RENDERER.toString());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}


	@Override
	public void resize() {
		logger.debug("VPAIDRenderer resize");
		String resizeParameters = "\"" + getSlotWidth() + "\", \"" + getSlotHeight() + "\", \"" + VIEW_MODE + "\"";
		logger.debug("ResizeParameters: " + resizeParameters);
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.resizeAd(" + resizeParameters + ");", null);

	}

	@Override
	public void setVolume(float value) {
		logger.debug("setVolume(" + value + ")");
		vpaidWebView.setVolumeOnVPAIDCreative(value);
	}

	private void _getPlayheadTime() {
		//result received in adDurationCallback
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdDuration();", null);
		//result received in adRemainingTimeCallback
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdRemainingTime();", null);
	}

	public void _getAdSkippableState() {
		vpaidWebView.evaluateJavascript("fw_vast_wrapper.getAdSkippableState();", null);
	}

	@JavascriptInterface
	public void adSkippableStateCallback(String result) {
		adSkippableState = StringUtils.parseBoolean(result, false);
		if (hasAdSkippableStateInitiatedValue) {
			HashMap<String, Object> data = new HashMap<String, Object>();
			data.put(Constants._INFO_KEY_AD_SKIPPABLE_STATE, adSkippableState);
			rendererContext.dispatchEvent(constants.EVENT_AD_SKIPPABLE_STATE_CHANGED(), data);
		} else {
			hasAdSkippableStateInitiatedValue = true;
		}
	}

	@JavascriptInterface
	public void adDurationCallback(String result) {
		duration = StringUtils.parseDouble(result, -1D);
		logger.debug("Duration received " + duration);
	}

	@JavascriptInterface
	public void adVolumeCallback(String result) {
		float volume = StringUtils.parseFloat(result, 1F);
		logger.debug("Volume received " + volume + ", current volume " + this.vpaidVolume);

		if (volume < 0 || volume > 1) {
			logger.debug("Volume not in expected range");
			return;
		}

		this.vpaidVolume = volume;
		if (volumeDelegate != null) {
			this.volumeDelegate.onAdVolumeChanged(this.vpaidVolume);
		}
	}

	@JavascriptInterface
	public void adRemainingTimeCallback(String result) {
		double remainingTime = StringUtils.parseDouble(result, -1D);
		if (duration >= 0 && remainingTime >=0) {
			playheadTime = duration - remainingTime;
			logger.debug("Remaining time received " + remainingTime);
		} else {
			playheadTime = -1;
		}
	}

	protected void addView(final View view) {
		logger.debug("addView");
		this.mainLoopHandler.post(new Runnable() {
			@Override
			public void run() {
				final ViewGroup slotBase = VPAIDRenderer.this.slot.getBase();

				slotBase.addView(view, slotBase.getLayoutParams());

				onResizeListener = new View.OnLayoutChangeListener() {
					@Override
					public void onLayoutChange(View view, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7) {
						logger.debug("OnLayoutChange");
						String resizeParameters = "\"" + getSlotWidth() + "\", \"" + getSlotHeight() + "\", \"" + VIEW_MODE + "\"";
						logger.debug("ResizeParameters: " + resizeParameters);
						vpaidWebView.evaluateJavascript("fw_vast_wrapper.resizeAd(" + resizeParameters + ");", null);
					}
				};

				slotBase.addOnLayoutChangeListener(onResizeListener);

				logger.debug("LayoutParameters: Width: " + slotBase.getLayoutParams().width + ", Height: " + slotBase.getLayoutParams().height);
			}
		});
	}

	public Activity getActivity() {
		return activity;
	}

	@Override
	public View getAdView(){
		return this.vpaidWebView;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}

	public boolean getAdSkippableState() {
		return adSkippableState;
	}
}
