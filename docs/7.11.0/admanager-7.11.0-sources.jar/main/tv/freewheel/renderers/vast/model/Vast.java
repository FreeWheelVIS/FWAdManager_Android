package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.ArrayList;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class Vast {

	public enum Errors {
		ERROR_PARSE, ERROR_VERSION, ERROR_NO_AD, ERROR_INVALID_SCHEMA, NO_ERROR_FOUND;
	}

	public InLine inLine;
	public Wrapper wrapper;
	
	public Errors errorCode;
	public String errorMessage;

	private IRendererContext context;

	private static final Logger logger = Logger.getLogger("Vast");

	public Vast(IRendererContext context){
		this.context = context;
	}
	
	@Override
	public String toString(){
		return String.format("[Ad\n\tInLine=%s\n\tWrapper=%s\n]", this.inLine, this.wrapper);
	}
	
	public boolean parse(String is){
		boolean ret = false;
		try {
			Element el = XMLHandler.getXMLElementFromString(is, "VAST");
			int vastMajorVersion = getVastMajorVersion(el.getAttribute("version"));
			if (vastMajorVersion >= Constants.SUPPORTED_CREATIVE_VAST_VERSION_MIN
					&& vastMajorVersion <= Constants.SUPPORTED_CREATIVE_VAST_VERSION_MAX) {
				NodeList children = el.getChildNodes();
				for (int i = 0; i < children.getLength(); i++) {
					Node child = children.item(i);
					if (child.getNodeType() == Node.ELEMENT_NODE &&
							child.getNodeName().equals("Ad")) {
						ret = this.parseAdNode((Element)child);
						if (ret) {
							this.errorCode = Errors.NO_ERROR_FOUND;
							this.errorMessage = "";
							break;
						}
					}
				}
				if (!ret) {
					this.errorCode = Errors.ERROR_NO_AD;
					this.errorMessage = "Error validating VAST document: no Ad node found.";
					logger.error(this.errorMessage);
				}
			} else if (!isVastTagValid(el)) {
					this.errorCode = Errors.ERROR_INVALID_SCHEMA;
					this.errorMessage = "Error validating VAST Schema: missing VAST version attribute.";
					logger.error(this.errorMessage);
			} else {
					this.errorCode = Errors.ERROR_VERSION;
					this.errorMessage = "Not support VAST version " + el.getAttribute("version");
					logger.error(this.errorMessage);
			}
		} catch (Exception e) {
			if (e.toString().equals("java.lang.Exception: no root node VAST found in document")){
				this.errorCode = Errors.ERROR_INVALID_SCHEMA;
				this.errorMessage = "Error validating VAST Schema: missing VAST tag.";
				logger.error(this.errorMessage + " " + e.toString());
			} else {
				this.errorCode = Errors.ERROR_PARSE;
				this.errorMessage = "Error parsing VAST document: " + e.toString();
				logger.error(this.errorMessage, e);
				ret = false;
			}
		}
		return ret;
	}

	private boolean isVastTagValid(Element el) {
		if (!el.hasAttribute("version")) {
				return false;
		}
		return true;
	}
	
	private boolean parseAdNode(Element ad) {
		NodeList children = ad.getChildNodes();
		boolean requiredNodeMissing = true;
		for (int i = 0; i < children.getLength(); i++) {
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				if (child.getNodeName().equals("InLine")) {
					this.inLine = new InLine();
					this.inLine.parse((Element) child);
					if (this.inLine.isValid(context.getAdInstance().getSlot(),context.getConstants())) {
						requiredNodeMissing = false;
					} else {
						this.inLine = null;
					}
				} else if (child.getNodeName().equals("Wrapper")) {
					this.wrapper = new Wrapper();
					this.wrapper.parse((Element) child);
					if (this.wrapper.isValid(context.getAdInstance().getSlot(),context.getConstants())) {
						requiredNodeMissing = false;
					} else {
						this.wrapper = null;
					}
				}
			}
		}
		if (requiredNodeMissing) {
			logger.debug("Found an invalid Ad without valid InLine and Wrapper element, try next ad...");
		}
		return !requiredNodeMissing;
	}
	
	public List<? extends AbstractCreativeRendition> getRenditionsInDrivingSlot() {
		if (this.wrapper != null) {
			return wrapper.searchInDrivingSlot(context.getAdInstance().getSlot(), context.getConstants());
		} else if (this.inLine != null) {
			return inLine.searchInDrivingSlot(context.getAdInstance().getSlot(), context.getConstants());
		} else {
			return new ArrayList<>();
		}
	}
	
	public List<? extends AbstractCreativeRendition> getCompanionRenditions(ISlot companionSlot) {
		if (this.wrapper != null) {
			return wrapper.searchInCompanionSlot(companionSlot, context.getConstants());
		} else if (this.inLine != null) {
			return inLine.searchInCompanionSlot(companionSlot, context.getConstants());
		} else {
			return new ArrayList<>();
		}
	}

	public static Companion match(List<? extends AbstractCreativeRendition> companionRenditions, ISlot companionSlot, double deviceDPR) {
		if (companionRenditions == null || companionRenditions.isEmpty() || companionSlot == null) {
			return null;
		}
		int scaledSlotWidth = (int)Math.round(companionSlot.getWidth() * deviceDPR);
		int scaledSlotHeight = (int)Math.round(companionSlot.getHeight() * deviceDPR);
		Companion result = null;
		int mindw = Integer.MAX_VALUE;
		int mindh = Integer.MAX_VALUE;
		for (int i=0;i <companionRenditions.size();i++) {
			Companion companion = (Companion)companionRenditions.get(i);
			if (scaledSlotWidth == companion.width && scaledSlotHeight == companion.height) {
				result = companion;
				break;
			}
			if (companion.width > scaledSlotWidth || companion.height > scaledSlotHeight){
				continue;
			}

			int dw = scaledSlotWidth  - companion.width;
			int dh = scaledSlotHeight - companion.height;
			if ((mindw >= dw && mindh > dh) || (mindw > dw && mindh >= dh)) {
				mindw = dw;
				mindh = dh;
				result = companion;
			}
		}

		logger.debug(String.format("Match result:slot(customId=%s:width=%d,height=%d) with companion rendition (ID=%s:width=%d,height=%d) device_dpr %f",
				companionSlot.getCustomId(),companionSlot.getWidth(),companionSlot.getHeight(),
				result.id,result.width,result.height,deviceDPR));
		return result;
	}
	
	public int getVastMajorVersion(String versionString) {
		if (StringUtils.isBlank(versionString)){
			return -1;
		}
		return StringUtils.parseInt(versionString.substring(0, versionString.indexOf(".")), -1);
	}
}
