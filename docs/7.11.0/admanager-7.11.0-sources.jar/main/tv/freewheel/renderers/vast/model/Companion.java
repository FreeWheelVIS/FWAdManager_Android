package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.XMLHandler;

public class Companion extends AbstractNonMediaFile{
	String companionClickThrough;
	ArrayList<Tracking> trackingEvents;
	String altText;

	@Override
	String getAltText() {
		return altText;
	}

	public Companion(){
		super();
		this.trackingEvents = new ArrayList<Tracking>();
	}
	@Override
	public String toString(){
		return String.format("[Companion  %s companionClickThrough=%s trackingEvents=%s altText=%s  ]", 
				super.toString(), this.companionClickThrough, this.trackingEvents, this.altText);
	}
	
	@Override
	public void parse(Element node){
		super.parse(node);
		for (int i = 0; i < node.getChildNodes().getLength(); i++){
			Node child = node.getChildNodes().item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("CompanionClickThrough")){
					this.companionClickThrough = XMLHandler.getTextNodeValue(child);
				}else if(name.equals(InternalConstants.OpenMeasurementConstants.TAG_TRACKING_EVENTS)){
					NodeList trackings = ((Element) child).getElementsByTagName("Tracking");
					for (int j = 0; j < trackings.getLength(); j++){
						Tracking tracking = new Tracking();
						tracking.parse((Element) trackings.item(j));
						this.trackingEvents.add(tracking);
					}
				}else if (name.equals("AltText")){
					this.altText = XMLHandler.getTextNodeValue(child);
				}
			}
		}
	}

	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		return super.isValid(slot, constants);
	}

	public boolean isValidCompanion(ISlot slot,IConstants constants){
		if (slot != null && slot.getSlotType() != IConstants.SlotType.TEMPORAL) //In NON_TEMPORAL slot check w/h
			return super.isValid(slot, constants);
		else
			return false;
	}
	
	public ArrayList<Tracking> getTrackingEvents() {
		return trackingEvents;
	}
	
	@Override
	String getClickThroughURL() {
		return this.companionClickThrough;
	}
}
