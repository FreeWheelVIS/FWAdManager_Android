package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;

import tv.freewheel.ad.InternalConstants;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;

public abstract class AbstractCustomExtension implements Cloneable {
	protected String type;
	protected String value;
	protected String owner;
	private static final Logger logger = Logger.getLogger(AbstractCustomExtension.class);

	public void parse(Element node, String owner) {
		if (node.hasAttribute(InternalConstants.TAG_EXTENSION_TYPE)) {
			this.type = node.getAttribute(InternalConstants.TAG_EXTENSION_TYPE) != null ? node.getAttribute(InternalConstants.TAG_EXTENSION_TYPE) : null;
		} else if (node.hasAttribute(InternalConstants.TAG_EXTENSION_KEY)) {
			this.type = node.getAttribute(InternalConstants.TAG_EXTENSION_KEY) != null ? node.getAttribute(InternalConstants.TAG_EXTENSION_KEY) : null;
		}

		this.owner = owner;

		try {
			this.value = StringUtils.convertNodeListToString(node);
		} catch (TransformerException e) {
			logger.debug(String.format("Cannot translate XML Node %s, exception = %s", node.toString(), e.toString()));
		}

	}

	@Override
	public String toString() {
		return String.format("[Extension\n\t\ttype=%s\n\t\tvalue=%s\n\t\towner=%s]", type, value, owner);
	}
}
