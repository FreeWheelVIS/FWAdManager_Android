package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;

import tv.freewheel.ad.InternalConstants;

public class ProgressTracking extends Tracking {
	public String offsetString;
	
	@Override
	public String toString(){
		return String.format("[Tracking %s event=%s skipoffset=%s]",super.toString() ,this.event, this.offsetString);
	}

	@Override
	public void parse(Element node){
		super.parse(node);
		this.offsetString = node.getAttribute(InternalConstants.TAG_OFFSET);
	}

	@Override
	public ProgressTracking clone() throws CloneNotSupportedException {
		return (ProgressTracking) super.clone();
	}
}
