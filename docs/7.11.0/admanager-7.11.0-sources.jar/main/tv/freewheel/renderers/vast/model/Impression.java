package tv.freewheel.renderers.vast.model;

public class Impression extends AbstractPager {	
	@Override
	public String toString(){
		return String.format("[Impression %s]", super.toString());
	}
}
