package tv.freewheel.renderers.vast.model;

import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.InternalConstants;


public class NonLinearAds extends AbstractCreativeRenditionCollection  {

	ArrayList<Tracking> trackingEvents;
	ArrayList<NonLinear> nonLinears;
	
	public NonLinearAds(){
		this.trackingEvents = new ArrayList<Tracking>();
		this.nonLinears = new ArrayList<NonLinear>();
	}
	
	public void parse(Element node){
		for (int i = 0; i < node.getChildNodes().getLength(); i++){
			Node child = node.getChildNodes().item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals(InternalConstants.OpenMeasurementConstants.TAG_TRACKING_EVENTS)){
					NodeList trackings = ((Element) child).getElementsByTagName("Tracking");
					for (int j = 0; j < trackings.getLength(); j++){
						Tracking tracking = new Tracking();
						tracking.parse((Element) trackings.item(j));
						this.trackingEvents.add(tracking);
					}
				}else if (name.equals("NonLinear")){
					NonLinear nonlinear = new NonLinear();
					nonlinear.parse((Element)child);
					this.nonLinears.add(nonlinear); 
				}
			}
		}
	}
	
	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		return this.validate(nonLinears,slot,constants);
	}

	public ArrayList<? extends AbstractCreativeRendition> search (ISlot slot,IConstants constants){
		return this.searchAll(nonLinears, slot, constants);
	}
}
