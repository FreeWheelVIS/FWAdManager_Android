package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import tv.freewheel.utils.XMLHandler;

public class InLine extends AbstractAd {
	public String adTitle;
	public String description;
	public String survey;

	public InLine() {
		super();
	}

	@Override
	public void parse(Element node) {
		super.parse(node);
		for (int i = 0; i < node.getChildNodes().getLength(); i++) {
			Node child = node.getChildNodes().item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String name = child.getNodeName();
				switch (name) {
					case "AdTitle":
						this.adTitle = XMLHandler.getTextNodeValue(child);
						break;
					case "Description":
						this.description = XMLHandler.getTextNodeValue(child);
						break;
					case "Survey":
						this.survey = XMLHandler.getTextNodeValue(child);
						break;
				}
			}
		}
	}

}
