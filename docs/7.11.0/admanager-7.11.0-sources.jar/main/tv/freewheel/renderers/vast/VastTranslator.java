package tv.freewheel.renderers.vast;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.URLUtil;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.FreeWheelVersion;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.renderers.vast.model.AbstractAd;
import tv.freewheel.renderers.vast.model.AbstractCreativeRendition;
import tv.freewheel.renderers.vast.model.Companion;
import tv.freewheel.renderers.vast.model.Creative;
import tv.freewheel.renderers.vast.model.Impression;
import tv.freewheel.renderers.vast.model.Linear;
import tv.freewheel.renderers.vast.model.ProgressTracking;
import tv.freewheel.renderers.vast.model.Tracking;
import tv.freewheel.renderers.vast.model.Vast;
import tv.freewheel.renderers.vast.model.VideoClick;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.URLLoader;
import tv.freewheel.utils.URLRequest;
import tv.freewheel.utils.renderer.ParamParser;

public class VastTranslator implements IRenderer {
	private static final int INLINE = 0;
	private static final int WRAPPER = 1;

	private IRendererContext context;
	private IConstants constants;
	private String vastURL;
	private ICreativeRendition originalActiveRendition;
	private Vast vast;
	private URLLoader httpLoader;
	private static final Logger logger = Logger.getLogger(VastTranslator.class, true);

	private ParamParser paramParser;

	public VastTranslator() {
		httpLoader = new URLLoader();
		httpLoader.addEventListener(URLLoader.EVENT_LOAD_COMPLETE, loadCompleteListener);
		httpLoader.addEventListener(URLLoader.EVENT_LOAD_ERROR, loadFailedListener);
	}

	private void sendRequest(String url) {
		logger.debug("Loading VAST document from: " + url);
		final URLRequest req = new URLRequest(url, System.getProperty("http.agent"));

		req.method = URLRequest.Method.GET;
		req.contentType = URLRequest.CONTENT_TYPE_TEXT_PLAIN;

		double timeoutSeconds = getTimeoutInSeconds();
		logger.debug("Loading VAST document with timeout: " + timeoutSeconds);
		httpLoader.load(req, timeoutSeconds);
	}

	private double getTimeoutInSeconds() {
		int timeoutMs = paramParser.getPositiveIntValueFromParameter(
				constants.PARAMETER_VAST_TIMEOUT_IN_MILLISECONDS(),
				InternalConstants.VAST_DEFAULT_TIMEOUT);
		return timeoutMs / 1000d;
	}

	private void parseVastResponse(String data) {
		vast = new Vast(context);
		if (vast.parse(data)) {
			logger.debug("Vast document parsed, " + vast);
			this.startVASTAdTranslation();
		} else {
			if (vast.errorCode == Vast.Errors.ERROR_NO_AD) {
				failWithError(constants.ERROR_NO_AD_AVAILABLE(), vast.errorMessage, Constants.VastErrors.ERROR_VAST_NO_AD.getValue());
			} else if (vast.errorCode == Vast.Errors.ERROR_INVALID_SCHEMA) {
				failWithError(constants.ERROR_PARSE(), vast.errorMessage, Constants.VastErrors.ERROR_VAST_SCHEMA_VALIDATION.getValue());
			} else if (vast.errorCode == Vast.Errors.ERROR_PARSE) {
				failWithError(constants.ERROR_PARSE(), vast.errorMessage, Constants.VastErrors.ERROR_VAST_XML_PARSING.getValue());
			} else if (vast.errorCode == Vast.Errors.ERROR_VERSION) {
				failWithError(constants.ERROR_PARSE(), vast.errorMessage, Constants.VastErrors.ERROR_VAST_VERSION_NOT_SUPPORTED.getValue());
			}
			vast = null;
		}
	}

	@Override
	public void load(IRendererContext rendererContext) {
		logger.debug("load()");
		this.context = rendererContext;
		this.constants = rendererContext.getConstants();
		this.paramParser = new ParamParser(context, "translator.vast");

		if (!this.checkCompatibilityWithSDK()) {
			return;
		}

		AdInstance adInstance = (AdInstance) this.context.getAdInstance();
		ISlot drivingSlot = adInstance.getSlot();
		if (drivingSlot.getSlotType() != IConstants.SlotType.TEMPORAL) {
			this.failWithError(this.constants.ERROR_INVALID_SLOT(), "Vast Translator only supports temporal slots.");
			return;
		}

		this.originalActiveRendition = adInstance.getActiveCreativeRendition();
		int maxWrapperCount = paramParser.getPositiveIntValueFromParameter(constants.PARAMETER_VAST_MAX_WRAPPER_COUNT(), InternalConstants.VAST_DEFAULT_MAX_WRAPPER_COUNT);
		int currentWrapperCount = adInstance.getWrapperCount();

		if (currentWrapperCount >= maxWrapperCount && adInstance.getOriginalVastWrapperURL() != null) {
			failWithError(constants.ERROR_IO(), "maximum wrapper limit is reached: " + currentWrapperCount, Constants.VastErrors.ERROR_VAST_WRAPPER_LIMIT_REACHED.getValue());
			return;
		}

		// get wrapper url and load vast doc
		vastURL = adInstance.getActiveCreativeRendition().getWrapperURL();

		if (StringUtils.isBlank(vastURL)) {
			this.failWithError(constants.ERROR_NULL_ASSET(), "Vast wrapper URL is null");
			return;
		}
		if (!URLUtil.isValidUrl(vastURL)) {
			this.failWithError(constants.ERROR_INVALID_VALUE(), "Not a valid URL to load VAST document from: " + vastURL);
			return;
		}

		try {
			new URL(vastURL);
		} catch (MalformedURLException e) {
			logger.debug(e);
			failWithError(constants.ERROR_INVALID_VALUE(), "Not a valid URL to load VAST document from: " + vastURL);
			return;
		}

		this.sendRequest(vastURL);
	}

	@Override
	public void start() {
		logger.debug("start()");
		this.context.dispatchEvent(constants.EVENT_AD_STARTED());
		this.context.dispatchEvent(constants.EVENT_AD_STOPPED());
	}

	private void startVASTAdTranslation() {
		logger.debug("startTranslateAd()");
		if (this.vast != null) {
			List<? extends AbstractCreativeRendition> drivingRenditions = vast.getRenditionsInDrivingSlot();
			HashMap<ISlot, Companion> companionMap = new HashMap<>();
			List<ISlot> preparedSlots = new ArrayList<>();

			if (vast.wrapper != null || (vast.inLine != null && !drivingRenditions.isEmpty())) {
				preparedSlots.add(this.context.getAdInstance().getSlot());
			}

			List<ISlot> companionSlots = this.context.getCompanionSlots();
			ArrayList<Companion> matchedCompanions = new ArrayList<>();
			double deviceDPR = context.getActivity().getResources().getDisplayMetrics().density;
			for (int i = 0; i < companionSlots.size(); i++) {
				ISlot companionSlot = companionSlots.get(i);
				preparedSlots.add(companionSlot);
				List<? extends AbstractCreativeRendition> companionRenditions = vast.getCompanionRenditions(companionSlot);
				if (companionRenditions != null && !companionRenditions.isEmpty() && !matchedCompanions.isEmpty())
					companionRenditions.removeAll(matchedCompanions);
				if (!companionRenditions.isEmpty()) {
					Companion rend;
					rend = Vast.match(companionRenditions, companionSlot, deviceDPR);
					if (rend != null) {
						companionMap.put(companionSlot, rend);
						matchedCompanions.add(rend);
					} else
						logger.debug("No matching rendition for companion slot:" + companionSlot);
				}
			}

			List<IAdInstance> scheduledAds = this.context.scheduleAdInstances(preparedSlots);
			ArrayList<IAdInstance> ads = new ArrayList<IAdInstance>(scheduledAds.size());
			ads.addAll(scheduledAds);
			IAdInstance drivingAd = null;
			for (IAdInstance adi : ads) {
				if (adi == null) continue;
				if (adi.getSlot() == this.context.getAdInstance().getSlot()) {
					drivingAd = adi;
					this.configureDrivingAdInstance(drivingAd, drivingRenditions);
					break;
				}
			}
			if (drivingAd != null) {
				((AdInstance) drivingAd).addExtensions(vast.wrapper != null ? vast.wrapper.extensions : vast.inLine.extensions);
				((AdInstance) drivingAd).getAdVerifications().addAll(vast.wrapper != null ? vast.wrapper.adVerifications : vast.inLine.adVerifications);
				ads.remove(drivingAd);
			}
			for (IAdInstance adi : ads) {
				if (adi == null) continue;
				Companion rend = companionMap.get(adi.getSlot());
				if (rend != null) {
					ICreativeRendition cr = adi.createCreativeRenditionForTranslation();
					this.configureTracking(adi, rend.getTrackingEvents());
					rend.translateToFWCreativeRendition(cr, adi, context.getAdInstance(), constants);
					cr.setWidth((int) (cr.getWidth() / deviceDPR));
					cr.setHeight((int) (cr.getHeight() / deviceDPR));
					logger.debug(String.format("Translated companion:slot(customId=%s:width=%d,height=%d) Ad(Id=%d) companion (ID=%s:width=%d,height=%d)",
							adi.getSlot().getCustomId(), adi.getSlot().getWidth(), adi.getSlot().getHeight(), adi.getAdId(),
							rend.id, rend.width, rend.height));
				}
			}
		}
		context.dispatchEvent(constants.EVENT_AD_LOADED());
	}

	private void configureDrivingAdInstance(IAdInstance adInstance, List<? extends AbstractCreativeRendition> renditions) {
		logger.debug("configureDrivingAdInstance(" + adInstance + ")");
		List<Impression> impressions;
		List<String> vastErrors;

		int type = -1;
		AbstractAd vastAd;
		if (this.vast.inLine != null) {
			logger.debug("configure inline AdInstance: " + adInstance);
			// append Impression urls to defaultImpression callback urls
			impressions = this.vast.inLine.impressions;
			vastErrors = this.vast.inLine.errors;
			type = INLINE;
			vastAd = this.vast.inLine;
		} else if (this.vast.wrapper != null) {
			logger.debug("configure wrapper AdInstance: " + adInstance);
			if (((AdInstance) adInstance).getWrapperCount() == 0) {
				((AdInstance) adInstance).setOriginalVastWrapperURL(vastURL);
			}

			((AdInstance) adInstance).incrementWrapperCount();
			impressions = this.vast.wrapper.impressions;
			type = WRAPPER;
			vastErrors = this.vast.wrapper.errors;
			vastAd = this.vast.wrapper;
		} else {
			/*
			   We don't need an 'else' statement here because in such case Ad.parse will return false,
			   causing translator to fail before this method can be invoked.
			*/
			logger.debug("configure other AdInstance: " + adInstance);
			return;
		}

		if (impressions != null) {
			ArrayList<String> urls = new ArrayList<String>();
			for (Impression impr : impressions) {
				if (impr.isValid()){
					urls.add(impr.url);
				}
			}
			if (!urls.isEmpty()){
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_IMPRESSION(), this.constants.EVENT_TYPE_IMPRESSION(), urls);
			}
		}

		if (vastErrors != null) {
			ArrayList<String> urls = new ArrayList<>();
			for (String vastError: vastErrors) {
				if (!StringUtils.isBlank(vastError) && URLUtil.isValidUrl(vastError)){
					urls.add(vastError);
				}
			}
			if (!urls.isEmpty()){
				adInstance.addEventCallbackURLs("", InternalConstants.EVENT_TYPE_ERROR, urls);
			}
		}

		if (type != -1) {
			this.configureCreative(adInstance, vastAd, type, renditions);
		}
	}

	private void printMultilineLog(String head, String msg) {
		msg = msg.trim();
		if (msg.length() == 0) return;
		int linenum = 1;
		for (String log : msg.split("\n")) {
			logger.debug(head + linenum + ":" + log);
			linenum++;
		}
	}

	private void configureCreative(IAdInstance adInstance, AbstractAd ad, int type, List<? extends AbstractCreativeRendition> renditions) {
		logger.debug("configureCreative(" + adInstance + ", type:" + type + ")");
		for (Creative creative : ad.creatives) {
			if (creative.linear != null && (
					type == WRAPPER && adInstance.getSlot().getSlotTimePositionClass() != IConstants.TimePositionClass.OVERLAY ||
							type == INLINE && creative.linear.isValid(this.context.getAdInstance().getSlot(), constants))) {
				this.configureVideoClicks(adInstance, creative.linear);
				this.configureSkipOffset(adInstance, creative.linear);
				if (creative.linear.icons != null) {
					((AdInstance) adInstance).setIcons(creative.linear.icons);
				}
			}
			this.configureTracking(adInstance, creative.getTrackingEvents(this.context.getAdInstance().getSlot(), constants));
		}

		if (type == INLINE) {
			for (int i = 0; i < renditions.size(); i++) {
				ICreativeRendition rendition = adInstance.createCreativeRenditionForTranslation();
				AbstractCreativeRendition vastRendition = renditions.get(i);
				vastRendition.translateToFWCreativeRendition(rendition, adInstance, context.getAdInstance(), constants);
				this.printMultilineLog("Translated vast rendition(InLine)  ", vastRendition.toString());
			}
		} else {
			ICreativeRendition rendition = adInstance.createCreativeRenditionForTranslation();
			rendition.setWrapperType("external/vast-2");
			rendition.setWrapperURL(this.vast.wrapper.vastAdTagUri);
			if (renditions.size() > 0) {
				AbstractCreativeRendition vastRendition = renditions.get(0);//only need one rendition
				vastRendition.translateToFWCreativeRendition(rendition, adInstance, context.getAdInstance(), constants);
				this.printMultilineLog("Translated vast rendition(Wrapper)  ", vastRendition.toString());
			} else {
				if (originalActiveRendition != null) {
					rendition.setWidth(originalActiveRendition.getWidth());
					rendition.setHeight(originalActiveRendition.getHeight());
					rendition.setContentType(originalActiveRendition.getContentType());
					rendition.setCreativeAPI(originalActiveRendition.getCreativeAPI());
					ICreativeRenditionAsset originalAsset = originalActiveRendition.getPrimaryCreativRenditionAsset();
					ICreativeRenditionAsset asset = rendition.createCreativeRenditionAssetForTranslation("VAST_generated_placeholder_asset", true);
					if (originalAsset != null) {
						asset.setContentType(originalAsset.getContentType());
						asset.setMimeType(originalAsset.getMimeType());
					} else {
						asset.setContentType(originalActiveRendition.getContentType());
					}
				}
				this.printMultilineLog("Translated rendition(empty Wrapper)  ", rendition.toString());
			}
		}
	}

	private void configureVideoClicks(IAdInstance adInstance, Linear linear) {
		logger.debug("configureEventCallbacks()");
		ArrayList<String> urls = new ArrayList<String>();
		for (VideoClick click : linear.videoClicks) {
			if (!click.isValid())
				continue;
			if (click.type.equals("ClickThrough")) {
				adInstance.setClickThroughURL(click.url, this.constants.EVENT_AD_CLICK());
			} else if (click.type.equals("ClickTracking")) {
				urls.add(click.url);
			} else if (click.type.equals("CustomClick")) {
				ArrayList<String> clickTrackingURLs = new ArrayList<String>();
				clickTrackingURLs.add(click.url);
				adInstance.addEventCallbackURLs(click.id, this.constants.EVENT_TYPE_CLICK_TRACKING(), clickTrackingURLs);
			}
		}
		if (!urls.isEmpty())
			adInstance.addEventCallbackURLs(this.constants.EVENT_AD_CLICK(),
					this.constants.EVENT_TYPE_CLICK_TRACKING(), urls);

	}

	private void configureSkipOffset(IAdInstance adInstance, Linear linear) {
		logger.debug("configureSkipOffset()");
		if (StringUtils.isBlank(linear.skipOffsetString)) return;
		if (!linear.skipOffsetString.endsWith("%")) {
			((AdInstance) adInstance).setSkipOffsetInSecond(linear.skipOffsetString);
		} else {
			((AdInstance) adInstance).setSkipOffsetPercentage(linear.skipOffsetString);
		}
	}

	private void configureTracking(IAdInstance adInstance, ArrayList<Tracking> trackingEvents) {
		ArrayList<String> urls = new ArrayList<String>();
		logger.debug("trackings:" + trackingEvents.toString());
		for (Tracking tracking : trackingEvents) {
			if (!tracking.isValid())
				continue;
			urls.clear();
			urls.add(tracking.url);
			if (tracking.event.equals("creativeView") ||
					tracking.event.equals("start")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_IMPRESSION(),
						this.constants.EVENT_TYPE_IMPRESSION(), urls);
			} else if (tracking.event.equals("midpoint")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_MIDPOINT(),
						this.constants.EVENT_TYPE_IMPRESSION(), urls);
			} else if (tracking.event.equals("firstQuartile")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_FIRST_QUARTILE(),
						this.constants.EVENT_TYPE_IMPRESSION(), urls);
			} else if (tracking.event.equals("thirdQuartile")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_THIRD_QUARTILE(),
						this.constants.EVENT_TYPE_IMPRESSION(), urls);
			} else if (tracking.event.equals("complete")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_COMPLETE(),
						this.constants.EVENT_TYPE_IMPRESSION(), urls);
			} else if (tracking.event.equals("mute")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_MUTE(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("unmute")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_UNMUTE(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("pause")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_PAUSE(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("resume")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_RESUME(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("rewind")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_REWIND(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("expand")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_EXPAND(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("fullscreen")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_EXPAND(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("collapse")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_COLLAPSE(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("acceptInvitation")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_ACCEPT_INVITATION(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("close")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_CLOSE(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("skip")) {
				adInstance.addEventCallbackURLs(this.constants.EVENT_AD_SKIPPED_BY_USER(),
						this.constants.EVENT_TYPE_STANDARD(), urls);
			} else if (tracking.event.equals("progress")) {
				ProgressTracking progressTracking = (ProgressTracking) tracking;
				((AdInstance) adInstance).addProgressEventCallbackUrls(progressTracking.offsetString, tracking.url);
			}
		}
	}

	@Override
	public void pause() {
		logger.warn("VastTranslator not response to pause");
	}

	@Override
	public void resume() {
		logger.warn("VastTranslator not response to resume");
	}

	private AtomicBoolean stopped = new AtomicBoolean(false);

	private void _stop() {
		if (stopped.get())
			return;
		stopped.set(true);
		if (this.context != null) {
			if (this.context.getActivity() != null) {
				Handler mainVideoHandler = new Handler(Looper.getMainLooper());
				mainVideoHandler.post(new Runnable() {
					@Override
					public void run() {
						httpLoader.removeAllListeners();
						httpLoader.close();
						context.dispatchEvent(constants.EVENT_AD_STOPPED());
					}
				});
			} else {
				context.dispatchEvent(constants.EVENT_AD_STOPPED());
			}
		}
	}

	@Override
	public void stop() {
		logger.debug("stop()");
		_stop();
	}

	public Map<String, String> getModuleInfo() {
		HashMap<String, String> ret = new HashMap<String, String>();
		ret.put(constants.INFO_KEY_MODULE_TYPE(), IConstants.ModuleType.TRANSLATOR.toString());
		ret.put(constants.INFO_KEY_REQUIRED_SDK_VERSION(), FreeWheelVersion.FW_SDK_INTERFACE_VERSION);
		return ret;
	}

	@Override
	public double getDuration() {
		return -1.;
	}

	@Override
	public double getPlayheadTime() {
		return -1.;
	}

	@Override
	public void dispose() {
		logger.debug("dispose()");
		_stop();
	}

	private boolean checkCompatibilityWithSDK() {
		try {
			this.context.getVersion();
		} catch (NoSuchMethodError e) {
			this.failWithError(constants.ERROR_RENDERER_INIT(), "VastTranslator only compatible with SDK version >= 4.1");
			return false;
		}
		return true;
	}

	private void failWithError(String errorCode, String errorMessage) {
		this.failWithError(errorCode, errorMessage, null);
	}

	private void failWithError(String errorCode, String errorMessage, String vastErrorCode) {
		String vastErrorCodeLogMessage = (vastErrorCode!=null)?(" " + constants.INFO_KEY_VAST_ERROR_CODE() + ": " + vastErrorCode ) : "";
		logger.debug("failWithError(" + errorCode + ", " + errorMessage + vastErrorCodeLogMessage + ")");
		Bundle info = new Bundle();
		info.putString(constants.INFO_KEY_ERROR_CODE(), errorCode);

		String url = this.vastURL != null ? this.vastURL : ((AdInstance) context.getAdInstance()).getOriginalVastWrapperURL();
		info.putString(constants.INFO_KEY_ERROR_INFO(), errorMessage + " wrapperURL: " + url);

		info.putString(constants.INFO_KEY_VAST_ERROR_CODE(), vastErrorCode);
		final HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(constants.INFO_KEY_EXTRA_INFO(), info);
		Handler mainVideoHandler = new Handler(Looper.getMainLooper());
		mainVideoHandler.post(new Runnable() {
			@Override
			public void run() {
				context.dispatchEvent(constants.EVENT_ERROR(), map);
			}
		});
	}

	private IEventListener loadCompleteListener = new IEventListener() {
		public void run(IEvent event) {
			httpLoader.removeAllListeners();
			String data = (String) event.getData().get(constants.INFO_KEY_MESSAGE());
			parseVastResponse(data);
		}
	};

	private IEventListener loadFailedListener = new IEventListener() {
		public void run(IEvent event) {
			httpLoader.removeAllListeners();
			String message = (String) event.getData().get(constants.INFO_KEY_MESSAGE());
			logger.verbose("request failed: " + message);
			String vastErrorCode = null;
			if (message != null && (message.contains("timeout") || message.contains("timed out"))) {
				vastErrorCode = Constants.VastErrors.ERROR_VAST_URI_TIMEOUT.getValue();
			}
			failWithError(constants.ERROR_IO(), "Failed to load VAST document " + message + ".", vastErrorCode);
		}
	};

	@Override
	public void resize() {
		// TODO Auto-generated method stub
	}

	@Override
	public void setVolume(float value) {

	}

	@Override
	public View getAdView(){
		return null;
	}

	@Override
	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return null;
	}

}
