package tv.freewheel.renderers.vast.model;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.XMLHandler;

public class Linear extends AbstractCreativeRenditionCollection  {

	public Double duration;
	public String adParameters;
	public ArrayList<Tracking> trackingEvents;
	public ArrayList<VideoClick> videoClicks;
	public ArrayList<MediaFile> mediaFiles;
	public String skipOffsetString;
	public NodeList icons;
	List<FWVastInteractiveCreativeFile> interactiveCreativeFiles;

	public Linear() {
		this.trackingEvents = new ArrayList<Tracking>();
		this.videoClicks = new ArrayList<VideoClick>();
		this.mediaFiles = new ArrayList<MediaFile>();
		this.interactiveCreativeFiles = new ArrayList<>();
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Tracking t : this.trackingEvents) {
			sb.append(t);
			sb.append("\n\t\t\t\t\t");
		}
		return String.format("[Linear\n\t\t\t\tDuration=%f\n\t\t\t\tAdParameters=%s\n\t\t\t\tIcons=%s\n\t\t\t\tTrackingEvents=%s\n\t\t\t\tVideoClicks=%s\n\t\t\t\tMediaFiles=%s\n\t\t\tInteractiveCreativeFiles=%s\n\t\t\t]",
				this.duration, this.adParameters, this.icons ,sb.toString(), this.videoClicks, this.mediaFiles, this.interactiveCreativeFiles);
	}
	
	public void parse(Element node) {
		/*
		 * As InLine->Creatives->Creative->Linear and Wrapper->Creatives->Creative->Linear
		 * is different, we don't return false here ever since the latter has no required
		 * child nodes at all. We'll check if there's valid MediaFile nodes when configuring
		 * translated adInstances.
		*/
		
		//parse AdParameters first for the sake of MediaFile usage
		NodeList adParameterList = node.getElementsByTagName("AdParameters");
		if (adParameterList.getLength()>0) {
			this.adParameters = XMLHandler.getTextNodeValue(adParameterList.item(0));
		}

		if (node.hasAttribute(InternalConstants.TAG_SKIP_OFFSET)) {
			this.skipOffsetString = node.getAttribute(InternalConstants.TAG_SKIP_OFFSET);
		}
		
		NodeList children = node.getChildNodes();
		int len = children.getLength();
		for (int i = 0; i < len; i++) {
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String name = child.getNodeName();
				if (name.equals("Duration")) {
					String durationStr = XMLHandler.getTextNodeValue(child);
					this.duration = CommonUtil.convertVastDurationStringToSeconds(durationStr);
				} else if (name.equals(InternalConstants.OpenMeasurementConstants.TAG_TRACKING_EVENTS)) {
					NodeList trackings = ((Element) child).getElementsByTagName("Tracking");
					for (int j = 0; j < trackings.getLength(); j++) {
						Tracking tracking = new Tracking();
						tracking.parse((Element) trackings.item(j));
						if (tracking.event.equals("progress")) {
							tracking = new ProgressTracking();
							tracking.parse((Element) trackings.item(j));
						}
						this.trackingEvents.add(tracking);
					}
				} else if (name.equals("VideoClicks")) {
					NodeList videoClickNodes = child.getChildNodes();
					for (int j = 0; j < videoClickNodes.getLength(); j++) {
						Node videoClick = videoClickNodes.item(j);
						if (videoClick.getNodeType() == Node.ELEMENT_NODE) {
							String clickType = videoClick.getNodeName();
							VideoClick vc = new VideoClick(clickType);
							vc.parse((Element) videoClick);
							this.videoClicks.add(vc);
						}
					}
				} else if (name.equals("MediaFiles")) {
					NodeList interactiveCreativeFileNodes = ((Element) child).getElementsByTagName("InteractiveCreativeFile");
					for (int j = 0; j < interactiveCreativeFileNodes.getLength(); j++) {
						Node interactiveCreativeFileNode = interactiveCreativeFileNodes.item(j);
						if (interactiveCreativeFileNode.getNodeType() == Node.ELEMENT_NODE) {
							FWVastInteractiveCreativeFile interactiveCreativeFile = new FWVastInteractiveCreativeFile(this);
							interactiveCreativeFile.parse((Element) interactiveCreativeFileNodes.item(j));
							this.interactiveCreativeFiles.add(interactiveCreativeFile);
						}
					}

					NodeList mediaFileElements = ((Element) child).getElementsByTagName("MediaFile");
					for (int j = 0; j < mediaFileElements.getLength(); j++) {
						MediaFile mf = new MediaFile(this);
						mf.parse((Element) mediaFileElements.item(j));
						mf.setInteractiveCreativeFiles((ArrayList<FWVastInteractiveCreativeFile>) this.interactiveCreativeFiles);
						this.mediaFiles.add(mf);
					}
				} else if (name.equals("Icons")) {
					this.icons = child.getChildNodes();
				}
			}
		}
	}
	
	@Override
	public boolean isValid(ISlot slot,IConstants constants) {
		return this.validate(mediaFiles,slot,constants);
	}
	
	public ArrayList<? extends AbstractCreativeRendition> search (ISlot slot,IConstants constants){
		return this.searchAll(mediaFiles, slot, constants);
	}
}
