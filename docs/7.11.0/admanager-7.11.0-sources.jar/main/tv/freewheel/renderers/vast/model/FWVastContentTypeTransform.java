package tv.freewheel.renderers.vast.model;

import tv.freewheel.utils.Logger;

public class FWVastContentTypeTransform {
	//equivalence class array, each of which includes headed key element and following member elements
	static String[][] equivalence = {
			{"text/html_doc_lit_mobile"/*key element*/,"text/html","text/javascript","text/js_ref"},
			{"image/gif", "image/gif"},
			{"image/jpeg", "image/jpeg", "image/jpg"},
			{"image/png", "image/png"},
			{"image/bmp", "image/bmp"},
			{"video/3gpp"/*key element*/,"video/3gp"}};

	private static final Logger logger = Logger.getLogger("FWVastContentTypeTransform");

	public static String transform(String transformee) {
		String  transformed = null;
		if(transformee != null) {
			transformed = transformee;	//No transformation should return original type
			transformee = transformee.trim();
			OUTER_LOOP:for(int i=0;i<equivalence.length;i++){
				String[] eqclass = equivalence[i];
				if (eqclass.length<1)
					continue;
				String  key = eqclass[0];
				for(int j=0;j<eqclass.length;j++){  
					if(transformee.equalsIgnoreCase(eqclass[j])){
						transformed = key;
						break OUTER_LOOP;
					}
				}
			}
		}
		logger.debug("The content type "+transformee+" transformed to FW content type "+transformed);
		return transformed;
	}
}
