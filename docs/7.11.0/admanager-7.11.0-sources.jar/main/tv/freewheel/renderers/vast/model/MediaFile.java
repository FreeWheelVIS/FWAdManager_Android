package tv.freewheel.renderers.vast.model;

import android.webkit.URLUtil;

import org.w3c.dom.Element;

import java.util.ArrayList;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class MediaFile extends AbstractCreativeRendition {

	public String delivery;
	public Integer bitrate;
	public Boolean scalable;
	public Boolean maintainAspectRatio;
	
	private Linear linear; // Ancient Linear ;
	
	public MediaFile(Linear linear){
		this.linear = linear;
	}
	
	@Override
	public String toString(){
		return String.format("[MediaFile %s delivery=%s bitrate=%d scalable=%b maintainAspectRatio=%b]", 
				super.toString(), this.delivery, this.bitrate, this.scalable, this.maintainAspectRatio);
	}
	
	@Override
	public void parse(Element node){
		super.parse(node);
		String tp = node.getAttribute("type");
		if (!StringUtils.isBlank(tp)) {
			this.type = tp.trim();
			String url = XMLHandler.getTextNodeValue(node).trim();
			if(!StringUtils.isBlank(url) && URLUtil.isValidUrl(url)) {
				if(!super.isSetAssetContentSuccessfully(url)){
					this.assetURL = url.trim();
					if(this.type.equalsIgnoreCase(FW_VAST_CONTENT_TYPE_TEXT_HTML)) {
						this.type = FW_VAST_CONTENT_TYPE_HTML_REF;
					}
				}
				// keep assetURL for now
				// later if VPAID, remove content, otherwise remove assetURL
				this.assetURL = url.trim();
			}
			if (this.type.toLowerCase().contains("javascript")) {
				this.type = "text/js_ref";
			}
		}
		this.delivery = node.getAttribute("delivery");
		this.bitrate = StringUtils.parseInt(node.getAttribute("bitrate"), -1);
		this.scalable = StringUtils.parseBoolean(node.getAttribute("scalable"));
		this.maintainAspectRatio = StringUtils.parseBoolean(node.getAttribute("maintainAspectRatio"));
		this.adParameters = linear.adParameters;
	}

	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		if (slot.getSlotType() == IConstants.SlotType.TEMPORAL && slot.getSlotTimePositionClass() != IConstants.TimePositionClass.OVERLAY) {
			return type != null && (assetURL != null || assetContent != null);
		}
		return false;
	}
	
	@Override
	public void translateToFWCreativeRenditionAsset (ICreativeRenditionAsset asset) {
		if(this.linear.duration != null && this.linear.duration > 0. && this.bitrate !=null && this.bitrate >0) {
			asset.setBytes((int)(this.linear.duration*this.bitrate*1000.0/8.));
		}
	}

	@Override
	public void adjustMatchedRendition(ICreativeRendition cr, String expectedContentType, String expectedCreativeAPI) {
		boolean contentTypeMatched = false;
		if (cr.getContentType() != null && !cr.getContentType().isEmpty()
				&& expectedContentType != null && !expectedContentType.isEmpty()) {
			String ct = cr.getContentType().toLowerCase();
			String ect = expectedContentType.toLowerCase();

			if (ct.equals(ect)) {
				contentTypeMatched = true;
			} else if ((ct.startsWith("video/mp4") && ect.startsWith("video/mp4"))
					|| (ct.equals("text/js_ref") && ect.equals("application/javascript"))) {
				contentTypeMatched = true;
				cr.setContentType(expectedContentType);
			}
		}

		boolean creativeAPIMatched = false;
		if (cr.getCreativeAPI() != null && !cr.getCreativeAPI().isEmpty()
				&& expectedCreativeAPI != null && !expectedCreativeAPI.isEmpty()) {
			String capi = cr.getCreativeAPI().toLowerCase();
			String ecapi = expectedCreativeAPI.toLowerCase();

			if (capi.equals(ecapi)) {
				creativeAPIMatched = true;
			} else if (capi.startsWith(Constants.MOBILE_RICH_MEDIA_AD_INTERFACE_DEFINITIONS) && ecapi.startsWith(Constants.MOBILE_RICH_MEDIA_AD_INTERFACE_DEFINITIONS)) {
				creativeAPIMatched = true;
				cr.setCreativeAPI(expectedCreativeAPI);
			}
		}

		if (contentTypeMatched && creativeAPIMatched) {
			cr.setPreference(10);
		} else if (creativeAPIMatched) {
			cr.setPreference(6);
		} else if (contentTypeMatched) {
			cr.setPreference(5);
		} else {
			cr.setPreference(0);
		}

		logger.debug("adjustMatchedRendition " + cr.getId()
				+ ", contentType " + cr.getContentType()
				+ ", creativeAPI " + cr.getCreativeAPI()
				+ ", preference " + cr.getPreference());
	}

	@Override
	public void translateToFWCreativeRendition(ICreativeRendition cr, IAdInstance adi, IAdInstance hostAdi, IConstants constants) {
		if(this.linear.duration != null) {
			cr.setDuration(this.linear.duration);
		}else {
			if (hostAdi.getActiveCreativeRendition() != null) {
				this.linear.duration = hostAdi.getActiveCreativeRendition().getDuration();//for asset bytes only
				cr.setDuration(this.linear.duration);
			}
		}
		super.translateToFWCreativeRendition(cr,adi,hostAdi,constants);
	}

	@Override
	String getClickThroughURL() {
		String ret = null;
		for(VideoClick vclick: linear.videoClicks){
			if (VideoClick.TYPE_CLICK_THROUGH.equals(vclick.type)) {
				ret = vclick.url;
				break;
			}
		}
		return ret;
	}

	@Override
	ArrayList<String> getClickTrackingURLs() {
		ArrayList<String> ret = new ArrayList<String>();
		for(VideoClick vclick: linear.videoClicks){
			if (VideoClick.TYPE_CLICK_TRACKING.equals(vclick.type)) {
				ret.add(vclick.url);
			}
		}
		return ret;
	}
}
