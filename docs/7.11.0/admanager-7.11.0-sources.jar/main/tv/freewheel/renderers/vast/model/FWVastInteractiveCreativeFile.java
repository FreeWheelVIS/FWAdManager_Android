package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;

import tv.freewheel.utils.StringUtils;

public class FWVastInteractiveCreativeFile extends MediaFile {
	boolean variableDuration;

	public FWVastInteractiveCreativeFile(Linear linear) {
		super(linear);
	}

	public void parse(Element node) {
		super.parse(node);
		// Override type because MediaFile will parse text/html to text/html_doc_ref
		this.type = node.getAttribute("type");
		this.variableDuration = StringUtils.parseBoolean(node.getAttribute("variableDuration"));
	}
	@Override
	public String toString() {
		return String.format("[InteractiveCreativeFile %s variableDuration=%s]",
				super.toString(), this.variableDuration);
	}
}
