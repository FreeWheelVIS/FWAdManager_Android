package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import tv.freewheel.ad.InternalConstants;

public class JavaScriptResource extends AdVerificationResource {
    private boolean browserOptional;

    public JavaScriptResource() {
        this("", "", false);
    }

    public JavaScriptResource(String resourceURL, String apiFramework, boolean browserOptional) {
        super(resourceURL, apiFramework);
        this.browserOptional = browserOptional;
    }

    public void parse(Node node){
        super.parse(node);
        this.browserOptional = Boolean.parseBoolean(((Element) node).getAttribute(InternalConstants.OpenMeasurementConstants.TAG_BROWSER_OPTIONAL));
    }

    public boolean isBrowserOptional() {
        return this.browserOptional;
    }

    @Override
    public String toString() {
        return String.format("\n\t\t\t\t\t[AdVerificationResource\n\t\t\t\t\t\tresourceURL=%s\n\t\t\t\t\t\tapiFramework=%s\n\t\t\t\t\t\tbrowserOptional=%s]", this.resourceURL, this.apiFramework, this.browserOptional);
    }
}
