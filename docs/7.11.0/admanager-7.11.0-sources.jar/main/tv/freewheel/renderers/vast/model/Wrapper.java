package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.webkit.URLUtil;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class Wrapper extends AbstractAd {
	public String vastAdTagUri;

	public Wrapper(){
		super();
	}

	@Override
	public void parse(Element node){
		super.parse(node);
		NodeList children = node.getChildNodes();
		int len = children.getLength();
		for (int i = 0; i < len; i++){
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("VASTAdTagURI")){
					this.vastAdTagUri = XMLHandler.getTextNodeValue(child).trim();
				}
			}
		}
	}

	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		return (!StringUtils.isBlank(vastAdTagUri) && URLUtil.isValidUrl(vastAdTagUri));
	}
}
