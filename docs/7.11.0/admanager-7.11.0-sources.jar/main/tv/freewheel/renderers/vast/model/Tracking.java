package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;

import tv.freewheel.ad.InternalConstants;

public class Tracking extends AbstractPager implements Cloneable {
	public String event;
	
	@Override
	public String toString(){
		return String.format("[Tracking %s event=%s]",super.toString() ,this.event);
	}

	@Override
	public void parse(Element node){
		super.parse(node);
		this.event = node.getAttribute(InternalConstants.TAG_EVENT);
	}

	@Override
	public Tracking clone() throws CloneNotSupportedException {
		return (Tracking) super.clone();
	}
}
