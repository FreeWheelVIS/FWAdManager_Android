package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import tv.freewheel.ad.InternalConstants;

public class ExecutableResource extends AdVerificationResource {
    private String type;

    public ExecutableResource() {
        this("", "", "");
    }

    public ExecutableResource(String resourceURL, String apiFramework, String type) {
        super(resourceURL, apiFramework);
        this.type = (type != null) ? type : "";
    }

    public void parse(Node node){
        super.parse(node);
        this.type = ((Element) node).getAttribute(InternalConstants.OpenMeasurementConstants.TAG_TYPE);
    }

    public String getType() {
        return this.type;
    }

    @Override
    public String toString() {
        return String.format("\n\t\t\t\t\t[AdVerificationResource\n\t\t\t\t\t\tresourceURL=%s\n\t\t\t\t\t\tapiFramework=%s\n\t\t\t\t\t\ttype=%s]", this.resourceURL, this.apiFramework, this.type);
    }
}
