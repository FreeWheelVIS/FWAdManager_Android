package tv.freewheel.renderers.vast.model;

import java.util.ArrayList;


import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;

abstract class AbstractCreativeRenditionCollection implements IVastValidation {
	protected boolean validate (ArrayList<? extends IVastValidation> renditions, ISlot slot,IConstants constants){
		if (renditions == null || renditions.isEmpty()) {
			return false;
		}
		for (IVastValidation vv : renditions) {
			if (vv instanceof Companion) {
				Companion comp = (Companion) vv;
				if (comp.isValidCompanion(slot, constants)) {
					return true;
				}
			} else if(vv.isValid(slot,constants)) {
				return true;
			}
		}
		return false;
	}
	
	protected ArrayList<? extends AbstractCreativeRendition>searchAll(ArrayList<? extends AbstractCreativeRendition> renditions, ISlot slot,IConstants constants){
		ArrayList<AbstractCreativeRendition> ret = new ArrayList<AbstractCreativeRendition>();
		if (renditions == null || renditions.isEmpty())
			return ret;
		for (AbstractCreativeRendition vv : renditions) {
			if(vv.isValid(slot,constants)) {
				if (this instanceof CompanionAds) {
					Companion comp = (Companion)vv;
					if (comp.isValidCompanion(slot, constants)) {
						ret.add(vv);
					}
				}else {
					ret.add(vv);
				}
			}
		}
		return ret;
	}
}
