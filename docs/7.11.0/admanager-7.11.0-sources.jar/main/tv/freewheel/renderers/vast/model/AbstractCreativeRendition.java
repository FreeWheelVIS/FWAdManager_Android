package tv.freewheel.renderers.vast.model;

import android.util.Pair;

import org.w3c.dom.Element;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.UniversalAdId;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;

import static tv.freewheel.utils.URIUtil.splitQuery;

public abstract class AbstractCreativeRendition implements IVastValidation {
	public static final String FW_VAST_CONTENT_TYPE_HTML_CONTENT = "text/html_doc_lit_mobile";
	public static final String FW_VAST_CONTENT_TYPE_HTML_REF = "text/html_doc_ref";
	public static final String FW_VAST_CONTENT_TYPE_TEXT_HTML = "text/html";
	public static final String FW_VAST_SIMID = "SIMID";

	public String id;
	public UniversalAdId universalAdId;
	public Integer width;
	public Integer height;
	String assetURL;
	String assetContent;
	String type;
	String apiFramework;

	String adParameters;
	List<FWVastInteractiveCreativeFile> interactiveCreativeFiles;
	private boolean shouldInjectCallback = false;

	protected static final Logger logger = Logger.getLogger(AbstractCreativeRendition.class);

	protected AbstractCreativeRendition() {
	}

	@Override
	public String toString() {
		return String.format("[[%s] id=%s assetURL=%s assetContent=%s  width=%d height=%d type=%s apiFramework=%s]",
				super.toString(), this.id, this.assetURL, this.assetContent, this.width, this.height, this.type, this.apiFramework);
	}

	String getAltText() {
		return null;
	}

	public void parse(Element node) {
		this.id = node.getAttribute("id");
		this.width = StringUtils.parseInt(node.getAttribute("width"));
		this.height = StringUtils.parseInt(node.getAttribute("height"));
		this.apiFramework = node.getAttribute("apiFramework");
	}

	@Override
	public boolean isValid(ISlot slot, IConstants constants) {
		return (width != null && width > 0. && height != null && height > 0. && type != null && (assetURL != null || assetContent != null));
	}

	public String getContentType() {
		if (type != null)
			return FWVastContentTypeTransform.transform(this.type);
		else
			return null;
	}

	public boolean isSetAssetContentSuccessfully(String url) {
		if (type.contains("javascript")) {
			this.assetContent = FWVastContentTransform.text_js_ref_TO_text_html_doc_lit_mobile(url);
			return true;
		}
		return false;
	}

	abstract String getClickThroughURL();

	abstract ArrayList<String> getClickTrackingURLs();

	public void translateToFWCreativeRenditionAsset(ICreativeRenditionAsset asset) {
	}

	public void adjustMatchedRendition(ICreativeRendition cr, String expectedContentType, String expectedCreativeAPI) {
	}

	public void translateToFWCreativeRendition(ICreativeRendition cr, IAdInstance adi, IAdInstance hostAdi, IConstants constants) {
		cr.setContentType(this.getContentType());
		((CreativeRendition) cr).setUniversalAdId(universalAdId);

		//Vast to MRAID
		if (this.apiFramework != null && !this.apiFramework.isEmpty()) {
			if (this.apiFramework.equalsIgnoreCase("MRAID")) {
				cr.setCreativeAPI("MRAID-1.0");
			} else if (this.apiFramework.equalsIgnoreCase("VPAID")) {
				cr.setCreativeAPI("VPAID");
			} else {
				cr.setCreativeAPI(this.apiFramework);
			}
		} // else "None"

		// text/js_ref and VPAID
		if (this.type.equals("text/js_ref")) {
			if (cr.getCreativeAPI().equals("VPAID")) {
				cr.setContentType(this.type);
				this.assetContent = null;
			} else {
				this.assetURL = null;
			}
		}

		// SIMID
		if (this.interactiveCreativeFiles != null && !this.interactiveCreativeFiles.isEmpty()) {
			for (int i = 0; i < this.interactiveCreativeFiles.size(); i++) {
				FWVastInteractiveCreativeFile interactiveCreativeFile = this.interactiveCreativeFiles.get(i);
				if (interactiveCreativeFile.apiFramework.equalsIgnoreCase(FW_VAST_SIMID) && interactiveCreativeFile.type.equalsIgnoreCase(FW_VAST_CONTENT_TYPE_TEXT_HTML)) {
					((CreativeRendition) cr).setSimidCreativeUrl(interactiveCreativeFile.assetURL);
					((CreativeRendition) cr).setSimidVariableDurationAllowed(interactiveCreativeFile.variableDuration);
					cr.setContentType(interactiveCreativeFile.type);
					cr.setCreativeAPI(interactiveCreativeFile.apiFramework);
					break;
				}
			}
		}

		//AdParameters
		if (adParameters != null) {
			URI uri;
			try {
				uri = URI.create("http://fakehost?" + adParameters);
				List<Pair<String, String>> list = splitQuery(uri);
				for (Pair<String, String> nvp : list){
					cr.setParameter(nvp.first, nvp.second);
				}
			} catch (Throwable e) {
				logger.debug("Invalid adParameters:" + adParameters);
			}
			cr.setParameter("creativeData", adParameters);
			logger.debug("creativeData: " + adParameters);
		}

		cr.setWidth(this.width);
		cr.setHeight(this.height);
		if (cr.getWrapperURL() == null) {
			ICreativeRenditionAsset asset = cr.createCreativeRenditionAssetForTranslation(this.id, true);
			asset.setContentType(cr.getContentType());
			asset.setMimeType(this.type);
			if (this.assetURL != null) {
				asset.setURL(this.assetURL);
			} else {
				if (shouldInjectCallback) {
					String clickURL = null;
					final String url = this.getClickThroughURL();
					if (url != null) {
						adi.setClickThroughURL(url, constants.EVENT_AD_CLICK());
						List<String> urls = adi.getEventCallbackURLs(constants.EVENT_AD_CLICK(), constants.EVENT_TYPE_CLICK());
						if (urls != null && urls.size() > 0) {
							clickURL = urls.get(0);
						}
					}
					List<String> trackingURLs = adi.getEventCallbackURLs(constants.EVENT_AD_CLICK(), constants.EVENT_TYPE_CLICK_TRACKING());
					logger.debug("injected tracking urls:" + trackingURLs.toString());
					String safeId = null;
					if (adi != null && adi.getSlot() != null) {
						safeId = adi.getSlot().getCustomId();
					}
					this.assetContent = FWVastContentTransform.injectCallback(this.assetContent, clickURL, trackingURLs, safeId);
				}
				asset.setContent(this.assetContent);
			}
			this.translateToFWCreativeRenditionAsset(asset);
			logger.debug("translate to asset (content type:" + asset.getContentType() + ",mime type:" + asset.getMimeType()
					+ ", url:" + asset.getURL() + ",content:" + asset.getContent());

		}
		if (hostAdi.getActiveCreativeRendition() != null) {
			adjustMatchedRendition(cr, hostAdi.getActiveCreativeRendition().getContentType(), hostAdi.getActiveCreativeRendition().getCreativeAPI());
		}
		logger.debug("translate to content type:" + cr.getContentType());
		logger.debug("translate to width:" + cr.getWidth() + ",height=" + cr.getHeight());
	}

	public void setInteractiveCreativeFiles(List<FWVastInteractiveCreativeFile> interactiveCreativeFiles) {
		this.interactiveCreativeFiles = interactiveCreativeFiles;
	}
}
