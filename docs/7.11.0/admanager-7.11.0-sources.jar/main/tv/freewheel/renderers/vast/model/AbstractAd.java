package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.ArrayList;

import tv.freewheel.ad.AdVerification;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.Extension;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.XMLHandler;
import tv.freewheel.utils.StringUtils;

public abstract class AbstractAd implements IVastValidation {
	public List<String> errors;
	public List<Impression> impressions;
	public List<Creative> creatives;
	public List<Extension> extensions;
	public List<AdVerification> adVerifications;
	private static final Logger logger = Logger.getLogger(AbstractAd.class);

	public AbstractAd() {
		this.impressions = new ArrayList<>();
		this.errors = new ArrayList<>();
		this.creatives = new ArrayList<>();
		this.extensions = new ArrayList<>();
		this.adVerifications = new ArrayList<>();
	}

	public void parse(Element node) {
		NodeList children = node.getChildNodes();
		int len = children.getLength();
		for (int i = 0; i < len; i++) {
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String name = child.getNodeName();
				if (name.equals("Error")) {
					this.errors.add(XMLHandler.getTextNodeValue(child));
				} else if (name.equals("Impression")) {
					Impression impr = new Impression();
					impr.parse((Element) child);
					this.impressions.add(impr);
				} else if (name.equals("Creatives")) {
					NodeList creativeNodes = ((Element) child).getElementsByTagName("Creative");
					for (int j = 0; j < creativeNodes.getLength(); j++) {
						Creative creative = new Creative();
						creative.parse((Element) creativeNodes.item(j));
						this.creatives.add(creative);
					}
				} else if (name.equals("Extensions")) {
					NodeList extensionNodes = ((Element) child).getElementsByTagName("Extension");
					for (int j = 0; j < extensionNodes.getLength(); j++) {
						Element element = (Element) extensionNodes.item(j);
						if (element.getAttribute(InternalConstants.TAG_EXTENSION_TYPE).equals(InternalConstants.OpenMeasurementConstants.TAG_AD_VERIFICATIONS)) {
							for (int k = 0; k < element.getChildNodes().getLength(); k++) {
								Node insideChildNode = element.getChildNodes().item(k);
								if (insideChildNode.getNodeType() == Node.ELEMENT_NODE
										&& insideChildNode.getNodeName().equals(InternalConstants.OpenMeasurementConstants.TAG_AD_VERIFICATIONS)) {
									adVerifications.addAll(StringUtils.parseAdVerifications(insideChildNode));
								}
							}
						}
						Extension extension = new Extension();
						extension.parse(element, "");
						this.extensions.add(extension);
					}
				} else if (name.equals(InternalConstants.OpenMeasurementConstants.TAG_AD_VERIFICATIONS)) {
					adVerifications.addAll(StringUtils.parseAdVerifications(child));
				}
			}
		}
	}

	@Override
	public boolean isValid(ISlot slot, IConstants constants) {
		if (creatives == null || creatives.isEmpty())
			return false;
		for (Creative creative : this.creatives) {
			if (creative.isValid(slot, constants)) {
				return true;
			}
		}
		return false;
	}

	public List<? extends AbstractCreativeRendition> searchInDrivingSlot(ISlot drivingSlot, IConstants constants) {
		List<AbstractCreativeRendition> retval = new ArrayList<>();
		if (drivingSlot.getSlotType() == IConstants.SlotType.TEMPORAL) {
			for (Creative creative : this.creatives) {
				retval.addAll(creative.searchInDrivingSlot(drivingSlot, constants));
			}
		} else
			logger.debug("Non-Temporal slot should NOT be driving slot. ");
		return retval;
	}

	public List<? extends AbstractCreativeRendition> searchInCompanionSlot(ISlot companionSlot, IConstants constants) {
		List<AbstractCreativeRendition> retval = new ArrayList<>();
		if (companionSlot.getSlotType() != IConstants.SlotType.TEMPORAL) {
			for (Creative creative : this.creatives) {
				retval.addAll(creative.searchInCompanionSlot(companionSlot, constants));
			}
		} else
			logger.debug("Temporal slot should NOT be companion slot. ");
		return retval;
	}

	@Override
	public String toString() {
		return String.format("[VastAd\n\t\tErrors=%s\n\t\tImpressions=%s\n\t\tCreatives=%s\n\t\tExtensions=%s\n\t\tAdVerifications=%s]",
				this.errors, this.impressions, this.creatives, this.extensions, this.adVerifications);
	}
}
