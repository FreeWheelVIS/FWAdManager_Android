package tv.freewheel.renderers.vast.model;

import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.webkit.URLUtil;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

abstract class AbstractNonMediaFile extends AbstractCreativeRendition {
	Integer expandedWidth;
	Integer expandedHeight;
	String staticResource;
	String iframeResource;
	String htmlResource;
	
	private String getResource() {
		if (staticResource != null)
			return "staticResource='" + staticResource + "'";
		else if (iframeResource != null)
			return "iframeResource='" + iframeResource + "'";
		else if (htmlResource != null)
			return "htmlResource='" + htmlResource + "'";
		else 
			return "no resource";
	}
	@Override
	public String toString(){
		return String.format("[%s resource=%s adParameters='%s' expandedWidth=%d expandedHeight=%d]", 
				super.toString(),this.getResource(), this.adParameters, this.expandedWidth, this.expandedHeight);
	}

	@Override
	public void parse(Element node){
		super.parse(node);
		this.expandedWidth = StringUtils.parseInt(node.getAttribute("expandedWidth"));
		this.expandedHeight = StringUtils.parseInt(node.getAttribute("expandedHeight"));
		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++){
			Node child = childList.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("AdParameters")){
					this.adParameters = XMLHandler.getTextNodeValue(child);
				}else if (name.equals("StaticResource")){
					this.staticResource = XMLHandler.getTextNodeValue(child);
					String creativeType = ((Element)child).getAttribute("creativeType");
					if (!StringUtils.isBlank(creativeType)){
						this.type = creativeType.trim();
						if (!StringUtils.isBlank(staticResource) && URLUtil.isValidUrl(staticResource.trim())) {
							if(!super.isSetAssetContentSuccessfully(staticResource)){
								this.assetURL = staticResource.trim();
								if(this.type.equalsIgnoreCase(FW_VAST_CONTENT_TYPE_TEXT_HTML))
									this.type = FW_VAST_CONTENT_TYPE_HTML_REF;
							}
						}
					}
				}else if (name.equals("IFrameResource")){
					this.iframeResource = XMLHandler.getTextNodeValue(child);
					if (!StringUtils.isBlank(iframeResource) && URLUtil.isValidUrl(iframeResource.trim())){
						logger.debug("selected IFrameResource :" + iframeResource);
						this.assetURL = iframeResource.trim();
						this.type = FW_VAST_CONTENT_TYPE_HTML_REF;
					}
				}else if (name.equals("HTMLResource")){
					this.htmlResource = XMLHandler.getTextNodeValue(child);
					if (!StringUtils.isBlank(htmlResource)) {
						logger.debug("selected HTMLResource :" + htmlResource);
						this.assetContent = FWVastContentTransform.text_html_TO_text_html_doc_lit_mobile(htmlResource);
					}
					this.type = FW_VAST_CONTENT_TYPE_HTML_CONTENT;
				}
			}
		}
	}
	
	@Override
	public void translateToFWCreativeRendition(ICreativeRendition cr, IAdInstance adi, IAdInstance hostAdi, IConstants constants) {
		String url = this.getClickThroughURL();
		if (url != null) {
			adi.setClickThroughURL(url, constants.EVENT_AD_CLICK());
		}
		super.translateToFWCreativeRendition(cr, adi, hostAdi, constants);
	}

	@Override
	ArrayList<String> getClickTrackingURLs() {
		return new ArrayList<String>();
	}
}
