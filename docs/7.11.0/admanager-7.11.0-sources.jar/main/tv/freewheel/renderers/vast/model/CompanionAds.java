package tv.freewheel.renderers.vast.model;

import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;

class CompanionAds extends AbstractCreativeRenditionCollection {
	ArrayList<Companion> companions;
	
	public CompanionAds(){
		this.companions = new ArrayList<Companion>();
	}
	
	public void parse(Element node){
		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++){
			Node child = childList.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("Companion")){
					Companion companion = new Companion();
					companion.parse((Element)child);
					this.companions.add(companion); 
				}
			}
		}
	}
	
	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		return this.validate(companions,slot,constants);
	}
	
	public ArrayList<? extends AbstractCreativeRendition> search (ISlot slot,IConstants constants){
		return this.searchAll(companions, slot, constants);
	}
}
