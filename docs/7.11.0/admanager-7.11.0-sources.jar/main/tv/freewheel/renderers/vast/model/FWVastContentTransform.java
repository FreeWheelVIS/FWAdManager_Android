package tv.freewheel.renderers.vast.model;

import tv.freewheel.utils.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FWVastContentTransform {
//macro
	public static final String FW_VAST_CONTENT_MACRO = "#{content}";
	public static final String FW_VAST_REQUEST_PAGE_URL_MACRO = "#j{request.pageUrl}";
	public static final String FW_VAST_AD_CREATIVE_MARGIN_WIDTH_MACRO = "#{ad.creative.marginWidth}";
	public static final String FW_VAST_AD_CREATIVE_MARGIN_HEIGHT_MACRO ="#{ad.creative.marginHeight}";
	public static final String FW_VAST_AD_CREATIVE_WIDTH_MACRO = "#{ad.creative.width}";
	public static final String FW_VAST_AD_CREATIVE_HEIGHT_MACRO = "#{ad.creative.height}";
	public static final String FW_VAST_DEFAULT_CLICK_URL_MACRO = "#{click(\"defaultClick\")}";
	public static final String FW_VAST_SLOT_SAFE_ID_MACRO = "#{slot.safeId}";
	public static final String FW_VAST_JS_CLICK_ARRAY_MACRO = "#{jsClickArray}";
	public static final String FW_VAST_ALT_TEXT = "#{altText_VAST}";
	
	private static FWVastContentTransform instance = null;
	private static final Logger logger;

	static {
		logger = Logger.getLogger("FWVastContentTransform");
		instance = new FWVastContentTransform();
		instance.setDefaultMacros();
	}
	private HashMap<String,String> macros;
	private FWVastContentTransform() {
		macros = new HashMap<String,String>();
	}

	void setDefaultMacros() {
		macros.put(FW_VAST_AD_CREATIVE_MARGIN_WIDTH_MACRO, "0");
		macros.put(FW_VAST_AD_CREATIVE_MARGIN_HEIGHT_MACRO, "0");
	}
		
	public static void clearMacros(){
		instance.macros.clear();
		instance.setDefaultMacros();
	}
	
	public static void setMarco(String name , String value){
		if (name == null || value == null)
			return;
		instance.macros.put(name, value);
	}
	
	private static void setRequestPageURL(String url) {
		if (url == null)
			url = "";
		instance.macros.put(FW_VAST_REQUEST_PAGE_URL_MACRO,url);
	}
	
	public static String text_js_ref_TO_text_html_doc_lit_mobile(String content) {
		setRequestPageURL(null);
		return instance.injectContent(content). 
					JSRef_to_HTMLLit() .
					HTMLLit_to_HTMLLit_deco().
					HTMLLit_to_HTMLDocLit_mobile().
				retrieveContent();
	}
	
	public static String text_html_TO_text_html_doc_lit_mobile(String content) {
		setRequestPageURL(null);
		return instance.injectContent(content). 
					HTMLLit_to_HTMLLit_deco().
					HTMLLit_to_HTMLDocLit_mobile().
				retrieveContent();
	}
	
	public static String text_javascript_TO_text_html_doc_lit_mobile(String content) {
		setRequestPageURL(null);
		return instance.injectContent(content).
					JSLit_to_HTMLLit(). 
					HTMLLit_to_HTMLLit_deco().
					HTMLLit_to_HTMLDocLit_mobile().
				retrieveContent();
	}
	
	public static String injectCallback(String content, String clickURL, List<String> trackingURLs, String safeId) {
		clearMacros();
		if(clickURL == null)
			clickURL = "#";
		instance.macros.put(FW_VAST_DEFAULT_CLICK_URL_MACRO, clickURL);
		
		//set specific macros if it is not set before using setMarco class method
		if (safeId == null) {
			safeId = "" + (int)(Math.random()*1000000.);
		}
		instance.macros.put(FW_VAST_SLOT_SAFE_ID_MACRO,safeId);

		String jsTrackingURLs = "{}";
		if (!trackingURLs.isEmpty()) {
			StringBuffer js = null;
			for (String url : trackingURLs) {
				if (js == null) {
					js = new StringBuffer("[");
				}else {
					js.append(",");
				}
				js.append("\"" + url + "\"");
			}
			js.append("]");
			jsTrackingURLs = "[{\"name\":\"defaultClick\",\"url\":\"" + clickURL + "\",\"trackingURLs\":" + js.toString() + "}]";
		}
		instance.macros.put(FW_VAST_JS_CLICK_ARRAY_MACRO,jsTrackingURLs);
		instance.applyMacros(content);
		logger.debug("The defaultClick:" + clickURL + ", trackingURLs:" + jsTrackingURLs + " are injected");
		String ret = instance.retrieveContent();
		clearMacros();
		return ret;
	}
	
	//see Ads_Macro_Expander::escape_javascript(const std::string& in, std::string& out)
	//
	String jsescape(String escapee) {
		if (escapee == null)
			return null;
		StringBuffer result = new StringBuffer();
		for (int i=0; i<escapee.length(); i++) {
			char c =  escapee.charAt(i);
			switch (c) {
				case '\'':	result.append("\\'");	break;
				case '"':	result.append("\\\"");	break;
				case '&':	result.append("\\&");	break;
				case '\\':	result.append("\\\\");	break;
				case '\r':	result.append("\\r");	break;
				case '\n':	result.append("\\n");	break;
				case '\t':	result.append("\\t");	break;
				case '\b':	result.append("\\b");	break;
				case '\f':  result.append("\\f");	break;
				default: result.append(c);
			}
		}
		return result.toString();
	}
	
	FWVastContentTransform injectContent(String content) {
		if (content != null && content.trim().length() != 0 )
			macros.put(FW_VAST_CONTENT_MACRO, content);
		return this;
	}
			
	String retrieveContent() {
		String ret = macros.get(FW_VAST_CONTENT_MACRO);
		macros.remove(FW_VAST_CONTENT_MACRO);
		return  ret;
	}
	
	FWVastContentTransform applyMacros(String template) {
		logger.debug("applyMacros");
		if(template == null || template.length() == 0)
			return this;
		StringBuffer muttemplate = new StringBuffer(template); 
		for(String key : macros.keySet()) {
			String value =  macros.get(key);
			if (key.startsWith("#j{")) {
				value = this.jsescape(value);
			}
			int start = 0;
			int idx = muttemplate.indexOf(key);
			StringBuffer entity = new StringBuffer();
			while (idx>0){
				entity.append(muttemplate.substring(start,idx));
				entity.append(value);
				start = idx + key.length();
				idx = muttemplate.indexOf(key, start);
			}
			entity.append(muttemplate.substring(start));
			muttemplate = entity;
		}
		this.injectContent(muttemplate.toString());
		return this;
	}
	
	FWVastContentTransform JSLit_to_HTMLLit() {
		//4_JSLit_to_HTMLLit.html
		String template =
		"<script type=\"text/javascript\" language=\"javascript\">" + 
		"//<!--\n" + 
		"#{content}" +
		"//-->" + 
		"</script>";
		return this.applyMacros(template);
	}
	
	FWVastContentTransform JSRef_to_HTMLLit() {
		//8_JSRef_to_HTMLLit.html
		String template = 
		"<script src=\"#{content}\" type=\"text/javascript\" language=\"javascript\"></script>";
		
		return this.applyMacros(template);
	}
	
	FWVastContentTransform HTMLLit_to_HTMLLit_deco() {
		//20_HTMLLit_to_HTMLLit_deco.html
		String template = 
		"<span style=\"display:inline-block; vertical-align:top; margin:#{ad.creative.marginHeight}px #{ad.creative.marginWidth}px #{ad.creative.marginHeight}px #{ad.creative.marginWidth}px;\">#{content}</span>";
		
		return this.applyMacros(template);
	}
	
	FWVastContentTransform HTMLLit_to_HTMLDocLit_mobile() {
		//23_HTMLLit_to_HTMLDocLit_mobile.html
		String template = 
		"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">" +
		"<html>" +
		"<head>" +
		"<meta name = \"viewport\" content = \"initial-scale = 1.0\" />" +
		"<title>Advertisement</title>" +
		"<script type=\"text/javascript\">window._fw_page_url = \"#j{request.pageUrl}\";</script>" +
		"</head>" +
		"<body style=\"margin:0px;background-color:transparent;\">#{content}</body>" +
		"</html>";	
		return  this.applyMacros(template);
	}
}