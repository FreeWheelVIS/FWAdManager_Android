package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import tv.freewheel.ad.InternalConstants;

public abstract class AdVerificationResource {
    protected String resourceURL;
    protected String apiFramework;

    public AdVerificationResource(String resourceURL, String apiFramework) {
        this.resourceURL = (resourceURL != null) ? resourceURL : "";
        this.apiFramework = (apiFramework != null) ? apiFramework : "";
    }

    public void parse(Node node){
        this.resourceURL = node.getTextContent().trim();
        this.apiFramework =  ((Element) node).getAttribute(InternalConstants.OpenMeasurementConstants.TAG_API_FRAMEWORK);
    }

    public String getResourceURL() {
        return this.resourceURL;
    }

    public String getApiFramework() {
        return this.apiFramework;
    }

    public String toString() {
        return String.format("\n\t\t\t\t\t[AdVerificationResource\n\t\t\t\t\t\tresourceURL=%s\n\t\t\t\t\t\tapiFramework=%s]", this.resourceURL, this.apiFramework);
    }
}
