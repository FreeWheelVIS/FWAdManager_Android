package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

import tv.freewheel.ad.UniversalAdId;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;

public class Creative  implements IVastValidation{

	String adId;
	public Linear linear;
	public CompanionAds companionAds;
	public NonLinearAds nonLinearAds;

	public UniversalAdId universalAdId;

	public Creative(){

	}

	@Override
	public String toString(){
		return String.format("[Creative\n\t\t\tadId=%s\n\t\t\tUniversalAdId=%s\n\t\t\tLinear=%s\n\t\t\tCompanions=%s\n\t\t\tNonLinearAds=%s\n\t\t]",
				this.adId, this.universalAdId, this.linear, this.companionAds, this.nonLinearAds);
	}

	public void parse(Element node){
		this.adId = node.getAttribute("AdID");
		NodeList children = node.getChildNodes();
		int len = children.getLength();
		for (int i = 0; i < len; i++){
			Node child = children.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("Linear")){
					this.linear = new Linear();
					this.linear.parse((Element) child);
				}else if (name.equals("NonLinearAds")){
					this.nonLinearAds = new NonLinearAds();
					this.nonLinearAds.parse((Element) child);
				}else if (name.equals("CompanionAds")){
					this.companionAds = new CompanionAds();
					this.companionAds.parse((Element)child);
				}else if (name.equals("UniversalAdId")) {
					this.universalAdId = new UniversalAdId();
					this.universalAdId.parse((Element)child);
				}
			}
		}
	}

	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		return (linear!=null && linear.isValid(slot,constants)) ||
				(nonLinearAds !=null && nonLinearAds.isValid(slot,constants)) ||
				(companionAds !=null && companionAds.isValid(slot,constants));
	}

	public ArrayList<? extends AbstractCreativeRendition> searchInDrivingSlot(ISlot drivingSlot,IConstants constants){
		ArrayList<? extends  AbstractCreativeRendition> ret;
		if(linear!=null && linear.isValid(drivingSlot,constants))
			ret = linear.search(drivingSlot, constants);
		else if(nonLinearAds !=null && nonLinearAds.isValid(drivingSlot,constants))
			ret = nonLinearAds.search(drivingSlot, constants);
		else
			ret = new ArrayList<AbstractCreativeRendition>();
		// assign universalAdId to all the selected renditions
		for (AbstractCreativeRendition cr: ret) {
			cr.universalAdId = this.universalAdId;
		}
		return ret;
	}

	public ArrayList<? extends AbstractCreativeRendition> searchInCompanionSlot(ISlot companionSlot,IConstants constants){
		if(companionAds!=null && companionAds.isValid(companionSlot,constants))
			return companionAds.search(companionSlot, constants);
		else
			return new ArrayList<AbstractCreativeRendition>();
	}

	public ArrayList<Tracking> getTrackingEvents(ISlot drivingSlot,IConstants constants) {
		if (linear != null &&
				drivingSlot.getSlotType() == IConstants.SlotType.TEMPORAL &&
				drivingSlot.getSlotTimePositionClass() != IConstants.TimePositionClass.OVERLAY) {
			return linear.trackingEvents;
		} else if(nonLinearAds != null && drivingSlot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
			return nonLinearAds.trackingEvents;
		} else {
			return new ArrayList<Tracking>();//CompanionAds No tracking event, because every companion has its own
		}

	}
}
