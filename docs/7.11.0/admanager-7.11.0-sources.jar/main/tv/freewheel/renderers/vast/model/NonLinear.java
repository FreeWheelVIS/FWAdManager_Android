package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;	
import org.w3c.dom.Node;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class NonLinear extends AbstractNonMediaFile {
	
	String minSuggestionDuration;
	String nonLinearClickThrough;
	Boolean scalable;
	Boolean maintainAspectRatio;

	@Override
	public String toString(){
		return String.format("[NonLinear  %s minSuggestionDuration=%s nonLinearClickThrough=%s scalable=%b maintainAspectRatio=%b ]", 
				super.toString(), this.minSuggestionDuration, this.nonLinearClickThrough, this.scalable, this.maintainAspectRatio);
	}
	
	@Override
	public void parse(Element node){
		super.parse(node);
		this.scalable = StringUtils.parseBoolean(node.getAttribute("scalable"));
		this.maintainAspectRatio = StringUtils.parseBoolean(node.getAttribute("maintainAspectRatio"));
		this.minSuggestionDuration = node.getAttribute("minSuggestionDuration");
		for (int i = 0; i < node.getChildNodes().getLength(); i++){
			Node child = node.getChildNodes().item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE){
				String name = child.getNodeName();
				if (name.equals("NonLinearClickThrough")){
					this.nonLinearClickThrough = XMLHandler.getTextNodeValue(child);
				}
			}
		}
	}
	
	@Override
	public void translateToFWCreativeRendition(ICreativeRendition cr, IAdInstance adi, IAdInstance hostAdi, IConstants constants) {
		if (hostAdi.getActiveCreativeRendition() != null) {
			cr.setDuration(hostAdi.getActiveCreativeRendition().getDuration());
		}
		super.translateToFWCreativeRendition(cr,adi,hostAdi,constants);
	}

	@Override
	public boolean isValid(ISlot slot,IConstants constants){
		if (slot.getSlotTimePositionClass() == IConstants.TimePositionClass.OVERLAY) {
			return super.isValid(slot, constants);
		}
		return false;
	}
	
	@Override
	String getClickThroughURL() {
		return this.nonLinearClickThrough;
	}

}
