package tv.freewheel.renderers.vast.model;

import org.w3c.dom.Element;

import android.webkit.URLUtil;

import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

abstract class AbstractPager {
	public String id;//Tracking use null value
	public String url;
	
	@Override
	public String toString(){
		return String.format("[id=%s url=%s]", this.id, this.url);
	}
	
	public void parse(Element node){
		this.id = node.getAttribute("id");
		this.url = XMLHandler.getTextNodeValue(node);
	}

	public boolean isValid() {
		return (!StringUtils.isBlank(url) && URLUtil.isValidUrl(url));
	}
}
