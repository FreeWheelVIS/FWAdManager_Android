package tv.freewheel.renderers.vast.model;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;

public interface IVastValidation {
	public boolean isValid(ISlot slot,IConstants constants);
}
