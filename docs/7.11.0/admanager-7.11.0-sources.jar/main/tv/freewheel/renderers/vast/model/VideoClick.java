package tv.freewheel.renderers.vast.model;

public class VideoClick extends AbstractPager {
	public static final String TYPE_CLICK_THROUGH = "ClickThrough";
	public static final String TYPE_CLICK_TRACKING = "ClickTracking";
	public static final String TYPE_CUSTOM_CLICK = "CustomClick";
	public String type;//{ClickThrough,ClickTracking,CustomClick}
	
	public VideoClick(String type){
		this.type = type;
	}
	
	@Override
	public String toString(){
		return String.format("[VideoClick %s type=%s]", super.toString() ,this.type);
	}
}
