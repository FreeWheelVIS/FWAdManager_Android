package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.utils.StringUtils;

public class CreativeRendition extends ParametersHolder implements ICreativeRendition, Comparable<CreativeRendition> {

	private String baseUnit;
	private String contentType; //use getContentType instead
	private String wrapperType;
	private String wrapperUrl;
	private String creativeAPI;
	private int preference;
	private int height;
	private int width;
	private double duration;
	private CreativeRenditionAsset primaryCreativeRenditionAsset;
	private ArrayList<CreativeRenditionAsset> otherCreativeRenditionAssets;

	public int creativeRenditionId;
	public String replicaId;
	private UniversalAdId universalAdId;
	private String simidCreativeUrl;
	private Boolean simidVariableDurationAllowed;

	public CreativeRendition(Creative creative) {
		super(creative.getAdContext());
		this.baseUnit = creative.baseUnit;
		this.otherCreativeRenditionAssets = new ArrayList<>();
		this.setCreativeAPI("None");
	}

	public void parse(Element node) {
		NodeList childList = node.getChildNodes();

		this.creativeRenditionId = StringUtils.parseInt(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_ID), 0);

		this.replicaId = node.hasAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_REPLICA_ID) ? node.getAttribute(InternalConstants.ATTR_CREATIVE_RENDITION_REPLICA_ID) : "";

		this.setContentType(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_CONTENT_TYPE));

		this.setWrapperType(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_WRAPPER_TYPE));

		this.setWrapperURL(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_WRAPPER_URL));

		this.setPreference(StringUtils.parseInt(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_PREFERENCE), 0));

		this.setHeight(StringUtils.parseInt(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_HEIGHT), 0));

		this.setWidth(StringUtils.parseInt(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_WIDTH), 0));

		this.setCreativeAPI(node.getAttribute(
				InternalConstants.ATTR_CREATIVE_RENDITION_CREATIVEAPI));

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_PARAMETERS)){
					this.parameters = parseParameters((Element)childNode);
				} else if (name.equals(InternalConstants.TAG_ASSET)){
					this.primaryCreativeRenditionAsset = new CreativeRenditionAsset(this.context);
					this.primaryCreativeRenditionAsset.parse((Element)childNode);
				} else if (name.equals(InternalConstants.TAG_OTHER_ASSETS)){
					this.parseOtherAssets((Element)childNode);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	protected void parseOtherAssets(Element node) {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseOtherAssets(), name: " + name);

				if (name.equals(InternalConstants.TAG_ASSET)){
					CreativeRenditionAsset asset = new CreativeRenditionAsset(this.context);
					asset.parse((Element)childNode);
					this.otherCreativeRenditionAssets.add(asset);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	public Object getParameter(final String key) {
		if(key == null) {
			return null;
		}

		return this.parameters.get(key);
	}

	public void setParameter(final String key, final Object value){
		if(key == null) {
			return;
		}

		if(value != null) {
			this.parameters.put(key, value);
		} else {
			this.parameters.remove(key);
		}
	}

	public ICreativeRenditionAsset createCreativeRenditionAssetForTranslation(String name, boolean isPrimary) {
		CreativeRenditionAsset asset = new CreativeRenditionAsset(this.context);
		asset.name = name;
		if (isPrimary){
			this.primaryCreativeRenditionAsset = asset;
		}
		else {
			this.otherCreativeRenditionAssets.add(asset);
		}
		return asset;
	}

	public String getContentType() {
		if (this.contentType != null && this.contentType.length() > 0) {
			return this.contentType;
		} else if (this.primaryCreativeRenditionAsset != null) {
			return this.primaryCreativeRenditionAsset.contentType;
		} else {
			return "";
		}
	}

	public String getBaseUnit() {
		return this.baseUnit;
	}

	public ICreativeRenditionAsset getPrimaryCreativRenditionAsset() {
		return this.primaryCreativeRenditionAsset;
	}

	public String getCreativeAPI() {
		return this.creativeAPI;
	}

	public double getDuration() {
		return this.duration;
	}

	public int getHeight() {
		return this.height;
	}

	public List<ICreativeRenditionAsset> getOtherRenditionAssets() {
		List<ICreativeRenditionAsset> assets = new ArrayList<>();
		assets.addAll(this.otherCreativeRenditionAssets);
		return assets;
	}

	public int getPreference() {
		return this.preference;
	}

	public int getWidth() {
		return this.width;
	}

	public void setContentType(String value) {
		this.contentType = value;
	}

	public void setCreativeAPI(String creativeAPIStr) {
		this.creativeAPI = creativeAPIStr;
	}

	public void setDuration(double value) {
		this.duration = value;
	}

	public void setHeight(int value) {
		this.height = value;
	}

	public void setPreference(int value) {
		this.preference = value;
	}

	public void setWidth(int value) {
		this.width = value;
	}

	public void setWrapperType(String wrapperType) {
		this.wrapperType = wrapperType;
	}

	public String getWrapperType() {
		return wrapperType;
	}

	public void setWrapperURL(String wrapperUrl) {
		this.wrapperUrl = wrapperUrl;
	}

	public String getWrapperURL() {
		return wrapperUrl;
	}

	public int compareTo(CreativeRendition another) {
		if (this.preference > another.preference) {
			return -1;
		} else if (this.preference < another.preference) {
			return 1;
		}
		return 0;
	}

	public int getId() {
		return creativeRenditionId;
	}
	
	public UniversalAdId getUniversalAdId() {
		return universalAdId;
	}
	
	public void setUniversalAdId(UniversalAdId universalAdId) {
		this.universalAdId = universalAdId;
	}
	
	@Override
	public String toString() {
		return String.format("[CreativeRendition hashCode:%s, renditionId:%s, baseUnit:%s, contentType:%s, wrapperType:%s, preference:%s, width:%s, height:%s, " +
				"duration:%s, primaryCreativeRenditionAsset:%s]", hashCode(), creativeRenditionId, baseUnit, contentType, wrapperType, preference, width, height,
				duration, primaryCreativeRenditionAsset);
	}

	public double getBitRate() {
		if (this.getPrimaryCreativRenditionAsset().getBytes() <= 0 || this.getDuration() <= 0) {
			return -1.0;
		}
		return 8.0 * this.getPrimaryCreativRenditionAsset().getBytes() / 1000 / this.getDuration();
	}

	public void addCreativeRenditionAsset(CreativeRenditionAsset asset) {
		if (primaryCreativeRenditionAsset == null) {
			primaryCreativeRenditionAsset = asset;
		} else {
			otherCreativeRenditionAssets.add(asset);
		}
	}

	public void setSimidCreativeUrl(String simidCreativeUrl) {
		this.simidCreativeUrl = simidCreativeUrl;
	}

	public void setSimidVariableDurationAllowed(Boolean simidVariableDurationAllowed) {
		this.simidVariableDurationAllowed = simidVariableDurationAllowed;
	}

	public Boolean getSimidVariableDurationAllowed() {
		return simidVariableDurationAllowed;
	}

	public String getSimidCreativeUrl() {
		return simidCreativeUrl;
	}
}
