package tv.freewheel.ad;

import android.app.Activity;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.handler.ClickCallbackHandler;
import tv.freewheel.ad.handler.EventCallbackHandler;
import tv.freewheel.ad.handler.QuartileCallbackHandler;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ICreativeRendition;
import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IRendererController;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.slot.NonTemporalSlot;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.ad.state.AdFailedState;
import tv.freewheel.ad.state.AdInitState;
import tv.freewheel.ad.state.AdLoadedState;
import tv.freewheel.ad.state.AdState;
import tv.freewheel.ad.state.RendererInitState;
import tv.freewheel.ad.state.RendererState;
import tv.freewheel.renderers.interfaces.IActivityStateChangeCallbackListener;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.interfaces.IRendererContext;
import tv.freewheel.renderers.temporal.CustomPlayer;
import tv.freewheel.renderers.temporal.VPAIDRenderer;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;
import tv.freewheel.utils.events.Event;

public class AdInstance extends EventCallbackHolder implements IAdInstance, IRendererContext, IRendererController {
	private static final Logger logger = Logger.getLogger(AdInstance.class, true);
	public Ad ad;
	public Creative creative;
	public int creativeRenditionId;
	public String replicaId;
	public Slot slot;
	public AdState state;
	public RendererState rendererState;
	public ArrayList<AdInstance> companionAds;
	public IRenderer renderer;
	public CallbackManager callbackManager;
	public boolean isCompanionAdOfPauseAd = false;

	private String originalVastWrapperUrl;

	private int metrValue;
	private int startTimePosition;
	private CreativeRendition primaryCreativeRendition;
	private String additionalErrorInfo = "";
	private AdRenderer adRenderer;
	private ArrayList<IAdInstance> translatedAds;
	private ArrayList<AdInstance> fallbackAds;

	private double duration = -1.;//last duration value of the adInstance
	private boolean resellerNoAdDispatched = false;
	public AdChain adChain;
	public boolean imprSent = false;
	public boolean preInitSent = false;
	public boolean scheduledDrivingAd = false;
	public boolean pauseWhenLoading = false;

	public boolean isSkipped = false;
	private boolean isFallbackAd = false;

	private boolean skippableStateChangedFired = false;

	private List<Extension> extensions;

	public String externalAdId;
	private NodeList icons;

	private String dealId = "";
	private String openExchangeId = "";
	private String marketUnifiedAdId = "";
	private String soAdUnit = "";
	private String action = "";

	private String universalAdId = "";
	private String universalAdIdRegistry = "";

	private int skipOffset;
	private int skipOffsetPercentage;

	private int wrapperCount = 0;

	private TreeMap<Integer, List<String>> progressMap;
	private TreeMap<Integer, List<String>> progressPercentageMap;
	private int lastFiredProgress = -1;

	public AdInstance(final AdContext context) {
		super(context);
		this.state = AdInitState.Instance();
		this.companionAds = new ArrayList<>();
		this.fallbackAds = new ArrayList<>();
		this.adVerifications = new ArrayList<>();
		this.extensions = new ArrayList<>();
		this.metrValue = 0;
		this.startTimePosition = -1;
		this.callbackManager = new CallbackManager(this);
		this.skipOffset = -1;
		this.skipOffsetPercentage = -1;
		this.progressMap = new TreeMap<>();
		this.progressPercentageMap = new TreeMap<>();
	}

	public void parse(Element node) throws IllegalAdResponseException {
		int adId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_REFERENCE_AD_ID));

		int creativeId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_REFERENCE_CREATIVE_ID));

		this.creativeRenditionId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_REFERENCE_RENDITION_ID));

		this.replicaId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_REPLICA_ID);

		this.externalAdId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_EXTERNAL_AD_ID);

		this.dealId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_DEAL_ID);
		this.openExchangeId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_OPEN_EXCHANGE_ID);
		this.marketUnifiedAdId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_MARKET_UNIFIED_AD_ID);

		this.action = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_ACTION);

		this.universalAdId = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_UNIVERSAL_AD_ID);
		this.universalAdIdRegistry = StringUtils.getNodeAttributeValueFromElement(node, InternalConstants.ATTR_AD_REFERENCE_UNIVERSAL_AD_ID_REGISTRY);

		this.ad = this.getAdResponse().getAd(adId, externalAdId);
		if (this.ad == null) {
			throw new IllegalAdResponseException("No ad with adId: " + adId + " and with externalAdId: " + externalAdId + " could be found in the adresponse");
		}

		this.soAdUnit = this.ad.soAdUnit;

		this.creative = this.ad.getCreative(creativeId);
		if (this.creative == null) {
			throw new IllegalAdResponseException("No creative with creativeId: " + creativeId + " can be found in ad with adId: " + adId);
		}

		// set primary creative rendition: if a rendition with a matching renditionId & replicaId exist, set it as primary;
		for (int i = 0; i < creative.creativeRenditions.size(); i++) {
			CreativeRendition iter = creative.creativeRenditions.get(i);
			if (iter.getId() == creativeRenditionId && iter.replicaId != null && iter.replicaId.equals(replicaId)) {
				this.primaryCreativeRendition = iter;
				break;
			}
		}
		// otherwise set the first rendition without adReplicaId as the primary rendition.
		if (primaryCreativeRendition == null) {
			for (int i = 0; i < creative.creativeRenditions.size(); i++) {
				CreativeRendition iter = creative.creativeRenditions.get(i);
				if (iter.replicaId == null || iter.replicaId.isEmpty()) {
					this.primaryCreativeRendition = iter;
					break;
				}
			}
		}

		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_EVENT_CALLBACKS)) {
					this.parseEventCallbacks((Element) childNode);
					this.callbackManager.init();
				} else if (name.equals(InternalConstants.TAG_COMPANION_ADS)) {
					this.parseCompanionAds((Element) childNode);
				} else if (name.equals(InternalConstants.TAG_FALLBACK_ADS)) {
					this.parseFallbackAds((Element) childNode);
				} else if (name.equals(InternalConstants.TAG_EXTENSIONS)) {
					this.parseExtensions((Element) childNode);
				} else {
					logger.warn("parse() ignore node: " + name);
				}
			}
		}
	}

	private void parseExtensions(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseExtensions(), name: " + name);
				if (name.equals(InternalConstants.TAG_EXTENSION)) {
					if (((Element) childNode).getAttribute(InternalConstants.TAG_EXTENSION_KEY).equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_AD_VERIFICATIONS)) {
						String nodeStr = "";
						try {
							nodeStr = XMLHandler.getTextFromNestedCDATA(childNode);
							adVerifications.addAll(StringUtils.parseAdVerifications(XMLHandler.getXMLElementFromString(nodeStr, InternalConstants.OpenMeasurementConstants.TAG_AD_VERIFICATIONS)));
						} catch (Exception e) {
							logger.error("parse adverification from smart xml throws exception with error: " + e.getMessage(), e);
						}
					}
					Extension extension = new Extension();
					extension.parse((Element) childNode, "Freewheel");
					this.extensions.add(extension);
				} else {
					logger.warn("parseExtensions() ignore node: " + name);
				}
			}
		}
	}

	private void parseFallbackAds(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseFallbackAds(), name: " + name);
				if (name.equals(InternalConstants.TAG_AD_REFERENCE)) {
					AdInstance adInstance = new AdInstance(this.context);
					adInstance.slot = this.slot;
					adInstance.isFallbackAd = true;
					/*
					 * We add the fallback adInstance to the fallbackAds list before parsing it to
					 * ensure that any nested fallback ads are added after the parent fallback ad.
					 * This preserves the order of the fallback ads in the adChain.
					 */
					this.fallbackAds.add(adInstance);
					adInstance.parse((Element) childNode);
				} else {
					logger.warn("parseFallbackAds() ignore node: " + name);
				}
			}
		}
	}

	/**
	 * The constructor of AdChain would set "adInstance.adChain" to the constructing object,
	 * therefore, this method also works as a setter for this.adChain
	 *
	 * @return this.adChain
	 */
	public AdChain buildAdChain() {
		AdChain newAdChain = new AdChain(this);
		logger.debug(this + " build add chain " + newAdChain);
		for (AdInstance fallbackAd : this.fallbackAds) {
			newAdChain.append(fallbackAd);
			ArrayList<AdInstance> nested = getNestedFallbackAds(fallbackAd);
			if (nested != null) {
				for (AdInstance nestedFallback : nested) {
					newAdChain.append(nestedFallback);
				}
			}
		}
		this.fallbackAds.clear();
		return newAdChain;
	}

	public ArrayList<AdInstance> getNestedFallbackAds(AdInstance ad) {
		ArrayList<AdInstance> ret = new ArrayList<>();
		for (AdInstance fallbackAd : ad.fallbackAds) {
			ret.add(fallbackAd);
			ret.addAll(getNestedFallbackAds(fallbackAd));
		}
		return ret;
	}

	private void parseCompanionAds(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseCompanionAds(), name: " + name);

				if (name.equals(InternalConstants.TAG_AD_REFERENCE)) {
					AdInstance adInstance = new AdInstance(this.context);
					String slotCustomId = ((Element) childNode).getAttribute(InternalConstants.ATTR_AD_REFERENCE_AD_SLOT_CUSTOM_ID);
					// Get slot from response at first to see if the slot has been added by other companion ads
					NonTemporalSlot companionSlot = (NonTemporalSlot) this.context.getSlotByCustomId(slotCustomId);
					if (companionSlot == null) {
						companionSlot = (NonTemporalSlot) this.context.adRequest.getSlotByCustomId(slotCustomId);
						if (companionSlot != null) {
							companionSlot = companionSlot.copy();
							this.context.adResponse.nonTemporalSlots.add(companionSlot);
						}
					}
					if (companionSlot != null) {
						adInstance.slot = companionSlot;
						adInstance.parse((Element) childNode);
						this.companionAds.add(adInstance);
					}
				} else {
					logger.warn("parseCompanionAds() ignore node: " + name);
				}
			}
		}
	}

	public void play() {
		logger.debug(this + " play()");
		this.adChain.chainBehavior = ChainBehavior.getPlayBehavior();
		this.state.play(this);
	}

	public void stop() {
		logger.debug(this + " stop()");
		this.state.stop(this);
	}

	public CreativeRendition getActiveCreativeRendition() {
		return this.primaryCreativeRendition;
	}

	public boolean isPlayable() {
		boolean ret = true;
		ret = ret && (this.state != AdFailedState.Instance() || this.imprSent);
		if (!ret) {
			logger.debug(this + " isPlayable returning false because adState is " + this.state + " and imprSent is " + imprSent);
			return ret;
		}
		ret = ret && (!this.scheduledDrivingAd || (this.scheduledDrivingAd && this.state == AdLoadedState.Instance()));
		if (!ret) {
			logger.debug(this + " isPlayable returning false becasue scheduledDrivingAd is true");
			return ret;
		}
		logger.debug(this + " isPlayable returning " + ret);
		return ret;
	}

	/**
	 * called before AdPlayingState
	 */
	public void loadRenderer() {
		logger.debug("loadRenderer()");

		if (this.adRenderer == null) {
			this.getAdRenderer();
		}

		if (this.adRenderer != null) {
			this.onRendererModuleLoaded();
		} else {
			String errorInfo = "no renderer matched";
			this.adFailed(Constants._ERROR_NO_RENDERER, errorInfo);
		}
	}

	public void setAdRenderer(AdRenderer adRenderer) {
		this.adRenderer = adRenderer;
	}

	/**
	 * return -1 means no AdRenderer found, 0 means local rendererModule should used,
	 * 1 means AdRenderer found
	 */
	private int getAdRenderer() {
		int ret = -1;
		List<ICreativeRendition> renditions = this.getAllCreativeRenditions();
		for (int i = 0; i < renditions.size(); ++i) {
			ICreativeRendition cr = renditions.get(i);
			String contentType = cr.getContentType();

			if (contentType != null &&
					(contentType.equals("null/null") || contentType.equals("test/ad"))) {
				if (this.adRenderer == null) {
					this.setAdRenderer(new AdRenderer(this.context));
					adRenderer.name = contentType;
				}
				ret = 0;
				break;
			}

			if (this.adRenderer == null) {
				this.setAdRenderer(this.findRenderer(cr.getBaseUnit(), this.ad.soAdUnit, contentType, this.slot.timePositionClass, cr.getCreativeAPI(), cr.getWrapperType()));
			}
			if (this.adRenderer != null) {
				if (cr != this.primaryCreativeRendition) {
					this.setActiveCreativeRendition(cr);
				}
				ret = 1;
				break;
			}
		}
		return ret;
	}

	public void onRendererModuleLoaded() {
		ICreativeRenditionAsset asset = this.primaryCreativeRendition.getPrimaryCreativRenditionAsset();
		if (asset != null) {
			logger.debug("startPlay: " + asset.getURL());
		} else {
			logger.debug("startPlay: no assets");
		}

		try {
			this.renderer = AdRenderer.getRenderer(this.adRenderer);
			// Send preinit after matching renderer but before loading
			if (!preInitSent) {
				this.dispatchAdEvent(Constants._EVENT_AD_PREINIT);
				preInitSent = true;
			}
			if (this.renderer == null) {
				logger.error("can not find a renderer to play");
				this.adFailed(Constants._ERROR_RENDERER_LOAD, this.additionalErrorInfo);
			} else {
				this.rendererState = RendererInitState.Instance();
				this.rendererState.load(this);
			}
		} catch (IllegalAccessException e) {
			logger.error("Renderer loading failed with message: " + e.getMessage(), e);
			this.adFailed(Constants._ERROR_RENDERER_LOAD, e.getMessage());
		} catch (InstantiationException e) {
			logger.error("Renderer loading failed with message: " + e.getMessage(), e);
			this.adFailed(Constants._ERROR_RENDERER_LOAD, e.getMessage());
		}
	}

	public void adFailed(String errorCode, String details) {
		Bundle info = new Bundle();
		info.putString(Constants._INFO_KEY_ERROR_CODE, errorCode);
		info.putString(Constants._INFO_KEY_ERROR_INFO, details);
		info.putString(Constants._INFO_KEY_ERROR_MODULE, (this.adRenderer != null && this.adRenderer.url != null) ? this.adRenderer.url : "unknown");
		this.callbackManager.errorHandler.send(info);
		this.state.fail(this);
	}

	public void onResumePlay() {
		logger.debug("onResumePlay");
		this.callbackManager.resume();
		if (this.rendererState != null) {
			this.rendererState.resume(this);
		}
	}

	public void onPausePlay() {
		logger.debug("onPausePlay");
		this.callbackManager.pause();
		if (this.rendererState != null) {
			this.rendererState.pause(this);
		}
	}

	public void onStopPlay() {
		logger.debug("onStopPlay");
		if (this.rendererState != null) {
			this.rendererState.stop(this);
		}
	}

	public void onRendererLoaded(IEvent event) {
		logger.debug("onRendererLoaded:");
		this.dispatchAdEvent(Constants._EVENT_AD_LOADED);
		this.state.notifyAdLoaded(this);
		this.commitAdInstances();
		if (this.adChain.chainBehavior.isDestState(this.state)) {
			this.slot.notifyAdDone(this);
		} else {
			if (!this.pauseWhenLoading) {
				this.state.play(this);
			} else {
				logger.debug("player pause when loaing, ad pause");
				this.pauseWhenLoading = false;
			}
		}
	}

	public void onRendererStarted(IEvent event) {
		logger.debug(this + " onRendererStarted()");
		this.commitAdInstances();
		// send default impression first.
		if (!this.scheduledDrivingAd) {
			this.callbackManager.sendDefaultImpression();
			this.playCompanionAds();
		}
	}

	public void onRendererStopped(IEvent event) {
		logger.debug("onRendererStopped");
		if (!this.scheduledDrivingAd) {
			this.callbackManager.sendAdImpressionEnd();
		}

		rendererState.dispose(AdInstance.this);
		this.state.complete(this);
	}

	private void sendResellerNoAd(String errorCode) {
		if (errorCode.equals(Constants._ERROR_PARSE) ||
				errorCode.equals(Constants._ERROR_NO_AD_AVAILABLE)) {
			this.callbackManager.callback(Constants._EVENT_RESELLER_NO_AD);
			if (!this.resellerNoAdDispatched) {
				this.resellerNoAdDispatched = true;
				this.dispatchAdEvent(Constants._EVENT_RESELLER_NO_AD);
			}
		}
	}

	private void onRendererError(IEvent event) {
		logger.debug("onRendererError");
		if (this.slot.isPreloading()) {
			logger.debug("The following error occurred during preload: " + event.getData());
			slot.notifyAdDone(this);
			return;
		}
		Bundle info = (Bundle) event.getData().get(Constants._INFO_KEY_EXTRA_INFO);
		this.sendResellerNoAd(info.getString(Constants._INFO_KEY_ERROR_CODE));
		String moduleName;

		if (this.adRenderer != null) {
			moduleName = this.adRenderer.url;
		} else {
			//only for null/null renderer
			moduleName = renderer.getClass().getName();
		}
		info.putString(Constants._INFO_KEY_ERROR_MODULE, moduleName);
		this.callbackManager.errorHandler.send(info);
		rendererState.fail(AdInstance.this);
		state.fail(AdInstance.this);
	}

	private void onRendererClicked(IEvent event) {
		logger.debug("onRendererClicked");
		Bundle info = (Bundle) event.getData().get(Constants._INFO_KEY_EXTRA_INFO);
		if (info == null) {
			info = new Bundle();
		}
		String eventName = info.getString(Constants._INFO_KEY_MESSAGE);
		if (eventName == null || eventName.equals(Constants._EVENT_AD_CLICK)) {
			if (this.callbackManager.defaultClickHandler != null) {
				this.callbackManager.defaultClickHandler.send(info);
			} else {
				logger.warn("no default click callback");
			}
		} else {
			// custom click
			this.callbackManager.callback(eventName, info);
		}
	}

	private AdRenderer findRenderer(String adUnit, String soAdUnit, String contentType, IConstants.TimePositionClass slotType, String creativeAPI, String wrapperType) {
		logger.debug(this + " findRenderer(adUnit:" + adUnit + ",soAdUnit:" + soAdUnit + ",contentType:" + contentType + ",slotType:" + slotType + ",creativeAPI:" + creativeAPI + ",wrapperType:" + wrapperType);

		for (AdRenderer renderer : this.context.adRenderers) {
			if (renderer.match(adUnit, soAdUnit, contentType, Slot.slotTypeString(slotType), creativeAPI, wrapperType)) {
				return renderer;
			}
		}
		return null;
	}

	public List<ICreativeRendition> getAllCreativeRenditions() {
		Collections.sort(this.creative.creativeRenditions);
		ArrayList<ICreativeRendition> renderableRenditionsWithMatchingReplicaId = new ArrayList<>();
		ArrayList<ICreativeRendition> renderableRenditionsWithoutReplicaId = new ArrayList<>();
		for (CreativeRendition cr : creative.creativeRenditions) {
			if (cr.getId() == creativeRenditionId && cr.replicaId != null && cr.replicaId.equals(replicaId)) {
				renderableRenditionsWithMatchingReplicaId.add(cr);
			}
			// shouldn't use `else if`. We need to include renditions with/without a matching rendition id.
			if (cr.replicaId == null || cr.replicaId.isEmpty()) {
				renderableRenditionsWithoutReplicaId.add(cr);
			}
		}

		ArrayList<ICreativeRendition> ret = renderableRenditionsWithMatchingReplicaId.isEmpty() ?
				renderableRenditionsWithoutReplicaId : renderableRenditionsWithMatchingReplicaId;

		if (primaryCreativeRendition != null && ret.remove(primaryCreativeRendition)) {
			ret.add(0, primaryCreativeRendition);
		}
		return ret;
	}

	@Override
	public List<ICreativeRendition> getRenderableCreativeRenditions() {
		ArrayList<ICreativeRendition> ret = new ArrayList<>();
		for (ICreativeRendition cr : getAllCreativeRenditions()) {
			if (this.adRenderer == null || this.adRenderer.match(cr.getBaseUnit(), this.ad.soAdUnit, cr.getContentType(),
					Slot.slotTypeString(this.slot.timePositionClass), cr.getCreativeAPI(), cr.getWrapperType())) {
				ret.add(cr);
			}
		}

		if (this.primaryCreativeRendition != null && ret.remove(this.primaryCreativeRendition)) {
			ret.add(0, this.primaryCreativeRendition);
		}

		return ret;
	}

	@Override
	public IAdInstance getAdInstance() {
		return this;
	}

	public Object getParameter(String name) {
		Object value = null;
		List<Map<String, Object>> paramArray = new ArrayList<>();
		paramArray.add(this.context.adRequest.overrideLevelParameters);


		if (this.primaryCreativeRendition != null) {
			paramArray.add(this.primaryCreativeRendition.parameters);
		}

		if (this.creative != null) {
			paramArray.add(this.creative.parameters);
		}

		if (this.slot != null) {
			paramArray.add(this.slot.parameters);
		}

		paramArray.add(this.context.adResponse.profileParameters);
		paramArray.add(this.context.adRequest.globalLevelParameters);

		if (this.adRenderer != null) {
			paramArray.add(this.adRenderer.parameters);
		}

		for (Map<String, Object> params : paramArray) {
			value = params.get(name);
			if (value != null) {
				break;
			}
		}

		logger.debug("getParameter:" + name + ":" + value);
		return value;
	}

	public ISlot getSlot() {
		return this.slot;
	}

	@Override
	public void setSupportedAdEvent(String adEventName, boolean supported) {
		Integer mask = InternalConstants.METR_MAP.get(adEventName);
		if (mask == null) {
			return;
		}
		if (adEventName.equals(Constants._EVENT_AD_CLICK)) {
			supported = !supported;
		}
		if (supported) {
			this.metrValue |= mask;
		} else {
			this.metrValue &= ~mask;
		}

		logger.debug("setSupportedAdEvent metrValue is " + this.metrValue);
	}

	public void pause() {
		logger.debug("pause");
		this.state.pause(this);
	}

	public void resume() {
		logger.debug("resume");
		this.state.play(this);
	}

	public IConstants getConstants() {
		return this.context.getConstants();
	}

	@Override
	public float getInitialAdVolume() {
		return this.context.getAdVolume();
	}

	public Activity getActivity() {
		return this.context.getActivity();
	}

	public int getVersion() {
		return this.context.version;
	}

	public int getMetrValue() {
		return this.metrValue;
	}

	public void setStartTimePosition(int timePosition) {
		if (timePosition > -1 && timePosition < this.getDuration()) {
			this.startTimePosition = timePosition;
		} else {
			logger.warn("Invalid value for setStartTimePosition");
		}
	}

	public int getStartTimePosition() {
		return this.startTimePosition;
	}

	public double getDuration() {
		if (this.scheduledDrivingAd)
			return 0.;
		double rendererDuration = -1.;
		if (this.renderer != null) {
			final String logMsg = "The renderer has no getDuration implemented.";
			try {
				rendererDuration = renderer.getDuration();
			} catch (NoSuchMethodError err) {
				rendererDuration = -1.;
				logger.warn(logMsg);

			} catch (AbstractMethodError err) {
				rendererDuration = -1.;
				logger.warn(logMsg);
			}
		}
		if (rendererDuration >= 0.) {
			duration = rendererDuration;
			return duration;
		} else if (duration >= 0.)
			return duration;
		else {
			double creativeDuration = -1.;
			if (this.primaryCreativeRendition != null) {
				creativeDuration = this.primaryCreativeRendition.getDuration();
			}
			if (creativeDuration >= 0.) {
				duration = creativeDuration;
				return duration;
			} else
				return 0.;
		}
	}

	public double getPlayheadTime() {
		if (this.scheduledDrivingAd)
			return 0.;
		double rendererPlayheadTime = -1.;
		if (this.renderer != null) {
			final String logMsg = "The renderer has no getPlayheadTime implemented.";
			try {
				rendererPlayheadTime = this.renderer.getPlayheadTime();
			} catch (NoSuchMethodError err) {
				rendererPlayheadTime = -1.;
				logger.warn(logMsg);
			} catch (AbstractMethodError err) {
				rendererPlayheadTime = -1.;
				logger.warn(logMsg);
			}
		}
		if (rendererPlayheadTime >= 0.) {
			return rendererPlayheadTime;
		}
		return 0.;
	}

	public void setActiveCreativeRendition(ICreativeRendition rendition) {
		if (rendition == null) {
			this.primaryCreativeRendition = null;
			return;
		}
		this.primaryCreativeRendition = (CreativeRendition) rendition;
	}

	public ICreativeRendition createCreativeRenditionForTranslation() {
		logger.debug("createCreativeRenditionForTranslation()");

		CreativeRendition ret = this.creative.createCreativeRendition();
		ret.creativeRenditionId = this.creativeRenditionId;
		ret.replicaId = this.replicaId;
		logger.debug("createCreativeRenditionForTranslation(): returning " + ret);
		return ret;
	}

	private void dispatchEvent(IEvent event) {
		if (this.context.getActivity() == null) {
			logger.warn("Activity not registered. Run dispatchEvent on current thread.");
		} else if (Looper.myLooper() != Looper.getMainLooper()) {
			logger.warn("Re-dispatchEvent " + event.getType() + " to main UI thread.");
			final IEvent eventRef = event;
			new Handler(Looper.getMainLooper()).post(new Runnable() {
				public void run() {
					dispatchEvent(eventRef);
				}
			});
			return;
		}
		String eventName = event.getType();
		logger.debug("process ad event:" + eventName);

		if (eventName.equals(Constants._EVENT_AD_LOADED)) {
			this.rendererState.notifyLoaded(this, event);
		} else if (eventName.equals(Constants._EVENT_AD_STARTED)) {
			Bundle info = (Bundle) event.getData().get(Constants._INFO_KEY_EXTRA_INFO);
			if (info != null) {
				this.setStartTimePosition(info.getInt(Constants._INFO_KEY_START_TIME_POSITION, -1));
			}
			this.rendererState.notifyStarted(this, event);
		} else if (eventName.equals(Constants._EVENT_AD_STOPPED)) {
			this.rendererState.notifyStopped(this, event);
		} else if (eventName.equals(Constants._EVENT_ERROR)) {
			this.onRendererError(event);
		} else if (eventName.equals(Constants._EVENT_AD_CLICK)) {
			this.onRendererClicked(event);
			this.dispatchAdEvent(eventName);
		} else if (eventName.equals(Constants._EVENT_AD_BUFFERING_START)
				|| eventName.equals(Constants._EVENT_AD_BUFFERING_END)) {
			// events that should not send callbacks
			this.dispatchAdEvent(eventName);
		} else if (eventName.equals(Constants._EVENT_AD_MEASUREMENT)) {
			Bundle info = (Bundle) event.getData().get(Constants._INFO_KEY_EXTRA_INFO);
			String concreteEventId = (info != null) ? info.getString(Constants._INFO_KEY_CONCRETE_EVENT_ID) : null;
			if (concreteEventId == null || concreteEventId.isEmpty()) {
				concreteEventId = (String) event.getData().get(Constants._INFO_KEY_CONCRETE_EVENT_ID);
				// concreteEventId comes from 1.bundle for key INFO_KEY_EXTRA_INFO;2. string for key INFO_KEY_CONCRETE_EVENT_ID.
				if (concreteEventId == null || concreteEventId.isEmpty()) {
					logger.debug("Processing invalid concrete event id.");
					return;
				} else {
					info = new Bundle();
					info.putString(Constants._INFO_KEY_CONCRETE_EVENT_ID, concreteEventId);
				}
			}
			this.dispatchAdEvent(eventName);
			this.callbackManager.callback(eventName, info);
		} else if (eventName.equals(Constants._EVENT_AD_PROGRESS)) {
			HashMap<String, Object> data = event.getData();
			this.dispatchAdEvent(eventName, data);
			Bundle info = new Bundle();
			info.putString(InternalConstants.TAG_OFFSET, data.get(Constants._INFO_KEY_OFFSET) + "");
			this.callbackManager.callback(eventName, info);
		} else {
			if (eventName.equals(Constants._EVENT_AD_FIRST_QUARTILE)
					|| eventName.equals(Constants._EVENT_AD_MIDPOINT)
					|| eventName.equals(Constants._EVENT_AD_THIRD_QUARTILE)
					|| eventName.equals(Constants._EVENT_AD_COMPLETE)) {
				QuartileCallbackHandler handler = (QuartileCallbackHandler) this.callbackManager.getEventCallbackHandler(eventName, Constants._EVENT_TYPE_IMPRESSION);
				boolean enableCountingReplayCallback = (this.context.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK) != null) ? Boolean.valueOf(this.context.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK).toString()) : false;
				if (!handler.imprSent || enableCountingReplayCallback) {
					this.dispatchAdEvent(eventName);
				}
			} else {
				this.dispatchAdEvent(eventName, event.getData());
			}
			this.callbackManager.callback(eventName);
		}
	}

	public void dispatchEvent(String eventName) {
		logger.debug("dispatchEvent(eventName=" + eventName + ")");
		Event event = new Event(eventName);
		this.dispatchEvent(event);
	}

	public void dispatchEvent(String eventName, HashMap<String, Object> extraInfo) {
		Event event = new Event(eventName);
		event.data = extraInfo;
		this.dispatchEvent(event);
	}

	public void dispatchAdEvent(String eventName) {
		dispatchAdEvent(eventName, null);
	}

	public void dispatchAdEvent(String eventName, HashMap<String, Object> extraInfo) {
		Event event = new Event(eventName);
		event.data.put(Constants._INFO_KEY_AD_ID, this.getAdId());
		event.data.put(Constants._INFO_KEY_CREATIVE_ID, this.creative.creativeId);
		event.data.put(Constants._INFO_KEY_SLOT_CUSTOM_ID, this.slot.customId);
		event.data.put(Constants._INFO_KEY_ADINSTANCE, this);
		if (extraInfo != null && !extraInfo.isEmpty()) {
			event.data.putAll(extraInfo);
		}
		this.context.dispatchEvent(event);
	}

	public void dispatchAdEvent(String eventName, String errorCode, String info, String module) {
		Event event = new Event(eventName);
		event.data.put(Constants._INFO_KEY_AD_ID, this.getAdId());
		event.data.put(Constants._INFO_KEY_CREATIVE_ID, this.creative.creativeId);
		event.data.put(Constants._INFO_KEY_SLOT_CUSTOM_ID, this.slot.customId);
		event.data.put(Constants._INFO_KEY_ADINSTANCE, this);
		event.data.put(Constants._INFO_KEY_ERROR_CODE, errorCode);
		event.data.put(Constants._INFO_KEY_ERROR_INFO, info);
		event.data.put(Constants._INFO_KEY_ERROR_MODULE, module);
		this.context.dispatchEvent(event);
	}

	public int getAdId() {
		return this.ad.adId;
	}

	public List<AdVerification> getAdVerifications() {
		return adVerifications;
	}

	private List<AdVerification> adVerifications;

	@Override
	public UniversalAdId getUniversalAdId() {
		if (this.universalAdId != "") {
			return new UniversalAdId(this.universalAdIdRegistry, universalAdId);
		}
		CreativeRendition creativeRendition = getActiveCreativeRendition();
		return creativeRendition == null ? null : creativeRendition.getUniversalAdId();
	}

	@Override
	public String getExternalAdId() {
		return this.externalAdId;
	}

	public void incrementWrapperCount() {
		wrapperCount++;
	}

	public int getWrapperCount() {
		return wrapperCount;
	}

	public void setOriginalVastWrapperURL(String vastUrl) {
		this.originalVastWrapperUrl = vastUrl;
	}

	public String getOriginalVastWrapperURL() {
		return originalVastWrapperUrl;
	}

	@Override
	public String getAdUniqueId() {
		return getAdId() + (StringUtils.isBlank(this.externalAdId) ? "" : ("_" + this.externalAdId));
	}

	protected final Handler rendererLoadHandler = new Handler(this.getActivity().getMainLooper()) {
		public void handleMessage(final Message msg) {
			String returnCode = msg.getData().getString("CODE");
			String message = msg.getData().getString("MSG");
			logger.debug("renderer load complete code:" + returnCode + " msg:" + message);
			if (returnCode.equals("ERROR")) {
				additionalErrorInfo = message;
			}
			state.notifyRendererModuleLoaded(AdInstance.this);
		}
	};

	public Location getLocation() {
		return this.context.geoLocation;
	}

	public List<ISlot> getCompanionSlots() {
		ArrayList<ISlot> ret = new ArrayList<ISlot>();
		for (int i = 0; i < this.companionAds.size(); i++) {
			AdInstance adInstance = this.companionAds.get(i);
			if (adInstance.ad.noLoad) {
				ret.add(adInstance.slot);
			}
		}
		logger.debug("getCompanionSlots(" + ret + ")");
		return ret;
	}

	@Override
	public void addOnActivityStateChangedListener(IActivityStateChangeCallbackListener activityStateChangeCallbackListener) {
		this.context.addOnActivityStateChangeCallbackListener(activityStateChangeCallbackListener);
	}

	public IAdInstance cloneForTranslation() {
		logger.debug("cloneForTranslation()");
		AdInstance ret = new AdInstance(this.context);
		ret.originalVastWrapperUrl = this.originalVastWrapperUrl;
		ret.ad = this.ad.cloneForTranslation();
		ret.creative = this.creative.cloneForTranslation();
		ret.creativeRenditionId = this.primaryCreativeRendition != null ?
				this.primaryCreativeRendition.creativeRenditionId : this.creativeRenditionId;
		ret.replicaId = this.replicaId;
		ret.slot = this.slot;
		ret.externalAdId = this.externalAdId;
		ret.dealId = this.dealId;
		ret.openExchangeId = this.openExchangeId;
		ret.marketUnifiedAdId = this.marketUnifiedAdId;
		ret.wrapperCount = this.wrapperCount;
		ret.action = this.action;
		ret.eventCallbacks.clear();
		for (EventCallback eventCallback : this.eventCallbacks) {
			ret.eventCallbacks.add(eventCallback.cloneForTranslation());
		}
		ret.callbackManager.copyOtherHandlers(this.callbackManager);
		ret.adVerifications.addAll((Collection<? extends AdVerification>) ((ArrayList) adVerifications).clone());
		ret.extensions.addAll((Collection<? extends Extension>) ((ArrayList) extensions).clone());
		ret.skipOffset = this.skipOffset;
		ret.progressMap = this.progressMap;
		ret.progressPercentageMap = this.progressPercentageMap;
		ret.lastFiredProgress = this.lastFiredProgress;
		ret.isFallbackAd = this.isFallbackAd;
		return ret;
	}

	public boolean getAdSkippableState() {
		logger.debug("getAdSkippableState()");
		if (this.adRenderer.url.equals("class://tv.freewheel.renderers.temporal.VPAIDRenderer")) {
			return ((VPAIDRenderer) this.renderer).getAdSkippableState();
		}
		if (this.skipOffset == - 1) return false;
		return this.getPlayheadTime() >= this.skipOffset;
	}

	public void addProgressEventCallbackUrls(int offset, List<String> urls) {
		if (!progressMap.containsKey(offset)) {
			progressMap.put(offset, urls);
		} else {
			progressMap.get(offset).addAll(urls);
		}
	}

	public void addProgressEventCallbackUrls(String offsetString, String url) {
		if (offsetString.endsWith("%")) {
			Integer offsetPercentageInteger = StringUtils.validPercentageOffset(offsetString);
			if (offsetPercentageInteger != null) {
				int offsetPercentage = offsetPercentageInteger.intValue();
				if (!progressPercentageMap.containsKey(offsetPercentage)) {
					progressPercentageMap.put(offsetPercentage, new ArrayList<>());
				}
				progressPercentageMap.get(offsetPercentage).add(url);
			}
		} else {
			Integer offsetInteger = StringUtils.validSecondOffset(offsetString);
			if (offsetInteger != null) {
				int offset = offsetInteger.intValue();
				if (!progressMap.containsKey(offset)) {
					progressMap.put(offset, new ArrayList<>());
				}
				progressMap.get(offset).add(url);
			}
		}
	}

	public TreeMap<Integer, List<String>> getProgressPercentageEventCallbackURLs() {
		return this.progressPercentageMap;
	}

	public TreeMap<Integer, List<String>> getProgressEventCallbackURLs() {
		return this.progressMap;
	}

	public void addEventCallbackURLs(String eventName, String eventType, final List<String> urls) {
		logger.debug("eventName:" + eventName + " eventType:" + eventType + " " + urls);
		List<String> errors = EventCallback.validate(eventName, eventType, urls);
		if (errors.isEmpty()) {
			if (eventType.equals(Constants._EVENT_TYPE_CLICK_TRACKING)) {
				eventType = Constants._EVENT_TYPE_CLICK;
			}
			EventCallbackHandler handler = this.callbackManager.getEventCallbackHandler(eventName, eventType);
			handler.addExternalTrackingURLs(urls);
		} else {
			logger.error(errors.toString());
		}
	}

	public List<String> getEventCallbackURLs(String eventName, String eventType) {
		logger.debug("getEventCallbackURLs(" + eventName + "," + eventType + ")");
		ArrayList<String> ret = new ArrayList<>();
		EventCallbackHandler handler = this.callbackManager.getEventCallbackHandler(eventName, eventType);
		if (handler != null) {
			if (eventType.equals(InternalConstants.EVENT_TYPE_ERROR)) {
				ret.add(handler.getInternalUrl());
			} else if (eventType.equals(Constants._EVENT_TYPE_CLICK)) {
				if (this.callbackManager.defaultClickHandler.isShowBrowser()) {
					ret.add(handler.getInternalUrl());
				}
			} else if (eventType.equals(Constants._EVENT_TYPE_CLICK_TRACKING)) {
				if (!this.callbackManager.defaultClickHandler.isShowBrowser()) {
					ret.add(handler.getInternalUrl());
				}
				ret.addAll(handler.getTrackingURLs());
			} else {
				ret.add(handler.getInternalUrl());
				ret.addAll(handler.getTrackingURLs());
			}
		} else {
			logger.warn("getEventCallbackURLs: failed to get event callback handler!");
		}
		logger.debug("getEventCallbackURLs() Returning " + ret);
		return ret;
	}

	public void setClickThroughURL(String url, String clickName) {
		logger.debug("setClickThroughURL(" + url + "," + clickName + ")");
		if (clickName == null || clickName.equals("")) {
			clickName = Constants._EVENT_AD_CLICK;
		}
		EventCallback evtCbk = this.fetchEventCallback(clickName, Constants._EVENT_TYPE_CLICK, true);

		ClickCallbackHandler handler =
				(ClickCallbackHandler) this.callbackManager.getEventCallbackHandler(clickName, Constants._EVENT_TYPE_CLICK);
		if (handler != null) {
			handler.setShowBrowserValue(true);
			handler.setParameter(InternalConstants.URL_PARAMETER_KEY_CR, url);
		} else {
			if (evtCbk != null) {
				if (evtCbk.type.equals(InternalConstants.EVENT_TYPE_GENERIC)) {
					EventCallback newClickCbk = evtCbk.cloneForTranslation();
					newClickCbk.type = Constants._EVENT_TYPE_CLICK;
					newClickCbk.name = clickName;
					newClickCbk.showBrowser = true;
					this.eventCallbacks.add(newClickCbk);
				} else {
					evtCbk.showBrowser = true;
				}
				handler = (ClickCallbackHandler) this.createEventHandler(clickName, Constants._EVENT_TYPE_CLICK, true);
				handler.setParameter(InternalConstants.URL_PARAMETER_KEY_CR, url);
				this.callbackManager.addEventCallbackHandler(clickName, Constants._EVENT_TYPE_CLICK, handler);
			} else {
				// This shouldn't ever happen.
				logger.warn("Failed to find generic callback for template.");
			}
		}
	}

	public List<IAdInstance> scheduleAdInstances(List<ISlot> slots) {
		logger.debug("scheduleAdInstances(" + slots + ")");
		this.translatedAds = new ArrayList<>();
		for (int i = 0; i < slots.size(); i++) {
			ISlot currentSlot = slots.get(i);
			if (this.slot == currentSlot) {
				translatedAds.add(this.cloneForTranslation());
			} else {
				for (int j = 0; j < this.companionAds.size(); j++) {
					AdInstance companionAd = this.companionAds.get(j);
					if (currentSlot == companionAd.getSlot() && companionAd.ad.noLoad) {
						translatedAds.add(companionAd.cloneForTranslation());
					}
				}
			}
			if (translatedAds.size() <= i) {
				logger.error(this + ".scheduleAd: bad slot: " + currentSlot.getCustomId());
				translatedAds.add(null);
			}
		}
		logger.debug("scheduleAdInstances(): returning " + translatedAds);
		return translatedAds;
	}

	private void commitAdInstances() {
		logger.debug(this + " commitAdInstances()");

		if (this.translatedAds == null || this.translatedAds.isEmpty()) {
			logger.debug(this + "commitAdInstances() nothing to commit, translatedAds is empty.");
			return;
		}
		AdInstance translatedDriver = null;
		Iterator<IAdInstance> iter;
		boolean isTranslator = this.adRenderer.isTranslator();
		// if is translator, commit driving ad
		if (isTranslator) {
			for (IAdInstance adInstance : this.translatedAds) {
				if (adInstance.getSlot() == this.getSlot()) {
					logger.debug("committing driving ad " + ad);
					this.adChain.insertAfter((AdInstance) adInstance, this);
					translatedDriver = (AdInstance) adInstance;
					this.scheduledDrivingAd = true;
					break;
				}
			}
		}

		if (translatedDriver == null) {
			// if it is a translator, then driving ad is missing.
			if (this.adRenderer.isTranslator()) {
				AdInstance emptyDrivingAd = (AdInstance) this.cloneForTranslation();
				CreativeRendition emptyRendition = (CreativeRendition) emptyDrivingAd.createCreativeRenditionForTranslation();
				emptyRendition.setContentType("null/null");
				emptyDrivingAd.primaryCreativeRendition = emptyRendition;
				this.adChain.insertAfter(emptyDrivingAd, this);
				translatedDriver = emptyDrivingAd;
				this.scheduledDrivingAd = true;
				logger.debug("committing empty driving ad " + emptyDrivingAd.ad.noLoad);
			}
			// if it is a hybrid renderer, simply assign this to translatedDriver
			else {
				translatedDriver = this;
			}
		}

		// commit translated companion ads
		iter = this.translatedAds.iterator();
		while (iter.hasNext()) {
			AdInstance companionAd = (AdInstance) iter.next();
			if (translatedDriver != companionAd) {
				if (companionAd.slot.getSlotType() != IConstants.SlotType.TEMPORAL) {
					logger.debug("commitAdInstances: committing companion ad: " + companionAd);
					if (companionAd.getAllCreativeRenditions().isEmpty())
						companionAd.ad.noLoad = true;
					translatedDriver.companionAds.add(companionAd);
				} else {
					logger.error("commitAdInstances: got a translated ad which is neither driving nor nontemporal.");
				}
			}
		}
		// carry on the companion ads that are not scheduled
		for (int i = 0; i < this.companionAds.size(); i++) {
			AdInstance companionAd = this.companionAds.get(i);
			if (!this.containsAd(translatedDriver.companionAds, companionAd)) {
				translatedDriver.companionAds.add(companionAd);
			}
		}
		this.translatedAds = null;
	}

	private boolean containsAd(ArrayList<AdInstance> adInstances, AdInstance adInstance) {
		for (int i = 0; i < adInstances.size(); i++) {
			if (adInstance.getAdId() == adInstances.get(i).getAdId()) {
				return true;
			}
		}
		return false;
	}

	private void playCompanionAds() {
		logger.debug(this + " playCompanionAds()");
		for (int i = 0; i < this.companionAds.size(); i++) {
			AdInstance adInstance = this.companionAds.get(i);
			adInstance.isCompanionAdOfPauseAd = this.slot.isPauseMidroll();
			if (!adInstance.ad.noLoad) {
				((NonTemporalSlot) adInstance.slot).playCompanionAdInstance(adInstance);
			}
		}
	}

	@Override
	public String toString() {
		return String.format("[AdInst hashCode:%s adId:%s, creativeId:%s, creativeRenditionId:%s, replicaId:%s, adState:%s, primaryCreativeRendition:%s]", this.hashCode(), this.getAdId(), this.creative.creativeId, this.creativeRenditionId, this.replicaId, this.state, this.primaryCreativeRendition);
	}

	@Override
	public IRendererController getRendererController() {
		return this;
	}

	@Override
	public void processEvent(String type) {
		logger.debug("processEvent(type=" + type + ")");
		if (type.equals(Constants._EVENT_AD_CLICK)) {
			this.dispatchEvent(type);
		}
	}

	@Override
	public void processEvent(String type, HashMap<String, Object> extraInfo) {
		logger.debug("processEvent(type=" + type + "," + extraInfo.toString() + ")");
		if (type.equals(Constants._EVENT_AD_MEASUREMENT)) {
			this.dispatchEvent(type, extraInfo);
		}
	}

	public void processSimidError(String errorCode) {
		logger.debug("processSimidError errorCode: " + errorCode);
		Bundle info = new Bundle();
		info.putString(Constants._INFO_KEY_VAST_ERROR_CODE, errorCode);
		this.callbackManager.errorHandler.sendTrackingUrlWithoutFWError(info);
	}

	public void preload() {
		logger.debug(this + " preload()");
		this.adChain.chainBehavior = ChainBehavior.getPreloadBehavior();
		this.state.load(this);
	}

	public void onStartPlay() {
		logger.debug("onStartPlay()");
		skippableStateChangedFired = false;
		this.rendererState.start(this);
	}

	public List<IAdInstance> getCompanionAdInstances() {
		ArrayList<IAdInstance> ret = new ArrayList<>();
		for (AdInstance companionAd : this.companionAds) {
			if (!companionAd.ad.noLoad) {
				ret.add(companionAd);
			}
		}
		logger.debug(this + " getCompanionAdInstances() " + ret);
		return ret;
	}

	public boolean isRequiredToShow() {
		return this.ad.isRequiredToShow;
	}

	/**
	 * Set ad volume on the ad instance
	 *
	 * @param value volume to be set. value is expected to be in the range of [0,1]
	 */
	void setAdVolume(float value) {
		logger.debug("setAdVolume(): " + value);
		if (this.renderer != null) {
			this.renderer.setVolume(value);
		}
	}

	public void addEventCallback(String eventType, String eventName, String url, int adId) {
		logger.debug("AddEventCallback(): type: " + eventType + "  name: " + eventName + "  url: " + url);
		if (eventType == null || eventName == null || url == null) {
			logger.debug("Invalid input with null argument. Return.");
			return;
		}

		EventCallback callback = fetchEventCallback(eventName, eventType, false);

		if (callback == null) {
			logger.debug("Existing callback not found. Creating new callback.");

			callback = new EventCallback(getAdContext(), eventName, eventType, null, null, false, null);
			if (eventName.equals(getConstants().EVENT_AD_CLICK()) && url.contains(InternalConstants.URL_PARAMETER_KEY_CR+"=") && !url.endsWith(InternalConstants.URL_PARAMETER_KEY_CR+"=")) {
				callback.showBrowser = true;
			}
			eventCallbacks.add(callback);
		}
		if (StringUtils.isBlank(callback.url) && url.contains("adid=" + adId)) {
			callback.url = url;
		} else {
			callback.trackingURLs.add(url);
		}
	}

	@Override
	public void requestTimelinePause() {
		this.context.requestTimelineToPauseBySlot(this.slot);
	}

	@Override
	public void requestTimelineResume() {
		this.context.requestTimelineToResumeBySlot(this.slot);
	}

	public void addExtensions(List<Extension> extensions) {
		this.extensions.addAll(extensions);
	}

	public String getDealId() {
		return this.dealId;
	}

	public String getOpenExchangeId() {
		return this.openExchangeId;
	}

	public String getMarketUnifiedAdId() {
		return this.marketUnifiedAdId;
	}

	public String getSoAdUnit() { return this.soAdUnit; }

	public String getAction() {
		return this.action;
	}

	public int getSkipOffset() {
		return this.skipOffset;
	}

	public void resetSkipOffset() {
		this.skipOffset = -1;
	}

	public int getSkipOffsetPercentage() {
		return this.skipOffsetPercentage;
	}

	public void setSkipOffsetPercentage(String input) {
		logger.debug("setSkipOffsetPercentage with: " + input);
		Integer skipOffsetInteger = StringUtils.validPercentageOffset(input);
		if (skipOffsetInteger != null) {
			this.skipOffsetPercentage = skipOffsetInteger;
		}
	}

	public void setSkipOffsetUsingPercentageAndDuration() {
		logger.debug("setSkipOffsetUsingPercentageAndDuration with skipOffsetPercentage: " + skipOffsetPercentage + " , duration: " + this.getDuration());
		this.skipOffset = StringUtils.offsetPercentageToSecond(skipOffsetPercentage, this.getDuration());
	}

	public void setSkipOffsetInSecond(String input) {
		logger.debug("setSkipOffsetInSecond with: " + input);
		Integer skipOffsetInteger = StringUtils.validSecondOffset(input);
		if (skipOffsetInteger != null) {
			this.skipOffset = skipOffsetInteger;
		}
	}

	public void processSkippableStateChangedEvent(double playhead) {
		if (this.getSkipOffset() != -1 && playhead >= this.getSkipOffset() && !skippableStateChangedFired) {
			HashMap<String, Object> data = new HashMap<>();
			data.put(Constants._INFO_KEY_AD_SKIPPABLE_STATE, true);
			this.dispatchEvent(Constants._EVENT_AD_SKIPPABLE_STATE_CHANGED, data);
			skippableStateChangedFired = true;
		}
	}


	public void sendProgress(double playhead) {
		while (playhead > lastFiredProgress && progressMap.higherKey(lastFiredProgress) != null && playhead >= progressMap.higherKey(lastFiredProgress)) {
			int key = progressMap.higherKey(lastFiredProgress);
			logger.debug("sendProgress with offset: " + key);
			HashMap<String, Object> data = new HashMap<String, Object>();
			data.put(Constants._INFO_KEY_OFFSET, key);
			dispatchEvent(Constants._EVENT_AD_PROGRESS, data);
			lastFiredProgress = key;
		}
	}

	public void adjustOffsetWithRendererDuration() {
		// skip offset
		if (skipOffset == -1 && skipOffsetPercentage != -1) {
			setSkipOffsetUsingPercentageAndDuration();
		}

		// progress offset
		if (!progressPercentageMap.isEmpty()) {
			for (Map.Entry<Integer, List<String>> entry : progressPercentageMap.entrySet()) {
				addProgressEventCallbackUrls((int) (entry.getKey() * getDuration() / 100), entry.getValue());
			}
		}
	}

	public void setLastFiredProgress(int value) {
		lastFiredProgress = value;
	}

	public CustomPlayer getCustomPlayer(){
		return ((AdContext)this.getAdContext()).getCustomPlayer();
	}

	public boolean isFallbackAd(){
		return this.isFallbackAd;
	}

	public NodeList getIcons() { return this.icons; }

	public void setIcons(NodeList icons) {
		this.icons = icons;
	}

	public List<Extension> getAllExtensions() { return this.extensions; }

	public List<Extension> getExtensionsByType(String type) {
		ArrayList<Extension> ret = new ArrayList<>();
		for (Extension extension : extensions) {
			if (type == null) {
				if (extension.getType() == null) {
					ret.add(extension);
				}
			} else if (type.equals(extension.getType())) {
				ret.add(extension);
			}
		}

		if (ret.isEmpty()) { logger.warn("No extensions found for type or key: " + type); }

		return ret;
	}
}
