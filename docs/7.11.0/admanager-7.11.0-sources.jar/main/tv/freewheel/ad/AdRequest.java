package tv.freewheel.ad;

import android.text.TextUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.ad.slot.NonTemporalSlot;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.ad.slot.TemporalSlot;
import tv.freewheel.ad.state.VideoPendingState;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.URLLoader;
import tv.freewheel.utils.URLRequest;
import tv.freewheel.utils.XMLElement;
import tv.freewheel.utils.XMLHandler;


public class AdRequest extends AdContextScoped implements XMLObject {

	private static final Logger logger = Logger.getLogger(AdRequest.class);
	private String requestMode = "";
	private double requestDuration;

	private int	subsessionToken = 0;

	private String ssId;
	private String ssCustomId;
	private int ssPageViewRandom;
	private int ssNetworkId;
	private String ssFallbackId;
	private String vaId;
	private String vaCustomId;
	private String vaDurationType = "";
	private double vaDuration;
	private IConstants.VideoAssetAutoPlayType vaAutoPlayType = IConstants.VideoAssetAutoPlayType.ATTENDED;
	private double vaVideoAssetCurrentTimePosition;
	protected String vaMediaLocation;
	private int vaVideoPlayRandom;
	private int vaNetworkId;
	private String vaFallbackId;
	private int vaWindowStartTime;
	private TreeMap<String, TreeSet<String>> keyValues;
	protected ArrayList<TemporalSlot> temporalSlots;
	protected ArrayList<NonTemporalSlot> nonTemporalSlots;
	protected boolean videoViewCallbackRequested = false;
	public Map<String, Object> globalLevelParameters;
	public Map<String, Object> overrideLevelParameters;
	private IEventListener videoViewTestListener = null;

	public AdRequest(final AdContext context) {
		super(context);
		this.keyValues = new TreeMap<>();
		this.temporalSlots = new ArrayList<>();
		this.nonTemporalSlots = new ArrayList<>();
		this.globalLevelParameters = new HashMap<>();
		this.overrideLevelParameters = new HashMap<>();
	}

	public void setAdRequest(final AdRequest request) {
		this.requestMode = request.requestMode;
		this.requestDuration = request.requestDuration;
		this.subsessionToken = request.subsessionToken;

		this.ssId = request.ssId;
		this.ssCustomId = request.ssCustomId;
		this.ssPageViewRandom = request.ssPageViewRandom;
		this.ssNetworkId = request.ssNetworkId;
		this.ssFallbackId = request.ssFallbackId;

		this.vaId = request.vaId;
		this.vaCustomId = request.vaCustomId;
		this.vaFallbackId = request.vaFallbackId;
		this.vaMediaLocation = request.vaMediaLocation;
		this.vaDuration = request.vaDuration;
		this.vaNetworkId = request.vaNetworkId;
		this.vaVideoPlayRandom = request.vaVideoPlayRandom;
		this.vaAutoPlayType = request.vaAutoPlayType;
		this.vaDurationType = request.vaDurationType;
		this.vaVideoAssetCurrentTimePosition = request.vaVideoAssetCurrentTimePosition;
		this.videoViewCallbackRequested = request.videoViewCallbackRequested;
	}

	public void addKeyValue(String key, String value) {
		if (StringUtils.isBlank(key) || value == null) {
			return;
		}
		TreeSet<String> values = this.keyValues.get(key);
		if (values == null) {
			values = new TreeSet<>();
			this.keyValues.put(key, values);
		}
		values.add(value);
	}

	public void removeKey(String key) {
		if (StringUtils.isBlank(key)) {
			return;
		}
		this.keyValues.remove(key);
	}

	String[] valuesForKey(String key) {
		if (key == null || key.trim().length() == 0) {
			return null;
		}

		TreeSet<String> strings = this.keyValues.get(key);

		if (strings == null || strings.isEmpty()) {
			return null;
		}

		return strings.toArray(new String[strings.size()]);
	}

	public int getSubsessionToken() {
		return subsessionToken;
	}

	public void setSiteSection(String id, int pageViewRandom, int networkId, IConstants.IdType idType, String fallbackId) {
		this.ssId = this.getFWId(id, idType);
		this.ssCustomId = this.getCustomId(id, idType);
		this.ssPageViewRandom = pageViewRandom;
		this.ssNetworkId = networkId;
		this.ssFallbackId = fallbackId;
	}

	public void setVideoAsset(String videoAssetId, double duration,
							  String location, int videoPlayRandom,
							  int networkId, IConstants.IdType idType, String fallbackId, IConstants.VideoAssetDurationType durationType, IConstants.VideoAssetAutoPlayType autoPlayType, int windowStartTime){
		String oldVaId = this.vaId;
		String oldVaCustomId = this.vaCustomId;

		this.vaId = this.getFWId(videoAssetId, idType);
		this.vaCustomId = this.getCustomId(videoAssetId, idType);

		this.vaDuration = duration > 0 ? duration : 0;
		this.vaMediaLocation = location;
		this.vaVideoPlayRandom = videoPlayRandom;
		this.vaNetworkId = networkId;
		this.vaFallbackId = fallbackId;
		switch(durationType){
			case VARIABLE:
				this.vaDurationType = InternalConstants.VIDEO_ASSET_DURATION_TYPE_VARIABLE;
				break;
			case EXACT:
				this.vaDurationType = InternalConstants.VIDEO_ASSET_DURATION_TYPE_EXACT;
				break;
			default:
				break;
		}
		this.vaAutoPlayType = autoPlayType;
		this.vaWindowStartTime = windowStartTime;
		if((this.vaId != null && !this.vaId.equals(oldVaId)) ||
		   (this.vaCustomId != null && !this.vaCustomId.equals(oldVaCustomId))){
			if (oldVaId == null && oldVaCustomId == null && (this.context.adResponse.videoAsset.state == VideoPendingState.Instance())) {
				// the case before setVideoAsset, play set VideoState to Playing
				this.context.adResponse.videoAsset.play();
			} else {
				this.context.adResponse.onVideoAssetChanged();
				this.vaVideoAssetCurrentTimePosition = 0.0;
			}
		}
	}

	public void setVideoAssetCurrentTimePosition(double timePosition){
		this.vaVideoAssetCurrentTimePosition = timePosition>0.0?timePosition:0.0;
	}

	public void setRequestMode(IConstants.RequestMode requestMode){
		logger.debug("setRequestMode:" + requestMode.mode + ", " + this.subsessionToken);
		switch(requestMode){
			case LIVE:
				this.requestMode = InternalConstants.REQUEST_MODE_LIVE;
				if(this.subsessionToken <= 0) {
					this.startSubsession((int)(Math.random() * 10000 + 1));
				}
				break;
			case ON_DEMAND:
				this.requestMode = InternalConstants.REQUEST_MODE_ON_DEMAND;
				break;
		}
	}

	public String getRequestMode(){
		return this.requestMode;
	}

	public void setRequestDuration(double requestDuration){
		this.requestDuration = requestDuration>0.0?requestDuration:0.0;
	}

	public void startSubsession(int subsessionToken){
		logger.debug("startSubsession:" + subsessionToken);
		if(subsessionToken<=0){
			logger.error("Can not set non-positive subsession token :"	+ subsessionToken);
			return;
		}
		this.subsessionToken = subsessionToken;
		this.context.capabilities.setCapability(Constants._CAPABILITY_SYNC_MULTI_REQUESTS, IConstants.CapabilityStatus.ON);
	}

	public void addTemporalSlot(String customId, String adUnit, double timePosition, String slotProfile, int cuePointSequence, double maxDuration, String acceptPrimaryContentType, String acceptContentType, double minDuration, int maxAds, String signalId, int breakSequence) {
		if (StringUtils.isBlank(customId) || this.isSlotDuplicate(customId)) {
			return;
		}
		if (maxDuration < 0) {
			maxDuration = 0;
		}
		if (minDuration < 0) {
			minDuration = 0;
		}
		TemporalSlot slot = new TemporalSlot(this.context, IConstants.SlotType.TEMPORAL);
		slot.init(customId, adUnit, timePosition, slotProfile, cuePointSequence, maxDuration, acceptPrimaryContentType, acceptContentType, minDuration, maxAds);
		slot.signalId = signalId;
		slot.breakSequence = breakSequence;
		this.temporalSlots.add(slot);
	}

	public void addSiteSectionNonTemporalSlot(String customId, String adUnit, int width, int height, String slotProfile, boolean acceptCompanion, String acceptPrimaryContentType, String acceptContentType, IConstants.SlotInitialAdOption initialAdOption, String compatibleDimensions) {
		this.addNonTemporalSlot(IConstants.SlotType.NON_TEMPORAL, customId, adUnit, width, height, slotProfile, acceptCompanion, acceptPrimaryContentType, acceptContentType, initialAdOption, compatibleDimensions);
	}

	public Slot getSlotByCustomId(String customId) {
		Iterator<TemporalSlot> iter = this.temporalSlots.iterator();
		while (iter.hasNext()) {
			Slot slot = (Slot) iter.next();
			if (customId.equals(slot.customId)) {
				return slot;
			}
		}

		Iterator<NonTemporalSlot> iter2 = this.nonTemporalSlots.iterator();
		while (iter2.hasNext()) {
			Slot slot = (Slot) iter2.next();
			if (customId.equals(slot.customId)) {
				return slot;
			}
		}

		return null;
	}

	private void addNonTemporalSlot(IConstants.SlotType type, String customId, String adUnit, int width, int height, String slotProfile, boolean acceptCompanion, String acceptPrimaryContentType, String acceptContentType, IConstants.SlotInitialAdOption initialAdOption, String compatibleDimensions) {
		if (customId == null || customId.trim().length() == 0 || this.isSlotDuplicate(customId)) {
			return;
		}
		NonTemporalSlot slot = new NonTemporalSlot(this.context, type);
		slot.init(customId, width, height, slotProfile, adUnit, acceptCompanion, acceptPrimaryContentType, acceptContentType, initialAdOption, compatibleDimensions);
		this.nonTemporalSlots.add(slot);
	}

	private String getFWId(String id, IConstants.IdType idType) {
		if (id == null || id.trim().length() == 0) {
			return null;
		}
		if (idType == Constants.IdType.FREEWHEEL_GROUP) {
			return "g" + id;
		}
		if (idType == Constants.IdType.FREEWHEEL) {
			return id;
		}
		return null;
	}

	private String getCustomId(String id, IConstants.IdType idType) {
		if (id == null || id.trim().length() == 0) {
			return null;
		}
		if (idType == Constants.IdType.CUSTOM) {
			return id;
		}
		return null;
	}

	private boolean isSlotDuplicate(String customId) {
		Iterator<TemporalSlot> iter = this.temporalSlots.iterator();
		while (iter.hasNext()) {
			if (customId.equals(iter.next().customId)) {
				return true;
			}
		}

		Iterator<NonTemporalSlot> iter2 = this.nonTemporalSlots.iterator();
		while (iter2.hasNext()) {
			if (customId.equals(iter2.next().customId)) {
				return true;
			}
		}

		return false;
	}

	public String toXML() throws IllegalArgumentException, IllegalStateException, IOException{
		return XMLHandler.createXMLDocument(this.buildXMLElement());
	}

	public String toTypeBUrl(String overriddenServerUrl, boolean ignoreSlotQuery, HashMap additionalParameters){
		ArrayList<Slot> slotList = new ArrayList<>();
		if (!ignoreSlotQuery) {
			slotList.addAll(this.temporalSlots);
			slotList.addAll(this.nonTemporalSlots);
		}
		String slotsString = "";
		for(Slot slot : slotList){
			slotsString += slot.toTypeBString() + ";";
		}

		String keyValuesString = this.toKeyValuesStringForTypeBRequest();
		String serverUrl = "";
		if (overriddenServerUrl != null && !overriddenServerUrl.isEmpty()) {
			serverUrl = overriddenServerUrl;
		} else {
			serverUrl = this.getAdContext().getServerUrl().substring(0, this.getAdContext().getServerUrl().indexOf("ad/p/1")) + "ad/g/1";
		}
		return serverUrl + "?" + this.toGlobalParametersStringForTypeBRequest(additionalParameters) + ";" + keyValuesString + ";" + slotsString;
	}

	private String toGlobalParametersStringForTypeBRequest(HashMap<String, String> additionalGlobalParameters) {
		HashMap<String, String> globalParametersMap = new HashMap<>();
		CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_NETWORK_ID, this.context.networkId);
		CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_PROFILE, this.context.playerProfile);
		CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_RESPONSE_TYPE, "smrx");
		if (this.subsessionToken > 0) {
			CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_SUBSESSION_TOKEN, this.subsessionToken);
		}
		if (this.requestMode != null && this.requestMode.length() != 0) {
			switch (this.requestMode) {
				case InternalConstants.REQUEST_MODE_ON_DEMAND:
					globalParametersMap.put(InternalConstants.URL_PARAMETER_KEY_REQUEST_MODE, InternalConstants.URL_PARAMETER_VALUE_REQUEST_MODE_VOD);
					break;
				case InternalConstants.REQUEST_MODE_LIVE:
					globalParametersMap.put(InternalConstants.URL_PARAMETER_KEY_REQUEST_MODE, InternalConstants.URL_PARAMETER_VALUE_REQUEST_MODE_LIVE);
					break;

				default:
					CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_REQUEST_MODE, InternalConstants.URL_PARAMETER_VALUE_REQUEST_MODE_VOD);
					break;
			}
		} else {
			CommonUtil.appendQueryToMap(globalParametersMap, InternalConstants.URL_PARAMETER_KEY_REQUEST_MODE, InternalConstants.URL_PARAMETER_VALUE_REQUEST_MODE_VOD);
		}
		globalParametersMap.putAll(this.context.capabilities.toGlobalParametersMapForTypeBRequest());
		globalParametersMap.putAll(this.context.visitor.toGlobalParametersMapForTypeBRequest());
		globalParametersMap.putAll(this.toSiteSectionGlobalParametersMapForTypeBRequest());
		if (additionalGlobalParameters != null && !additionalGlobalParameters.isEmpty()) {
			globalParametersMap.putAll(additionalGlobalParameters);
		}

		String flagValue = globalParametersMap.containsKey(Constants._AD_REQUEST_FLAG_CAPABILITY)? globalParametersMap.get(Constants._AD_REQUEST_FLAG_CAPABILITY) : "";
		if (this.vaAutoPlayType == IConstants.VideoAssetAutoPlayType.ATTENDED) {
			flagValue += "+play";
		} else if (this.vaAutoPlayType == IConstants.VideoAssetAutoPlayType.UNATTENDED) {
			flagValue += "+play+uapl";
		} else if (this.vaAutoPlayType == IConstants.VideoAssetAutoPlayType.CLICK_TO_PLAY) {
			flagValue += "+cltp";
		}
		globalParametersMap.put(Constants._AD_REQUEST_FLAG_CAPABILITY, flagValue);

		return StringUtils.convertMapToURLQueryString(globalParametersMap);
	}

	public XMLElement buildXMLElement() {
		XMLElement root = new XMLElement(InternalConstants.TAG_AD_REQUEST);
		root.setAttribute(InternalConstants.ATTR_NETWORK_ID, this.context.networkId);
		root.setAttribute(InternalConstants.ATTR_VERSION, InternalConstants.XML_REQUEST_VERSION);
		root.setAttribute(InternalConstants.ATTR_PROFILE, this.context.playerProfile);
		if(this.requestMode!=null && this.requestMode.length()!=0)
			root.setAttribute(InternalConstants.ATTR_MODE, this.requestMode);
		if(this.subsessionToken>0)
			root.setAttribute(InternalConstants.ATTR_SUBSESSION_TOKEN, this.subsessionToken);
		root.appendChild(this.context.capabilities.buildXMLElement());
		root.appendChild(this.context.visitor.buildXMLElement());
		root.appendChild(this.buildKeyValuesElement());
		root.appendChild(this.buildSiteSectionElement());

		return root;
	}
	
	public String toKeyValuesStringForTypeBRequest() {
		List<String> list = new ArrayList<>();
		Iterator<String> iter = this.keyValues.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			TreeSet<String> values = this.keyValues.get(key);
			Iterator<String> ii = values.iterator();

			while (ii.hasNext()) {
				String value = ii.next().toString();
				list.add(StringUtils.encodeURIComponent(key) + "=" + StringUtils.encodeURIComponent(value));
			}
		}
		return TextUtils.join("&", list);
	}

	private XMLElement buildKeyValuesElement() {
		XMLElement node = new XMLElement(InternalConstants.TAG_KEY_VALUES);
		Iterator<String> iter = this.keyValues.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			TreeSet<String> values = this.keyValues.get(key);
			Iterator<String> ii = values.iterator();
			while (ii.hasNext()) {
				XMLElement child = new XMLElement(InternalConstants.TAG_KEY_VALUE);
				child.setAttribute(InternalConstants.TAG_KEY_VALUES_KEY, key);
				child.setAttribute(InternalConstants.TAG_KEY_VALUES_VALUE, ii.next());
				node.appendChild(child);
			}
		}

		return node;
	}
	
	private HashMap<String, String> toSiteSectionGlobalParametersMapForTypeBRequest() {
		HashMap<String, String> map = new HashMap<>();
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_SITE_CUSTOM_ID, this.ssCustomId);
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_SITE_SECTION_ID, this.ssId);
		if (this.ssFallbackId != null && !this.ssFallbackId.isEmpty()) {
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_SITE_FALLBACK_ID, this.ssFallbackId);
		}
		if(this.ssPageViewRandom > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_PAGE_VIEW_RANDOM, Integer.toString(this.ssPageViewRandom));
		if (this.ssNetworkId > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_SITE_NETWORK_ID, Integer.toString(this.ssNetworkId));
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_AD_SLOT_DEFAULT_PROFILE, this.context.defaultVideoPlayerSlotProfile);
		map.putAll(this.toVideoAssetGlobalParametersMapForTypeBRequest());
		return map;
	}

	private XMLElement buildSiteSectionElement() {
		XMLElement siteSectionNode = new XMLElement(InternalConstants.TAG_SITE_SECTION);
		siteSectionNode.setAttribute(InternalConstants.ATTR_CUSTOM_ID, this.ssCustomId);
		siteSectionNode.setAttribute(InternalConstants.ATTR_SITE_SECTION_ID, this.ssId);
		if (this.ssFallbackId != null && !this.ssFallbackId.isEmpty()) {
			siteSectionNode.setAttribute(InternalConstants.ATTR_SITE_SECTION_FALLBACK_ID, this.ssFallbackId);
		}
		siteSectionNode.setAttribute(InternalConstants.ATTR_SITE_SECTION_PAGE_VIEW_RANDOM, this.ssPageViewRandom, true);
		siteSectionNode.setAttribute(InternalConstants.ATTR_SITE_SECTION_NETWORK_ID, this.ssNetworkId, true);

		XMLElement videoPlayerNode = new XMLElement(InternalConstants.TAG_VIDEO_PLAYER);
		videoPlayerNode.appendChild(this.buildVideoAssetElement());
		siteSectionNode.appendChild(videoPlayerNode);

		XMLElement ssntSlotsNode = new XMLElement(InternalConstants.TAG_NON_TEMPORAL_AD_SLOTS);
		ssntSlotsNode.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE, this.context.defaultSiteSectionSlotProfile);

		if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
			for (NonTemporalSlot nonTemporalSlot : this.nonTemporalSlots) {
				if (nonTemporalSlot.type == IConstants.SlotType.NON_TEMPORAL) {
					ssntSlotsNode.appendChild(nonTemporalSlot.buildXMLElement());
				}
			}
		}
		siteSectionNode.appendChild(ssntSlotsNode);

		return siteSectionNode;
	}

	public void setParameter(String name, Object value, IConstants.ParameterLevel level) {
		if (name == null) {
			return;
		}
		Map<String, Object> dict = null;
		switch (level) {
			case GLOBAL:
				dict = this.globalLevelParameters;
				break;
			case OVERRIDE:
				dict = this.overrideLevelParameters;
				break;
			default:
				logger.warn("can not set parameter for level " + level);
				return;
		}
		if (value == null) {
			dict.remove(name);
		} else {
			dict.put(name, value);
		}
	}

	private XMLElement buildVideoAssetElement() {
		XMLElement node = new XMLElement(InternalConstants.TAG_VIDEO_ASSET);
		node.setAttribute(InternalConstants.ATTR_CUSTOM_ID, vaCustomId);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_ID, this.vaId);
		if (this.vaFallbackId != null && !this.vaFallbackId.isEmpty()) {
			node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_FALLBACK_ID, this.vaFallbackId);
		}
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_MEDIA_LOCATION, this.vaMediaLocation);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_DURATION, this.vaDuration, true);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_NETWORK_ID, this.vaNetworkId, true);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_VIDEO_PLAY_RANDOM, this.vaVideoPlayRandom, true);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_WINDOW_START_TIME, this.vaWindowStartTime, true);
		if (this.vaAutoPlayType == IConstants.VideoAssetAutoPlayType.CLICK_TO_PLAY) {
			node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_CLICK_TO_PLAY, true);
		} else {
			node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_AUTO_PLAY, (this.vaAutoPlayType != IConstants.VideoAssetAutoPlayType.NONE));
			if (this.vaAutoPlayType == IConstants.VideoAssetAutoPlayType.UNATTENDED)
				node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_UNATTENDED_PLAY, true);
		}
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_CURRENT_TIME_POSITION, vaVideoAssetCurrentTimePosition, true);
		node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_REQUEST_DURATION, this.requestDuration, true);

		if (this.vaDurationType != null && this.vaDurationType.length() != 0)
			node.setAttribute(InternalConstants.ATTR_VIDEO_ASSET_DURATION_TYPE, this.vaDurationType);

		XMLElement child = new XMLElement(InternalConstants.TAG_TEMPORAL_AD_SLOTS);
		child.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE, this.context.defaultTemporalSlotProfile);
		child.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOTS_COMP_DIM, this.context.getScreenDimensionStr());

		if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
			for (TemporalSlot temporalSlot : this.temporalSlots) {
				child.appendChild(temporalSlot.buildXMLElement());
			}
			node.appendChild(child);
		}
		return node;
	}

	private HashMap<String, String> toVideoAssetGlobalParametersMapForTypeBRequest() {
		HashMap<String, String> map = new HashMap<>();
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_CUSTOM_ID, this.vaCustomId);
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_ASSET_ID, this.vaId);
		if(this.vaFallbackId !=null && !this.vaFallbackId.isEmpty())
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_ASSET_FALLBACK_ID, this.vaFallbackId);
		if(this.vaDuration > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_ASSET_DURATION, this.vaDuration);
		if(this.vaNetworkId > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_ASSET_NETWORK_ID, this.vaNetworkId);
		if(this.vaVideoPlayRandom > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_PLAYER_RANDOM, this.vaVideoPlayRandom);
		if(this.vaVideoAssetCurrentTimePosition > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_TIME_POSITION, this.vaVideoAssetCurrentTimePosition);
		if(this.requestDuration > 0)
			CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_REQUEST_DURATION, this.requestDuration);
		switch (this.vaDurationType) {
			case InternalConstants.VIDEO_ASSET_DURATION_TYPE_VARIABLE:
				CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_DURATION_TYPE, InternalConstants.URL_PARAMETER_VALUE_VIDEO_DURATION_TYPE_VARIABLE);
				break;
			case InternalConstants.VIDEO_ASSET_DURATION_TYPE_EXACT:
				CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VIDEO_DURATION_TYPE, InternalConstants.URL_PARAMETER_VALUE_VIDEO_DURATION_TYPE_EXACT);
				break;
			default:
				break;
		}
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_AD_SLOTS_COMP_DIM, this.context.getScreenDimensionStr());
		return map;
	}

	public boolean hasSetVideoAssetId() {
		if (this.vaId == null && this.vaCustomId == null) {
			return false;
		}
		return true;
	}

	protected void setVideoViewTestListener(IEventListener l) {
		this.videoViewTestListener = l;
	}

	private IEventListener videoViewCompleteListener = new IEventListener() {
		public void run(IEvent event) {
			String xmldata =  (String) event.getData().get(Constants._INFO_KEY_MESSAGE);
			logger.verbose("got response: " +  xmldata);

			try {
				AdResponse response = new AdResponse(context);
				response.parse(xmldata);
				context.adResponse.videoAsset.callbackHandler =
					response.videoAsset.callbackHandler;
				response.videoAsset.callbackHandler = null;
				context.adResponse.videoAsset.play();
				IEventListener l = AdRequest.this.videoViewTestListener;
				if(l != null) {
					l.run(event);
				}
			} catch (IllegalAdResponseException e) {
				logger.error("failed to parse response for videoView request");
			}
		}
	};

	public boolean hasVideoAsset(){
		return this.vaId != null || this.vaCustomId !=null;
	}

	public void requestVideoView() {
		logger.debug("will send videoView request");
		if (this.videoViewCallbackRequested || this.context.isRecordVideoViewEnabled()) {
			return;
		}
		this.videoViewCallbackRequested = true;
		this.context.capabilities.setCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION, IConstants.CapabilityStatus.ON);
		this.context.capabilities.setCapability(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL, IConstants.CapabilityStatus.ON);

		if (!this.context.serverUrl.matches("^\\w+:.*")) {
			logger.verbose("requestVideoView: " + this.context.serverUrl);
			new Thread() {
				@Override
				public void run() {
					try {
						FileInputStream fis = new FileInputStream(new File(context.serverUrl));
						AdResponse response = new AdResponse(context);
						response.parse(fis);
						context.adResponse.videoAsset.callbackHandler =
							response.videoAsset.callbackHandler;
						response.videoAsset.callbackHandler = null;
						context.adResponse.videoAsset.play();

						IEventListener l = AdRequest.this.videoViewTestListener;
						if(l != null) {
							l.run(null);
						}
					} catch (FileNotFoundException e) {
						logger.error("file not found");
					} catch (IllegalAdResponseException e) {
						logger.error("file not well formatted " + e.getMessage());
					}
				}
			}.start();

			return;
		}

		URLRequest req = this.context.buildRequest();

		if (req != null) {
			URLLoader loader = new URLLoader();

			loader.addEventListener(URLLoader.EVENT_LOAD_COMPLETE, videoViewCompleteListener);

			loader.load(req);
		}
	}

	public IConstants.VideoAssetAutoPlayType getVaAutoplayType() {
		return vaAutoPlayType;
	}
}
