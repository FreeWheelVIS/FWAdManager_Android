package tv.freewheel.ad;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.slot.NonTemporalSlot;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.ad.slot.TemporalSlot;
import tv.freewheel.ad.state.VideoInitState;
import tv.freewheel.ad.state.VideoPendingState;
import tv.freewheel.ad.state.VideoPlayingState;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class AdResponse extends EventCallbackHolder {
	private static final Logger logger = Logger.getLogger(AdResponse.class, true);
	public List<Ad> ads;
	public List<TemporalSlot> temporalSlots;
	public List<NonTemporalSlot> nonTemporalSlots;
	public VideoAsset videoAsset;
	public Map<String, Object> profileParameters;
	
	public static final class IllegalAdResponseException extends Exception {
		private static final long serialVersionUID = 277370249776948979L;

		public IllegalAdResponseException(String msg) {
			super(msg);
		}
	}

	public AdResponse(final AdContext context) {
		super(context);

		this.ads = new ArrayList<>();
		this.temporalSlots = new ArrayList<>();
		this.nonTemporalSlots = new ArrayList<>();
		
		this.videoAsset = new VideoAsset(context);
		this.profileParameters = new HashMap<>();
	}

	public Ad getAd(int freewheelAdId, String externalAdId) {
		for (Ad ad : this.ads) {
			if (ad.adId == freewheelAdId && StringUtils.areEqualContentStrings(externalAdId, ad.externalAdId)) {
				return ad;
			}
		}
		return null;
	}
	
	public void parse(InputStream is) throws IllegalAdResponseException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;

		try {
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new IllegalAdResponseException("new DocumentBuilder failed");
		}

		Document document = null;
		try {
			document = builder.parse(is);
		} catch (SAXException e) {
			throw new IllegalAdResponseException("parse xml failed");
		} catch (IOException e) {
			throw new IllegalAdResponseException("IO Error occurred");
		}
		
		if (this.context.getActivity() != null) {
			parseXmlDocument(document);
		} else {
			logger.warn("host activity is null, won't parse response");
		}
	}
	
	public void parse(String adResponseString) throws IllegalAdResponseException {
		ByteArrayInputStream byteArrayInputStream;
		try {
			byteArrayInputStream = new ByteArrayInputStream(adResponseString.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			byteArrayInputStream = new ByteArrayInputStream(adResponseString.getBytes());
		}

		this.parse(byteArrayInputStream);
	}

	private void parseXmlDocument(Document document)
			throws IllegalAdResponseException {
		NodeList rootList = document.getElementsByTagName(InternalConstants.TAG_AD_RESPONSE);
		if(rootList.getLength() == 0) {
			throw new IllegalAdResponseException("no root node" + InternalConstants.TAG_AD_RESPONSE
					+ " found in document");
		}

		Element adResponseElement = (Element)rootList.item(0);
		NodeList childList = adResponseElement.getChildNodes();
		
		int length = childList.getLength();
		for(int i = 0; i < length; i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {

				logger.verbose("parseXMLString: name: " + childNode.getNodeName());

				String name = childNode.getNodeName();

				if (name.equals(InternalConstants.TAG_ADS)){
					if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
						this.parseAds((Element)childNode);
					}
				} else if (name.equals(InternalConstants.TAG_SITE_SECTION)) {
					this.parseSiteSection((Element)childNode);
				} else if (name.equals(InternalConstants.TAG_EVENT_CALLBACKS)) {
					if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
						this.parseEventCallbacks((Element)childNode);
					}
				} else if (name.equals(InternalConstants.TAG_RENDERER_MANIFEST)){
					this.parseAdRenderers((Element)childNode);
				} else if (name.equals(InternalConstants.TAG_VISITOR)) {
					this.context.visitor.parse((Element)childNode);
				} else if (name.equals(InternalConstants.TAG_PARAMETERS)) {
					this.profileParameters = ParametersHolder.parseParameters((Element)childNode);
				} else {
					logger.warn("parseXmlDocument() ignore node: " + name);
				}
			}
		}
	}
	
	private void parseAdRenderers(Element node) {
		NodeList childList = node.getChildNodes();
		
		String menifestStr = "";
		for(int i = 0; i < childList.getLength(); ++i) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.TEXT_NODE) {
				menifestStr += childNode.getNodeValue();
			}
		}
		logger.verbose("parseAdRenderers: " + menifestStr);
		try {
			Element renderers = XMLHandler.getXMLElementFromString(menifestStr, InternalConstants.TAG_AD_RENDERERS);
			this.parseAdRendererNode(renderers);
		} catch (Exception e) {
			logger.warn("Parsing ad renderers failed", e);
		}
	}

	private void parseAdRendererNode(Element node) {
		NodeList childList = node.getChildNodes();
		
		for(int i = 0; i < childList.getLength(); ++i) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseAdRendererNode, name: " + name);
				
				if (name.equals(InternalConstants.TAG_AD_RENDERER)){
					AdRenderer renderer = new AdRenderer(this.context);
					renderer.parse((Element)childNode);
					this.context.adRenderers.add(renderer);
				}
			}
		}
	}

	private void parseAds(Element node) {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseAds, name: " + name);
				if (name.equals(InternalConstants.TAG_AD)){
					Ad ad = new Ad(this.context);
					ad.parse((Element)childNode);
					this.ads.add(ad);
					
				} else {
					logger.warn("parseAds() ignore node: " + name);
				}
			}
		}
	}

	private void parseSiteSection(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		// parse <adSlots> first
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				if (name.equals(InternalConstants.TAG_NON_TEMPORAL_AD_SLOTS)) {
					logger.verbose("parseSiteSection, name: " + name);
					if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
						this.parseAdSlots((Element)childNode, IConstants.SlotType.NON_TEMPORAL);
					}
				}
			}
		}

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				if (name.equals(InternalConstants.TAG_VIDEO_PLAYER)){
					logger.verbose("parseSiteSection, name: " + name);
					this.parseVideoPlayer((Element)childNode);
				} else if (!name.equals(InternalConstants.TAG_NON_TEMPORAL_AD_SLOTS)) {
					logger.warn("parseSiteSection, ignore node: " + name);
				}
			}
		}
	}

	private void parseAdSlots(Element node, IConstants.SlotType type) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseAdSlots, name: " + name);

				if (name.equals(InternalConstants.TAG_NON_TEMPORAL_AD_SLOT)) {
					Element ele = (Element) childNode;
					
					String customId = ele.getAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_CUSTOM_ID);
					// in case the nonTemporalSlot has been added by companionAds
					NonTemporalSlot slot = (NonTemporalSlot)this.context.getSlotByCustomId(customId);
					if(slot == null) {
						slot = (NonTemporalSlot)this.getAdRequest().getSlotByCustomId(customId);
						if (slot != null) {
							slot = slot.copy();
						} else {
							slot = new NonTemporalSlot(this.context, type);
							slot.init(customId, 0, 0, null, null, true, null, null, IConstants.SlotInitialAdOption.STAND_ALONE, null);
						}
						this.nonTemporalSlots.add(slot);
					}
					slot.parse((Element)childNode);
				} else {
					logger.warn("parseAdSlots() ignore node: " + name);
				}
			}
		}
	}

	private void parseVideoPlayer(Element node) throws IllegalAdResponseException{
		NodeList childList = node.getChildNodes();

		// parse <adSlots> first
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				if (name.equals(InternalConstants.TAG_NON_TEMPORAL_AD_SLOTS)) {
					logger.verbose("parseVideoPlayer, name: " + name);
					if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
						this.parseAdSlots((Element)childNode, IConstants.SlotType.NON_TEMPORAL);
					}
				}
			}
		}

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				if (name.equals(InternalConstants.TAG_VIDEO_ASSET)){
					logger.verbose("parseVideoPlayer, name: " + name);
					this.videoAsset.parse((Element)childNode);
				} else if (!name.equals(InternalConstants.TAG_NON_TEMPORAL_AD_SLOTS)) {
					logger.warn("parseVideoPlayer, ignore node: " + name);
				}
			}
		}
	}
	
	public void onVideoAssetChanged() {
		logger.debug("onVideoAssetChanged");
		this.context.adRequest.videoViewCallbackRequested = false;
		if (this.videoAsset.state == VideoInitState.Instance()) {
			this.videoAsset = new VideoAsset(this.context);
			return;
		}
		boolean isPlaying = false;
		if (this.videoAsset.state == VideoPlayingState.Instance() ||
			this.videoAsset.state == VideoPendingState.Instance()) {
			isPlaying = true;
			this.videoAsset.complete();
		}
		
		this.videoAsset = new VideoAsset(this.context);
		if (isPlaying) {
			this.videoAsset.play();
		}
	}

	public Slot getSlotByCustomId(String customId) {
		Iterator<TemporalSlot> iter = this.temporalSlots.iterator();
		while (iter.hasNext()) {
			Slot slot = (Slot) iter.next();
			if (customId.equals(slot.customId)) {
				return slot;
			}
		}

		Iterator<NonTemporalSlot> iter2 = this.nonTemporalSlots.iterator();
		while (iter2.hasNext()) {
			Slot slot = (Slot) iter2.next();
			if (customId.equals(slot.customId)) {
				return slot;
			}
		}

		return null;

	}
	
	public NonTemporalSlot getOrCreateNonTemporalSlotWithCustomId(String slotCustomId, int width, int height) {
		NonTemporalSlot companionSlot = (NonTemporalSlot) this.getAdResponse().getSlotByCustomId(slotCustomId);
		if (companionSlot == null) {
			companionSlot = new NonTemporalSlot(this.context, IConstants.SlotType.NON_TEMPORAL);
			companionSlot.customId = slotCustomId;
			companionSlot.width = width;
			companionSlot.height = height;
			this.getAdResponse().nonTemporalSlots.add(companionSlot);
		}
		return companionSlot;
	}
}
