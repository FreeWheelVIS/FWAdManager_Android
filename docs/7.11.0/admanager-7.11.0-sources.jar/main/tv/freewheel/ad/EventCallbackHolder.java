package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import tv.freewheel.ad.handler.AdImpressionEndCallbackHandler;
import tv.freewheel.ad.handler.AdImpressionCallbackHandler;
import tv.freewheel.ad.handler.AdMeasurementCallbackHandler;
import tv.freewheel.ad.handler.ClickCallbackHandler;
import tv.freewheel.ad.handler.ErrorCallbackHandler;
import tv.freewheel.ad.handler.EventCallbackHandler;
import tv.freewheel.ad.handler.ProgressEventCallbackHandler;
import tv.freewheel.ad.handler.QuartileCallbackHandler;
import tv.freewheel.ad.handler.ResellerNoAdCallbackHandler;
import tv.freewheel.ad.handler.SlotImpressionCallbackHandler;
import tv.freewheel.ad.handler.StandardCallbackHandler;
import tv.freewheel.ad.handler.VideoViewCallbackHandler;
import tv.freewheel.utils.Logger;

public class EventCallbackHolder extends AdContextScoped {

	private static final Logger logger = Logger.getLogger(EventCallbackHolder.class, true);

	public List<EventCallback> eventCallbacks;
	
	public EventCallbackHolder(AdContext context) {
		super(context);
		this.eventCallbacks = new ArrayList<>();
	}
	
	public void parseEventCallbacks(Element node) {
		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				if (name.equals(InternalConstants.TAG_EVENT_CALLBACK)){
					EventCallback callback = new EventCallback(this.context);
					callback.parse((Element)childNode);
					this.eventCallbacks.add(callback);
				}
			}
		}
	}

	public EventCallback fetchEventCallback(String name,
			String type, boolean useGeneric) {
		
		EventCallback ret = null;
		EventCallback generic = null;
		Iterator<EventCallback> iter = this.eventCallbacks.iterator();
		while (iter.hasNext()) {
			EventCallback temp = iter.next();
			if (temp.name.equals(name) && temp.type.equals(type)) {
				ret = temp;
				break;
			}
			if (useGeneric && temp.type.equals(InternalConstants.EVENT_TYPE_GENERIC)) {
				generic = temp;
			}
		}
		return ret != null ? ret : generic;
	}
	
	public EventCallbackHandler createEventHandler(String name, String type, boolean useGeneric) {
		logger.debug("createEventHandler(" + name + "," + type + "," + useGeneric + ")");
		EventCallbackHandler ret = null;
		EventCallback callback = this.fetchEventCallback(name, type, useGeneric);
		
		try {
			if (type.equals(InternalConstants.EVENT_TYPE_ERROR)) {
				ret = new ErrorCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_AD_SKIPPED_BY_USER)) {
				ret = new EventCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_AD_PROGRESS)) {
				ret = new ProgressEventCallbackHandler(callback);
			} else if (type.equals(Constants._EVENT_TYPE_STANDARD)) {
				ret = new StandardCallbackHandler(callback);
				ret.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, name);
			} else if (type.equals(Constants._EVENT_TYPE_CLICK) || type.equals(Constants._EVENT_TYPE_CLICK_TRACKING)) {
				ret = new ClickCallbackHandler(callback);
				if (!name.equals(Constants._EVENT_AD_CLICK) && useGeneric) {
					ret.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, name);
					ret.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, EventCallback.getShortenedEventType(type));
				}
			} else if (name.equals(Constants._EVENT_SLOT_IMPRESSION)) {
				ret = new SlotImpressionCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_SLOT_IMPRESSION_END)) {
				ret = new SlotImpressionCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_AD_IMPRESSION)) {
				ret = new AdImpressionCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_AD_IMPRESSION_END)) {
				ret = new AdImpressionEndCallbackHandler(callback);
			} else if (name.equals(InternalConstants.EVENT_VIDEO_VIEW) && !this.context.isRecordVideoViewEnabled()) {
				ret = new VideoViewCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_RESELLER_NO_AD)) {
				ret = new ResellerNoAdCallbackHandler(callback);
			} else if (name.equals(Constants._EVENT_AD_MEASUREMENT)) {
				ret = new AdMeasurementCallbackHandler(callback);
				ret.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, name);
			} else if (type.equals(Constants._EVENT_TYPE_IMPRESSION)) {
				ret = new QuartileCallbackHandler(callback);
				ret.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, name);
			}
		} catch (MalformedURLException e) {
			ret = null;
			logger.warn(e.getMessage());
		}
		
		return ret;
	}
}
