package tv.freewheel.ad.handler;

import android.os.Bundle;

import java.net.MalformedURLException;
import java.util.List;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;

public class ProgressEventCallbackHandler extends EventCallbackHandler {
    public ProgressEventCallbackHandler(EventCallback callback) throws MalformedURLException {
        super(callback);
    }

    public void send(Bundle info){
        int offset = -1;
        try {
            offset = Integer.parseInt((String) info.get(Constants._INFO_KEY_OFFSET));
        } catch (Exception e) {
            logger.warn("progress beacon with invalid offset: " + (String) info.get(Constants._INFO_KEY_OFFSET));
            return;
        }
        List<String> progressURLList = this.adInstance.getProgressEventCallbackURLs().get(offset);
        for (String url : progressURLList) {
            this.sendRequest(url);
        }
    }
}
