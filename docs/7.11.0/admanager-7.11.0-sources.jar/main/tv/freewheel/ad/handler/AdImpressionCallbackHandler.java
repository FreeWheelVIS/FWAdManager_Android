package tv.freewheel.ad.handler;

import android.os.Bundle;

import java.net.MalformedURLException;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IConstants;

public class AdImpressionCallbackHandler extends AdCallbackHandler {
	private boolean impressionProcessed = false;
	
	public AdImpressionCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
	}

	public void send(Bundle info) {

		int metr = info.getInt("metr");
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_METR, String.valueOf(metr));
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "1");
		if (this.adInstance.slot.getSlotType() == IConstants.SlotType.TEMPORAL) {
			long ctValue = info.getLong(InternalConstants.URL_PARAMETER_KEY_CT);
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_CT, String.valueOf(ctValue));
			int startTimePosition = info.getInt(InternalConstants.URL_PARAMETER_KEY_START_TIME_POSITION);
			if (startTimePosition > -1) {
				this.setParameter(InternalConstants.URL_PARAMETER_KEY_START_TIME_POSITION, String.valueOf(startTimePosition));
			}
		}

		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CN,Constants._EVENT_AD_IMPRESSION);
		if(impressionProcessed){
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "2");
		} else{
			this.sendTrackingCallbacks();
			this.adInstance.imprSent = true;
		}
		
		this.send();
		this.impressionProcessed = true;
		this.adInstance.dispatchAdEvent(Constants._EVENT_AD_IMPRESSION);
	}
}
