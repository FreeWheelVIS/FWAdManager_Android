package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.slot.Slot;

public class SlotImpressionCallbackHandler extends EventCallbackHandler {
	private Slot slot;
	private boolean imprSent = false;
	
	public SlotImpressionCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
	}
	
	@Override
	public void send() {
		if (imprSent && !slot.isPauseMidroll()) {
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "2");
		} else {
			imprSent = true;
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "1");
			this.sendTrackingCallbacks();
		}
		super.send();
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}

	@Override
	protected double getContentPlayheadTime() {
		return slot != null ? slot.getAdContext().contentPlayheadTime : 0.0;
	}
}
