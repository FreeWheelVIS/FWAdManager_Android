package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.utils.Scheduler;

public class VideoViewCallbackHandler extends EventCallbackHandler {
	
	private static int[] intervals = {5, 10, 15, 30, 60, 120, 180, 300};
	private int intervalIndex = -1;
	private Scheduler scheduler;
	private boolean initSent = false;
	
	public boolean replay = false;
	
	public VideoViewCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
		this.scheduler = new Scheduler();
		this.scheduler.setRunnable(new Runnable() {
			public void run() {
				send(scheduler.getLastRunDuration());
				++intervalIndex;
				if (intervalIndex == 8) {
					intervalIndex = 7;
				}
				scheduler.start(intervals[intervalIndex]);
			}
		});
	}

	public void start(long delaySeconds) {
		logger.info("delaySeconds: " + delaySeconds);
		for (int i = 0; i < intervals.length; ++i) {
			if (delaySeconds < intervals[i]) {
				this.intervalIndex = i;
				break;
			}
		}
		this.send(delaySeconds);
		if (this.intervalIndex < 0) {
			this.intervalIndex = 7;
		}
		this.scheduler.start(intervals[this.intervalIndex]);
	}
	
	public void send(long ctValue) {
		if (this.replay) {
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "2");
		} else {
			if (this.initSent) {
				this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "0");
			} else {
				this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "1");
				this.sendTrackingCallbacks();
				this.initSent = true;
			}
		}
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CT, String.valueOf(ctValue));
		this.send();
	}

	public void pause() {
		this.scheduler.pause();
		this.send(this.scheduler.getLastRunDuration());
	}

	public void complete() {
		this.scheduler.pause();
		this.send(this.scheduler.getLastRunDuration());
		this.scheduler.stop();
		this.scheduler = new Scheduler();
		this.intervalIndex = -1;
		this.initSent = false;
	}

	public void resume() {
		this.scheduler.resume();
	}
}
