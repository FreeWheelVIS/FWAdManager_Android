package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import android.os.Bundle;

public class AdMeasurementCallbackHandler extends EventCallbackHandler {

	public boolean imprSent = false;

	public AdMeasurementCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, InternalConstants.SHORT_EVENT_TYPE_IMPRESSION);
	}

	public void send(Bundle info) {
		String concreteEventId = info.getString(Constants._INFO_KEY_CONCRETE_EVENT_ID);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CREID, concreteEventId);
		this.send();
		if(!imprSent){
			this.sendTrackingCallbacks();
		}
		this.imprSent = true;
	}
} 