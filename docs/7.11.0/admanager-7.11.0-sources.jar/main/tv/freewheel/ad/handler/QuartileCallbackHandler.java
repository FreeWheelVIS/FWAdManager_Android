package tv.freewheel.ad.handler;

import android.os.Bundle;

import java.net.MalformedURLException;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;

public class QuartileCallbackHandler extends AdCallbackHandler {

	public boolean imprSent = false;
	
	public QuartileCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, InternalConstants.SHORT_EVENT_TYPE_IMPRESSION);
	}

	public void send(Bundle info){
		boolean enableCountingReplayCallback = (this.adInstance.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK) != null) ? Boolean.valueOf(this.adInstance.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK).toString()) : false;
		if (this.imprSent && !enableCountingReplayCallback)
			return;

		if (enableCountingReplayCallback) {
			if (this.imprSent) {
				this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "2");
			} else {
				this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "1");
			}
		}
		this.imprSent = true;
		long ct = info.getLong(InternalConstants.URL_PARAMETER_KEY_CT);
		int metr = info.getInt(InternalConstants.URL_PARAMETER_KEY_METR);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CT, String.valueOf(ct));
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_METR, String.valueOf(metr));
		this.send();
		this.sendTrackingCallbacks();
	}
}
