package tv.freewheel.ad.handler;

import android.os.Bundle;

import java.net.MalformedURLException;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IConstants;

public class AdImpressionEndCallbackHandler extends AdCallbackHandler {
	private boolean adEndProcessed = false;
	
	public AdImpressionEndCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
	}

	public void send(Bundle info) {

		int metr = info.getInt("metr");
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_METR, String.valueOf(metr));
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, InternalConstants.SHORT_EVENT_TYPE_IMPRESSION);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "1");
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CN,Constants._EVENT_AD_IMPRESSION_END);
		
		if (this.adInstance.slot.getSlotType() == IConstants.SlotType.TEMPORAL) {
			long ctValue = info.getLong(InternalConstants.URL_PARAMETER_KEY_CT);
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_CT, String.valueOf(ctValue));
		}
		if (adEndProcessed){
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_INIT, "2");
		}
		this.send();
		this.adEndProcessed = true;
		this.adInstance.dispatchAdEvent(Constants._EVENT_AD_IMPRESSION_END);
	}
}
