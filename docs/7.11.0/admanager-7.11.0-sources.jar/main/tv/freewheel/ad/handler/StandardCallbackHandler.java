package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;

public class StandardCallbackHandler extends EventCallbackHandler {

	public StandardCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, InternalConstants.SHORT_EVENT_TYPE_STANDARD);
	}
	
	@Override
	public void send(){
		super.send();
		this.sendTrackingCallbacks();
	}
}
