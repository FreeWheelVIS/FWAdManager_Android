package tv.freewheel.ad.handler;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.net.MalformedURLException;
import java.net.URL;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;

public class ClickCallbackHandler extends AdCallbackHandler {
	public ClickCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
	}

	private void openLink(final String to) {
		if (this.adInstance.getActivity() != null) {
			logger.debug("will open: " + to);
			Uri uri = Uri.parse(to);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			this.adInstance.getActivity().startActivity(intent);
		}
	}

	public void send(Bundle info) {
		if (this.adInstance != null && this.adInstance.getActiveCreativeRendition() != null) {
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_REID, String.valueOf(this.adInstance.getActiveCreativeRendition().creativeRenditionId));
		}

		boolean skipTracking = false;
		String redirectUrl = this.getUrlParameter(InternalConstants.URL_PARAMETER_KEY_CR);
		String overriddenUrl = info.getString(Constants._INFO_KEY_URL);
		String callbackUrl = super.getCallbackUrl();
		boolean needShowBrowser = this.isShowBrowser();

		if (overriddenUrl != null && !overriddenUrl.isEmpty()) {
			needShowBrowser = true;

			// extract FW server host from player setting
			String fwServerHost = ".fwmrm.net";
			try {
				if (this.adInstance.getAdContext().serverUrl.startsWith("http")) {
					fwServerHost = new URL(this.adInstance.getAdContext().serverUrl).getHost();
				}
			} catch (MalformedURLException e) {}

			String overriddenServerHost = "";
			try {
				overriddenServerHost = new URL(overriddenUrl).getHost();
			} catch (MalformedURLException e) {}

			if (overriddenServerHost.contains(fwServerHost) && overriddenUrl.contains("ad/l/1")) {
				// Case A: FW callback
				skipTracking = true;

				callbackUrl = overriddenUrl;
				int idx = callbackUrl.lastIndexOf("&" + InternalConstants.URL_PARAMETER_KEY_CR + "=");
				if (idx != -1) {
					redirectUrl = Uri.decode(callbackUrl.substring(idx + ("&" + InternalConstants.URL_PARAMETER_KEY_CR + "=").length()));
				} else {
					redirectUrl = "";
				}
				logger.debug("Click through overridden by value: " + overriddenUrl);
			} else if (overriddenUrl.contains(fwServerHost) && overriddenUrl.contains("ad/l/1")) {
				// Case B: FW callback included in 3p callback
				// implies that tracking URLs sent by renderer/creative
				skipTracking = true;
				callbackUrl = overriddenUrl;
				redirectUrl = overriddenUrl;
				logger.debug("Click through overridden by value: " + overriddenUrl);
			} else {
				// Case C: arbitrary URL
				int idx = callbackUrl.lastIndexOf("&" + InternalConstants.URL_PARAMETER_KEY_CR + "=");
				if (idx != -1) {
					callbackUrl = callbackUrl.substring(0, idx);
				}
				callbackUrl += "&" + InternalConstants.URL_PARAMETER_KEY_CR + "=" + Uri.encode(overriddenUrl);
				logger.debug("Click through CR: original value: " + redirectUrl + ", overridden by value: " + overriddenUrl);
				redirectUrl = overriddenUrl;
			}
		}

		needShowBrowser = info.getBoolean(Constants._INFO_KEY_SHOW_BROWSER, needShowBrowser);

		// when open browser or external app, rely on activity change to pause the ad
		if (!callbackUrl.startsWith("http://") && !callbackUrl.startsWith("https://")) {
			try {
				this.openLink(callbackUrl);
			} catch (ActivityNotFoundException e) {
				logger.warn("unknown uri schema:" + callbackUrl);
			}
		} else if (!needShowBrowser || redirectUrl == null || redirectUrl.isEmpty()) {
			this.sendRequest(callbackUrl);
		} else if (redirectUrl.startsWith("http://") || redirectUrl.startsWith("https://")) {
			try {
				this.openLink(callbackUrl);
			} catch	(ActivityNotFoundException e) {
				logger.warn("clickthrough failed with uri: " + callbackUrl);
			}
		} else {
			this.sendRequest(callbackUrl);
			try {
				this.openLink(redirectUrl);
			} catch (ActivityNotFoundException e) {
				logger.warn("unknown uri schema:" + redirectUrl);
			}
		}

		if (!skipTracking) {
			this.sendTrackingCallbacks();
		}
	}
}
