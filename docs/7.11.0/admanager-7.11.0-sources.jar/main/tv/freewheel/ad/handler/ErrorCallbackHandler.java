package tv.freewheel.ad.handler;

import android.net.Uri;
import android.os.Bundle;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;

public class ErrorCallbackHandler extends EventCallbackHandler {
	public HashMap<String, String> errorCodeMap = new HashMap<>();

	public ErrorCallbackHandler(EventCallback callback) throws MalformedURLException {
		super(callback);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, "e");
	}

	public void send(Bundle info) {
		String errorCode = info.getString(Constants._INFO_KEY_ERROR_CODE);
		String additional = info.getString(Constants._INFO_KEY_ERROR_INFO);
		String renderer = info.getString(Constants._INFO_KEY_ERROR_MODULE);
		String value = Uri.encode(InternalConstants.URL_PARAMETER_KEY_ERROR_MODULE) + "=" + Uri.encode(renderer);
		value += "&" + Uri.encode(InternalConstants.URL_PARAMETER_KEY_ERROR_INFO) + "=" + Uri.encode(additional);
		String vastErrorCode = info.getString(Constants._INFO_KEY_VAST_ERROR_CODE);
		errorCodeMap.put(Constants._INFO_KEY_VAST_ERROR_CODE, vastErrorCode);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, errorCode);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_KV, value);
		this.send();
		this.sendTrackingCallbacks();
		this.adInstance.dispatchAdEvent(Constants._EVENT_ERROR, errorCode, additional, renderer);
	}

	public void sendTrackingUrlWithoutFWError(Bundle info) {
		String vastErrorCode = info.getString(Constants._INFO_KEY_VAST_ERROR_CODE);
		errorCodeMap.put(Constants._INFO_KEY_VAST_ERROR_CODE, vastErrorCode);
		this.send();
		this.sendTrackingCallbacks();
	}

	@Override
	protected String expandMacrosInString(String originalUrl) {
		originalUrl = super.expandMacrosInString(originalUrl);
		Pattern macroMatchRegexSquareBracketPattern = Pattern.compile("\\[ERRORCODE\\]");
		Matcher matcherForSquareBracket = macroMatchRegexSquareBracketPattern.matcher(originalUrl);

		while (matcherForSquareBracket.find()) {
			String macroValue = extractMacroValueWithName(matcherForSquareBracket.group(0));
			macroValue = super.encodeURIComponent(macroValue);
			originalUrl = originalUrl.replaceAll(Pattern.quote(matcherForSquareBracket.group()), Matcher.quoteReplacement(macroValue));
		}

		return originalUrl;
	}

	@Override
	public String extractMacroValueWithName(String macroName) {
		String errorCode = super.extractMacroValueWithName(macroName);
		String vastErrorCode = errorCodeMap.get(Constants._INFO_KEY_VAST_ERROR_CODE);
		switch (macroName){
			case InternalConstants.PINGBACK_MACRO_VAST_ERROR_CODE:
				return (vastErrorCode!=null)?vastErrorCode:errorCode;
			default:
				return errorCode;
		}
	}
}