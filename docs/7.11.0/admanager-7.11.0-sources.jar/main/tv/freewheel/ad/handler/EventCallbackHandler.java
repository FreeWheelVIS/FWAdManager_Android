package tv.freewheel.ad.handler;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.text.TextUtils;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.AdRenderer;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.URL.FWURL;
import tv.freewheel.utils.URLLoader;
import tv.freewheel.utils.URLRequest;

public class EventCallbackHandler {
	private EventCallback callback;
	private String baseUrl;
	private ArrayList<String> keys;
	private ArrayList<String> originalKeys;
	private HashMap<String, String> parameterPairs;
	private HashMap<String, String> originalParameterPairs;
	private String cachedUrl;
	private String crValue;
	protected static final Logger logger = Logger.getLogger(EventCallbackHandler.class);
	private ArrayList<String> externalTrackingURLs;
	private String internalUrl;
	protected AdInstance adInstance = null;

	public EventCallbackHandler(EventCallback callback) throws MalformedURLException {
		if (callback == null) {
			throw new MalformedURLException("callback object is null");
		}
		this.callback = callback;
		this.keys = new ArrayList<>();
		this.originalKeys = new ArrayList<>();
		this.parameterPairs = new HashMap<>();
		this.originalParameterPairs = new HashMap<>();
		this.externalTrackingURLs = new ArrayList<>();

		this.parseCallbackUrl(callback.url);
		this.originalKeys.addAll(this.keys);
		this.originalParameterPairs.putAll(this.parameterPairs);
	}

	private void parseCallbackUrl(String urlStr) throws MalformedURLException {
		if (urlStr == null || urlStr.length() == 0) {
			throw new MalformedURLException("url is empty");
		}

		this.cachedUrl = urlStr;

		URL url = new URL(urlStr);
		String[] queryComponents;
		try {
			queryComponents = url.getQuery().split("&");

			String[] urlComponents = urlStr.split("\\?");
			this.baseUrl = urlComponents[0];
		} catch (NullPointerException e) {
			queryComponents = new String[0];
			this.baseUrl = urlStr;
		}

		for (String queryComponent : queryComponents) {
			String[] kvPair = queryComponent.split("=", 2);
			if (kvPair.length == 0 || kvPair.length > 2 || kvPair[0].length() == 0) {
				throw new MalformedURLException("invalid format in query string");
			}

			String key = Uri.decode(kvPair[0]);
			String value = "";
			if (kvPair.length == 2) {
				value = Uri.decode(kvPair[1]);
			}

			if (key.equals(InternalConstants.URL_PARAMETER_KEY_CR)) {
				this.crValue = value.trim();
				continue;
			}

			this.keys.add(key);
			this.parameterPairs.put(key, value);
		}
	}

	public void setParameter(String key, String value) {
		if (key == null || key.length() == 0) {
			return;
		}

		if(key.equals(InternalConstants.URL_PARAMETER_KEY_CR)) {
			if (value == null) {
				return;
			}
			this.crValue = value;
			this.cachedUrl = null;
			this.internalUrl = null;
			return;
		}

		if (!this.keys.contains(key)) { // last added key should be at the head
			this.keys.add(0, key);
		}
		this.parameterPairs.put(key, value);

		this.cachedUrl = null;
		this.internalUrl = null;
	}

	public String getUrlParameter(String name) {
		if (name.equals(InternalConstants.URL_PARAMETER_KEY_CR)) {
			return this.crValue;
		}
		return this.parameterPairs.get(name);
	}

	public String getCallbackUrl() {
		if (this.cachedUrl == null) {
			this.cachedUrl = this.baseUrl + "?";

			Iterator<String> iter = this.keys.iterator();
			while (iter.hasNext()) {
				String key = iter.next();
				String value = this.parameterPairs.get(key);
				key = Uri.encode(key);
				if (value != null) {
					this.cachedUrl += key + "=" + Uri.encode(value);
				} else {
					this.cachedUrl += key;
				}

				if(iter.hasNext()) {
					this.cachedUrl += "&";
				}
			}

			// ensure &cr= is the last one
			if(this.crValue != null) {
				this.cachedUrl += "&" + InternalConstants.URL_PARAMETER_KEY_CR
									+ "=" + Uri.encode(this.crValue);
			}
		}
		return this.cachedUrl;
	}

	public String getInternalUrl() {
		if (this.internalUrl == null) {
			this.internalUrl = this.baseUrl + "?";

			if (!this.originalKeys.contains(InternalConstants.URL_PARAMETER_KEY_ET)) { // last added key should be at the head
				this.originalKeys.add(0, InternalConstants.URL_PARAMETER_KEY_ET);
			}
			if (!this.originalKeys.contains(InternalConstants.URL_PARAMETER_KEY_CN)) { // last added key should be at the head
				this.originalKeys.add(0, InternalConstants.URL_PARAMETER_KEY_CN);
			}
			this.originalParameterPairs.put(InternalConstants.URL_PARAMETER_KEY_CN, this.getUrlParameter(InternalConstants.URL_PARAMETER_KEY_CN));
			this.originalParameterPairs.put(InternalConstants.URL_PARAMETER_KEY_ET, this.getUrlParameter(InternalConstants.URL_PARAMETER_KEY_ET));

			Iterator<String> iter = this.originalKeys.iterator();
			while (iter.hasNext()) {
				String key = iter.next();
				String value = this.originalParameterPairs.get(key);

				key = Uri.encode(key);
				if (value != null) {
					this.internalUrl += key + "=" + Uri.encode(value);
				} else {
					this.internalUrl += key;
				}

				if(iter.hasNext()) {
					this.internalUrl += "&";
				}
			}

			// ensure &cr= is the last one
			if(this.crValue != null) {
				this.internalUrl += "&" + InternalConstants.URL_PARAMETER_KEY_CR
									+ "=" + Uri.encode(this.crValue);
			}
		}
		return this.internalUrl;
	}

	public boolean isShowBrowser() {
		return this.callback.showBrowser;
	}

	public void send() {
		if (this.adInstance != null && this.adInstance.getActiveCreativeRendition() != null) {
			this.setParameter(InternalConstants.URL_PARAMETER_KEY_REID, String.valueOf(this.adInstance.getActiveCreativeRendition().creativeRenditionId));
		}
		this.sendRequest(this.getCallbackUrl());
	}

	public void sendTrackingCallbacks() {
		logger.debug("sendTrackingCallbacks()");
		List<String> trackingURLs = this.getTrackingURLs();
		for (String url : trackingURLs) {
			this.sendRequest(url);
		}
	}

	protected void sendRequest(String url) {
		URLRequest request = new URLRequest(this.getExpandedPingbackUrl(url), this.callback.getAdContext().getUserAgent());

		request.method = URLRequest.Method.GET;
		request.contentType = URLRequest.CONTENT_TYPE_TEXT_PLAIN;

		URLLoader loader = new URLLoader();
		loader.load(request);
	}

	public List<String> getTrackingURLs() {
		ArrayList<String> ret = new ArrayList<>();
		ret.addAll(this.callback.trackingURLs);
		ret.addAll(this.externalTrackingURLs);
		return ret;
	}

	public void addExternalTrackingURLs(List<String> urls) {
		logger.info(this + " addExternalTrackingURLs " + urls);
		if (urls != null && !urls.isEmpty()) {
			if (!this.externalTrackingURLs.isEmpty())
				this.externalTrackingURLs.removeAll(urls);
			this.externalTrackingURLs.addAll(urls);
		}
	}

	public List<String> getExternalTrackingURLs(){
		return this.externalTrackingURLs;
	}

	public void setShowBrowserValue(boolean isShowBrowser) {
		this.callback.showBrowser = isShowBrowser;
	}

	public void setAdInstance(AdInstance ad) {
		this.adInstance = ad;
	}

	protected String getExpandedPingbackUrl(String originalUrl) {
		String result = StringUtils.isBlank(originalUrl) ? "" : expandMacrosInString(originalUrl);
		FWURL url = new FWURL(result);
		String cr = url.getParameter(InternalConstants.URL_PARAMETER_KEY_CR);
		if (!StringUtils.isBlank(cr)) {
			url.setParameter(InternalConstants.URL_PARAMETER_KEY_CR, getExpandedPingbackUrl(cr));
		}

		result = url.toString();
		logger.debug("getExpandedPingbackUrl():" + result);
		return result;
	}

	protected String expandMacrosInString(String originalUrl) {
		Pattern macroMatchRegexPattern = Pattern.compile("#c(e?)\\{(.*?)\\}");
		Matcher matcher = macroMatchRegexPattern.matcher(originalUrl);
		while (matcher.find()){
			String macroValue = extractMacroValueWithName(matcher.group(2));
			if (matcher.group(1).equalsIgnoreCase("e")) {
				macroValue = encodeURIComponent(macroValue);
			}
			originalUrl = originalUrl.replaceAll(Pattern.quote(matcher.group()), Matcher.quoteReplacement(macroValue));
		}
		int adManagerVersion = 0;
		String appPackageName = "";
		String fwLimitAdTrackingValue = "";
		if (this.adInstance != null) {
			adManagerVersion = this.adInstance.getAdContext().getAdManager().getVersion();
			appPackageName = this.adInstance.getAdContext().getAppPackageName();
			String[] fwLimitAdTrackingKeyObjects = this.adInstance.getAdContext().valuesForKey(InternalConstants.URL_PARAMETER_KEY_LIMIT_AD_TRACKING);
			if (fwLimitAdTrackingKeyObjects != null && fwLimitAdTrackingKeyObjects.length != 0) {
				fwLimitAdTrackingValue = fwLimitAdTrackingKeyObjects[0];
			}
			String adPlayheadTime=CommonUtil.secondsToHHMMSS(Math.floor(this.adInstance.getPlayheadTime()));
			originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_ADPLAYHEAD), Uri.encode(adPlayheadTime));
		}
		String contentPlayheadTime=CommonUtil.secondsToHHMMSS(getContentPlayheadTime());
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_CONTENTPLAYHEAD), Uri.encode(contentPlayheadTime));
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_MEDIAPLAYHEAD), Uri.encode(contentPlayheadTime));
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_OMIDPARTNER), Uri.encode(InternalConstants.OMSDK_PARTNER_NAME + "/" + adManagerVersion));
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_APIFRAMEWORKS), Uri.encode(getCreativeApisFromRendererManifest()));
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_TIMESTAMP), new SimpleDateFormat("yyyy-MM-dd'T'HH:MM:SS.mmm'Z'").format(new Date()));
		originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_APPBUNDLE), Uri.encode(appPackageName));
		if (!fwLimitAdTrackingValue.isEmpty()) {
			originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_LIMIT_AD_TRACKING), Uri.encode(fwLimitAdTrackingValue));
		} else {
			originalUrl = originalUrl.replaceAll(Pattern.quote(InternalConstants.PINGBACK_MACRO_VAST_LIMIT_AD_TRACKING), "");
		}
		return originalUrl;
	}

	@SuppressLint("DefaultLocale")
	protected String extractMacroValueWithName(String macroName) {
		switch (macroName) {
			case InternalConstants.PINGBACK_MACRO_COMSCORE_PLATFORM_NAME:
				return "android";
			case InternalConstants.PINGBACK_MACRO_COMSCORE_DEVICE_NAME:
				return android.os.Build.DEVICE;
			case InternalConstants.PINGBACK_MACRO_CONTENT_PLAYHEADTIME:
				double contentPlayheadTime = getContentPlayheadTime();
				return  contentPlayheadTime < 0 ? "" : String.format("%.2f", contentPlayheadTime);
			case InternalConstants.PINGBACK_MACRO_AD_PLAYHEADTIME:
				return (adInstance == null || adInstance.getPlayheadTime() < 0) ? "" : String.format("%.2f", adInstance.getPlayheadTime());
			default:
				if (macroName.startsWith(InternalConstants.PINGBACK_MACRO_PARAMETER_PREFIX) && adInstance != null) {
					return "" + this.adInstance.getParameter(macroName.substring(InternalConstants.PINGBACK_MACRO_PARAMETER_PREFIX.length()));
				}
				return "";
		}
	}

	private String getCreativeApisFromRendererManifest() {
		List<String> apiFrameworks = new ArrayList<String>();
		HashSet<String> creativeApiSet = new HashSet<String>();
		if (this.adInstance != null) {
			if (this.adInstance.getAdContext().loadedExtensions.containsKey("tv.freewheel.extension.openmeasurement.OpenMeasurementExtension")) {
				apiFrameworks.add(InternalConstants.IAB_API_FRAMEWORKS_OMID_1);
			}
			List<AdRenderer> adRenderers = this.adInstance.getAdContext().adRenderers;
			for (int i = 0; i < adRenderers.size(); i++) {
				HashSet<String> creativeApi = adRenderers.get(i).getCreativeApi();
				creativeApiSet.addAll(creativeApi);
			}
		}
		Iterator<String> it = creativeApiSet.iterator();
		while(it.hasNext()) {
			String api = it.next();
			if (api.contains("mraid")) {
				apiFrameworks.add(InternalConstants.IAB_API_FRAMEWORKS_MRAID_1);
			}
			if (api.contains("vpaid")) {
				apiFrameworks.add(InternalConstants.IAB_API_FRAMEWORKS_VPAID_2);
			}

		}
		Collections.sort(apiFrameworks);
		return TextUtils.join(",", apiFrameworks);
	}

	protected double getContentPlayheadTime() {
		return adInstance != null ? adInstance.getAdContext().contentPlayheadTime : 0.0;
	}

	protected String encodeURIComponent(String s) {
		String result;

		try {
			result = URLEncoder.encode(s, "UTF-8")
					.replaceAll("\\+", "%20")
					.replaceAll("\\%21", "!")
					.replaceAll("\\%27", "'")
					.replaceAll("\\%28", "(")
					.replaceAll("\\%29", ")")
					.replaceAll("\\%7E", "~");
		} catch (UnsupportedEncodingException e) {
			result = s;
		}

		return result;
	}

}
