package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.utils.StringUtils;

/**
 * Created by rvooda on 11/3/17.
 */

public class AdCallbackHandler extends EventCallbackHandler {
    AdCallbackHandler(EventCallback callback) throws MalformedURLException {
        super(callback);
    }

    @Override
    protected String extractMacroValueWithName(String macroName) {
        String result = super.extractMacroValueWithName(macroName);

        if (StringUtils.isBlank(result)) {
            if (macroName.equalsIgnoreCase(InternalConstants.PINGBACK_MACRO_CREATIVE_ASSET_LOCATION)) {
                result = this.adInstance.getActiveCreativeRendition().getPrimaryCreativRenditionAsset().getURL();
            }
        }

        return result;
    }
}
