package tv.freewheel.ad.handler;

import java.net.MalformedURLException;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallback;
import tv.freewheel.ad.InternalConstants;

public class ResellerNoAdCallbackHandler extends EventCallbackHandler {
	private boolean imprSent = false;
	
	public ResellerNoAdCallbackHandler(EventCallback callback)
			throws MalformedURLException {
		super(callback);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_ET, InternalConstants.SHORT_EVENT_TYPE_IMPRESSION);
		this.setParameter(InternalConstants.URL_PARAMETER_KEY_CN, Constants._EVENT_RESELLER_NO_AD);
	}
	
	@Override
	public void send(){
		if (this.imprSent) {
			return;
		}
		this.imprSent = true;
		super.send();
	}
}
