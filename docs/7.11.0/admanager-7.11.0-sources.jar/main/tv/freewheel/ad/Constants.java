package tv.freewheel.ad;

import tv.freewheel.ad.interfaces.IConstants;

public final class Constants implements IConstants {

	/** Supported VPAID Version */
	public static final double SUPPORTED_CREATIVE_VPAID_VERSION_MIN = 2;

	/** Supported VAST Version */
	public static final int SUPPORTED_CREATIVE_VAST_VERSION_MIN = 2;
	public static final int SUPPORTED_CREATIVE_VAST_VERSION_MAX = 4;

	public static final String MOBILE_RICH_MEDIA_AD_INTERFACE_DEFINITIONS="mraid";

	public static final String _EVENT_REQUEST_INITIATED = "requestInitiated";
	public static final String _EVENT_REQUEST_COMPLETE = "requestComplete";
	public static final String _EVENT_REQUEST_CONTENT_VIDEO_PAUSE = "requestContentVideoPause";
	public static final String _EVENT_REQUEST_CONTENT_VIDEO_RESUME = "requestContentVideoResume";
	public static final String _EVENT_SLOT_STARTED = "slotStarted";
	public static final String _EVENT_SLOT_ENDED = "slotEnded";
	public static final String _EVENT_SLOT_PRELOADED = "slotPreloaded";
	public static final String _EVENT_USER_ACTION_NOTIFIED = "userActionNotified";
	public static final String _EVENT_ACTIVITY_STATE_CHANGED = "activityStateChanged";
	public static final String _EVENT_EXTENSION_LOADED = "extensionLoaded";

	public static final String _ADUNIT_PREROLL	= "PREROLL";
	public static final String _ADUNIT_MIDROLL	= "MIDROLL";
	public static final String _ADUNIT_POSTROLL  = "POSTROLL";
	public static final String _ADUNIT_OVERLAY	= "OVERLAY";
	public static final String _ADUNIT_PAUSE_MIDROLL = "PAUSE_MIDROLL";
	public static final String _ADUNIT_DISPLAY = "DISPLAY";
	public static final String _ADUNIT_UNKNOWN	= "UNKNOWN";

	public static final String _URL_LOCATION = "Location";

	public static final String _ADUNIT_STREAM_PREROLL = "stream_preroll";
	public static final String _ADUNIT_STREAM_POSTROLL = "stream_postroll";

	public static final String _AD_REQUEST_FLAG_CAPABILITY = "flag";
	public static final String _CAPABILITY_SLOT_TEMPLATE = "supportsSlotTemplate";
	public static final String _CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS = "supportsAdUnitInMultipleSlots";
	public static final String _CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION = "bypassCommercialRatioRestriction";
	public static final String _CAPABILITY_CHECK_TARGETING = "checkTargeting";
	public static final String _CAPABILITY_SLOT_CALLBACK = "supportsSlotCallback";
	public static final String _CAPABILITY_RECORD_VIDEO_VIEW = "recordVideoView";
	public static final String _CAPABILITY_RESET_EXCLUSIVITY = "resetExclusivity";
	public static final String _CAPABILITY_SYNC_MULTI_REQUESTS = "synchronizeMultipleRequests";
	public static final String _CAPABILITY_REQUIRES_RENDERER_MANIFEST = "requiresRendererManifest";
	public static final String _CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS = "expectMultipleCreativeRenditions";
	public static final String _CAPABILITY_FALLBACK_ADS = "supportsFallbackAds";

	public static final String _EVENT_SLOT_IMPRESSION		= "slotImpression";
	public static final String _EVENT_SLOT_IMPRESSION_END	= "slotEnd";
	public static final String _EVENT_AD_PREINIT            = "preInit";
	public static final String _EVENT_AD_IMPRESSION			= "defaultImpression";
	public static final String _EVENT_AD_IMPRESSION_END		= "adEnd";
	public static final String _EVENT_AD_QUARTILE			= "quartile";
	public static final String _EVENT_AD_FIRST_QUARTILE		= "firstQuartile";
	public static final String _EVENT_AD_MIDPOINT			= "midPoint";
	public static final String _EVENT_AD_THIRD_QUARTILE		= "thirdQuartile";
	public static final String _EVENT_AD_COMPLETE			= "complete";
	public static final String _EVENT_AD_CLICK				= "defaultClick";
	public static final String _EVENT_AD_MUTE				= "_mute";
	public static final String _EVENT_AD_UNMUTE				= "_un-mute";
	public static final String _EVENT_AD_VOLUME_CHANGED		= "_volume-changed";
	public static final String _EVENT_AD_COLLAPSE			= "_collapse";
	public static final String _EVENT_AD_EXPAND				= "_expand";
	public static final String _EVENT_AD_PAUSE				= "_pause";
	public static final String _EVENT_AD_RESUME				= "_resume";
	public static final String _EVENT_AD_REWIND				= "_rewind";
	public static final String _EVENT_AD_ACCEPT_INVITATION	= "_accept-invitation";
	public static final String _EVENT_AD_CLOSE				= "_close";
	public static final String _EVENT_AD_SKIPPED_BY_USER	= "_skip";
	public static final String _EVENT_AD_PROGRESS			= "_progress";
	public static final String _EVENT_AD_SKIPPABLE_STATE_CHANGED = "skippableStateChanged";
	public static final String _EVENT_AD_MINIMIZE			= "_minimize";
	public static final String _EVENT_AD_LOADED 			= "loaded";
	public static final String _EVENT_AD_STARTED 			= "started";
	public static final String _EVENT_AD_STOPPED 			= "stopped";
	public static final String _EVENT_AD_BUFFERING_START	= "bufferingStart";
	public static final String _EVENT_AD_BUFFERING_END		= "bufferingEnd";
	public static final String _EVENT_AD_MEASUREMENT 		= "concreteEvent";
	public static final String _EVENT_ERROR					= "_e_unknown";
	public static final String _EVENT_RESELLER_NO_AD		= "resellerNoAd";
	public static final String _EVENT_VIDEO_DISPLAY_BASE_CHANGED = "videoDisplayBaseChanged";

	public static final String _EVENT_TYPE_CLICK_TRACKING = "CLICKTRACKING";
	public static final String _EVENT_TYPE_IMPRESSION = "IMPRESSION";
	public static final String _EVENT_TYPE_CLICK = "CLICK";
	public static final String _EVENT_TYPE_STANDARD = "STANDARD";
	public static final String _EVENT_TYPE_API_ONLY = "APIONLY"; // The event is for API only and is not sent as a callback

	public static final String _PARAMETER_CLICK_DETECTION = "renderer.video.clickDetection";
	public static final String _PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK = "enableCountingReplayCallback";
	public static final String _PARAMETER_VIDEO_RENDERER_FORCE_MEDIA_PLAYER = "renderer.video.forceMediaPlayer";
	public static final String _PARAMETER_VIDEO_RENDERER_REQUEST_FOCUS = "renderer.video.requestFocus";
	public static final String _PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT = "renderer.video.playbackUnexpectedPauseTimeout";
	public static final String _PARAMETER_VAST_TIMEOUT_IN_MILLISECONDS = "translator.vast.timeoutInMilliseconds";
	public static final String _PARAMETER_VAST_MAX_WRAPPER_COUNT = "translator.vast.maxWrapperCount";
	public static final String _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HTML = "extension.skippableAd.html";
	public static final String _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_WIDTH = "extension.skippableAd.width";
	public static final String _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HEIGHT = "extension.skippableAd.height";
	public static final String _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_TEXT = "extension.skippableAd.text";
	public static final String _PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START = "timeoutMillisecondsBeforeStart";
	public static final String _PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG = "image.renderer.inPreferredConfig";

	public static final String _INFO_KEY_URL = "url";
	public static final String _INFO_KEY_SLOT_CUSTOM_ID = "customId";
	public static final String _INFO_KEY_MESSAGE = "message";
	public static final String _INFO_KEY_SUCCESS = "success";
	public static final String _INFO_KEY_MODULE_TYPE = "moduleType";
	public static final String _INFO_KEY_MODULE_NAME = "moduleName";
	public static final String _INFO_KEY_EXTRA_INFO = "extraInfo";
	public static final String _INFO_KEY_START_TIME_POSITION = "startTimePosition";
	public static final String _INFO_KEY_REQUIRED_API_VERSION = "requiredAPIVersion";
	public static final String _INFO_KEY_AD_ID = "adId";
	public static final String _INFO_KEY_ADINSTANCE = "adInstance";
	public static final String _INFO_KEY_CONCRETE_EVENT_ID = "concreteEventId";
	public static final String _INFO_KEY_CREATIVE_ID = "creativeId";
	public static final String _INFO_KEY_USER_TRIGGERED_ACTION = "userTriggeredAction";
	public static final String _INFO_KEY_ACTIVITY_STATE = "activityState";
	public static final String _INFO_KEY_ERROR_CODE = "errorCode";
	public static final String _INFO_KEY_ERROR_INFO = "errorInfo";
	public static final String _INFO_KEY_ERROR_MODULE = "errorModule";
	public static final String _INFO_KEY_VOLUME = "volume";
	public static final String _INFO_KEY_VAST_ERROR_CODE = "vastErrorCode";
	public static final String _INFO_KEY_OFFSET = "offset";
	public static final String _INFO_KEY_AD_SKIPPABLE_STATE = "skippableState";

	public static final String _ERROR_IO = "_e_io";
	public static final String _ERROR_TIMEOUT = "_e_timeout";
	public static final String _ERROR_NULL_ASSET = "_e_null-asset";
	public static final String _ERROR_ADINSTANCE_UNAVAILABLE = "_e_adinst-unavail";
	public static final String _ERROR_UNKNOWN = "_e_unknown";
	public static final String _ERROR_MISSING_PARAMETER = "_e_missing-param";
	public static final String _ERROR_NO_AD_AVAILABLE = "_e_no-ad";
	public static final String _ERROR_PARSE = "_e_parse";
	public static final String _ERROR_INVALID_VALUE = "_e_invalid-value";
	public static final String _ERROR_NO_RENDERER = "_e_no-renderer";
	public static final String _ERROR_RENDERER_LOAD = "_e_renderer-load";
	public static final String _ERROR_INVALID_SLOT = "_e_invalid-slot";
	public static final String _ERROR_UNSUPPORTED_3P_FEATURE = "_e_unsupp-3p-feature";
	public static final String _ERROR_RENDERER_INIT = "_e_renderer_init";
	public static final String _ERROR_3P_COMPONENT = "_e_3p-comp";
	public static final String _INFO_KEY_SHOW_BROWSER = "showBrowser";
	public static final String _INFO_KEY_CUSTOM_EVENT_NAME = "customEventName";

	public static final String _PARAMETER_GOOGLE_ADVERTISING_ID = "_fw_did_google_advertising_id";
	public static final String _PARAMETER_FWU_TOPIC = "_fwu_topic";

	public static final String _PARAM_DESIRED_BITRATE = "desiredBitrate";
	public static final String _PARAM_VIDEO_RENDITION_SELECTION_ASPECT_RATIO_RATIO_WEIGHT = "aspectRatioWeight";
	public static final String _PARAM_VIDEO_RENDITION_SELECTION_PIXELATION_WEIGHT = "pixelationWeight";
	public static final String _PARAM_VIDEO_RENDITION_SELECTION_CONVERSION_FACTOR = "conversionFactor";

	public static final String _IAB_CONSENT_STRING = "IABTCF_TCString";
	public static final String _IAB_SUBJECT_TO_GDPR = "IABTCF_gdprApplies";
	public static final String _IAB_US_PRIVACY_STRING = "IABUSPrivacy_String";
	public static final String _IAB_GPP_CMP_API_GPP_STRING = "IABGPP_HDR_GppString";
	public static final String _IAB_GPP_CMP_API_GPP_SID = "IABGPP_GppSID";
	public static final String _IAB_OMSDK_UPDATE_LAST_ACTIVITY = "IABOMSDK_updateLastActivity";


	public enum VastErrors {
		ERROR_VAST_XML_PARSING(100),
		ERROR_VAST_SCHEMA_VALIDATION(101),
		ERROR_VAST_VERSION_NOT_SUPPORTED(102),
		ERROR_VAST_URI_TIMEOUT(301),
		ERROR_VAST_WRAPPER_LIMIT_REACHED(302),
		ERROR_VAST_NO_AD(303);

		private int value;

		VastErrors(int value) {
			this.value = value;
		}

		public String getValue() {
			return Integer.toString(value);
		}
	}

	private static String _PARAMETER_DOUBLE_DECODE_VPAID_URL = "doubleDecodeVPAIDURL";

	public final String EVENT_REQUEST_INITIATED() {
		return _EVENT_REQUEST_INITIATED;
	}
	public final String EVENT_REQUEST_COMPLETE() {
		return _EVENT_REQUEST_COMPLETE;
	}
	public final String EVENT_REQUEST_CONTENT_VIDEO_PAUSE() {
		return _EVENT_REQUEST_CONTENT_VIDEO_PAUSE;
	}
	public final String EVENT_REQUEST_CONTENT_VIDEO_RESUME() {
		return _EVENT_REQUEST_CONTENT_VIDEO_RESUME;
	}
	public final String EVENT_SLOT_STARTED() {
		return _EVENT_SLOT_STARTED;
	}
	public final String EVENT_SLOT_ENDED() {
		return _EVENT_SLOT_ENDED;
	}
	public final String EVENT_SLOT_PRELOADED() {
		return _EVENT_SLOT_PRELOADED;
	}
	public final String EVENT_USER_ACTION_NOTIFIED() {
		return _EVENT_USER_ACTION_NOTIFIED;
	}
	public final String EVENT_ACTIVITY_STATE_CHANGED() {
		return _EVENT_ACTIVITY_STATE_CHANGED;
	}
	public final String EVENT_EXTENSION_LOADED() {
		return _EVENT_EXTENSION_LOADED;
	}
	public final String ADUNIT_PREROLL() {
		return _ADUNIT_PREROLL;
	}
	public final String ADUNIT_MIDROLL() {
		return _ADUNIT_MIDROLL;
	}
	public final String ADUNIT_POSTROLL() {
		return _ADUNIT_POSTROLL;
	}
	public final String ADUNIT_OVERLAY() {
		return _ADUNIT_OVERLAY;
	}
	public final String ADUNIT_PAUSE_MIDROLL() {
		return _ADUNIT_PAUSE_MIDROLL;
	}
	public final String ADUNIT_DISPLAY() {
		return _ADUNIT_DISPLAY;
	}
	public final String ADUNIT_UNKNOWN() {
		return _ADUNIT_UNKNOWN;
	}
	public final String ADUNIT_STREAM_PREROLL() {
		return _ADUNIT_STREAM_PREROLL;
	}
	public final String ADUNIT_STREAM_POSTROLL() {
		return _ADUNIT_STREAM_POSTROLL;
	}

	public final String CAPABILITY_SLOT_TEMPLATE() {
		return _CAPABILITY_SLOT_TEMPLATE;
	}
	public final String CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS() {
		return _CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS;
	}
	public final String CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION() {
		return _CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION;
	}
	public final String CAPABILITY_CHECK_TARGETING() {
		return _CAPABILITY_CHECK_TARGETING;
	}
	public final String CAPABILITY_SLOT_CALLBACK() {
		return _CAPABILITY_SLOT_CALLBACK;
	}
	public final String CAPABILITY_RECORD_VIDEO_VIEW() {
		return _CAPABILITY_RECORD_VIDEO_VIEW;
	}
	public final String CAPABILITY_RESET_EXCLUSIVITY() {
		return _CAPABILITY_RESET_EXCLUSIVITY;
	}
	public final String CAPABILITY_SYNC_MULTI_REQUESTS() {
		return _CAPABILITY_SYNC_MULTI_REQUESTS;
	}
	public final String CAPABILITY_REQUIRES_RENDERER_MANIFEST() {
		return _CAPABILITY_REQUIRES_RENDERER_MANIFEST;
	}
	public final String CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS() {
		return _CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS;
	}
	public final String CAPABILITY_FALLBACK_ADS() {
		return _CAPABILITY_FALLBACK_ADS;
	}
	public final String EVENT_SLOT_IMPRESSION() {
		return _EVENT_SLOT_IMPRESSION;
	}
	public final String EVENT_SLOT_IMPRESSION_END() {
		return _EVENT_SLOT_IMPRESSION_END;
	}
	public final String EVENT_AD_PREINIT() {
		return _EVENT_AD_PREINIT;
	}
	public final String EVENT_AD_IMPRESSION() {
		return _EVENT_AD_IMPRESSION;
	}
	public final String EVENT_AD_IMPRESSION_END() {
		return _EVENT_AD_IMPRESSION_END;
	}
	public final String EVENT_AD_QUARTILE() {
		return _EVENT_AD_QUARTILE;
	}
	public final String EVENT_AD_FIRST_QUARTILE() {
		return _EVENT_AD_FIRST_QUARTILE;
	}
	public final String EVENT_AD_MIDPOINT() {
		return _EVENT_AD_MIDPOINT;
	}
	public final String EVENT_AD_THIRD_QUARTILE() {
		return _EVENT_AD_THIRD_QUARTILE;
	}
	public final String EVENT_AD_COMPLETE() {
		return _EVENT_AD_COMPLETE;
	}
	public final String EVENT_AD_CLICK() {
		return _EVENT_AD_CLICK;
	}
	public final String EVENT_AD_MUTE() {
		return _EVENT_AD_MUTE;
	}
	public final String EVENT_AD_UNMUTE() {
		return _EVENT_AD_UNMUTE;
	}
	public final String EVENT_AD_VOLUME_CHANGED() {
		return _EVENT_AD_VOLUME_CHANGED;
	}
	public final String EVENT_AD_COLLAPSE() {
		return _EVENT_AD_COLLAPSE;
	}
	public final String EVENT_AD_EXPAND() {
		return _EVENT_AD_EXPAND;
	}
	public final String EVENT_AD_PAUSE() {
		return _EVENT_AD_PAUSE;
	}
	public final String EVENT_AD_RESUME() {
		return _EVENT_AD_RESUME;
	}
	public final String EVENT_AD_REWIND() {
		return _EVENT_AD_REWIND;
	}
	public final String EVENT_AD_ACCEPT_INVITATION() {
		return _EVENT_AD_ACCEPT_INVITATION;
	}
	public final String EVENT_AD_CLOSE() {
		return _EVENT_AD_CLOSE;
	}
	public final String EVENT_AD_SKIPPED_BY_USER() {
		return _EVENT_AD_SKIPPED_BY_USER;
	}
	public final String EVENT_AD_PROGRESS() {
		return _EVENT_AD_PROGRESS;
	}
	public final String EVENT_AD_SKIPPABLE_STATE_CHANGED() {
		return _EVENT_AD_SKIPPABLE_STATE_CHANGED;
	}
	public final String EVENT_AD_MINIMIZE() {
		return _EVENT_AD_MINIMIZE;
	}
	public final String EVENT_AD_LOADED() {
		return _EVENT_AD_LOADED;
	}
	public final String EVENT_AD_STARTED() {
		return _EVENT_AD_STARTED;
	}
	public final String EVENT_AD_STOPPED() {
		return _EVENT_AD_STOPPED;
	}
	public final String EVENT_AD_BUFFERING_START() {
		return _EVENT_AD_BUFFERING_START;
	}
	public final String EVENT_AD_BUFFERING_END() {
		return _EVENT_AD_BUFFERING_END;
	}
	public final String EVENT_AD_MEASUREMENT() {
		return _EVENT_AD_MEASUREMENT;
	}
	public final String EVENT_VIDEO_DISPLAY_BASE_CHANGED() {return _EVENT_VIDEO_DISPLAY_BASE_CHANGED; }
	public final String EVENT_ERROR() {
		return _EVENT_ERROR;
	}
	public final String EVENT_RESELLER_NO_AD() {
		return _EVENT_RESELLER_NO_AD;
	}
	public final String EVENT_TYPE_CLICK_TRACKING() {
		return _EVENT_TYPE_CLICK_TRACKING;
	}
	public final String EVENT_TYPE_IMPRESSION() {
		return _EVENT_TYPE_IMPRESSION;
	}
	public final String EVENT_TYPE_CLICK() {
		return _EVENT_TYPE_CLICK;
	}
	public final String EVENT_TYPE_STANDARD() {
		return _EVENT_TYPE_STANDARD;
	}
	public final String PARAMETER_VIDEO_RENDERER_FORCE_MEDIA_PLAYER() {
		return _PARAMETER_VIDEO_RENDERER_FORCE_MEDIA_PLAYER;
	}
	public final String PARAMETER_VIDEO_RENDERER_REQUEST_FOCUS() {
		return _PARAMETER_VIDEO_RENDERER_REQUEST_FOCUS;
	}
	public final String PARAMETER_VAST_TIMEOUT_IN_MILLISECONDS() {
		return _PARAMETER_VAST_TIMEOUT_IN_MILLISECONDS;
	}
	public final String PARAMETER_VAST_MAX_WRAPPER_COUNT() {
		return _PARAMETER_VAST_MAX_WRAPPER_COUNT;
	}
	public final String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_TEXT() {
		return _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_TEXT;
	}
	public final String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HTML() {
		return _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HTML;
	}
	public final String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_WIDTH() {
		return _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_WIDTH;
	}
	public final String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HEIGHT() {
		return _PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HEIGHT;
	}
	public final String PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START() {
		return _PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START;
	}

	public final String PARAMETER_CLICK_DETECTION() {
		return _PARAMETER_CLICK_DETECTION;
	}
	public final String PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT() {
		return _PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT;
	}
	public final String PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK() {
		return _PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK;
	}

	public final String PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG(){
		return _PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG;
	}

	@Override
	public String PARAMETER_DOUBLE_DECODE_VPAID_URL() {
		return _PARAMETER_DOUBLE_DECODE_VPAID_URL;
	}

	public final String INFO_KEY_URL() {
		return _INFO_KEY_URL;
	}
	public final String INFO_KEY_SLOT_CUSTOM_ID() {
		return _INFO_KEY_SLOT_CUSTOM_ID;
	}
	public final String INFO_KEY_MESSAGE() {
		return _INFO_KEY_MESSAGE;
	}
	public final String INFO_KEY_MODULE_TYPE() {
		return _INFO_KEY_MODULE_TYPE;
	}
	public final String INFO_KEY_MODULE_NAME() {
		return _INFO_KEY_MODULE_NAME;
	}
	public final String INFO_KEY_EXTRA_INFO() {
		return _INFO_KEY_EXTRA_INFO;
	}
	public final String INFO_KEY_START_TIME_POSITION() {
		return _INFO_KEY_START_TIME_POSITION;
	}
	public final String INFO_KEY_REQUIRED_SDK_VERSION() {
		return _INFO_KEY_REQUIRED_API_VERSION;
	}
	public final String INFO_KEY_AD_ID() {
		return _INFO_KEY_AD_ID;
	}
	public final String INFO_KEY_CREATIVE_ID() {
		return _INFO_KEY_CREATIVE_ID;
	}
	@Override
	public final String INFO_KEY_USER_TRIGGERED_ACTION() {
		return _INFO_KEY_USER_TRIGGERED_ACTION;
	}
	public final String INFO_KEY_ACTIVITY_STATE() {
		return _INFO_KEY_ACTIVITY_STATE;
	}
	public final String INFO_KEY_ADINSTANCE() {
		return _INFO_KEY_ADINSTANCE;
	}
	public final String INFO_KEY_CONCRETE_EVENT_ID() {
		return _INFO_KEY_CONCRETE_EVENT_ID;
	}
	public final String INFO_KEY_VAST_ERROR_CODE() {
		return _INFO_KEY_VAST_ERROR_CODE;
	}
	public final String INFO_KEY_ERROR_CODE() {
		return _INFO_KEY_ERROR_CODE;
	}
	public final String INFO_KEY_ERROR_INFO() {
		return _INFO_KEY_ERROR_INFO;
	}
	public final String INFO_KEY_ERROR_MODULE() {
		return _INFO_KEY_ERROR_MODULE;
	}
	public final String INFO_KEY_VOLUME() {
		return _INFO_KEY_VOLUME;
	}
	public final String INFO_KEY_OFFSET() {
		return _INFO_KEY_OFFSET;
	}
	public final String INFO_KEY_AD_SKIPPABLE_STATE() {
		return _INFO_KEY_AD_SKIPPABLE_STATE;
	}
	public final String ERROR_IO() {
		return _ERROR_IO;
	}
	public final String ERROR_TIMEOUT() {
		return _ERROR_TIMEOUT;
	}
	public final String ERROR_NULL_ASSET() {
		return _ERROR_NULL_ASSET;
	}
	public final String ERROR_ADINSTANCE_UNAVAILABLE() {
		return _ERROR_ADINSTANCE_UNAVAILABLE;
	}
	public final String ERROR_UNKNOWN() {
		return _ERROR_UNKNOWN;
	}
	public final String ERROR_MISSING_PARAMETER() {
		return _ERROR_MISSING_PARAMETER;
	}
	public final String ERROR_NO_AD_AVAILABLE() {
		return _ERROR_NO_AD_AVAILABLE;
	}
	public final String ERROR_PARSE() {
		return _ERROR_PARSE;
	}
	public final String ERROR_INVALID_VALUE() {
		return _ERROR_INVALID_VALUE;
	}
	public final String ERROR_NO_RENDERER() {
		return _ERROR_NO_RENDERER;
	}
	public final String ERROR_INVALID_SLOT() {
		return _ERROR_INVALID_SLOT;
	}
	public final String ERROR_UNSUPPORTED_3P_FEATURE() {
		return _ERROR_UNSUPPORTED_3P_FEATURE;
	}
	public final String ERROR_RENDERER_INIT() {
		return _ERROR_RENDERER_INIT;
	}
	public final String ERROR_3P_COMPONENT() {
		return _ERROR_3P_COMPONENT;
	}
	public final String INFO_KEY_SHOW_BROWSER() {
		return _INFO_KEY_SHOW_BROWSER;
	}
	public final String INFO_KEY_CUSTOM_EVENT_NAME() {
		return _INFO_KEY_CUSTOM_EVENT_NAME;
	}
	public String INFO_KEY_SUCCESS() {
		return _INFO_KEY_SUCCESS;
	}

	public String PARAMETER_GOOGLE_ADVERTISING_ID() {
		return _PARAMETER_GOOGLE_ADVERTISING_ID;
	}

	public String PARAMETER_FWU_TOPIC() {
		return _PARAMETER_FWU_TOPIC;
	}

	public String PARAM_DESIRED_BITRATE() { return _PARAM_DESIRED_BITRATE; }
	public String PARAM_VIDEO_RENDITION_SELECTION_ASPECT_RATIO_RATIO_WEIGHT() {
		return _PARAM_VIDEO_RENDITION_SELECTION_ASPECT_RATIO_RATIO_WEIGHT;
	}
	public String PARAM_VIDEO_RENDITION_SELECTION_PIXELATION_WEIGHT() {
		return _PARAM_VIDEO_RENDITION_SELECTION_PIXELATION_WEIGHT;
	}
	public String PARAM_VIDEO_RENDITION_SELECTION_CONVERSION_FACTOR() {
		return _PARAM_VIDEO_RENDITION_SELECTION_CONVERSION_FACTOR;
	}
	public String IAB_CONSENT_STRING() {
		return _IAB_CONSENT_STRING;
	}
	public String IAB_SUBJECT_TO_GDPR() {
		return _IAB_SUBJECT_TO_GDPR;
	}

	public String IAB_US_PRIVACY_STRING() {
		return _IAB_US_PRIVACY_STRING;
	}
	public String IAB_GPP_CMP_API_GPP_STRING() {
		return _IAB_GPP_CMP_API_GPP_STRING;
	}
	public String IAB_GPP_CMP_API_GPP_SID() {
		return _IAB_GPP_CMP_API_GPP_SID;
	}
	public String IAB_OMSDK_UPDATE_LAST_ACTIVITY() {
		return _IAB_OMSDK_UPDATE_LAST_ACTIVITY;
	}

}
