package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;

public class Ad extends AdContextScoped {
	public List<Creative> creatives;
	public int adId;
	public String soAdUnit;
	public boolean noLoad;
	public boolean isRequiredToShow;
	public String externalAdId;

	private static final Logger logger = Logger.getLogger(Ad.class, true);

	public Ad(AdContext context) {
		super(context);
		this.creatives = new ArrayList<>();
		this.adId = 0;
		this.soAdUnit = null;
		this.noLoad = false;
		this.isRequiredToShow = false;
	}
	
	public void parse(Element node) {
		this.adId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_ID));
		this.soAdUnit = node.getAttribute(InternalConstants.ATTR_AD_ADUNIT);
		this.noLoad = StringUtils.parseBoolean(node.getAttribute(InternalConstants.ATTR_AD_NO_LOAD), false);
		this.externalAdId = node.hasAttribute(InternalConstants.ATTR_AD_EXTERNAL_AD_ID) ? node.getAttribute(InternalConstants.ATTR_AD_EXTERNAL_AD_ID) : "";
		if (node.hasAttribute(InternalConstants.ATTR_AD_REFERENCE_REQUIRED)) {
			this.isRequiredToShow = node.getAttribute(InternalConstants.ATTR_AD_REFERENCE_REQUIRED).equalsIgnoreCase("true");
		}
		
		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_CREATIVES)){
					this.parseCreatives((Element)childNode);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	private void parseCreatives(Element node) {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_CREATIVE)){
					Creative creative = new Creative(this.context);
					creative.parse((Element) childNode);
					this.creatives.add(creative);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}
	
	public Creative getCreative(int creativeId) {
		Iterator<Creative> iter = this.creatives.iterator();
		
		while (iter.hasNext()) {
			Creative creative = iter.next();
			if (creative.creativeId == creativeId) {
				return creative;
			}
		}

		return null;
	}
	
	public Ad cloneForTranslation() {
		Ad clone = new Ad(this.context);
		clone.adId = this.adId;
		clone.soAdUnit = this.soAdUnit;
		clone.isRequiredToShow = this.isRequiredToShow;
		clone.externalAdId = this.externalAdId;
		for(int i = 0; i < this.creatives.size(); i++) {
			clone.creatives.add(this.creatives.get(i).cloneForTranslation());
		}
		// For ads are cloned, noLoad won't be cloned.
		return clone;
	}
}
