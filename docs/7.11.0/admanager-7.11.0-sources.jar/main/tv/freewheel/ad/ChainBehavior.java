package tv.freewheel.ad;

import tv.freewheel.ad.state.AdState;
import tv.freewheel.ad.state.SlotState;

public abstract class ChainBehavior {
	private static ChainBehavior preloadBehavior = null;
	private static ChainBehavior playBehavior = null;
	
	public static ChainBehavior getPreloadBehavior() {
		if (preloadBehavior == null) {
			preloadBehavior = new PreloadChainBehavior();
		}
		return preloadBehavior;
	}
	
	public static ChainBehavior getPlayBehavior() {
		if (playBehavior == null) {
			playBehavior = new PlayChainBehavior();
		}
		
		return playBehavior;
	}
	
	public abstract SlotState relatedSlotState();
	
	public abstract boolean isChainStopper(AdInstance adInstance);
	
	public abstract boolean isDestState(AdState adState);
}
