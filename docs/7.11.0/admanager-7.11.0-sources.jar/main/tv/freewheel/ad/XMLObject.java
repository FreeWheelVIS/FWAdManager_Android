package tv.freewheel.ad;

import tv.freewheel.utils.XMLElement;

public interface XMLObject {
	public abstract XMLElement buildXMLElement();
}
