package tv.freewheel.ad;

import tv.freewheel.renderers.vast.model.AbstractCustomExtension;

/**
 * An abstraction of the IAB definition of Extension. Extensions enable custom integrations which cannot be covered in the scope of VAST spec. For more details on the VAST Extensions, please refer to https://www.iab.com/wp-content/uploads/2015/11/VAST-2_0-FINAL.pdf.
 */

public class Extension extends AbstractCustomExtension {

	/**
	 * Get the extension type
	 *
	 * @return a String of the extension type, could be null if type is not available in extension node.
	 */
	public String getType() {
		return type;
	}
	/**
	 * Get the extension value
	 *
	 * @return a String of the extension value, which should be a Custom XML object. Could be null if the extension is empty.
	 */
	public String getValue() {
		return value;
	}
	/**
	 * Get the extension owner
	 *
	 * @return a String of the extension owner. Could be null if owner information is unavailable
	 */
	public String getOwner() {
		return owner;
	}
}
