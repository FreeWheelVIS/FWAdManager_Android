package tv.freewheel.ad.slot;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLElement;

public class TemporalSlot extends Slot {
	protected static final String BLACK_BACKGROUND_TAG = "tv.freewheel.SLOT_BLACK_BACKGROUND_TAG";
	public double timePosition;
	public int cuePointSequence;
	public int breakSequence;
	public double maxDuration;
	public double minDuration;
	public int maxAds;
	public double embeddedAdsDuration;
	public double endTimePosition;
	protected View blackBackgroundView;

	private static final Logger logger = Logger.getLogger(TemporalSlot.class, true);

	public TemporalSlot(final AdContext context, IConstants.SlotType type) {
		super(context, type);
	}

	public void init(String customId, String adUnit, double timePosition,
					 String slotProfile, int cuePointSequence, double maxDuration,
					 String acceptPrimaryContentType,
					 String acceptContentType,
					 double minDuration, int maxAds) {

		super.init(customId, adUnit, slotProfile,
				acceptContentType, acceptPrimaryContentType);
		this.timePosition = timePosition;
		this.cuePointSequence = cuePointSequence;
		this.maxDuration = maxDuration;
		this.minDuration = minDuration;
		this.maxAds = maxAds;
		this.embeddedAdsDuration = -1;
		this.endTimePosition = -1;
		this.blackBackgroundView = null;
		this.breakSequence = 0;
	}

	@Override
	public TemporalSlot copy() {
		TemporalSlot slot = (TemporalSlot)super.copy();
		slot.maxDuration = this.maxDuration;
		slot.timePosition = this.timePosition;
		slot.cuePointSequence = this.cuePointSequence;
		slot.minDuration = this.minDuration;
		slot.maxAds = this.maxAds;
		slot.embeddedAdsDuration = this.embeddedAdsDuration;
		slot.endTimePosition = this.endTimePosition;
		slot.breakSequence = this.breakSequence;
		return slot;
	}

	@Override
	protected void setTimePositionClass(String adUnit) {
		if (adUnit.equalsIgnoreCase(Constants._ADUNIT_PREROLL)) {
			this.timePositionClass = IConstants.TimePositionClass.PREROLL;
		} else if (adUnit.equalsIgnoreCase(Constants._ADUNIT_MIDROLL)) {
			this.timePositionClass = IConstants.TimePositionClass.MIDROLL;
		} else if (adUnit.equalsIgnoreCase(Constants._ADUNIT_POSTROLL)) {
			this.timePositionClass = IConstants.TimePositionClass.POSTROLL;
		} else if (adUnit.equalsIgnoreCase(Constants._ADUNIT_OVERLAY)) {
			this.timePositionClass = IConstants.TimePositionClass.OVERLAY;
		} else if(adUnit.equalsIgnoreCase(Constants._ADUNIT_PAUSE_MIDROLL)) {
			this.timePositionClass = IConstants.TimePositionClass.PAUSE_MIDROLL;
		}
	}

	@Override
	protected HashMap<String, String> buildTypeBQueryMap () {
		HashMap<String, String> map = super.buildTypeBQueryMap();
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOTS,
				InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT);
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_TIME_POSITION,
				this.timePosition);
		if (this.maxDuration > 0) {
			CommonUtil.appendQueryToMap(map,
					InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_MAX_SLOT_DURATION,
					this.maxDuration);
		}
		if (this.minDuration > 0) {
			CommonUtil.appendQueryToMap(map,
					InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_MIN_SLOT_DURATION,
					this.minDuration);
		}
		if (this.maxAds > 0) {
			CommonUtil.appendQueryToMap(map,
					InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_MAX_ADS,
					this.maxAds);
		}
		if (this.cuePointSequence > 0) {
			CommonUtil.appendQueryToMap(map,
					InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_CUE_POINT_SEQUENCE,
					this.cuePointSequence);
		}
		return map;
	}

	@Override
	public XMLElement buildXMLElement() {
		XMLElement node = new XMLElement(InternalConstants.TAG_TEMPORAL_AD_SLOT);
		super.buildXMLElement(node);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_TIME_POSITION,
				this.timePosition);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_MAX_SLOT_DURATION,
				this.maxDuration, true);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_MIN_SLOT_DURATION,
				this.minDuration, true);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_MAX_ADS,
				this.maxAds, true);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_CUE_POINT_SEQUENCE,
				this.cuePointSequence, true);
		node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_BREAK_SEQUENCE,
				this.breakSequence, true);
		if (!StringUtils.isBlank(this.signalId)) {
			node.setAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_SIGNAL_ID, this.signalId);
		}

		return node;
	}

	@Override
	public void parse(Element node) throws IllegalAdResponseException {
		this.timePosition = StringUtils.parseDouble(node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_TIME_POSITION));
		double parsedEmbeddedAdsDuration = StringUtils.parseDouble(node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_EMBEDDED_ADS_DURATION), (double) -1);
		this.embeddedAdsDuration = parsedEmbeddedAdsDuration >= 0? parsedEmbeddedAdsDuration : -1;
		double parsedEndTimePosition = StringUtils.parseDouble(node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_END_TIME_POSITION), (double) -1);
		this.endTimePosition = parsedEndTimePosition >= this.timePosition? parsedEndTimePosition : -1;
		this.cuePointSequence = StringUtils.parseInt(node.getAttribute(
				InternalConstants.ATTR_TEMPORAL_AD_SLOT_CUE_POINT_SEQUENCE));
		String timePositionClassStr = node.getAttribute(
				InternalConstants.ATTR_TEMPORAL_AD_SLOT_TIME_POSITION_CLASS).toUpperCase();
		this.setTimePositionClass(timePositionClassStr);
		super.parse(node);
	}

	@Override
	public double getTimePosition() {
		return this.timePosition;
	}

	@Override
	public double getEmbeddedAdsDuration() {
		return this.embeddedAdsDuration;
	}

	@Override
	public double getEndTimePosition() {
		return this.endTimePosition;
	}

	@Override
	public void onStartPlay() {
		if (isLinear() && !this.getAdInstances().isEmpty()) {
			Handler handler = new Handler(Looper.getMainLooper());
			handler.post(new Runnable() {
				public void run() {
					addBlackBackgroundView();
				}
			});
		}
		if (this.timePositionClass == IConstants.TimePositionClass.MIDROLL && !this.getAdInstances().isEmpty()) {
			this.context.requestContentPause(this);
		}
		super.onStartPlay();
	}

	@Override
	public void onComplete() {
		logger.info("onComplete");
		if (isLinear()) {
			Handler handler = new Handler(Looper.getMainLooper());
			handler.post(new Runnable() {
				@Override
				public void run() {
					removeBlackBackgroundView();
				}
			});
		}
		if (this.timePositionClass == IConstants.TimePositionClass.MIDROLL) {
			this.context.requestContentResume(this);
		}
		super.onComplete();
	}

	@Override
	public ViewGroup getBase() {
		return this.context.getTemporalSlotBase();
	}

	@Override
	public int getHeight() {
		FrameLayout slotBase = this.context.getTemporalSlotBase();
		if (slotBase != null) {
			DisplayMetrics dm = this.context.getActivity().getResources().getDisplayMetrics();
			return slotBase.getHeight() > 0 ? (int)(slotBase.getHeight() / dm.density) : -1;
		} else {
			return -1;
		}
	}

	@Override
	public int getWidth() {
		FrameLayout slotBase = this.context.getTemporalSlotBase();
		if (slotBase != null) {
			DisplayMetrics dm = this.context.getActivity().getResources().getDisplayMetrics();
			return slotBase.getWidth() > 0 ? (int)(slotBase.getWidth() / dm.density) : -1;
		} else {
			return -1;
		}
	}

	@Override
	public List<IAdInstance> getAdInstances() {
		ArrayList<tv.freewheel.ad.interfaces.IAdInstance> ret = new ArrayList<>();
		for (AdInstance adInstance: this.getAdInstancesInPlayPlan()) {
			ret.add(adInstance);
		}
		return ret;
	}

	@Override
	public void play() {
		super.play();
	}

	@Override
	public void pause() {
		logger.debug("pause");
		this.state.pause(this);
	}

	@Override
	public void resume() {
		logger.debug("resume");
		this.state.resume(this);
	}

	protected void addBlackBackgroundView() {
		if (getBase() == null)
			return;
		if(blackBackgroundView == null) {
			blackBackgroundView = new View(getBase().getContext());
			blackBackgroundView.setBackgroundColor(Color.BLACK);
			blackBackgroundView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		}

		if (blackBackgroundView.getParent() != null) {
			((ViewGroup)blackBackgroundView.getParent()).removeView(blackBackgroundView);
		}
		
		getBase().addView(blackBackgroundView);
		blackBackgroundView.bringToFront();
	}

	protected void removeBlackBackgroundView() {
		if(blackBackgroundView != null && blackBackgroundView.getParent() != null) {
			((ViewGroup)blackBackgroundView.getParent()).removeView(blackBackgroundView);
			blackBackgroundView = null;
		}
	}

	public void onUpdatedSlotBase(){
		if(blackBackgroundView != null) {
			addBlackBackgroundView();
		}
		this.currentPlayingAdInstance.renderer.resize();
	}
}
