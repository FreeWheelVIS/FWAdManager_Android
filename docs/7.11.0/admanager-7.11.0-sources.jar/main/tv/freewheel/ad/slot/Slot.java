package tv.freewheel.ad.slot;

import android.view.ViewGroup;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tv.freewheel.ad.AdChain;
import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.EventCallbackHolder;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.XMLObject;
import tv.freewheel.ad.handler.SlotImpressionCallbackHandler;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.state.SlotEndedState;
import tv.freewheel.ad.state.SlotInitState;
import tv.freewheel.ad.state.SlotPauseState;
import tv.freewheel.ad.state.SlotPlayingState;
import tv.freewheel.ad.state.SlotPreloadingState;
import tv.freewheel.ad.state.SlotState;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLElement;
import tv.freewheel.utils.events.Event;

public class Slot extends EventCallbackHolder implements XMLObject, ISlot {
	public String customId;
	public String adUnit;
	public String slotProfile;
	public String acceptContentType;
	public String acceptPrimaryContentType;
	public IConstants.TimePositionClass timePositionClass;
	public IConstants.SlotType type;
	public int width;
	public int height;
	public SlotState state;
	public SlotImpressionCallbackHandler slotStartCallbackHandler;
	public SlotImpressionCallbackHandler slotEndCallbackHandler;
	public Map<String, Object> parameters;
	public AdInstance currentPlayingAdInstance;
	protected ViewGroup displayBase;
	private double lastPlayheadTime = 0.;
	public List<AdChain> adChains;
	public String signalId;

	private static final Logger logger = Logger.getLogger(Slot.class, true);

	public Slot(final AdContext context, IConstants.SlotType type) {
		super(context);
		this.type = type;
		this.parameters = new HashMap<>();
		state = SlotInitState.Instance();
		this.adChains = new ArrayList<>();
	}

	public void init(String customId, String adUnit, String slotProfile, String acceptContentType, String acceptPrimaryContentType) {
		this.customId = customId;
		this.adUnit = adUnit;
		this.slotProfile = slotProfile;
		this.acceptContentType = acceptContentType;
		this.acceptPrimaryContentType = acceptPrimaryContentType;
		if (this.adUnit == null) {
			this.adUnit = Constants._ADUNIT_UNKNOWN;
		}
		this.setTimePositionClass(this.adUnit);
	}

	public Slot copy() {
		Slot slot = null;
		try {
			slot = (Slot)this.getClass().getConstructor(AdContext.class, IConstants.SlotType.class).newInstance(this.context, this.type);
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
		slot.width = this.width;
		slot.height = this.height;
		slot.customId = this.customId;
		slot.adUnit = this.adUnit;
		slot.slotProfile = this.slotProfile;
		slot.timePositionClass = this.timePositionClass;
		slot.acceptContentType = this.acceptContentType;
		slot.acceptPrimaryContentType = this.acceptPrimaryContentType;
		return slot;
	}

	protected HashMap<String, String> buildTypeBQueryMap() {
		// Limitation - Accept Content Type Not supported
		// Limitation - Time Position Class is not supported
		HashMap<String, String> map = new HashMap<String, String>();
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_NON_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE, this.slotProfile);
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_SLOT_CUSTOM_ID, this.customId);
		if (!this.adUnit.equals(Constants._ADUNIT_UNKNOWN)) {
			CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_SLOT_ADUNIT, this.adUnit);
		}
		if (this.acceptPrimaryContentType != null && !this.acceptPrimaryContentType.isEmpty()) {
			CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_ACCEPT_PRIMARY_CONTENT_TYPE, this.acceptPrimaryContentType);
		}

		if (!StringUtils.isBlank(this.signalId)) {
			CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOT_SIGNAL_ID, this.signalId);
		}

		return map;
	}

	public String toTypeBString() {
		return StringUtils.convertMapToURLQueryString(this.buildTypeBQueryMap());
	}

	protected XMLElement buildXMLElement(XMLElement node) {
		node.setAttribute(InternalConstants.ATTR_AD_SLOT_PROFILE, this.slotProfile);
		node.setAttribute(InternalConstants.ATTR_CUSTOM_ID, this.customId);
		if (!this.adUnit.equals(Constants._ADUNIT_UNKNOWN)) {
			node.setAttribute(InternalConstants.ATTR_AD_SLOT_AD_UNIT, this.adUnit);
		}
		String[] primaryContentTypes = new String[0];
		String[] contentTypes = primaryContentTypes;

		if ((StringUtils.isBlank(this.acceptPrimaryContentType) && StringUtils.isBlank(this.context.playerProfile)) &&
				(this.type == IConstants.SlotType.NON_TEMPORAL && (this.context.defaultSiteSectionSlotProfile == null || this.context.defaultSiteSectionSlotProfile.equals("")))) {
			this.acceptPrimaryContentType = "text/html_doc_lit_mobile";
		}
		if (this.acceptPrimaryContentType != null) {
			primaryContentTypes = this.acceptPrimaryContentType.split(",");
		}
		if (this.acceptContentType != null) {
			contentTypes = this.acceptContentType.split(",");
		}
		if (primaryContentTypes.length > 0 || contentTypes.length > 0) {
			XMLElement child = buildContentTypeElement(primaryContentTypes, contentTypes);
			node.appendChild(child);
		}

		return node;
	}

	protected static XMLElement buildContentTypeElement(String[] primaryContentTypes,
														String[] contentTypes) {
		XMLElement node = new XMLElement(InternalConstants.TAG_CONTENT_TYPES);

		int length = primaryContentTypes.length;
		for (int i = 0; i < length; ++i) {
			XMLElement pc = new XMLElement(InternalConstants.TAG_ACCEPT_PRIMARY_CONTENT_TYPE);
			pc.setAttribute(InternalConstants.ATTR_ACCEPT_PRIMARY_CONTENT_TYPE_ID,
					primaryContentTypes[i].trim());
			node.appendChild(pc);
		}

		length = contentTypes.length;
		for (int j = 0; j < length; ++j) {
			XMLElement c = new XMLElement(InternalConstants.TAG_ACCEPT_CONTENT_TYPE);
			c.setAttribute(InternalConstants.ATTR_ACCEPT_CONTENT_TYPE_ID,
					contentTypes[j].trim());
			node.appendChild(c);
		}

		return node;
	}

	protected void setTimePositionClass(String adUnit) {
		// must be override
	}

	public XMLElement buildXMLElement() {
		return null;
	}

	public void parse(Element node) throws IllegalAdResponseException {
		this.customId = node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_CUSTOM_ID);
		this.adUnit = node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_AD_UNIT);
		this.signalId = node.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_SIGNAL_ID);

		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();

				if (name.equals(InternalConstants.TAG_AD_SELECTEDADS)){
					this.parseSelectedAds((Element) childNode);
				} else if (name.equals(InternalConstants.TAG_EVENT_CALLBACKS)) {
					this.parseEventCallbacks((Element)childNode);

					this.slotStartCallbackHandler = (SlotImpressionCallbackHandler) this.createEventHandler(Constants._EVENT_SLOT_IMPRESSION, Constants._EVENT_TYPE_IMPRESSION, false);
					if (this.slotStartCallbackHandler != null) {
						this.slotStartCallbackHandler.setSlot(this);
					}

					this.slotEndCallbackHandler = (SlotImpressionCallbackHandler) this.createEventHandler(Constants._EVENT_SLOT_IMPRESSION_END, Constants._EVENT_TYPE_IMPRESSION, false);
					if (this.slotEndCallbackHandler != null) {
						this.slotEndCallbackHandler.setSlot(this);
					}
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	private void parseSelectedAds(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_AD_REFERENCE)){
					AdInstance adInstance = new AdInstance(this.context);
					adInstance.slot = this;
					adInstance.parse((Element)childNode);
					AdChain adChain = adInstance.buildAdChain();
					this.adChains.add(adChain);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	public String getCustomId() {
		return this.customId;
	}

	@Override
	public IConstants.SlotType getSlotType() {
		return this.type;
	}

	public double getTimePosition() {
		return -1;
	}

	/**
	 * @deprecated Please get time position class from SlotConfiguration object instead
	 */
	@Override
	public IConstants.TimePositionClass getSlotTimePositionClass() {
		return this.timePositionClass;
	}

	public double getEmbeddedAdsDuration() {
		return -1;
	}

	public double getEndTimePosition() {
		return -1;
	}

	public int getWidth() {
		return this.width;
	}

	public int getHeight() {
		return this.height;
	}

	public double getTotalDuration() {
		double totalDuration = 0.;
		for(AdInstance adInstance:this.getAdInstancesInPlayPlan()){
			totalDuration += adInstance.getDuration();
		}
		return totalDuration;
	}

	public double getPlayheadTime() {
		if (this.state == SlotInitState.Instance()) {
			lastPlayheadTime = 0.;
		}else if (this.state == SlotEndedState.Instance()) {
			lastPlayheadTime = this.getTotalDuration();
		}else if (this.currentPlayingAdInstance != null) {
			double currentTime = this.currentPlayingAdInstance.getPlayheadTime();
			double totalPlayheadTime = 0.;
			for(AdInstance adInstance:this.getAdInstancesInPlayPlan()){
				if(adInstance == this.currentPlayingAdInstance)
					break;
				else
					totalPlayheadTime += adInstance.getDuration();
			}
			double slotTotalDurationTime = this.getTotalDuration();
			totalPlayheadTime += currentTime;
			lastPlayheadTime = totalPlayheadTime>slotTotalDurationTime?slotTotalDurationTime:totalPlayheadTime;
		}
		return lastPlayheadTime;
	}

	public void play() {
		List<IAdInstance> adInstances = this.getAdInstances();
		for(IAdInstance adInstance : adInstances) {
			AdInstance adi = ((AdInstance) adInstance);
			adi.isSkipped = false;
			adi.setLastFiredProgress(-1);
		}
		this.state.play(this);
	}

	public void preload() {
		this.state.preload(this);
	}

	public void stop() {
		this.state.stop(this);
	}

	public void onStartPlay() {
		logger.info("onStartPlay");
		this.dispatchSlotEvent(Constants._EVENT_SLOT_STARTED);

		this.playAd();
	}

	public void onStopPlay() {
		logger.info("onStopPlay");

		if (this.currentPlayingAdInstance != null) {
			this.currentPlayingAdInstance.stop();
		}
		// Logic to ensure that preloading renderers are disposed
		List<IAdInstance> adInstances = this.getAdInstances();
		for (IAdInstance ad : adInstances) {
			AdInstance adInstance = (AdInstance) ad;
			if (adInstance != this.currentPlayingAdInstance) {
				adInstance.stop();
			}
		}
	}

	public void onPausePlay() {
		logger.info("onPausePlay");
		if (this.currentPlayingAdInstance != null) {
			this.currentPlayingAdInstance.pause();
		}
	}

	public void onResumePlay() {
		logger.info("onResumePlay");
		if (this.currentPlayingAdInstance != null) {
			this.currentPlayingAdInstance.resume();
		}
	}

	public void playAd() {
		logger.info("playAd");
		this.currentPlayingAdInstance = this.findNextAdToWork(null);
		if (this.currentPlayingAdInstance != null) {
			this.currentPlayingAdInstance.play();
		} else {
			logger.warn("no playable ad");
			this.state.complete(this);
		}
	}

	public void pause() {
		logger.debug("pause");
	}

	public void resume() {
		logger.debug("resume");
	}

	public void skipCurrentAd() {
		logger.info("skipCurrentAd");
		if (this.currentPlayingAdInstance != null) {
			this.currentPlayingAdInstance.isSkipped = true;
			this.currentPlayingAdInstance.dispatchEvent(Constants._EVENT_AD_SKIPPED_BY_USER);
			this.currentPlayingAdInstance.stop();
		} else {
			logger.info("current ad is null , ignore this skip request");
		}
	}

	@Override
	public String toString() {
		return String.format("[Slot hashCode: %s, customId:%s, timePositionClass:%s, slotType:%s, adUnit:%s, width:%s, height:%s, state:%s]",
				hashCode(), customId, timePositionClass, type, adUnit, width, height, state);
	}

	public void setParameter(String name, Object value) {
		logger.debug("setParameter(name:" + name + " value:" + value + ") " + this);
		if (name == null) {
			return;
		}
		if (value == null) {
			this.parameters.remove(name);
			return;
		}
		this.parameters.put(name, value);
	}

	public boolean isPreloading() {
		return this.state == SlotPreloadingState.Instance();
	}

	public boolean isPlaying() {
		return this.state == SlotPlayingState.Instance();
	}

	public boolean isPaused() {
		return this.state == SlotPauseState.Instance();
	}

	public ViewGroup getBase() {
		// will be override by subclass
		return null;
	}

	public List<IAdInstance> getAdInstances() {
		// will be override by subclass
		return new ArrayList<>();
	}

	@Override
	public String getSignalId() {
		return this.signalId;
	}

	public List<AdInstance> getAdInstancesInPlayPlan(boolean withTranslator) {
		ArrayList<AdInstance> ret = new ArrayList<AdInstance>();
		boolean foundPlayable = false;
		for (AdChain adChain : this.adChains) {
			for (AdInstance ad : adChain.adInstances) {
				if (!foundPlayable && ad.isPlayable()) {
					if (!ad.scheduledDrivingAd) {
						ret.add(ad);
						foundPlayable = true;
					}
				}
				if (withTranslator && ad.scheduledDrivingAd) {
					ret.add(ad);
				}
			}
			foundPlayable = false;
		}
		logger.debug(this + " getAdInstancesInPlayPlan() withTranslator:" + withTranslator + ", returning " + ret);
		return ret;
	}

	public List<AdInstance> getAdInstancesInPlayPlan() {
		return this.getAdInstancesInPlayPlan(false);
	}

	public void onComplete() {
		logger.info("onComplete");
		currentPlayingAdInstance = null;
		this.dispatchSlotEvent(Constants._EVENT_SLOT_ENDED);
	}

	protected void dispatchSlotEvent(String eventName) {
		if (Constants._EVENT_SLOT_STARTED.equalsIgnoreCase(eventName) && this.slotStartCallbackHandler != null) {
			this.slotStartCallbackHandler.send();
		} else if (Constants._EVENT_SLOT_ENDED.equalsIgnoreCase(eventName) && this.slotEndCallbackHandler != null) {
			this.slotEndCallbackHandler.send();
		}
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Constants._INFO_KEY_MESSAGE, this.customId);
		data.put(Constants._INFO_KEY_SLOT_CUSTOM_ID, this.customId);
		this.context.dispatchEvent(new Event(eventName, data));
	}

	public boolean isPauseMidroll() {
		return this.timePositionClass == IConstants.TimePositionClass.PAUSE_MIDROLL;
	}

	public boolean isLinear(){
		return this.timePositionClass == IConstants.TimePositionClass.PREROLL ||
				this.timePositionClass == IConstants.TimePositionClass.MIDROLL ||
				this.timePositionClass == IConstants.TimePositionClass.POSTROLL;
	}

	public void onPreloading() {
		logger.debug("onPreloading");
		AdInstance ad = this.findNextAdToWork(null);
		if (ad != null) {
			ad.preload();
		} else {
			this.dispatchSlotEvent(Constants._EVENT_SLOT_PRELOADED);
		}
	}

	protected AdInstance findNextAdToWork(AdInstance from) {
		logger.debug(this + " findNextAdToWork() from:" + from);
		if (from == null) {
			return findNextPlayableAd(null);
		}
		if (from.slot != this) {
			logger.error(this + "findNextAdToWork() AdInstance " + from + " does not belong to slot " + this);
			return null;
		}

		AdInstance next = null;
		if (this.state == from.adChain.relatedSlotState()) {
			if (from.adChain.isChainStopper(from)) {
				logger.debug(this + " findNextAdToWork() met chain stopper " + from);
				from = from.adChain.getLastAdInstanceInChain();
			}
			next = this.findNextPlayableAd(from);
		} else {
			logger.debug(this + "findNextAdToWork() slot state is not " + from.adChain.relatedSlotState() + ", so won't continue");
		}
		logger.debug(this + "findNextAdToWork() returning " + next);
		return next;
	}

	private AdInstance findNextPlayableAd(AdInstance from) {
		logger.debug(this + " findNextPlayableAd() from:" + from);
		AdInstance ret = null;
		int chainIndex = -1;
		if (from != null) {
			chainIndex = this.adChains.indexOf(from.adChain);
		} else {
			chainIndex = 0;
		}
		logger.debug(this + " findNextPlayableAd() look from chain index " + chainIndex + " chain size:" + this.adChains.size());
		AdChain chain = null;
		for (int i = chainIndex; i < this.adChains.size(); ++i) {
			chain = this.adChains.get(i);
			ret = chain.findNextPlayableAd(from);
			if (ret != null) {
				break;
			}
		}
		logger.debug(this + " findNextPlayableAd() returning " + ret);
		return ret;
	}

	public void notifyAdDone(AdInstance ad) {
		logger.debug(this + " notifyAdDone() " + ad);
		AdInstance nextAd = this.findNextAdToWork(ad);
		if (nextAd != null) {
			logger.debug(this + " notifyAdDone() found next ad " + nextAd);
			if (this.state == SlotPreloadingState.Instance()) {
				nextAd.preload();
			} else if (state == SlotPlayingState.Instance()) {
				this.currentPlayingAdInstance = nextAd;
				nextAd.play();
			}
		} else {
			logger.debug(this + " notifyAdDone() no more ad to work on");
			if (this.state == SlotPreloadingState.Instance()) {
				this.dispatchSlotEvent(Constants._EVENT_SLOT_PRELOADED);
			} else if ((this.state == SlotPlayingState.Instance() || this.state == SlotPauseState.Instance() || this.state == SlotEndedState.Instance()) && (ad.adChain.relatedSlotState() == SlotPlayingState.Instance())) {
				this.state.complete(this);
			}
		}
	}

	public static String slotTypeString(IConstants.TimePositionClass tpc) {
		return tpc.toString().toLowerCase();
	}
}