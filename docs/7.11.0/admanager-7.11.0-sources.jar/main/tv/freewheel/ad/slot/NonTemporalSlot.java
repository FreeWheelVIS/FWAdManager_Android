package tv.freewheel.ad.slot;

import android.view.ViewGroup;
import android.widget.RelativeLayout;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import tv.freewheel.ad.AdChain;
import tv.freewheel.ad.AdContext;
import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.AdResponse;
import tv.freewheel.ad.Constants;
import tv.freewheel.ad.CreativeRendition;
import tv.freewheel.ad.InternalConstants;
import tv.freewheel.ad.interfaces.IAdInstance;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLElement;

public class NonTemporalSlot extends Slot {
	public boolean acceptCompanion;
	public IConstants.SlotInitialAdOption initialAdOption;
	public String compatibleDimensions;
	
	// A NonTemporal slot may holds a standalone ad at first (or empty), then it may be filled by companion ad from any temporal ad
	// This boolean flag is to mark if this slot has been filled by companion ad.
	// When a NonTemporal slot holds and plays companion ad, it shouldn't dispatch slotStarted, slotEnded, slotPreloaded events
	private boolean holdsCompanionAd = false;
	// If a driving ad was replayed, then the companion slot should replay the same ad in this slot.
	// In this case, we must first stop the slot, then replay it, but since the stop maybe async,
	// add this flag to indicate whether the slot need replay when ended.
	private boolean hasPendingCompanion = false;

	private static final Logger logger = Logger.getLogger(NonTemporalSlot.class, true);

	public NonTemporalSlot(final AdContext context, IConstants.SlotType type) {
		super(context, type);
	}
	
	public void init(String customId, int width, int height, String slotProfile, String adUnit, boolean acceptCompanion, String acceptPrimaryContentType, String acceptContentType, IConstants.SlotInitialAdOption initialAdOption, String compatibleDimensions) {
		super.init(customId, adUnit, slotProfile, acceptContentType, acceptPrimaryContentType);
		this.width = width;
		this.height = height;
		this.acceptCompanion = acceptCompanion;
		this.initialAdOption = initialAdOption;
		this.compatibleDimensions = compatibleDimensions;
	}

	@Override
	public NonTemporalSlot copy() {
		NonTemporalSlot slot = (NonTemporalSlot)super.copy();
		slot.acceptCompanion = this.acceptCompanion;
		slot.initialAdOption = this.initialAdOption;
		slot.compatibleDimensions = this.compatibleDimensions;
		return slot;
	}

	private String slotOptionToString(String slotOption, Boolean enabled) {
		if (slotOption == null || slotOption.isEmpty())
			return "";

		if(enabled){
			return ("+" + slotOption);
		}else{
			return ("-" + slotOption);
		}
	}

	@Override
	protected void setTimePositionClass(String adUnit) {
		this.timePositionClass = IConstants.TimePositionClass.DISPLAY;
	}

	@Override
	protected HashMap<String, String> buildTypeBQueryMap() {
		HashMap<String, String> map = super.buildTypeBQueryMap();
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_TEMPORAL_AD_SLOTS, InternalConstants.TYPEB_QUERY_SITE_NON_TEMPORAL_AD_SLOT);
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_AD_SLOT_WIDTH, this.width);
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_AD_SLOT_HEIGHT, this.height);
		CommonUtil.appendQueryToMap(map, InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOTS_COMP_DIM, this.compatibleDimensions);

		// slot options
		StringBuilder slotOptionsStringBuilder = new StringBuilder();
		slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_ACCEPT_COMPANION, this.acceptCompanion));
		if (this.initialAdOption == IConstants.SlotInitialAdOption.KEEP_ORIGINAL || this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_ONLY) {
			slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_INITIAL,false));
		}
		if (this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_ONLY ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_THEN_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE_IF_TEMPORAL) {
			slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_FRIST_COMPANION_AS_INITIAL, true));
		}
		if (this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_THEN_STAND_ALONE) {
			slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_INITIAL_IF_COMPANION, true));
		}
		if (this.initialAdOption == IConstants.SlotInitialAdOption.NO_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE) {
			slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_STANDALONE, true));
		}
		if (this.initialAdOption == IConstants.SlotInitialAdOption.NO_STAND_ALONE_IF_TEMPORAL ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE_IF_TEMPORAL) {
			slotOptionsStringBuilder.append(this.slotOptionToString(InternalConstants.TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_STANDALONE_IF_TEMPORAL, true));
		}
		if (slotOptionsStringBuilder.capacity() > 0){
			CommonUtil.appendQueryToMap(map, Constants._AD_REQUEST_FLAG_CAPABILITY, slotOptionsStringBuilder.toString());
		}
		return map;
	}

	@Override
	public XMLElement buildXMLElement() {
		XMLElement node = new XMLElement(InternalConstants.TAG_NON_TEMPORAL_AD_SLOT_REQUEST);
		super.buildXMLElement(node);
		node.setAttribute(InternalConstants.ATTR_AD_SLOT_WIDTH, this.width, true);
		node.setAttribute(InternalConstants.ATTR_AD_SLOT_HEIGHT, this.height, true);
		node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_COMP_DIM, this.compatibleDimensions);
		node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_ACCEPT_COMPANION, this.acceptCompanion);
		
		if (this.initialAdOption == IConstants.SlotInitialAdOption.KEEP_ORIGINAL ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_ONLY) {
				node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_NO_INITIAL, true);
			}
			if (this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_ONLY ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_THEN_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE_IF_TEMPORAL) {
				node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_FIRST_COMPANION_AS_INITIAL, true);
			}
			if (this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_THEN_STAND_ALONE) {
				node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_NO_INITIAL_IF_COMPANION, true);
			}
			if (this.initialAdOption == IConstants.SlotInitialAdOption.NO_STAND_ALONE ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE) {
				node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_NO_STANDALONE, true);
			}
			if (this.initialAdOption == IConstants.SlotInitialAdOption.NO_STAND_ALONE_IF_TEMPORAL ||
				this.initialAdOption == IConstants.SlotInitialAdOption.FIRST_COMPANION_OR_NO_STAND_ALONE_IF_TEMPORAL) {
				node.setAttribute(InternalConstants.ATTR_NON_TEMPORAL_AD_SLOT_NO_STANDALONE_IF_TEMPORAL, true);
			}
		
		return node;
	}
	
	@Override
	public void parse(Element node) throws AdResponse.IllegalAdResponseException {
		if (this.width <= 0 && this.height <= 0) { // not set or invalid value in request
			this.width = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_SLOT_WIDTH), 0);
			this.height = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_AD_SLOT_HEIGHT), 0);
		}
		super.parse(node);
	}

	@Override
	public ViewGroup getBase() {
		if (this.displayBase == null) {
			if (this.context.getActivity() == null) {
				logger.error("host activity is null, can not create slot base");
			} else {
				this.displayBase = new RelativeLayout(this.context.getActivity());
				this.displayBase.setId((int) (Math.random() * 100000000));
			}
		}
		
		return this.displayBase;
	}
	
	@Override
	public void play() {
		while (this.adChains.size() > 1) {
			this.adChains.remove(this.adChains.size()-1);
		}
		super.play();
	}
	
	public void playCompanionAdInstance(AdInstance adInstance) {
		logger.verbose(this + " playCompanionAdInstance(" + adInstance + ")");
		
		if (adInstance.adChain == null) {
			AdChain adChain = new AdChain(adInstance);
		}
		this.adChains.add(0, adInstance.adChain);
		
		if (this.currentPlayingAdInstance != null) {
			this.hasPendingCompanion = true;
			this.stop();
		} else {
			this.holdsCompanionAd = true;
			this.play();
		}
	}

	@Override
	protected void dispatchSlotEvent(String eventName) {
		if (!this.holdsCompanionAd) {
			super.dispatchSlotEvent(eventName);
		}
	}
	
	@Override
	public void onComplete() {
		logger.info("onComplete");
		super.onComplete();
		if (this.hasPendingCompanion) {
			holdsCompanionAd = true;
			this.hasPendingCompanion = false;
			this.play();
		}
	}

	@Override
	public int getWidth() {
		if (this.width > 0) {
			return this.width;
		}

		if (currentPlayingAdInstance != null) {
			CreativeRendition cr = currentPlayingAdInstance.getActiveCreativeRendition();
			if (cr != null) {
				return cr.getWidth();
			} else {
				return 0;
			}
		} else {
			return 0;
		}
	}

	@Override
	public int getHeight() {
		if (this.height > 0) {
			return this.height;
		}

		if (currentPlayingAdInstance != null) {
			CreativeRendition cr = currentPlayingAdInstance.getActiveCreativeRendition();
			if (cr != null) {
				return cr.getHeight();
			} else {
				return 0;
			}
		} else {
			return 0;
		}
	}

	@Override
	public List<IAdInstance> getAdInstances() {
		ArrayList<tv.freewheel.ad.interfaces.IAdInstance> ret
				= new ArrayList<tv.freewheel.ad.interfaces.IAdInstance>();

		if (currentPlayingAdInstance == null) {
			//It return original adInstances if no ad is currently playing
			ret.addAll(this.getAdInstancesInPlayPlan(true));
		} else{
			//At runtime, it only return current adInstance
			ret.add(currentPlayingAdInstance);
		}
		return ret;
	}
}
