package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;

public class VideoEndedState extends VideoState {
	private static final VideoEndedState instance = new VideoEndedState();
	
	public static VideoState Instance() {
		return instance;
	}

	@Override
	public void play(VideoAsset video) {
		logger.debug("play");
		video.callbackHandler.replay = true;
		video.onStartPlay();
		video.state = VideoPlayingState.Instance();
	}
}
