package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;

public class VideoPausedState extends VideoState {
	private static final VideoPausedState instance = new VideoPausedState();
	
	public static VideoState Instance() {
		return instance;
	}

	@Override
	public void play(VideoAsset video) {
		logger.debug("play");
		video.state = VideoPlayingState.Instance();
		video.onResumePlay();
	}

	@Override
	public void stop(VideoAsset video) {
		logger.debug("stop");
		video.state = VideoEndedState.Instance();
		video.onStopPlay();
	}
}
