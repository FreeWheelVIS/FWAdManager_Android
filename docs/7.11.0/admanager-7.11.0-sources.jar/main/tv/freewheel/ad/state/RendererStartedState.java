package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;

public class RendererStartedState extends RendererState {
	private static final RendererStartedState instance = new RendererStartedState();
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override
	public void pause(AdInstance ad) {
		logger.debug("pause");
		ad.rendererState = RendererPausedState.Instance();
		((RendererPausedState)ad.rendererState).rendererStartedBeforePause = true;
		ad.renderer.pause();
	}
	
	@Override
	public void notifyStopped(AdInstance ad, IEvent event) {
		ad.rendererState = RendererStopPendingState.Instance();
		ad.rendererState.notifyStopped(ad, event);
	}
	
	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.rendererState = RendererStopPendingState.Instance();
		ad.renderer.stop();
	}
	
	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
