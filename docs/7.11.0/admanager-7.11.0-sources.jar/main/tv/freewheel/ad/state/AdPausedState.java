package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdPausedState extends AdState {
	private static final AdPausedState instance = new AdPausedState();
	
	public static AdState Instance() {
		return instance;
	}

	@Override
	public void play(AdInstance ad) {
		logger.debug("play");
		ad.state = AdPlayingState.Instance();
		ad.onResumePlay();
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.state = AdEndPendingState.Instance();
		ad.onStopPlay();
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.state = AdFailedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public void complete(AdInstance ad) {
		logger.debug("complete");
		ad.state = AdEndedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public String toString() {
		return "AdPausedState";
	}
}
