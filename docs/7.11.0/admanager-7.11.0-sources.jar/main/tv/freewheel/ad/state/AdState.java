package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.utils.Logger;

public class AdState {
	protected static final Logger logger = Logger.getLogger(AdState.class, true);
	public void load(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:load");
	}
	public void play(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:play");
	}
	public void pause(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:pause");
	}
	public void stop(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:stop");
	}
	public void complete(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:complete");
	}
	public void fail(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:fail");
	}
	public void notifyAdLoaded(AdInstance ad) {
		logger.warn(this + " " + ad + " invalid action:notifyAdLoaded");
	}
	public void notifyRendererModuleLoaded(AdInstance ad) {
		logger.debug(this + " " + ad + " invalid action:notifyRendererModuleLoaded");
	}
	public String toString() {
		return "AdState";
	}
}
