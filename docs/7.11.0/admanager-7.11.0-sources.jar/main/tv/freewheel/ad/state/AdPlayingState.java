package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdPlayingState extends AdState {
	private static final AdPlayingState instance = new AdPlayingState();
	
	public static AdState Instance() {
		return instance;
	}

	@Override
	public void pause(AdInstance ad) {
		logger.debug("pause");
		ad.state = AdPausedState.Instance();
		ad.onPausePlay();
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.state = AdEndPendingState.Instance();
		ad.onStopPlay();
	}
	
	// ad complete by it self
	@Override
	public void complete(AdInstance ad) {
		logger.debug("complete");
		ad.state = AdEndedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.state = AdFailedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public String toString() {
		return "AdPlayingState";
	}
}
