package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdLoadedState extends AdState {
	private static final AdLoadedState instance = new AdLoadedState();

	public static AdState Instance() {
		return instance;
	}

	@Override
	public void play(AdInstance ad) {
		logger.debug("play");
		ad.pauseWhenLoading = false;
		ad.state = AdPlayingState.Instance();
		ad.onStartPlay();
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.state = AdEndPendingState.Instance();
		ad.onStopPlay();
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.state = AdFailedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public String toString() {
		return "AdLoadedState";
	}
}
