package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdFailedState extends AdState {
	private static final AdFailedState instance = new AdFailedState();
	
	public static AdState Instance() {
		return instance;
	}

	@Override
	public void load(AdInstance ad) {
		logger.debug("load");
		ad.state = AdLoadingState.Instance();
		ad.loadRenderer();
	}

	@Override
	public void play(AdInstance ad) {
		this.load(ad);
	}

	@Override
	public String toString() {
		return "AdFailedState";
	}
}
