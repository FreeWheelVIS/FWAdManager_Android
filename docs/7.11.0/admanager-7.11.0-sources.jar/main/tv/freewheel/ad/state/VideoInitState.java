package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;

public class VideoInitState extends VideoState {
	private static final VideoInitState instance = new VideoInitState();
	
	public static VideoState Instance() {
		return instance;
	}

	@Override
	public void play(VideoAsset video) {
		logger.debug("play");
		if (video.isReadyToStart()) {
			video.state = VideoPlayingState.Instance();
			video.onStartPlay();
		} else {
			video.state = VideoPendingState.Instance();
		}
	}
}
