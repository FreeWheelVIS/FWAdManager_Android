package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;

public class VideoPendingState extends VideoState {
	private static final VideoPendingState instance = new VideoPendingState();
	
	public static VideoState Instance() {
		return instance;
	}

	@Override
	public void play(VideoAsset video) {
		logger.debug("play");
		if (video.isReadyToStart()) {
			video.state = VideoPlayingState.Instance();
			video.onStartPlay();
		}
	}

	@Override
	public void pause(VideoAsset video) {
		logger.debug("pause");
		video.state = VideoPausedState.Instance();
		video.onPausePlay();
	}

	@Override
	public void stop(VideoAsset video) {
		logger.debug("stop");
		video.state = VideoEndedState.Instance();
		video.onStopPlay();
	}
}
