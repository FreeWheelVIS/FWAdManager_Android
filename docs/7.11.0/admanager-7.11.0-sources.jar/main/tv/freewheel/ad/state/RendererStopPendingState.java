package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;

public class RendererStopPendingState extends RendererState {
	private static final RendererStopPendingState instance = new RendererStopPendingState();
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override
	public void notifyStopped(AdInstance ad, IEvent event) {
		ad.rendererState = RendererStoppedState.Instance();
		ad.onRendererStopped(event);
	}
	
	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
