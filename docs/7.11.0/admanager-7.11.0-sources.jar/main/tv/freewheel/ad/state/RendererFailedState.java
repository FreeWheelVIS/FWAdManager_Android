package tv.freewheel.ad.state;

public class RendererFailedState extends RendererState {
	private static final RendererFailedState instance = new RendererFailedState();
	
	public static RendererState Instance() {
		return instance;
	}
}
