package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdLoadingState extends AdState {
	private static final AdLoadingState instance = new AdLoadingState();
	
	public static AdState Instance() {
		return instance;
	}

	@Override
	public void notifyAdLoaded(AdInstance ad) {
		logger.debug("notifyAdLoaded");
		ad.state = AdLoadedState.Instance();
	}

	@Override
	public void notifyRendererModuleLoaded(AdInstance ad) {
		ad.onRendererModuleLoaded();
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.pauseWhenLoading = false;
		ad.state = AdFailedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public void pause(AdInstance ad) {
		logger.debug("pause");
		ad.pauseWhenLoading = true;
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.pauseWhenLoading = false;
		ad.state = AdEndPendingState.Instance();
		ad.onStopPlay();
	}

	@Override
	public String toString() {
		return "AdLoadingState";
	}
}
