package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdEndPendingState extends AdState {
	private static final AdEndPendingState instance = new AdEndPendingState();
	
	public static AdState Instance() {
		return instance;
	}
	
	// ad complete by IAdInstance.stop
	@Override
	public void complete(AdInstance ad) {
		logger.debug("complete");
		ad.state = AdEndedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.state = AdFailedState.Instance();
		ad.slot.notifyAdDone(ad);
	}

	@Override
	public String toString() {
		return "AdEndPendingState";
	}
}
