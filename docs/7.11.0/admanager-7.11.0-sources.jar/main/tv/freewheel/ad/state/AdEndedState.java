package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class AdEndedState extends AdState {
	private static final AdEndedState instance = new AdEndedState();
	
	public static AdState Instance() {
		return instance;
	}

	@Override
	public void load(AdInstance ad) {
		logger.debug("load");
		ad.state = AdLoadingState.Instance();
		ad.loadRenderer();
	}

	@Override
	public void play(AdInstance ad) {
		this.load(ad);
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.state = AdFailedState.Instance();
	}

	@Override
	public String toString() {
		return "AdEndedState";
	}
}
