package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;

public class SlotInitState extends SlotState {
	private static final SlotInitState instance = new SlotInitState();
	
	public static SlotState Instance() {
		return instance;
	}

	@Override
	public void play(Slot slot) {
		logger.debug("play");
		slot.state = SlotPlayingState.Instance();
		slot.onStartPlay();
	}

	@Override
	public void preload(Slot slot) {
		logger.debug("preload");
		slot.state = SlotPreloadingState.Instance();
		slot.onPreloading();
	}

	@Override
	public String toString() {
		return "SlotInitState";
	}
}
