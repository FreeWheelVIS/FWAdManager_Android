package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;

public class SlotEndedState extends SlotState {
	private static final SlotEndedState instance = new SlotEndedState();
	
	public static SlotState Instance() {
		return instance;
	}

	@Override
	public void play(Slot slot) {
		logger.debug("play");
		slot.state = SlotPlayingState.Instance();
		slot.onStartPlay();
	}
	
	// slot ended by ISlot.stop
	@Override
	public void complete(Slot slot) {
		logger.debug("complete");
		slot.onComplete();
	}

	@Override
	public String toString() {
		return "SlotEndedState";
	}
}
