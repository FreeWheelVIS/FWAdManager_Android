package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;

public class SlotPreloadingState extends SlotState {
	private static final SlotPreloadingState instance = new SlotPreloadingState();
	
	public static SlotState Instance() {
		return instance;
	}

	@Override
	public void stop(Slot slot) {
		logger.debug("stop");
		slot.state = SlotEndedState.Instance();
		slot.onStopPlay();
	}

	@Override
	public void play(Slot slot) {
		logger.debug("play");
		slot.state = SlotPlayingState.Instance();
		slot.onStartPlay();
	}

	@Override
	public String toString() {
		return "SlotPreloadingState";
	}
}
