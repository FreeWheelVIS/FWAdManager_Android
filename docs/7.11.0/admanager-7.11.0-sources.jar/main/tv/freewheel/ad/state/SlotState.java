package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;
import tv.freewheel.utils.Logger;

public class SlotState {
	protected static final Logger logger = Logger.getLogger(SlotState.class);
	public void preload(Slot slot) {
		logger.warn("invalid action:preload");
	}
	public void play(Slot slot) {
		logger.warn("invalid action: play");
	}
	public void pause(Slot slot) {
		logger.warn("invalid action: pause");
	}
	public void resume(Slot slot) {
		logger.warn("invalid action: resume");
	}
	public void stop(Slot slot) {
		logger.warn("invalid action: stop");
	}
	public void complete(Slot slot) {
		logger.warn("invalid action: complete");
	}
	public String toString() {
		return "SlotState";
	}
}
