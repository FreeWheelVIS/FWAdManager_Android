package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;
import tv.freewheel.utils.Logger;

public class VideoState {
	protected static final Logger logger = Logger.getLogger(VideoState.class);
	public void play(VideoAsset slot) {
		logger.warn("invalid action: play");
	}
	public void pause(VideoAsset slot) {
		logger.warn("invalid action: pause");
	}
	public void stop(VideoAsset slot) {
		logger.warn("invalid action: stop");
	}
}
