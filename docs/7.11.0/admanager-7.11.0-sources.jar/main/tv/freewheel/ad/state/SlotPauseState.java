package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;

public class SlotPauseState extends SlotState {
	private static final SlotPauseState instance = new SlotPauseState();
	
	public static SlotState Instance() {
		return instance;
	}

	@Override
	public void play(Slot slot) {
		logger.debug("play");
		this.resume(slot);
	}

	@Override
	public void resume(Slot slot) {
		logger.debug("resume");
		slot.state = SlotPlayingState.Instance();
		slot.onResumePlay();
	}

	@Override
	public void stop(Slot slot) {
		logger.debug("stop");
		slot.state = SlotEndedState.Instance();
		slot.onStopPlay();
	}

	@Override
	public void complete(Slot slot) {
		logger.debug("complete");
		slot.state = SlotEndedState.Instance();
		slot.onComplete();
	}

	@Override
	public String toString() {
		return "SlotPauseState";
	}
}
