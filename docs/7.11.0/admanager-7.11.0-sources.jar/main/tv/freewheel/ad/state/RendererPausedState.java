package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;

public class RendererPausedState extends RendererState {
	private static final RendererPausedState instance = new RendererPausedState();
	public boolean rendererStartedBeforePause = false;
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override
	public void resume(AdInstance ad) {
		logger.debug("resume");
		if (this.rendererStartedBeforePause) {
			ad.rendererState = RendererStartedState.Instance();
		} else {
			ad.rendererState = RendererStartingState.Instance();
		}
		ad.renderer.resume();
	}

	@Override
	public void notifyStopped(AdInstance ad, IEvent event) {
		ad.rendererState = RendererStopPendingState.Instance();
		ad.rendererState.notifyStopped(ad, event);
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.rendererState = RendererStopPendingState.Instance();
		ad.renderer.stop();
	}
	
	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
