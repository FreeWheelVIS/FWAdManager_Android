package tv.freewheel.ad.state;

import tv.freewheel.ad.slot.Slot;

public class SlotPlayingState extends SlotState {
	private static final SlotPlayingState instance = new SlotPlayingState();
	
	public static SlotState Instance() {
		return instance;
	}

	@Override
	public void pause(Slot slot) {
		logger.debug("pause");
		slot.state = SlotPauseState.Instance();
		slot.onPausePlay();
	}

	@Override
	public void stop(Slot slot) {
		logger.debug("stop");
		slot.state = SlotEndedState.Instance();
		slot.onStopPlay();
	}
	
	// slot ended by self
	@Override
	public void complete(Slot slot) {
		logger.debug("complete");
		slot.state = SlotEndedState.Instance();
		slot.onComplete();
	}

	@Override
	public String toString() {
		return "SlotPlayingState";
	}
}
