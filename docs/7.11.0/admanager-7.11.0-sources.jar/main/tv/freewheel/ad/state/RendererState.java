package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.utils.Logger;

public class RendererState {
	protected static final Logger logger = Logger.getLogger(RendererState.class);
	protected void onErrorAction(String action) {
		logger.warn("invalid action " + action);
	}
	public void load(AdInstance ad) {
		this.onErrorAction("load");
	}
	public void notifyLoaded(AdInstance ad, IEvent event) {
		this.onErrorAction("notifyLoaded");
	}
	public void start(AdInstance ad) {
		this.onErrorAction("start");
	}
	public void notifyStarted(AdInstance ad, IEvent event) {
		this.onErrorAction("notifyStarted");
	}
	public void pause(AdInstance ad) {
		this.onErrorAction("pause");
	}
	public void resume(AdInstance ad) {
		this.onErrorAction("resume");
	}
	public void stop(AdInstance ad) {
		this.onErrorAction("stop");
	}
	public void notifyStopped(AdInstance ad, IEvent event) {
		this.onErrorAction("notifyStopped");
	}
	public void dispose(AdInstance ad) {
		this.onErrorAction("dispose");
	}
	public void fail(AdInstance ad) {
		this.onErrorAction("fail");
	}
}
