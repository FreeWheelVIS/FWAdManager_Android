package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;

public class RendererLoadedState extends RendererState {
	private static final RendererLoadedState instance = new RendererLoadedState();
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override
	public void start(AdInstance ad) {
		logger.debug("start");
		ad.rendererState = RendererStartingState.Instance();
		ad.renderer.start();
	}

	@Override
	public void notifyStopped(AdInstance ad, IEvent event) {
		ad.rendererState = RendererStopPendingState.Instance();
		ad.rendererState.notifyStopped(ad, event);
	}

	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
