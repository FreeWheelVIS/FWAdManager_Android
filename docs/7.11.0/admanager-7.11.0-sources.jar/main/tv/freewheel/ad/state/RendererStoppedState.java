package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class RendererStoppedState extends RendererState {
	private static final RendererStoppedState instance = new RendererStoppedState();
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override
	public void dispose(AdInstance ad) {
		logger.debug("dispose");
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
