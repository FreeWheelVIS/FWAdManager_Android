package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;
import tv.freewheel.ad.interfaces.IEvent;

public class RendererLoadPendingState extends RendererState {
	private static final RendererLoadPendingState instance = new RendererLoadPendingState();
	
	public static RendererState Instance() {
		return instance;
	}
	
	@Override 
	public void notifyLoaded(AdInstance ad, IEvent event) {
		ad.rendererState = RendererLoadedState.Instance();
		ad.onRendererLoaded(event);
	}

	@Override
	public void notifyStopped(AdInstance ad, IEvent event) {
		ad.rendererState = RendererStopPendingState.Instance();
		ad.rendererState.notifyStopped(ad, event);
	}

	@Override
	public void stop(AdInstance ad) {
		logger.debug("stop");
		ad.rendererState = RendererStopPendingState.Instance();
		ad.renderer.stop();
	}
	
	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
