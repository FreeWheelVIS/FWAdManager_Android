package tv.freewheel.ad.state;

import tv.freewheel.ad.VideoAsset;

public class VideoPlayingState extends VideoState {
	private static final VideoPlayingState instance = new VideoPlayingState();
	
	public static VideoState Instance() {
		return instance;
	}

	@Override
	public void pause(VideoAsset video) {
		logger.debug("pause");
		video.state = VideoPausedState.Instance();
		video.onPausePlay();
	}

	@Override
	public void stop(VideoAsset video) {
		logger.debug("stop");
		video.state = VideoEndedState.Instance();
		video.onStopPlay();
	}
}
