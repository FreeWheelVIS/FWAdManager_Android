package tv.freewheel.ad.state;

import tv.freewheel.ad.AdInstance;

public class RendererInitState extends RendererState {
	private static final RendererInitState instance = new RendererInitState();
	
	public static RendererState Instance() {
		return instance;
	}

	@Override
	public void load(AdInstance ad) {
		logger.debug("load");
		ad.rendererState = RendererLoadPendingState.Instance();
		ad.renderer.load(ad);
	}
	
	@Override
	public void fail(AdInstance ad) {
		logger.debug("fail");
		ad.rendererState = RendererFailedState.Instance();
		ad.renderer.dispose();
		ad.renderer = null;
	}
}
