package tv.freewheel.ad;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tv.freewheel.utils.Logger;
import tv.freewheel.utils.XMLHandler;

public class ParametersHolder extends AdContextScoped {
	public Map<String, Object> parameters;
	protected static final Logger logger = Logger.getLogger(ParametersHolder.class, true);

	public ParametersHolder(AdContext context) {
		super(context);
		this.parameters = new HashMap<>();
	}
	
	/**
	 * example: 
	 * <parameters>
	 *		<parameter name="version"><![CDATA[5.0.0]]></parameter>
	 * </parameters>
	 * 
	 * @param node
	 */
	public static Map<String, Object> parseParameters(Element node) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				// logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_PARAMETER)){
					Element paramNode = (Element) childNode;
					String key = paramNode.getAttribute(
										InternalConstants.ATTR_PARAMETER_NAME);
					String value = XMLHandler.getTextNodeValue(paramNode); //paramNode.getFirstChild().getNodeValue();
					if(value == null) {
						value = "";
					}
					if(key != null) {
						params.put(key, value);
						logger.debug("profile parameter name:" + key + " value:" + value);
					}
				}
			}
		}
		return params;
	}
	
	/**
	 * example: 
	 * 
	 * <adRenderer name="...">
	 * <parameter name="bannerBorder" value="bannerGreenBorder"/>
	 * </adRenderer>
	 * 
	 * @param node
	 */
	protected void parseRendererParameters(Element node) {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_PARAMETER)){
					Element paramNode = (Element) childNode;
					String key = paramNode.getAttribute(
										InternalConstants.ATTR_PARAMETER_NAME);
					String value = paramNode.getAttribute(
										InternalConstants.TAG_KEY_VALUES_VALUE);
					if(value == null) {
						value = "";
					}
					if(key != null) {
						this.parameters.put(key, value);
					}
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}
}
