package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

import tv.freewheel.renderers.vast.model.ExecutableResource;
import tv.freewheel.renderers.vast.model.JavaScriptResource;
import tv.freewheel.renderers.vast.model.Tracking;

import tv.freewheel.utils.URIUtil;
import tv.freewheel.utils.URLLoader;
import tv.freewheel.utils.URLRequest;



public class AdVerification implements Cloneable {
	// the vendorKey is only mandatory when verification parameters have been provided.
	private String vendorKey;
	private ArrayList<JavaScriptResource> javaScriptResources = new ArrayList<>();
	private ArrayList<ExecutableResource> executableResources = new ArrayList<>();
	private String verificationParameters;
	private ArrayList<Tracking> trackingEvents = new ArrayList<>();
	private final String REASON_REGEX_MACRO = "\\[REASON\\]";

	public enum VerificationNotExecutedReason {
		VERIFICATION_RESOURCE_REJECTED(1),
		VERIFICATION_NOT_SUPPORTED(2),
		VERIFICATION_RESOURCE_LOAD_ERROR(3);
		final int reason;

		VerificationNotExecutedReason(int reason) { this.reason = reason;}
		@Override
		public String toString() {
			return Integer.toString(this.reason);
		}
	}

	public String getVendorKey() {
		return vendorKey;
	}

	public ArrayList<JavaScriptResource> getJavaScriptResources() {
		return javaScriptResources;
	}

	public ArrayList<ExecutableResource> getExecutableResources() {
		return executableResources;
	}

	public String getVerificationParameters() {
		return verificationParameters;
	}

	public ArrayList<Tracking> getTrackingEvents() {
		return trackingEvents;
	}

	public ArrayList<Tracking> getTrackingEventsByName(String name) {
		ArrayList<Tracking> trackingEventsByName = new ArrayList<>();
		for (Tracking trackingEvent: trackingEvents) {
			if (trackingEvent.event.equals(name)) {
				trackingEventsByName.add(trackingEvent);
			}
		}
		return trackingEventsByName;
	}

	public void dispatchVerificationNotExecutedCallback(AdContext adContext, VerificationNotExecutedReason reason) {
		ArrayList<Tracking> verificationEvents = getTrackingEventsByName(InternalConstants.AD_VERIFICATION_EVENT_NOT_EXECUTED);
		for (Tracking trackingEvent : verificationEvents) {
			String url = URIUtil.getFixedString(trackingEvent.url.replaceAll(REASON_REGEX_MACRO, reason.toString()));
			URLRequest request = new URLRequest(url, adContext.getUserAgent());
			request.method = URLRequest.Method.GET;
			request.contentType = URLRequest.CONTENT_TYPE_TEXT_PLAIN;
			URLLoader loader = new URLLoader();
			loader.load(request);
		}
	}

	public AdVerification() {
	}

	public AdVerification(String vendorKey, ArrayList<JavaScriptResource> javaScriptResources, ArrayList<ExecutableResource> executableResources, String verificationParameters) {
		this.vendorKey = vendorKey;
		this.javaScriptResources = javaScriptResources;
		this.executableResources = executableResources;
		this.verificationParameters = verificationParameters;
	}

	public void parse(Element node) {
		this.vendorKey = node.getAttribute(InternalConstants.OpenMeasurementConstants.TAG_VENDOR);
		for (int i = 0; i < node.getChildNodes().getLength(); i++) {
			Node child = node.getChildNodes().item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE) {
				String name = child.getNodeName();
				if (name.equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_JAVASCRIPT_RESOURCE)) {
					JavaScriptResource javaScriptResource = new JavaScriptResource();
					javaScriptResource.parse(child);
					this.javaScriptResources.add(javaScriptResource);
				} else if (name.equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_EXECUTABLE_RESOURCE)) {
					ExecutableResource executableResource = new ExecutableResource();
					executableResource.parse(child);
					this.executableResources.add(executableResource);
				} else if (name.equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_VERIFICATION_PARAMETERS)) {
					this.verificationParameters = child.getTextContent().trim();
				} else if (name.equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_TRACKING_EVENTS)) {
					//only trackingEvents event type is currently supported in Verification node
					NodeList trackings = child.getChildNodes();
					for (int j = 0; j < trackings.getLength(); j++) {
						if (trackings.item(j).getNodeType() == Node.ELEMENT_NODE && trackings.item(j).getNodeName().equalsIgnoreCase(InternalConstants.OpenMeasurementConstants.TAG_TRACKING)) {
							Tracking tracking = new Tracking();
							tracking.parse((Element) trackings.item(j));
							this.trackingEvents.add(tracking);
						}
					}
				}
			}
		}
	}

	@Override
	public String toString() {
		return String.format("[AdVerification\n\t\t\t\tvendorKey=%s\n\t\t\t\tjavaScriptResources=%s\n\t\t\t\texecutableResources=%s\n\t\t\t\tverificationParameters=%s\n\t\t\t\ttrackingEvents=%s]",
				this.vendorKey, this.javaScriptResources, this.executableResources, this.verificationParameters, this.trackingEvents);
	}

	@Override
	protected AdVerification clone() throws CloneNotSupportedException {
		// automatically derived and copied primitive type parameters by the compile
		AdVerification clone = (AdVerification) super.clone();

		// deep clone of tracking array
		clone.trackingEvents = new ArrayList<>(this.trackingEvents.size());
		for (Tracking tracking: this.trackingEvents) {
			clone.trackingEvents.add(tracking.clone());
		}

		return clone;
	}
}
