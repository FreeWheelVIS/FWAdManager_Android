package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.HashMap;

import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.handler.VideoViewCallbackHandler;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.slot.TemporalSlot;
import tv.freewheel.ad.state.VideoInitState;
import tv.freewheel.ad.state.VideoPausedState;
import tv.freewheel.ad.state.VideoPendingState;
import tv.freewheel.ad.state.VideoPlayingState;
import tv.freewheel.ad.state.VideoState;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.RecordTimer;
import tv.freewheel.utils.events.Event;

public class VideoAsset extends EventCallbackHolder {
	public VideoState state;
	public VideoViewCallbackHandler callbackHandler;
	public RecordTimer timer;
	public int pauseRequestCounter;

	private static final Logger logger = Logger.getLogger(VideoAsset.class, true);

	public VideoAsset(final AdContext context) {
		super(context);
		this.state = VideoInitState.Instance();
	}
	
	public void parseTemporalAdSlots(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parseTemporalAdSlots(), name: " + name);
				if (name.equals(InternalConstants.TAG_TEMPORAL_AD_SLOT)){
					Element childElement = (Element)childNode;
					String customId = childElement.getAttribute(InternalConstants.ATTR_TEMPORAL_AD_SLOT_CUSTOM_ID);
					logger.debug("adding new TemporalSlot:" + customId + " to collection:" 
							+ this.getAdResponse().temporalSlots.toString()
							+ ", context: " + this.context.toString());
					TemporalSlot slot = (TemporalSlot)this.getAdRequest().getSlotByCustomId(customId);
					slot = slot != null ? slot = slot.copy() : new TemporalSlot(this.context, IConstants.SlotType.TEMPORAL);
					slot.parse(childElement);
					this.getAdResponse().temporalSlots.add(slot);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}
	
	public void parse(Element node) throws IllegalAdResponseException {
		NodeList childList = node.getChildNodes();

		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_TEMPORAL_AD_SLOTS)){
					if (this.context.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == IConstants.CapabilityStatus.OFF) {
						this.parseTemporalAdSlots((Element)childNode);
					}
				} else if (name.equals(InternalConstants.TAG_EVENT_CALLBACKS)) {
					this.parseEventCallbacks((Element)childNode);
					if (this.callbackHandler == null && !this.context.isRecordVideoViewEnabled()) {
						this.callbackHandler = 
							(VideoViewCallbackHandler) this.createEventHandler(
									InternalConstants.EVENT_VIDEO_VIEW, 
									Constants._EVENT_TYPE_IMPRESSION, false);
					}
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}
	
	public void play() {
		logger.debug("play");
		this.state.play(this);
	}
	
	public void pause() {
		logger.debug("pause");
		this.state.pause(this);
	}
	
	public void complete() {
		logger.debug("complete");
		this.state.stop(this);
	}

	public void onPausePlay() {
		logger.debug("onPausePlay");
		if (this.callbackHandler == null) {
			this.timer.pause();
		} else {
			this.callbackHandler.pause();
		}
	}

	public void onStopPlay() {
		logger.debug("onStopPlay");
		if (this.callbackHandler == null) {
			this.timer = null;
		} else {
			this.callbackHandler.complete();
		}
	}

	public void onResumePlay() {
		logger.debug("onResumePlay");
		if (this.callbackHandler == null) {
			this.timer.resume();
		} else {
			this.callbackHandler.resume();
		}
	}

	public void onStartPlay() {
		logger.debug("onStartPlay");
		long delay = 0;
		this.pauseRequestCounter = 0;
		if (this.timer != null) {
			delay = this.timer.tick();
		}
		this.callbackHandler.start(delay);
	}
	
	public boolean isReadyToStart() {
		if (this.callbackHandler == null) {
			this.timer = new RecordTimer();
			if (this.context.adRequest.hasSetVideoAssetId()) {
				this.context.adRequest.requestVideoView();
			}
			return false;
		}
		
		return true;
	}

	public void requestPauseBySlot(Slot slot) {
		logger.debug("requestPauseBySlot(slot=" + slot + ")");
		this.pauseRequestCounter += 1;
		if (this.pauseRequestCounter == 1) {
			if (this.state == VideoPlayingState.Instance() || this.state == VideoPendingState.Instance()) {
				HashMap<String, Object> data = new HashMap<>();
				data.put(Constants._INFO_KEY_SLOT_CUSTOM_ID, slot.customId);
				this.context.dispatchEvent(new Event(Constants._EVENT_REQUEST_CONTENT_VIDEO_PAUSE, data));
			} else {
				logger.info("ignore since main video is not in playing state");
			}
		} else {
			logger.debug("ignore since the content has been paused");
		}
	}

	public void requestResumeBySlot(Slot slot) {
		logger.debug("requestResumeBySlot(slot=" + slot + ")");
		this.pauseRequestCounter -= 1;
		if (this.pauseRequestCounter == 0) {
			if (this.state == VideoPausedState.Instance()) {
				HashMap<String, Object> data = new HashMap<>();
				data.put(Constants._INFO_KEY_SLOT_CUSTOM_ID, slot.customId);
				this.context.dispatchEvent(new Event(Constants._EVENT_REQUEST_CONTENT_VIDEO_RESUME, data));
			} else {
				logger.info("ignore since main video is in playing state");
			}
		} else {
			logger.info("ignore since there are other slots that requested the content video to pause");
		}
		if (this.pauseRequestCounter < 0) {
			this.pauseRequestCounter = 0;
		}
	}
}
