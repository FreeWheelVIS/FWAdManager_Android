package tv.freewheel.ad;

import android.content.Context;
import android.location.Location;
import android.util.Log;

import com.iab.omid.library.freewheeltv.Omid;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tv.freewheel.ad.interfaces.IAdManager;
import tv.freewheel.ad.interfaces.IAdContext;
import tv.freewheel.extension.ExtensionManager;
import tv.freewheel.extension.IExtension;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.TopicsManager;
import tv.freewheel.utils.cookie.AndroidCookieStore;

public class AdManager implements IAdManager {
	private int version = -1;
	public String adManagerVersion = FreeWheelVersion.FW_SDK_INTERFACE_VERSION;
	public static final String DEFAULT_SERVER_URL = "http://g1.v.fwmrm.net";
	private static IAdManager instance;
	private static final String TAG = "AdManager";

	protected String serverUrl = DEFAULT_SERVER_URL;
	protected int networkId = 0;
	protected Location geoLocation;

	private Context appContext;
	private TopicsManager topicsManager;

	public void registerRenderer(String name, Class<? extends IRenderer> cls) {
		AdRenderer.registerRenderer(name,  cls);
	}
	
	public void registerExtension(String name, Class<? extends IExtension> cls) {
		ExtensionManager.registerExtension(name, cls);
	}

	private AdManager(Context appContext, int logLevel) {
		Logger.setLogLevel(logLevel);
		AndroidCookieStore.initialize(appContext);
		this.appContext = appContext;
		Log.i(TAG, "Version:" + this.adManagerVersion);
	}

	public void enableTopics() {
		if (topicsManager == null) {
			Log.i(TAG, "Creating topics manager");
			topicsManager = new TopicsManager(this.appContext);
		} else {
			Log.w(TAG, "Topics already enabled, ignoring");
		}
	}

	public String getTopicsString() {
		if (topicsManager != null) {
			return topicsManager.getTopicsString();
		} else {
			return "";
		}
	}

	public IAdContext newContext() {
		return new AdContext(this);
	}
	
	public IAdContext newContextWithContext(IAdContext originAdContext){
		return new AdContext((AdContext)originAdContext);
	}

	public int getVersion() {
		if (this.version < 0) {
			this.version = 0x7fffffff;
			String[] component = this.adManagerVersion.split("-");
			if (component.length > 0) {
				String mainPart = component[0];
				if (!mainPart.equals("trunk")) {
					version = 0;
					String[] n = mainPart.split("\\.");
					int length = n.length;
					if (length > 4) {
						length = 4;
					}
					short level = 3;
					for (int i = 0; i < length; ++i, --level) {
						int factor = 1;
						for (int j = 0; j < level; ++j) {
							factor *= 256;
						}
						try {
							version += Integer.parseInt(n[i]) * factor;
						} catch (NumberFormatException e) {
							version += 9 * factor;
						}
					}
				}
			}
		}
		return this.version;
	}
	
	public String getStringVersion() {
		return this.adManagerVersion;
	}

	public String getOMSDKLibraryVersion() {
		Pattern regex = Pattern.compile("^\\d+(\\.\\d+)++");
		Matcher matcher = regex.matcher(Omid.getVersion());
		return matcher.find() ? matcher.group() : "-1";
	}

	public String getOMSDKPartnerVersion() {
		Pattern regex = Pattern.compile("^\\d+(\\.\\d+)++");
		Matcher matcher = regex.matcher(this.adManagerVersion);
		return matcher.find() ? matcher.group() : "0.0.0";
	}

	public void setNetwork(int networkId) {
		this.networkId = networkId;
	}

	public void setLocation(Location location) {
		this.geoLocation = location;
	}

	/**
	 * Return the singleton instance of IAdManager.
	 *
	 * @param context the Context object which will be used by the IAdManager instance.
	 *                Usually the application global context.
	 * @return the IAdManager instance.
	 */
	public static IAdManager getInstance(Context context) {
		if (instance == null) {
			try {
				instance = new AdManager(context, Logger.getLogLevel());
			} catch (Exception e) {
				// Web view is not present on Android device; cannot initialize AdManager.
				Log.e(TAG, "IAdManager instance not created; null value is returned.", e);
				return null;
			}
		}
		return instance;
	}
}
