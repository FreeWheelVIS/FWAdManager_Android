package tv.freewheel.ad;

import java.util.ArrayList;
import java.util.List;

import tv.freewheel.ad.state.AdState;
import tv.freewheel.ad.state.SlotState;
import tv.freewheel.utils.Logger;

public class AdChain {
	private static final Logger logger = Logger.getLogger(AdChain.class, false);
	public List<AdInstance> adInstances;
	protected ChainBehavior chainBehavior = null;
	
	public AdChain(AdInstance adInstance) {
		adInstances = new ArrayList<>();
		this.append(adInstance);
	}
	
	public AdInstance findNextPlayableAd(AdInstance from) {
		int fromIndex = this.adInstances.indexOf(from) + 1;
		AdInstance ret = null;
		for (int i = fromIndex; i < this.adInstances.size(); ++i) {
			if (this.adInstances.get(i).isPlayable()) {
				ret = this.adInstances.get(i);
				break;
			}
		}
		logger.debug(this + " findNextPlayableAd returning " + ret);
		return ret;
	}
	
	public void append(AdInstance adInstance) {
		logger.debug(this + " append " + adInstance);
		if (adInstance != null) {
			this.adInstances.add(adInstance);
			adInstance.adChain = this;
		}
	}
	
	public void insertAfter(AdInstance newAdInstance, AdInstance target) {
		logger.debug(this + " insertAfter(" + newAdInstance + ", " + target);
		int i = this.adInstances.indexOf(target);
		if (i >= 0) {
			adInstances.add(i+1, newAdInstance);
			newAdInstance.adChain = this;
		} else {
			logger.error(this + " target " + target + " is not in this chain");
		}
	}
	
	public SlotState relatedSlotState() {
		return this.chainBehavior.relatedSlotState();
	}
	
	public boolean isChainStopper(AdInstance adInstance) {
		return this.chainBehavior.isChainStopper(adInstance);
	}
	
	public AdInstance getLastAdInstanceInChain() {
		if (this.adInstances.isEmpty()) {
			return null;
		}
		return this.adInstances.get(this.adInstances.size()-1);
	}
	
	public boolean isDestState(AdState adState) {
		return this.chainBehavior.isDestState(adState);
	}
	
	@Override
	public String toString() {
		return "[AdChain " + this.adInstances + "]";
	}
}
