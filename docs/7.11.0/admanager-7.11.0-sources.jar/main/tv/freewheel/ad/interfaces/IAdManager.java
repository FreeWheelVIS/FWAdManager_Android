package tv.freewheel.ad.interfaces;

import android.location.Location;

/**
 * IAdManager is the {@link IAdContext} creator.
 *
 * <p>The instance of IAdManager can be retrieved from<br>
 * <pre>	public static IAdManager tv.freewheel.ad.AdManager.getInstance(Context context)</pre>
 * This method requires an Android Context object (usually the application global context) for the ad manager,
 * and returns the singleton object of IAdManager.
 *
 * <p>In case the Android device does not have WebView package installed or if the package is being inflated, the method<br>
 * <pre>tv.freewheel.ad.AdManager.getInstance(Context context)</pre> would return <pre>null</pre>.
 *
 * Note:
 *      All FreeWheel SDK APIs need to be called on main thread.
 *
 *
 * <p>AdManager log level could be set via<br>
 * <pre>	public static void tv.freewheel.utils.Logger.setLogLevel(int level)</pre>
 * Log level could be one of:
 * <br>
 * <br>	-	Logger.VERBOSE
 * <br>	-	Logger.DEBUG
 * <br>	-	Logger.INFO
 * <br>	-	Logger.WARN
 * <br>	-	Logger.ERROR
 * <br>	-	Logger.ASSERT
 * <br>
 *
 */
public interface IAdManager {

	/**
	 *  Set the network id of the distributor.
	 *            
	 *  Note:
	 *      This method should only be invoked only once.
	 *      
	 *  @param networkId network id of the distributor
	 */
	public void setNetwork(int networkId);
	
	/**
	 *	Set the current location of device. This value will be used by AdContext objects created from this AdManager object for geo targeting.
	 *
	 *	@param	location value of the location to be set. null has no effect
	 */
	public void setLocation(Location location);

	/**
	 *  Create a new ad context.
	 *  
	 *  An ad context instance is used to set ad request information for a particular ad or ad set.
	 *  <p>
	 *  Multiple contexts can be created throughout the lifecycle of the FreeWheel AdManager 
	 *  and may exist simultaneously without consequence. 
	 *  Multiple simultaneous contexts are useful to optimize user experience in the network-resource limited environment.
	 *
	 *  @return an IAdContext object
	 */
	public IAdContext newContext();
	
	/**
	 *	Create a new context from the original context.
	 *
	 *	The new context copies internal state of the original one for submitting new ad request.
	 *	Following methods DO NOT NEED to call again on the new context: 
	 *  <br>
	 *	<br>	-	registerVideoDisplay
	 *	<br>	-	setActivity
	 *	<br>	-	setVideoDisplaySize
	 *	<br>	-	setVideoState
	 *  <br>
	 *	<br>	
	 *	But the method below is REQUIRED to call again on the new context:
	 *		-	submitRequest
	 *
	 *	@param originAdContext	refer to an object of original context  	
	 *	@return an IAdContext object	
	 */
	public IAdContext newContextWithContext(IAdContext originAdContext);

	/**
	 *  Get the AdManager's version.
	 *
	 *  @return the version String, e.g. 0x02060000 for v2.6
	 */
	public int getVersion();

	/**
	 *  Get the version of the integrated OMSDK.
	 *
	 *  @return the OMSDK version string (e.g. 1.3.34).
	 */
	public String getOMSDKLibraryVersion();

	/**
	 *  Get the AdManager version string that is submitted to OMSDK.
	 *
	 *  @return the OMSDK partner version string.
	 */
	public String getOMSDKPartnerVersion();

	/**
	 *  Enables AdManager to call the android.adservices.topics.TopicsManager.getTopics() API when available.
	 *  If it is available and topics are returned, the ids of the topics will be added to the ad request
	 *  using the  "_fwu_topic" key-value pair.
	 *
	 *  This method should be called immediately after instantiating AdManager.
	 *  If this method is called, and the "_fwu_topic" value is manually set, the manually set value will be used in the ad request.
	 *
	 * 	Note that this is still an experimental feature. More info on this can be found at the "AdManager Support for Google Privacy Sandbox Topics API" Hub page:
	 * 	https://hub.freewheel.tv/x/OwKNkg
	 */
	public void enableTopics();
}
