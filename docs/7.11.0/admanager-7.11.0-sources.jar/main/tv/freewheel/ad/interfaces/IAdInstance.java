package tv.freewheel.ad.interfaces;

import org.w3c.dom.NodeList;

import java.util.List;

import tv.freewheel.ad.UniversalAdId;
import tv.freewheel.ad.Extension;

/**
 *	Internal context of an ad instance.
 *
 *	Note:
 *		Some methods and references to ICreativeRendition and ICreativeRenditionAsset
 *		are *not* available for player right now.
 */
public interface IAdInstance {
	/**
	 * Get the ad id.
	 *
	 * @return an int value represent ad id
	 */
	public int getAdId();
	
	/**
	 * Get the universal ad ID of the ad instance, if it is returned in the SMRX ad response. If there is no universal ad ID in the SMRX ad response, and the ad is a VAST ad, this method will return the universal ad ID from the VAST ad, if applicable. Note that this only applies to VAST ads after they have started playback.
	 * For more information on the IAB Universal Ad ID, please refer to section 3.7.1 in the VAST 4.0 spec: https://www.iab.com/guidelines/digital-video-ad-serving-template-vast-4-0/.
	 *
	 * @return an IABUniversalAdId object that contains the id registry and id value.
	 */
	public UniversalAdId getUniversalAdId();
	
	/**
	 * Get the external ad id for ads delivered via third party or external sources, like SSVT
	 * Please note, this will return an empty string for first party ads or if the AdId is not available via the third party owner
	 *
	 * @return a String value of the external ad id
	 */
	public String getExternalAdId();

	/**
	 * Get a uniquely identifiable ID of the ad instance.
	 * For ads from third party or external sources, via SSVT, this ID includes externalAdId to reflect the true uniquely identifiable ID.
	 *
	 * @return a String value of uniquely identifiable ID for an ad
	 */
	public String getAdUniqueId();

	/**
	 * Get IRendererController of the ad. Only for player use.
	 *
	 * @return IRendererController of the ad
	 */
	public IRendererController getRendererController();

	/**
	 * Retrieve the parameters from the ad instance.
	 *
	 * The parameter value will be retrieved from levels in the following order:
	 * override, creative rendition, creative, slot, profile, global.
	 * Only for player use.
	 *
	 * @param    name    parameter name
	 * @return the value of the parameter
	 */
	public Object getParameter(String name);

	/**
	 *	Get the ad slot which contain this ad. Only for renderer use.
	 *
	 *	@return an object of ISlot
	 */
	public ISlot getSlot();

 	/**
	 *	Get the duration of the ad. It returns the most accurate value available to AdManager, which may come from the renderer or the ad response XML.
	 * 	The value reported by the renderer is considered more accurate than the value from ad response, aka. the creative duration value booked in MRM UI.
	 *
	 *	@return the duration of the ad, in seconds.
	 */
	public double getDuration();

	/**
	 *	Get the playhead time of the ad.
	 *
	 *	@return the playhead time of the ad, in seconds.
	 */
	public double getPlayheadTime();


	/**
	 *	Get active rendition of the ad instance. Only for renderer use.
	 *
	 *	@return an object of ICreativeRendition
	 */
	public ICreativeRendition getActiveCreativeRendition();

	/**
	 *	Get all renditions of this ad instance. Only for renderer use.
	 *
	 *	@return a List of type ICreativeRendition
	 */
	public List<ICreativeRendition> getAllCreativeRenditions();

	/**
	 * Get renderable renditions of this ad instance. Only for renderer use.
	 *
	 * @return a List of renderable ICreativeRendition
	 */
	public List<ICreativeRendition> getRenderableCreativeRenditions();

	/**
	 *	Set the active rendition of this ad, this rendition will finally be showed. Only for renderer use.
	 *
	 *	@param rendition the active rendition will be set
	 */
	public void setActiveCreativeRendition(ICreativeRendition rendition);

	/**
	 * Add a creative rendition to the ad instance. Only for renderer use.
	 *
	 * @return the ICreativeRendition object added to the ad instance
	 */
	public ICreativeRendition createCreativeRenditionForTranslation();

	/**
	 * Append additional tracking URLs to certain event specified by eventName and eventType. Only for renderer use.
	 *
	 * @param eventName name of the event
	 * @param eventType type of the event
	 * @param urls List of URLs to be added
	 * <br>
	 * <br>
	 * Available combination of input:<br>
	 *		(EVENT_AD_IMPRESSION, EVENT_TYPE_IMPRESSION)	-	impression, aka ad display start<br>
	 *		(EVENT_AD_CLICK,      EVENT_TYPE_CLICK_TRACKING)	-	click tracking<br>
	 *		("a_custom_string",   EVENT_TYPE_CLICK_TRACKING)	-	custom click tracking<br>
	 *		(EVENT_AD_FIRST_QUARTILE,     EVENT_TYPE_IMPRESSION)	-	1st quartile<br>
	 *		(EVENTCALLBACK_MIDPOINT,      EVENT_TYPE_IMPRESSION)	-	middle point<br>
	 *		(EVENTCALLBACK_THIRDQUARTILE, EVENT_TYPE_IMPRESSION)	-	3rd quartile<br>
	 *		(EVENTCALLBACK_COMPLETE,      EVENT_TYPE_IMPRESSION)	-	complete<br>
	 *		(EVENT_AD_PAUSE,              EVENT_TYPE_STANDARD)		-	IAB metric, pause<br>
	 *		(EVENT_AD_RESUME,             EVENT_TYPE_STANDARD)		-	IAB metric, resume<br>
	 *		(EVENT_AD_REWIND,             EVENT_TYPE_STANDARD)		-	IAB metric, rewind<br>
	 *		(EVENT_AD_MUTE,               EVENT_TYPE_STANDARD)		-	IAB metric, mute<br>
	 *		(EVENT_AD_UNMUTE,             EVENT_TYPE_STANDARD)		-	IAB metric, unmute<br>
	 *		(EVENT_AD_COLLAPSE,           EVENT_TYPE_STANDARD)		-	IAB metric, collapse<br>
	 *		(EVENT_AD_EXPAND,             EVENT_TYPE_STANDARD)		-	IAB metric, expand<br>
	 *		(EVENT_AD_MINIMIZE,           EVENT_TYPE_STANDARD)		-	IAB metric, minimize<br>
	 *		(EVENT_AD_CLOSE,              EVENT_TYPE_STANDARD)		-	IAB metric, close<br>
	 *		(EVENT_AD_ACCEPT_INVITATION,  EVENT_TYPE_STANDARD)		-	IAB metric, accept invitation<br>
	 *		(EVENT_AD_SKIPPED_BY_USER,    EVENT_TYPE_STANDARD)		-	IAB metric, skip<br>
	 */
	public void addEventCallbackURLs(String eventName, String eventType, final List<String> urls);

	/**
	 * Set click through URL (replaces the CR value). Only for renderer use.
	 *
	 * @param url URL in String
	 * @param clickName name of the click in String, if clickName is null or empty, will set click through url to default click callback
	 */
	public void setClickThroughURL(String url, String clickName);

	/**
	 * Get the event callback URLs in a List. Only for renderer use.
	 *
	 * @param eventName name of the event
	 * @param eventType type of the event
	 * @return List of event callback URLs
	 * <br>
	 * <br>
	 * Available combination of input:<br>
	 *		(EVENT_AD_IMPRESSION, EVENT_TYPE_IMPRESSION)	-	impression, aka ad display start<br>
	 *		(EVENT_AD_CLICK,      EVENT_TYPE_CLICK)			-	click through<br>
	 *		(EVENT_AD_CLICK,      EVENT_TYPE_CLICK_TRACKING)	-	click tracking<br>
	 *		("a_custom_string",   EVENT_TYPE_CLICK)			-	custom click<br>
	 *		("a_custom_string",   EVENT_TYPE_CLICK_TRACKING)	-	custom click tracking<br>
	 *		(EVENT_AD_FIRST_QUARTILE,     EVENT_TYPE_IMPRESSION)	-	1st quartile<br>
	 *		(EVENTCALLBACK_MIDPOINT,      EVENT_TYPE_IMPRESSION)	-	middle point<br>
	 *		(EVENTCALLBACK_THIRDQUARTILE, EVENT_TYPE_IMPRESSION)	-	3rd quartile<br>
	 *		(EVENTCALLBACK_COMPLETE,      EVENT_TYPE_IMPRESSION)	-	complete<br>
	 *		(EVENT_AD_PAUSE,              EVENT_TYPE_STANDARD)		-	IAB metric, pause<br>
	 *		(EVENT_AD_RESUME,             EVENT_TYPE_STANDARD)		-	IAB metric, resume<br>
	 *		(EVENT_AD_REWIND,             EVENT_TYPE_STANDARD)		-	IAB metric, rewind<br>
	 *		(EVENT_AD_MUTE,               EVENT_TYPE_STANDARD)		-	IAB metric, mute<br>
	 *		(EVENT_AD_UNMUTE,             EVENT_TYPE_STANDARD)		-	IAB metric, unmute<br>
	 *		(EVENT_AD_COLLAPSE,           EVENT_TYPE_STANDARD)		-	IAB metric, collapse<br>
	 *		(EVENT_AD_EXPAND,             EVENT_TYPE_STANDARD)		-	IAB metric, expand<br>
	 *		(EVENT_AD_MINIMIZE,           EVENT_TYPE_STANDARD)		-	IAB metric, minimize<br>
	 *		(EVENT_AD_CLOSE,              EVENT_TYPE_STANDARD)		-	IAB metric, close<br>
	 *		(EVENT_AD_ACCEPT_INVITATION,  EVENT_TYPE_STANDARD)		-	IAB metric, accept invitation<br>
	 *		(EVENT_AD_SKIPPED_BY_USER,    EVENT_TYPE_STANDARD)		-	IAB metric, skip<br>
	 */
	public List<String> getEventCallbackURLs(String eventName, String eventType);
	
	/**
	 *	Get the playable companion ad instances.
	 *
	 *	@return a List of IAdInstance instances
	 */
	public List<IAdInstance> getCompanionAdInstances();
	
	/**
	 *	Whether the ad is required to be shown by law, usually the ad is a companion ad.
	 *
	 *	@return true if this ad is required to be shown, otherwise false
	 */
	public boolean isRequiredToShow();

	/**
	 * Get deal id of the ad instance if the ad is delivered via deal, otherwise it will be an empty String.
	 *
	 * @return a String value of the deal id of the ad instance
	 */
	public String getDealId();

	/**
	 * Get the open exchange id of the ad instance if the ad is delivered via the Open Exchange rule, otherwise it will be an empty String.
	 *
	 * @return a String value of the open exchange id of the ad instance
	 */
	public String getOpenExchangeId();

	/**
	 * Get the market unified ad id of the ad instance if the ad is delivered via deal or the Open Exchange rule, otherwise it will be an empty String.
	 *
	 * @return a String value of the market unified ad id of the ad instance
	 */
	public String getMarketUnifiedAdId();

	/**
	 * Get the sold as ad unit of an ad instance.
	 *
	 * @return a String value of the sold as ad unit of an ad instance.
	 */
	public String getSoAdUnit();

	/**
	 * Get the action of an ad instance.
	 *
	 * @return a String value of the action of an ad instance, and empty string if the ad instance doesn't contain action string.
	 */
	public String getAction();

	/**
	 * Get the skip offset of the skippable ad instance in seconds.
	 *
	 * @return an int value of the skipOffset from a 3rd-party VAST ad instance in seconds, -1 if the ad instance doesn't contain skipOffset or has an invalid value.
	 */
	public int getSkipOffset();

	/**
	 * Get the Icons per IAB VAST Icon spec (https://iabtechlab.com/wp-content/uploads/2019/06/VAST_4.2_final_june26.pdf section 3.11)
	 *
	 * @return a NodeList object containing the Icons element from third party VAST ads.
	 * This API should be called after receiving the defaultImpression event.
	 */
	public NodeList getIcons();

	/**
	 * Get all Extensions included in a third-party VAST or SMRX response.
	 *
	 * @return a List of Extensions containing all Extension elements.
	 */
	public List<Extension> getAllExtensions();

	/**
	 * Get specific Extension by extension type
	 *
	 * @param    type    type of the expected extensions
	 * @return a List of Extension objects whose type or key matches the string passed as an argument to getExtenionsByType.
	 */
	public List<Extension> getExtensionsByType(String type);

	/**
	 * A method that indicates whether or not an ad is skippable when it is called.
	 *
	 * @return For VPAID ad, return the getAdSkippableState() result from vpaid ad.
	 * 		   For video ad, return true if the ad playhead time of an ad passes the skipoffset time. Otherwise, it returns false. If there is no skipoffset time, it always returns false.
	 *		   For other type of ad, it always returns false.
	 */
	public boolean getAdSkippableState();

	/**
	 * A method that indicates whether or not an ad is fallback ad
	 *
	 * @return true if the ad is a fallback ad, otherwise false
	 */
	public boolean isFallbackAd();

	/**
	 * A method that sends the VAST tracking URL for certain SIMID related errors without firing a FW error beacon.
	 *
	 */
    void processSimidError(String errorCode);
}
