package tv.freewheel.ad.interfaces;
import java.util.HashMap;

/**
 * IRendererController is the common interface for controlling ad renderers.
 */
public abstract interface IRendererController {
	/**
	 * Pass the event to ad renderer.
	 *
	 * @param type name of the event
	 * <br>
	 * <br>
	 * Available event:<br>
	 * 	EVENT_AD_CLICK		-		click on the ad<br>
	 */
	public void processEvent(String type);

	/**
	 * See also {@link #processEvent(String)}.
	 *
	 * @param type name of the event.
	 * <br>
	 * <br>
	 * Available event:<br>
	 *	EVENT_AD_MEASUREMENT	-	measurement triggered
	 * <br>
	 * <br>
	 * @param extraInfo additional information need to be processed by AdManager. Available keys:
	 * <br>
	 *			<br>- INFO_KEY_CONCRETE_EVENT_ID Required when the eventName is EVENT_AD_MEASUREMENT.
	 *			<br>use this key to specify which measurement event is triggerd, i.e. the concrete event id(a String).
	 */
	public void processEvent(String type, HashMap<String, Object> extraInfo);
}
