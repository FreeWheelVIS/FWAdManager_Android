package tv.freewheel.ad.interfaces;

/**
 *	Interface for creative rendition asset, only for renderer use by now.
 */
public interface ICreativeRenditionAsset {
	/**
	 *	Get the URL of the asset.
	 *	
	 *	@return URL in String
	 */
	public String getURL();

	/**
	 *	Change the URL of the asset. Only for translator use.
	 *
	 *	@param url URL of the asset
	 */
	public void setURL(String url);

	/**
	 *	Get the content of the asset.
	 *	
	 *	@return content in String
	 */
	public String getContent();

	/**
	 *	Set the content of the asset. Only for translator use.
	 *	
	 *	@param content content in String
	 */
	public void setContent(String content);

	/**
	 *	Get the mime type of the asset.
	 *	
	 *	@return mime type in String
	 */
	public String getMimeType();

	/**
	 *	Set the mime type of the asset. Only for translator use.
	 *	
	 *	@param mimeType mime type in String
	 */
	public void setMimeType(String mimeType);

	/**
	 *	Get the content type of the asset.
	 *	
	 *	@return content type in String
	 */
	public String getContentType();

	/**
	 *	Set the content type of the asset. Only for translator use.
	 *	
	 *  @param contentType content type in a string
	 */
	public void setContentType(String contentType);

	/**
	 *	Get size of the asset.
	 *	
	 *	@return size in bytes, or -1 if unknown
	 */
	public int getBytes();

	/**
	 *	Set size of the asset. Only for translator use.
	 *	
	 *	@param bytes size in bytes, or -1 if unknown
	 */
	public void setBytes(int bytes);
}
