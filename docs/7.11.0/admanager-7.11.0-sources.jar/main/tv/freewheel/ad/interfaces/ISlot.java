package tv.freewheel.ad.interfaces;

import android.view.ViewGroup;

import java.util.List;

/**
 * ISlot is the base Ad placement unit, which is used to play the ads.
 */
public interface ISlot {
	/**
	 *	Get custom id of the slot.
	 *
	 *	@return custom id of the slot
	 */
	public String getCustomId();

	/**
	 * Get type of the slot
	 * @return the enum value of the slot type
	 */
	public IConstants.SlotType getSlotType();

	/**
	 *	Get time position of the slot.
	 *
	 *	@return time position of the slot
	 */
	public double getTimePosition();

	/**
	 * Get the time position class of the slot
	 *
	 * @return enumerated value of the time position class
	 */
	public IConstants.TimePositionClass getSlotTimePositionClass();

	/**
	 *	Get the duration of the embedded ads.
	 *
	 *	@return the duration of embedded ads, -1 if unavailable
	 */
	public double getEmbeddedAdsDuration();

	/**
	 *  Get the end time position of the slot.
	 *
	 *  @return the end time position of the temporal slot, -1 if unavailable
	 */
	public double getEndTimePosition();
	
	/**
	 *	Get width of the slot.
	 *
	 *	@return width in density-independent pixels
	 */
	public int getWidth();
	
	/**
	 *	Get height of the slot.
	 *
	 *	@return height in density-independent pixels
	 */
	public int getHeight();
	
	/**
	 *	Get slot display base object, the ad will be drawn on the base. <br>
	 *
	 *	@return the ViewGroup object. For Temporal Slot it is a FrameLayout, for nonTemporal Slot it is a RelativeLayout. If failed to create slotBase will return null
	 */
	public ViewGroup getBase();
	
	/**
	 *	Play the slot.
	 */
	public void play();
	
	/**
	 * 	Preload the slot.
	 */
	public void preload();
	
	/**
	 *	Stop the slot.
	 */
	public void stop();
	
	/**
	 * 	Pause the slot.
	 */
	public void pause();
	
	/**
	 * 	Resume the slot.
	 */
	public void resume();

	/**
	 *  Skip the current ad in the slot. Note that the fallback ads associated with the skipped ad will not be played.
	 */
	public void skipCurrentAd();
	
	/**
	 *	Set the parameters at slot level.
	 *
	 *	@param	name	key of the parameter to be set
	 *	@param	value	value for the key
	 */
	public void setParameter(String name, Object value);
	
	/**
	 *	Get duration of the slot.
	 *
	 *	@return a number in seconds, which is greater than or equal to 0
	 */
	public double getTotalDuration();
	
	/**
	 *	Get playheadTime of the slot.
	 *
	 *	@return a number in seconds, which is greater than or equal to 0
	 */
	public double getPlayheadTime();

	/**
	 * Get all ad instances in the slot. Only for player use.
	 *
	 * @return List of ad instances
	 */
	public List<IAdInstance> getAdInstances();

	/**
	 * Get the signal Id of the slot. Applicable only in Linear TV Integrations
	 * @return The string value of signal ID of the slot. Returns `null` if not available.
	 */
	String getSignalId();
}
