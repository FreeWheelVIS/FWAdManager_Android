package tv.freewheel.ad.interfaces;


/**
 * IEventListener is common interface for event listeners.
 */
public abstract interface IEventListener {
	
	/**
	 * This is the callback function that should be registered using addEventListener().
	 * When the event occurs, this function will be called.
	 * 
	 * @param event the IEvent object returned to the listener
	 */
	public void run(IEvent event);
}
