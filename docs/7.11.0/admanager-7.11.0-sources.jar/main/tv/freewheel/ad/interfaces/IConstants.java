package tv.freewheel.ad.interfaces;

/**
 * The IConstants interface contains all the constants for ad serving and rendering
 */
public interface IConstants {
	/**
	 * Capability Status.
	 */
	public enum CapabilityStatus {
		/**
		 * Capability is enabled/on
		 */
		ON(0),

		/**
		 * Capability is disabled/off
		 */
		OFF(1),

		/**
		 * Capability status is default
		 */
		DEFAULT(2);

		/**
		 * Value representing the capability status
		 */
		public final int status;

		CapabilityStatus(int status) {
			this.status = status;
		}
	}

	/**
	 * Enumeration of ID Types
	 */
	public enum IdType {
		/**
		 * Custom ID provided by non-FreeWheel parties
		 */
		CUSTOM(0),

		/**
		 * Unique ID provided by FreeWheel
		 */
		FREEWHEEL(1),

		/**
		 * Unique Group ID provided by FreeWheel
		 */
		FREEWHEEL_GROUP(2);

		/**
		 * Value representing the ID type
		 */
		public final int type;

		IdType(int type) {
			this.type = type;
		}
	}

	/**
	 * Enumeration of Request Modes
	 */
	enum RequestMode {
		/**
		 * Request is for On-Demand (VOD) playback
		 */
		ON_DEMAND(0),

		/**
		 * Request is for Live playback
		 */
		LIVE(1);

		/**
		 * Value representing the request mode
		 */
		public final int mode;

		RequestMode(int mode) {
			this.mode = mode;
		}
	}

	/**
	 * Enumeration of Video Asset Duration types
	 */
	enum VideoAssetDurationType {
		/**
		 * Duration is exact
		 */
		EXACT(1),

		/**
		 * Duration is variable
		 */
		VARIABLE(2);

		@Override
		public String toString() {
			if (this == EXACT) {
				return "EXACT";
			}
			return "VARIABLE";
		}

		/**
		 * Value representing the video asset duration type
		 */
		public final int type;

		VideoAssetDurationType(int type) {
			this.type = type;
		}
	}

	/**
	 * Enumeration of Video Asset Auto Play types
	 * <p>
	 * Auto Play impacts ad selection, especially for Preroll companion ads
	 */
	enum VideoAssetAutoPlayType {
		/**
		 * Video Asset does not play automatically
		 */
		NONE(0),

		/**
		 * Video Asset plays automatically on page load and user interaction is registered to start playback
		 */
		ATTENDED(1),

		/**
		 * Video Asset plays automatically but without any user's player interaction
		 */
		UNATTENDED(2),

		/**
		 * Video Asset plays after user clicks to play
		 */
		CLICK_TO_PLAY(3);

		/**
		 * Value representing the video asset auto play type
		 */
		public final int type;

		VideoAssetAutoPlayType(int type) {
			this.type = type;
		}
	}

	/**
	 * Enumeration of current video asset's playback states
	 */
	enum VideoState {
		/**
		 * video asset is playing
		 */
		PLAYING(1),

		/**
		 * video asset is paused
		 */
		PAUSED(2),

		/**
		 * video asset is stopped
		 */
		STOPPED(3),

		/**
		 * video asset did complete
		 */
		COMPLETED(4);

		/**
		 * Value representing the video asset's playback states
		 */
		public final int state;

		VideoState(int state) {
			this.state = state;
		}

	}

	/**
	 * Enumeration of slot types
	 */
	enum SlotType {
		/**
		 * Slot type temporal (linear, nonlinear)
		 */
		TEMPORAL(0),

		/**
		 * Slot type non-temporal (display, companion)
		 */
		NON_TEMPORAL(2);

		/**
		 * Value representing the slot type
		 */
		public final int type;

		SlotType(int type) {
			this.type = type;
		}
	}

	/**
	 * Enumeration of ParameterLevel
	 */
	enum ParameterLevel {
		/**
		 * Profile level parameter
		 */
		PROFILE(0),

		/**
		 * Global level parameter
		 */
		GLOBAL(1),

		/**
		 * Slot level parameter
		 */
		SLOT(2),

		/**
		 * Creative level parameter
		 */
		CREATIVE(3),

		/**
		 * Rendition level parameter
		 */
		RENDITION(4),

		/**
		 * Override level parameter, highest priority
		 */
		OVERRIDE(5);

		/**
		 * Value representing the parameter level
		 */
		public final int level;

		ParameterLevel(int level) {
			this.level = level;
		}
	}

	/**
	 * Enumeration of activity states
	 */
	enum ActivityState {

		/**
		 * Activity is created
		 */
		CREATED(1),

		/**
		 * Activity did start
		 */
		STARTED(2),

		/**
		 * Activity did restart
		 */
		RESTARTED(3),

		/**
		 * Activity did pause
		 */
		PAUSED(4),

		/**
		 * Activity did resume
		 */
		RESUMED(5),

		/**
		 * Activity did stop
		 */
		STOPPED(6),

		/**
		 * Activity is destroyed
		 */
		DESTROYED(7);

		/**
		 * Value representing the activity state
		 */
		public final int state;

		ActivityState(int state) {
			this.state = state;
		}
	}

	/**
	 * AdManager publishes notification of this topic after ad request initialized.
	 * 
	 * @return a string value representing event request initiated (requestInitiated)
	 */
	public String EVENT_REQUEST_INITIATED();

	/**
	 * AdManager publishes notification of this topic after ad request completed.
	 * 
	 * @return a string value representing event request complete (requestComplete)
	 */
	public String EVENT_REQUEST_COMPLETE();

	/**
	 * AdManager publishes notification of this topic when a temporal slot
	 * will played and need content video to pause.
	 * 
	 * @return a string value representing event request content video pause (requestContentVideoPause)
	 */
	public String EVENT_REQUEST_CONTENT_VIDEO_PAUSE();

	/**
	 * AdManager publishes notification of this topic when a temporal slot
	 * play end and need content video to resume.
	 * 
	 * @return a string value representing event request content video resume (requestContentVideoResume)
	 */
	public String EVENT_REQUEST_CONTENT_VIDEO_RESUME();

	/**
	 * AdManager publishes notification of this topic before slot start.
	 * 
	 * @return a string value representing event slot start (slotStarted)
	 */
	public String EVENT_SLOT_STARTED();

	/**
	 * AdManager publishes notification of this topic after slot ended.
	 * 
	 * @return a string value representing event slot ended (slotEnded)
	 */
	public String EVENT_SLOT_ENDED();

	/**
	 * AdManager publishes notification of this topic after slot preload completed.
	 * 
	 * @return a string value representing event slot preloaded (slotPreloaded)
	 */
	public String EVENT_SLOT_PRELOADED();

	/**
	 * AdManager publishes notification of this topic after a user action is signaled.
	 * 
	 * @return a string value representing event user action notified (userActionNotified)
	 */
	public String EVENT_USER_ACTION_NOTIFIED();

	/**
	 * AdManager publishes the event on the activity state changed.
	 * 
	 * @return a string value representing event activity state changed (activityStateChanged)
	 */
	public String EVENT_ACTIVITY_STATE_CHANGED();

	/**
	 * AdManager publishes the event when a Player Extension is loaded.
	 * 
	 * @return a string value representing event extension loaded (extensionLoaded)
	 */
	public String EVENT_EXTENSION_LOADED();

	/**
	 * Predefined ad unit: preroll.
	 * 
	 * @return a string value representing ad unit preroll (PREROLL)
	 */
	public String ADUNIT_PREROLL();

	/**
	 * Predefined ad unit: midroll.
	 * 
	 * @return a string value representing ad unit midroll (MIDROLL)
	 */
	public String ADUNIT_MIDROLL();

	/**
	 * Predefined ad unit: postroll.
	 * 
	 * @return a string value representing ad unit postroll (POSTROLL)
	 */
	public String ADUNIT_POSTROLL();

	/**
	 * Predefined ad unit: overlay.
	 * 
	 * @return a string value representing ad unit overlay (OVERLAY)
	 */
	public String ADUNIT_OVERLAY();

	/**
	 * Predefined ad unit: pause_midroll.
	 * 
	 * @return a string value representing ad unit pause_midroll (PAUSE_MIDROLL)
	 */
	public String ADUNIT_PAUSE_MIDROLL();

	/**
	 * Predefined ad unit: unknown.
	 * 
	 * @return a string value representing ad unit unknown (UNKNOWN)
	 */
	public String ADUNIT_UNKNOWN();

	/**
	 * Type of ad unit: preroll of a live stream.
	 * 
	 * @return a string value representing ad unit stream preroll (stream_preroll)
	 */
	public String ADUNIT_STREAM_PREROLL();

	/**
	 * Type of ad unit: postroll of a live stream.
	 * 
	 * @return a string value representing ad unit stream postroll (stream_postroll)
	 */
	public String ADUNIT_STREAM_POSTROLL();

	/**
	 * Enumeration of slot time position classes
	 */
	enum TimePositionClass {
		/**
		 * Preroll, played before starting the playback of content video
		 */
		PREROLL(1),

		/**
		 * Midroll, played linearly during the playback of content video
		 */
		MIDROLL(2),

		/**
		 * Postroll, played after completing the playback of content video
		 */
		POSTROLL(3),

		/**
		 * Overlay, played non-linearly, overlaying on top of the content video playback
		 */
		OVERLAY(4),

		/**
		 * Display, played with no relation to the playback of content video
		 */
		DISPLAY(5),

		/**
		 * Pause Midroll, played when content video playback is paused by the user
		 */
		PAUSE_MIDROLL(6);

		/**
		 * Value representing the time position class
		 */
		public final int timeClass;

		TimePositionClass(int timeClass) {
			this.timeClass = timeClass;
		}

		@Override
		public String toString() {
			switch (this) {
				case PREROLL:
					return "preroll";
				case MIDROLL:
					return "midroll";
				case POSTROLL:
					return "postroll";
				case DISPLAY:
					return "display";
				case OVERLAY:
					return "overlay";
				case PAUSE_MIDROLL:
					return "pause_midroll";
			}
			return super.toString();
		}
	}

	/**
	 * Player expects template-based slots generated by ad server.
	 * <br><strong>This is on by default.</strong>
	 * 
	 * @return a string value representing capability slot template (supportsSlotTemplate)
	 */
	public String CAPABILITY_SLOT_TEMPLATE();

	/**
	 * Allow the same ad to be delivered into multiple slots.
	 * 
	 * @return a string value representing capability adunit in multiple slots (supportsAdUnitInMultipleSlots)
	 */
	public String CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS();

	/**
	 * Bypass commercial ratio restriction.
	 * 
	 * @return a string value representing capability bypass commercial ratio restriction (bypassCommercialRatioRestriction)
	 */
	public String CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION();

	/**
	 * Player expects ad server to check targeting for candidate ads.
	 * 
	 * @return a string value representing capability check targeting (checkTargeting)
	 */
	public String CAPABILITY_CHECK_TARGETING();

	/**
	 * Indicates that the player supports slot impression and slot end callbacks;
	 * 
	 * @return a string value representing capability slot callback (supportsSlotCallback)
	 */
	public String CAPABILITY_SLOT_CALLBACK();

	/**
	 * When set, one video view event will be recorded by the ad server for each ad request, and AdManager will not fire video view callbacks.
	 * 
	 * @return a string value representing capability record video view (recordVideoView)
	 */
	public String CAPABILITY_RECORD_VIDEO_VIEW();

	/**
	 * Used to reset the exclusivity state for the current session in live mode
	 * 
	 * @return a string value representing capability reset exclusivity (resetExclusivity)
	 */
	public String CAPABILITY_RESET_EXCLUSIVITY();

	/**
	 * Player expects ad server synchronize the request state between multiple request in live mode
	 * 
	 * @return a string value representing capability synchronize multiple requests (synchronizeMultipleRequests)
	 */
	public String CAPABILITY_SYNC_MULTI_REQUESTS();

	/**
	 * This enables ad server to return the renderer manifest settings in the ad response
	 * 
	 * @return a string value representing capability requires renderer manifest (requiresRendererManifest)
	 */
	public String CAPABILITY_REQUIRES_RENDERER_MANIFEST();

	/**
	 * Player expects multiple creative renditions for an ad.
	 * <br><strong>This is on by default.</strong>
	 * 
	 * @return a string value representing capability multiple creative renditions (expectMultipleCreativeRenditions)
	 */
	public String CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS();

	/**
	 * Slot impression.
	 * 
	 * @return a string value representing event slot impression (slotImpression)
	 */
	public String EVENT_SLOT_IMPRESSION();

	/**
	 * Ad PreInit.
	 * <br>Ad PreInit is dispatched when an AdInstance has started either playback attempt or preloading in background, whichever comes first.
	 * <br>Please note, PreInit is not dispatched when replaying a slot (or the adInstance in it). Also, multiple PreInit's will be dispatched when unwrapping multiple wrappers of VAST
	 * 
	 * @return a string value representing event ad preinit (preInit)
	 */
	public String EVENT_AD_PREINIT();

	/**
	 * Ad impression.
	 * 
	 * @return a string value representing event ad impression (defaultImpression)
	 */
	public String EVENT_AD_IMPRESSION();

	/**
	 * Ad impression end.
	 * 
	 * @return a string value representing event ad impression end (adEnd)
	 */
	public String EVENT_AD_IMPRESSION_END();

	/**
	 * Ad quartile.
	 * 
	 * @return a string value representing event ad quartile (quartile)
	 */
	public String EVENT_AD_QUARTILE();

	/**
	 * Ad first quartile.
	 * 
	 * @return a string value representing event ad first quartile (firstQuartile)
	 */
	public String EVENT_AD_FIRST_QUARTILE();

	/**
	 * Ad midPoint.
	 * 
	 * @return a string value representing event ad midPoint (midPoint)
	 */
	public String EVENT_AD_MIDPOINT();

	/**
	 * Ad third quartile.
	 * 
	 * @return a string value representing event ad third quartile (thirdQuartile)
	 */
	public String EVENT_AD_THIRD_QUARTILE();

	/**
	 * Ad complete.
	 * 
	 * @return a string value representing event ad complete (complete)
	 */
	public String EVENT_AD_COMPLETE();

	/**
	 * Ad click.
	 * 
	 * @return a string value representing a click event (defaultClick)
	 */
	public String EVENT_AD_CLICK();

	/**
	 * Ad mute.
	 * 
	 * @return a string value representing event ad mute (_mute)
	 */
	public String EVENT_AD_MUTE();

	/**
	 * Ad unmute.
	 * 
	 * @return a string value representing event ad unmute (_un-mute)
	 */
	public String EVENT_AD_UNMUTE();

	/**
	 * Ad collapse.
	 * 
	 * @return a string value representing event ad collapse (_collapse)
	 */
	public String EVENT_AD_COLLAPSE();

	/**
	 * Ad expand.
	 * 
	 * @return a string value representing event ad expand (_expand)
	 */
	public String EVENT_AD_EXPAND();

	/**
	 * Ad pause.
	 * 
	 * @return a string value representing event ad pause (_pause)
	 */
	public String EVENT_AD_PAUSE();

	/**
	 * Ad resume.
	 * 
	 * @return a string value representing event ad resume (_resume)
	 */
	public String EVENT_AD_RESUME();

	/**
	 * Ad rewind.
	 * 
	 * @return a string value representing event ad rewind (_rewind)
	 */
	public String EVENT_AD_REWIND();

	/**
	 * Ad accept invitation.
	 * 
	 * @return a string value representing event ad accept invitation (_accept-invitation)
	 */
	public String EVENT_AD_ACCEPT_INVITATION();

	/**
	 * Ad close.
	 * 
	 * @return a string value representing event ad close (_close)
	 */
	public String EVENT_AD_CLOSE();

	/**
	 * Ad has been skipped by the user.
	 * 
	 * @return a string value representing event ad skipped by user (_skip)
	 */
	public String EVENT_AD_SKIPPED_BY_USER();

	/**
	 * Ad reached a progress point. Player can use this event to listen for when a progress tracking event fired. Player can access the progress offset value in seconds using FWInfoKeyAdOffset. VPAID ads do not support this event type.
	 *
	 * The event carry the INFO_KEY_OFFSET to show the offset value in second
	 * 
	 * @return a string value representing event ad progress (_progress)
	 */
	public String EVENT_AD_PROGRESS();

	/**
	 * Notifies that the ad is skippable when the current playhead time passes the skipoffset time. This will not fire if no skipoffset is provided.
	 * 
	 * @return a string value representing event ad skippable state changed (skippableStateChanged)
	 */
	public String EVENT_AD_SKIPPABLE_STATE_CHANGED();

	/**
	 * Ad minimize.
	 * 
	 * @return a string value representing event ad minimize (_minimize)
	 */
	public String EVENT_AD_MINIMIZE();

	/**
	 * Ad loaded.
	 * 
	 * @return a string value representing event ad loaded (loaded)
	 */
	public String EVENT_AD_LOADED();

	/**
	 * Ad started. Only for renderer use.
	 * 
	 * @return a string value representing event ad started (started)
	 */
	public String EVENT_AD_STARTED();

	/**
	 * Ad stopped. Only for renderer use.
	 * 
	 * @return a string value representing event ad stopped (stopped)
	 */
	public String EVENT_AD_STOPPED();

	/**
	 * Ad temporarily paused internally in order to buffer more data.
	 * 
	 * @return a string value representing event ad buffering start (bufferingStart)
	 */
	public String EVENT_AD_BUFFERING_START();

	/**
	 * Ad resumed internally after filling buffers.
	 * 
	 * @return a string value representing event ad buffering end (bufferingEnd)
	 */
	public String EVENT_AD_BUFFERING_END();

	/**
	 * Ad measurement triggered.
	 * 
	 * @return a string value representing event ad measurement (concreteEvent)
	 */
	public String EVENT_AD_MEASUREMENT();

	/**
	 * Ad playback volume changed
	 * 
	 * @return a string value representing event ad volume changed (_volume-changed)
	 */
	public String EVENT_AD_VOLUME_CHANGED();

	/**
	 * Event sent when the video display base changes.
	 * 
	 * @return a string value representing event video display base changed (videoDisplayBaseChanged)
	 */
	public String EVENT_VIDEO_DISPLAY_BASE_CHANGED();

	/**
	 * Error.
	 * 
	 * @return a string value representing event error (_e_unknown)
	 */
	public String EVENT_ERROR();

	/**
	 * Reseller no ad.
	 * 
	 * @return a string value representing event reseller no ad (resellerNoAd)
	 */
	public String EVENT_RESELLER_NO_AD();

	/**
	 * Click tracking event type.
	 * 
	 * @return a string value representing event type click tracking (CLICKTRACKING)
	 */
	public String EVENT_TYPE_CLICK_TRACKING();

	/**
	 * Impression event type.
	 * 
	 * @return a string value representing event type impression (IMPRESSION)
	 */
	public String EVENT_TYPE_IMPRESSION();

	/**
	 * Click through event type.
	 * 
	 * @return a string value representing event type click through (CLICK)
	 */
	public String EVENT_TYPE_CLICK();

	/**
	 * Standard event type.
	 * 
	 * @return a string value representing event type standard (STANDARD)
	 */
	public String EVENT_TYPE_STANDARD();
	/**
	 * When enabled, VideoRenderer will always use MediaPlayer for video playback, even when ExoPlayer is included as a dependency in the client app.
	 * <br>Value can be string "true", "false". Default is "false".
	 *
	 * @return a string value representing parameter video renderer force mediaPlayer (renderer.video.forceMediaPlayer)
	 */
	public String PARAMETER_VIDEO_RENDERER_FORCE_MEDIA_PLAYER();

	/**
	 * Controls whether VideoRenderer calls requestFocus() on VideoAdView
	 * <br>Value can be string "true", "false". Default is "true".
	 * 
	 * @return a string value representing parameter video renderer request focus (renderer.video.requestFocus)
	 */
	public String PARAMETER_VIDEO_RENDERER_REQUEST_FOCUS();

	/**
	 * Indicates the maximum amount of VAST wrappers allowed. The ad will fail with an error when the number of wrappers equals this number.
	 * <br>Should be a string value which can convert to a int. Default value is "5".
	 * 
	 * @return a string value representing parameter vast max wrapper count (translator.vast.maxWrapperCount)
	 */
	public String PARAMETER_VAST_MAX_WRAPPER_COUNT();

	/**
	 * Indicates the amount of time in milliseconds allowed for a VAST creative before it fails due to timeout.
	 * <br>Should be a string value which can convert to a int. Default value is "5000".
	 * 
	 * @return a string value representing parameter vast timeout in milliseconds (translator.vast.timeoutInMilliseconds)
	 */
	public String PARAMETER_VAST_TIMEOUT_IN_MILLISECONDS();

	/**
	 * A string that the SkippableAdExtension should use for the skip button text.
	 *		- If the parameter is set, the SkippableAdExtension will use this string as the skip button, when skip is enabled.
	 * 		- If the parameter is not set, the SkippableAdExtension will set the default text to 'Skip Ad'.
	 * 
	 * @return a string value representing parameter extension skippable ad button text (extension.skippableAd.text)
	 */
	public String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_TEXT();

	/**
	 * 	A string containing the html that the SkippableAdExtension should use for the skip button WebView.
	 * 		- If the parameter is set, the SkippableAdExtension will use the provided html string to create the WebView to display the button.
	 * 			- The HTML must contain an element with the id, "_fw_skip_button", which the extension will use the display the countdown and button text.
	 * 		- If the parameter is not set or there is no html string found, the SkippableAdExtension will use the default html for the skip button.
	 * 
	 * @return a string value representing parameter extension skippable ad button html (extension.skippableAd.html)
	 */
	public String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HTML();

	/**
	 * 	A string that converts to an integer containing the width in dp that the SkippableAdExtension should use for the skip button WebView.
	 * 		- If the parameter is set, the SkippableAdExtension will use the provided width string to create the WebView to display the button.
	 * 		- If the parameter is not set or there is no width string found, the SkippableAdExtension will use the default width for the skip button.
	 * 		- The default width is 80.
	 * 
	 * @return a string value representing parameter extension skippable ad button width (extension.skippableAd.width)
	 */
	public String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_WIDTH();

	/**
	 * 	A string containing the height that the SkippableAdExtension should use for the skip button WebView.
	 * 		- If the parameter is set, the SkippableAdExtension will use the provided height string to create the WebView to display the button.
	 * 		- If the parameter is not set or there is no height string found, the SkippableAdExtension will use the default height for the skip button.
	 * 		- The default height utilizes the WRAP_CONTENT value, -2.
	 * 
	 * @return a string value representing parameter extension skippable ad button height (extension.skippableAd.height)
	 */
	public String PARAMETER_EXTENSION_SKIPPABLE_AD_BUTTON_HEIGHT();

	/**
	 * Indicates the amount of time in milliseconds used by the VideoRenderer, CustomPlayerRenderer and VPAIDRenderer to load the creative before it fails due to timeout.
	 * <br>Should be a string value which can convert to a int.
	 * <br>Default value used by VideoRenderer and CustomPlayerRenderer is "10000".
	 * <br>Default value used by VPAIDRenderer is "5000".
	 * 
	 * @return a string value representing parameter timeout milliseconds before start (timeoutMillisecondsBeforeStart)
	 */
	public String PARAMETER_TIMEOUT_MILLISECONDS_BEFORE_START();

	/**
	 * Specify whether renderer should handle user tapping on a temporal ad.
	 * <br>Value can be string "true", "false". Default is "true".
	 * <br>Note: Note: if the value is set to "false", app should handle the ad click by itself.
	 * <br>For example, opening the click through url in a browser.
	 * 
	 * @return a string value representing parameter click detection (renderer.video.clickDetection)
	 */
	public String PARAMETER_CLICK_DETECTION();

	/**
	 * Used by VideoRenderer and CustomPlayerRenderer to determine the amount of time in milliseconds to wait until a frozen ad times out during playback.
	 * <br>Should be a string value, in milliseconds, which can convert to an int.
	 * <br>Default value used by VideoRenderer and CustomPlayerRenderer is "10000" milliseconds.
	 * 
	 * @return a string value representing parameter playback unexpected pause timeout (renderer.video.playbackUnexpectedPauseTimeout)
	 */
	public String PARAMETER_PLAYBACK_UNEXPECTED_PAUSE_TIMEOUT();

	/**
	 * Specify whether enable counting replay callback. If the value is set to "true", init value will be included in quartile callback.
	 * <br>Value can be string "true", "false". Default is "false".
	 * 
	 * @return a string value representing parameter enable counting replay callback (enableCountingReplayCallback)
	 */
	public String PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK();

	/**
	 * Specify whether VPAID creative URLs should be double decoded before fetching them.
	 * <br>Please note, previous of 6.27, VPAIDRenderer would double decode the VPAID creative URL by default.
	 * <br>However, we are changing this to single decoding in 6.27.
	 * <br>If you want to enforce double decoding, please set this parameter to "true"
	 * 
	 * @return a string value representing parameter double decode VPAID URL (doubleDecodeVPAIDURL)
	 */
	public String PARAMETER_DOUBLE_DECODE_VPAID_URL();

	/**
     * Sets the inPreferredConfig value for the BitmapFactory.Options. This value can be set to one of the valid String value listed below.
     * Acceptable values include: "ALPHA_8", "RGB_565", "ARGB_4444", "ARGB_8888", "RGBA_F16", "HARDWARE", and "RGBA_1010102".
     * If this parameter is not set or set incorrectly, AdManager will use the default value from the Android system.
     * For more information, please see android.graphics.Bitmap.Config's documentation.
     * @see android.graphics.Bitmap.Config
     *
     * /
    public String PARAMETER_IMAGE_RENDERER_IN_PREFERRED_CONFIG();

    /**
     * The dictionary key value for retrieving overridden url to open on ad click event.
     *
     * @return a string value representing info key url (url)
     */
	public String INFO_KEY_URL();

	/**
	 * The dictionary key value for retrieving customId info.
	 * 
	 * @return a string value representing info key custom id (customId)
	 */
	public String INFO_KEY_SLOT_CUSTOM_ID();

	/**
	 * The dictionary key value for retrieving event message.
	 * 
	 * @return a string value representing info key message (message)
	 */
	public String INFO_KEY_MESSAGE();

	/**
	 * The dictionary key value to specify whether the event success. <br>
	 * Only used in request complete event.
	 * 
	 * @return a string value representing info key success (success)
	 */
	public String INFO_KEY_SUCCESS();

	/**
	 * The dictionary key value to add additional information for a event.
	 * The additional information can be click url, configuration, error code, error message
	 * This additional information need to be processed by AdManager
	 * 
	 * @return a string value representing info key extra info (extraInfo)
	 */
	public String INFO_KEY_EXTRA_INFO();

	/**
	 * The dictionary key value to specify start time position for trick play, default will be 0. <br>
	 * Only used in default ad impression event.
	 * 
	 * @return a string value representing info key start time position (startTimePosition)
	 */
	public String INFO_KEY_START_TIME_POSITION();

	/**
	 * IRenderer.getModuleInfo() function return two key/value pairs.
	 * Key:INFO_KEY_MODULE_TYPE() Value: one value of enum ModuleType
	 * Key:INFO_KEY_REQUIRED_SDK_VERSION() Value: Check constant INFO_KEY_REQUIRED_SDK_VERSION()
	 * 
	 * @return a string value representing info key module type (moduleType)
	 */
	public String INFO_KEY_MODULE_TYPE();

	/**
	 * IRenderer.getModuleInfo() function return two key/value pairs.
	 * Key:INFO_KEY_MODULE_TYPE() Value: Check INFO_KEY_MODULE_TYPE()
	 * Key:INFO_KEY_REQUIRED_SDK_VERSION() Value: FreeWheelVersion.FW_SDK_INTERFACE_VERSION
	 * 
	 * @return a string value representing info key required sdk version (requiredAPIVersion)
	 */
	public String INFO_KEY_REQUIRED_SDK_VERSION();

	/**
	 * The dictionary key value for retrieving adId message.
	 * 
	 * @return a string value representing info key ad id (adId)
	 */
	public String INFO_KEY_AD_ID();

	/**
	 * The dictionary key value for retrieving creativeId message.
	 * 
	 * @return a string value representing info key creative id (creativeId)
	 */
	public String INFO_KEY_CREATIVE_ID();

	/**
	 * The dictionary key value for retrieving adInstance message.
	 * <br> Value is IAdInstance Object.
	 * 
	 * @return a string value representing info key ad instance (adInstance)
	 */
	public String INFO_KEY_ADINSTANCE();

	/**
	 * The dictionary key value for concrete event id. The concrete event id should be a String.
	 * 
	 * @return a string value representing info key concrete event id (concreteEventId)
	 */
	public String INFO_KEY_CONCRETE_EVENT_ID();

	/**
	 * The dictionary key for retrieving user action enum value
	 * 
	 * @return a string value representing info key user triggered action (userTriggeredAction)
	 */
	public String INFO_KEY_USER_TRIGGERED_ACTION();

	/**
	 * The dictionary key of EVENT_ACTIVITY_STATE_CHANGED event.
	 * <p>
	 * Supported values:
	 * <br>ACTIVITY_CALLBACK_PAUSE
	 * <br>ACTIVITY_CALLBACK_RESUME
	 * 
	 * @return a string value representing info key activity state (activityState)
	 */
	public String INFO_KEY_ACTIVITY_STATE();

	/**
	 * The dictionary key of EVENT_EXTENSION_LOADED event.
	 * <br>This key can be used to retrieve the loaded extension's name
	 * 
	 * @return a string value representing info key extension name (moduleName)
	 */
	public String INFO_KEY_MODULE_NAME();

	/**
	 * Enumeration of module types
	 */
	enum ModuleType {
		/**
		 * Model type renderer; handles ad playback
		 */
		RENDERER,

		/**
		 * Model type translator; only translates ad but doesn't handle ad playback
		 */
		TRANSLATOR;

		@Override
		public String toString() {
			switch (this) {
				case RENDERER:
					return "renderer";
				case TRANSLATOR:
					return "translator";
			}
			return super.toString();
		}
	}

	/**
	 * The dictionary key value for VAST error code. Only for renderer use.
	 * 
	 * @return a string value representing info key vast error code (vastErrorCode)
	 */
	public String INFO_KEY_VAST_ERROR_CODE();

	/**
	 * The dictionary key value for error code. Only for renderer use.
	 * 
	 * @return a string value representing info key error code (errorCode)
	 */
	public String INFO_KEY_ERROR_CODE();

	/**
	 * The dictionary key value for additional error message. Only for renderer use.
	 * 
	 * @return a string value representing info key error info (errorInfo)
	 */
	public String INFO_KEY_ERROR_INFO();

	/**
	 * The volume key value for volume changed event
	 * 
	 * @return a string value representing info key volume (volume)
	 */
	public String INFO_KEY_VOLUME();

	/**
	 * The offset value in second for progress event
	 * 
	 * @return a string value representing info key offset (offset)
	 */
	public String INFO_KEY_OFFSET();

	/**
	 * The ad skippable state boolean value for EVENT_AD_SKIPPABLE_STATE_CHANGED event
	 * 
	 * @return a string value representing info key ad skippable state (skippableState)
	 */
	public String INFO_KEY_AD_SKIPPABLE_STATE();

	/**
	 * The dictionary key value for show browser.
	 * 
	 * @return a string value representing info key show browser (showBrowser)
	 */
	public String INFO_KEY_SHOW_BROWSER();

	/**
	 * Error type IO error. Only for renderer use.
	 * 
	 * @return a string value representing error type IO (_e_io)
	 */
	public String ERROR_IO();

	/**
	 * Error type timeout error. Only for renderer use.
	 * 
	 * @return a string value representing error type timeout (_e_timeout)
	 */
	public String ERROR_TIMEOUT();

	/**
	 * Error type null asset error. Only for renderer use.
	 * 
	 * @return a string value representing error type null asset (_e_null-asset)
	 */
	public String ERROR_NULL_ASSET();

	/**
	 * Error type null adInstance unavailable. Only for renderer use.
	 * 
	 * @return a string value representing error type adInstance unavailable (_e_adinst-unavail)
	 */
	public String ERROR_ADINSTANCE_UNAVAILABLE();

	/**
	 * Error type unknown. Only for renderer use.
	 * 
	 * @return a string value representing error type unknown (_e_unknown)
	 */
	public String ERROR_UNKNOWN();

	/**
	 * Error type missing parameter. Only for renderer use.
	 * 
	 * @return a string value representing error type missing parameter (_e_missing-param)
	 */
	public String ERROR_MISSING_PARAMETER();

	/**
	 * Error type no ad available. Only for renderer use.
	 * 
	 * @return a string value representing error type no ad available (_e_no-ad)
	 */
	public String ERROR_NO_AD_AVAILABLE();

	/**
	 * Error type parse error. Only for renderer use.
	 * 
	 * @return a string value representing error type parse error (_e_parse)
	 */
	public String ERROR_PARSE();

	/**
	 * Error type invalid value. Only for renderer use.
	 * 
	 * @return a string value representing error type invalid value (_e_invalid-value)
	 */
	public String ERROR_INVALID_VALUE();

	/**
	 * Error type no renderer. Only for renderer use.
	 * 
	 * @return a string value representing error type no renderer (_e_no-renderer)
	 */
	public String ERROR_NO_RENDERER();

	/**
	 * Error type invalid slot. Only for renderer use.
	 * 
	 * @return a string value representing error type invalid slot (_e_invalid-slot)
	 */
	public String ERROR_INVALID_SLOT();

	/**
	 * Error type unsupported 3rd party feature. Only for renderer use.
	 * 
	 * @return a string value representing error type unsupported 3rd party feature (_e_unsupp-3p-feature)
	 */
	public String ERROR_UNSUPPORTED_3P_FEATURE();

	/**
	 * Error type renderer init fails. Only for renderer use.
	 * 
	 * @return a string value representing error type renderer init (_e_renderer-init)
	 */
	public String ERROR_RENDERER_INIT();

	/**
	 * Error type 3rd part component error. Only for renderer use.
	 * 
	 * @return a string value representing error type 3rd party component (_e_3p-comp)
	 */
	public String ERROR_3P_COMPONENT();

	/**
	 * @deprecated No longer used.
	 * 
	 * @return a string value representing info key custom event name (customEventName)
	 */
	public String INFO_KEY_CUSTOM_EVENT_NAME();

	/**
	 * Enumeration of non-temporal slot ad initial options
	 */
	enum SlotInitialAdOption {
		/**
		 * Display an ad in the non-temporal slot
		 */
		STAND_ALONE(0),

		/**
		 * Keep the original ad in the non-temporal slot
		 */
		KEEP_ORIGINAL(1),

		/**
		 * Ask ad server to fill this slot with the first companion ad, or keep the original ad if there is no companion ad
		 */
		FIRST_COMPANION_ONLY(2),

		/**
		 * Ask ad server to fill this slot with the first companion ad, or display a new stand alone ad
		 */
		FIRST_COMPANION_OR_STAND_ALONE(3),

		/**
		 * Ask ad server to fill this slot with the first companion ad, or display a new stand alone ad if there is no companion ad
		 */
		FIRST_COMPANION_THEN_STAND_ALONE(4),

		/**
		 * Ask ad server to fill this slot with the first companion ad, but never deliver a standAlone ad if there is no companion ad
		 */
		FIRST_COMPANION_OR_NO_STAND_ALONE(5),

		/**
		 * Ask ad server to fill this slot only with the PREROLL slot's companion ad if there is one
		 */
		NO_STAND_ALONE(6),

		/**
		 * Ask ad server to fill this slot with a standAlone ad only when no temporal ad will be delivered, if there is any temporal ad selected, let this slot empty
		 */
		NO_STAND_ALONE_IF_TEMPORAL(7),

		/**
		 * Ask ad server to fill this slot with a standAlone ad only when no temporal ad will be delivered, if there is any temporal ad selected, let this slot stay unfilled; however if there is companion, can use this companion to initial this slot
		 */
		FIRST_COMPANION_OR_NO_STAND_ALONE_IF_TEMPORAL(8);

		/**
		 * Value representing the slot initial ad option
		 */
		public final int option;

		SlotInitialAdOption(int option) {
			this.option = option;
		}
	}

	/**
	 * Specify the user's advertising identifier passthrough to 3rd party component.
	 * 
	 * @return a string value representing parameter PARAMETER_GOOGLE_ADVERTISING_ID (_fw_did_google_advertising_id)
	 */
	public String PARAMETER_GOOGLE_ADVERTISING_ID();


	/**
	 * Parameter used to set the _fwu_topic key-value pair.
	 *
	 * The value associated with this key should be a string in the following format:<br>
	 * <pre>    'android:taxonomyVersion1:modelVersion1:topicId1,android:taxonomyVersion2:modelVersion2:topicId2'</pre>
	 * Usage:
	 * <pre>
	 * topicsString = result.getTopics().stream()
	 *     .map(topic -> String.format("android:%d:%d:%d", topic.getTaxonomyVersion(), topic.getModelVersion(), topic.getTopicId()))
	 *     .collect(Collectors.joining(","));
	 * KeyValueConfiguration kvConfig = new KeyValueConfiguration(constants.PARAMETER_FWU_TOPIC(), topicsString);
	 * adRequestConfiguration.addKeyValueConfiguration(topicsKv);
	 * </pre>
	 * When manually setting the value, adManager.enableTopics() should not be called. If adManager.enableTopics() is called when manually setting this key/value,
	 * AdManager will ignore adManager.enableTopics() and populate the key/value pair with the value provided by the client.
	 *
	 * @return a string value representing parameter PARAMETER_FWU_TOPIC (_fwu_topic)
	 */
	public String PARAMETER_FWU_TOPIC();

	/**
	 * Parameter used to set whether the ad is subject to GDPR regulations in the application. This key should be set in SharedPreferences.
	 * <p>Supported values: 1, 0, null.
	 * Usage: <pre>PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putInt(constants.IAB_SUBJECT_TO_GDPR(), 1).apply();</pre>
	 * 
	 * @return a string value representing parameter IAB_SUBJECT_TO_GDPR (IAB_SUBJECT_TO_GDPR)
	 */
	public String IAB_SUBJECT_TO_GDPR();

	/**
	 * Parameter used to set what information and which vendors the user consented to in the application. This key should be set in SharedPreferences.
	 * Usage: <pre>PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putString(constants.IAB_CONSENT_STRING(), YOUR_CONSENT_STRING).apply();</pre>
	 * 
	 * @return a string value representing parameter IAB_CONSENT_STRING (IABTCF_TCString)
	 */
	public String IAB_CONSENT_STRING();

	/**
	 * Used to set the disclosures made and choices selected by a user regarding consumer data privacy in association with CCPA. This key should be set in SharedPreferences.
	 * Usage: <pre>PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putString(constants.IAB_US_PRIVACY_STRING(), YOUR_US_PRIVACY_STRING).apply();</pre>
	 * 
	 * @return a string value representing parameter IAB_US_PRIVACY_STRING (IABUSPrivacy_String)
	 */
	public String IAB_US_PRIVACY_STRING();

	/**
	 * Used to set the disclosures made and choices selected by a user regarding consumer data privacy in association with GPP CMP API. This key should be set in SharedPreferences.
	 * <p>This is the complete encoded GPP string.
	 * Usage: <pre>PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putString(constants.IAB_GPP_CMP_API_GPP_STRING(), YOUR_US_PRIVACY_STRING).apply();</pre>
	 * 
	 * @return a string value representing parameter IAB_GPP_CMP_API_GPP (IABGPP_HDR_GppString)
	 */
	public String IAB_GPP_CMP_API_GPP_STRING();

	/**
	 * Used to set the disclosures made and choices selected by a user regarding consumer data privacy in association with GPP CMP API. This key should be set in SharedPreferences.
	 * <p>This is the GPP Section ID.
	 * Usage: <pre>PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putString(constants.IAB_GPP_CMP_API_GPP_SID(), YOUR_US_PRIVACY_STRING).apply();</pre>
	 * 
	 * @return a string value representing IAB_GPP_CMP_API_GPP_SID (IABGPP_GppSID)
	 */
	public String IAB_GPP_CMP_API_GPP_SID();

	/**
	 * Signal that an event occurred indicating someone is “still watching”.
	 * 
	 * @return a string value representing IAB_OMSDK_UPDATE_LAST_ACTIVITY (IABOMSDK_updateLastActivity)
	 */
	public String IAB_OMSDK_UPDATE_LAST_ACTIVITY();

	/**
	 * Enumeration of user actions
	 */
	enum UserAction {
		/**
		 * Player's pause button is clicked
		 */
		PauseButtonClicked(1),

		/**
		 * Player's resume button is clicked
		 */
		ResumeButtonClicked(2);

		/**
		 * Value representing the user action
		 */
		public final int action;

		UserAction(int action) {
			this.action = action;
		}
	}

	/**
	 * Enumeration of the purpose of a friendly obstruction for use with Open Measurement SDK.
	 */
	public enum FWFriendlyObstructionPurpose {
		/**
		 * Views related to interacting with a video (e.g. play/pause buttons)
		 */
		VIDEO_CONTROLS,
		/**
		 * Views relating to closing an ad (e.g. close button)
		 */
		CLOSE_AD,
		/**
		 * Views that are not visibly obstructing the ad but may seem so due to technical limitations
		 */
		NOT_VISIBLE,
		/**
		 * Views that are obstructing for any purpose not already described.
		 */
		OTHER;
	}
}
