package tv.freewheel.ad.interfaces;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;

import java.util.List;
import java.util.Map;

import tv.freewheel.ad.request.config.AdRequestConfiguration;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.renderers.temporal.CustomPlayer;

/**
 * IAdContext is the main facade for ad requesting, should be created in each Activity that wants to display Ads.
 */
public interface IAdContext extends IParameterHolder {
	
	/**
	 *  Get constants look up table.
	 *
	 *  @return an IConstants object
	 */
	public IConstants getConstants();

	/**
	 *	Set the FrameLayout on which the temporal ads will be drawn.
	 *	<br>
	 *	AdManager will use it to find where to play the temporal ads.
	 *	Video ads will fill the FrameLayout and overlay ads will be put at a certain position of the FrameLayout.
	 *  <br>
	 *
	 *	@param videoDisplayBase the FrameLayout on which the temporal ads will be drawn
	 */
	public void registerVideoDisplayBase(FrameLayout videoDisplayBase);

	/**
	 *	Sets the custom player used by the CustomPlayerRenderer to render advertisements.
	 *
	 *	@param customPlayer a custom player object that implements the CustomPlayer interface.
	 */
	public void registerCustomPlayer(CustomPlayer customPlayer);

 	/**
	 *  Set the Activity object which create this adContext. <br>
	 *  An Ad Context should be attached to an Activity.
     *
	 *  @param activity the Activity this IAdContext is attached to
	 */
	public void setActivity(Activity activity);
	
	/**
	 *	Return application's current Activity which create and hold the reference of this AdContext.
	 *
	 *	@return the Activity object
	 */
	public Activity getActivity();

	/**
	 * Set activity state on AdContext. Should be invoked when activity's state changes. i.e. in
	 *
	 * Activity.onCreate -> ActivityState.CREATED
	 * Activity.onStart -> ActivityState.STARTED
	 * Activity.onRestart -> ActivityState.RESTARTED
	 * Activity.onPause -> ActivityState.PAUSED
	 * Activity.onResume -> ActivityState.RESUMED
	 * Activity.onStop -> ActivityState.STOPPED
	 * Activity.onDestroy -> ActivityState.DESTROYED
	 *
	 * @param state state of the activity
	 */
	public void setActivityState(IConstants.ActivityState state);

	/**
	 * Set the playback state of content video asset (video state in AdContext should be always in sync with the content video assets playback state)
	 *
	 * @param videoState the state of the content video asset
	 */
	public void setVideoState(IConstants.VideoState videoState);

	/**
	 *  Set the current playhead time of the content video asset (should not contain the duration of ads)
	 *
	 *  @param playheadTime playhead time of the content video asset
	 */
	public void setContentVideoPlayheadTime(double playheadTime);

	/**
	 * Set the parameters for a special level.
	 *
	 * @param name key of the parameter to be set
	 * @param value value for the key
	 * @param level level of the parameter
	 */
	public void setParameter(String name, Object value, IConstants.ParameterLevel level);

	/**
	 *	Get a slots by its customId.
	 *
	 *	@param customId custom id of the slot
	 *	@return an ISlot object, or null if not found
	 */
	public ISlot getSlotByCustomId(String customId);

	/**
	 * Get all slots by time position class
	 *
	 * @param timePositionClass enumerated value of searching time position class
	 *
	 * @return a non-null List of ISlot objects matching searching time position class
	 */
	public List<ISlot> getSlotsByTimePositionClass(IConstants.TimePositionClass timePositionClass);
	
	/**
	 *	Get all the temporal slots.
	 *
	 *	@return a List of ISlot objects, will return an empty list if none found
	 */
	public List<ISlot> getTemporalSlots();
	
	/**
	 * @deprecated Please use getNonTemporalSlots() instead
	 * 
	 * @return a List of ISlot objects, will return an empty list if none found
	 */
	@Deprecated
	public List<ISlot> getSiteSectionNonTemporalSlots();
	
	/**
	 * 	Get all the non-temporal slots.
	 *
	 * 	@return a List of ISlot objects, will return an empty list if none found
	 */
	public List<ISlot> getNonTemporalSlots();

	/**
	 *  Construct the request with the an AdRequestConfiguration class object and submit the request to FreeWheel Ad Server.
	 *
	 *  Please note, activity must be set on the AdContext before submitting the ad request using the setActivity(Activity activity) API.
	 *  When called, if a US Privacy String is stored in SharedPreferences, it will be added to the AdRequest. Any existing US Privacy String
	 *  stored in the AdRequest will be overwritten. Once called, the US Privacy String cannot be modified. Please see
	 *  {@link IConstants#IAB_US_PRIVACY_STRING} for more information.
	 *
	 *  Each AdContext can only submitRequest once.
	 *
	 *  @param config AdRequestConfiguration object
	 *  @param timeoutSeconds timeout time in seconds for this request
	 *
	 */
	public void submitRequestWithConfiguration(AdRequestConfiguration config, double timeoutSeconds);
	
	/**
	 * Adds a renderer to the AdContext.
	 * @param className class name of renderer. Please note, class name is expected to have prefix "class://" and the package namespace
	 * @param baseUnit the base ad units that the renderer can support, separated by comma
	 * @param soldAsAdUnit the soldAs ad unit that the renderer can support, separated by comma
	 * @param contentType the content types that the renderer can support, separated by comma
	 * @param slotType the slot types that the renderer can support, separated by comma
	 * @param parameters the parameters set on renderer level
	 */
	public void addRenderer(String className, String baseUnit, String soldAsAdUnit, String contentType, String slotType, Map<String, Object> parameters);

	/**
	 * @param className 		class name of renderer. Please note, class name is expected to have prefix "class://" and the package namespace
	 * @param baseUnit			the base ad units that the renderer can support, separated by comma
	 * @param soldAsAdUnit		the soldAs ad unit that the renderer can support, separated by comma
	 * @param contentType		the content types that the renderer can support, separated by comma
	 * @param slotType			the slot types that the renderer can support, separated by comma
	 * @param creativeAPI		the creative APIs that the renderer can support, separated by comma
	 * @param parameters		the parameters set on renderer level
	 */
	public void addRenderer(String className, String baseUnit, String soldAsAdUnit, String contentType, String slotType, String creativeAPI, Map<String, Object> parameters);
	
	/**
	 * Register an event listener.
	 *
	 * @param type name of the event to listen to
	 * @param listener the listener
	 */
	public void addEventListener(String type, IEventListener listener);

	/**
	 * Remove an event listener.
	 *
	 * @param type the name of the event to listen to
	 * @param listener the listener
	 */
	public void removeEventListener(String type, IEventListener listener);
	
	/**
	 * Dispatch an event.
	 *
	 * @param event the value object for carrying out event info
	 */
	public void dispatchEvent(IEvent event);
	
	/**
	 * Dispose this AdContext object and remove all event listeners of it, stop all playing slots.
	 * <br>
	 * After this call, all other methods should not be invoked in this adContext.
	 */
	public void dispose();
	
	/**
	 *	Get video asset's url location.
	 *
	 *	@return a String set by API setVideoAsset's location parameter, or null if not set
	 */
	public String getVideoLocation();
	
	/**
	 *  Get the AdManager object which create the current AdContext.
	 *
	 *  @return an IAdManager object
	 */
	public IAdManager getAdManager();

	/**
	 * 	Notify AdManager and its modules with user's action
	 * 	@param userAction action performed by the user
	 */
	public void notifyUserAction(IConstants.UserAction userAction);
	
	/**
	 *	Load player extension from given URL which implements IExtension.
	 *
	 *	<br>Event IConstants.EVENT_EXTENSION_LOADED will be fired when an extension succeeds or fails to initialize.
	 *
	 *	@param name a String identifier of the extension
	 */
	public void loadExtension(String name);

	/**
	 * Set volume for current and subsequent ad playbacks.
	 *
	 * <strong> Note: A VPAID creative not implementing setAdVolume VPAID spec will not change its volume. </strong>
	 * Note that the events EVENT_AD_VOLUME_CHANGED, EVENT_AD_MUTE and EVENT_AD_UNMUTE won't be dispatched if
	 * IAdContext.setAdVolume() is called before the ad playback starts.
	 * However, the specified volume will be applied to the ad when it starts playback.
	 *
	 * @param volume volume is expected in range [0,1]
	 */
	public void setAdVolume(float volume);
	
	/**
	 * Get ad playback volume.
	 *
	 * <strong> Note: Ad playback volume is influenced by the player, renderer or creatives (VPAID). The value returned is the value set by the latest influence </strong>
	 *
	 * @return A float value in the range [0,1]
	 */
	public float getAdVolume();

	/**
	 * Add the friendly obstruction configuration of a view which should be excluded from all ad session viewability calculations for Open Measurement SDK.
	 * This method will have no effect if called after the ad session has finished.
	 *
	 * @param obstructionConfiguration The FWOMSDKFriendlyObstructionConfiguration containing information on a view to be excluded from all ad session viewability calculations.
	 */
	public void addFriendlyObstruction(FWOMSDKFriendlyObstructionConfiguration obstructionConfiguration);

	/**
	 * Remove a registered friendly obstruction view for Open Measurement SDK.
	 * This method will have no effect if called after the ad session has finished.
	 *
	 * @param obstructionConfiguration The FWOMSDKFriendlyObstructionConfiguration to be removed from the list of registered friendly obstructions.
	 */
	public void removeFriendlyObstruction(FWOMSDKFriendlyObstructionConfiguration obstructionConfiguration);

	/**
	 * Notifies OMSDK to update last activity time when users interact on CTV devices.
	 * Per IAB, A specified list of event types which are acceptable to trigger the “last activity" 
	 * signal are not included, as these interactions may vary by app. This may include interactions 
	 * such as “watch next,” “are you still watching,” “skip,” or others. The integrator may include as many signals as desired.
	 * This method will not have any effect before OMSDKExtension is initiated.
	 *
	 */
	public void updateOmidLastActivity();
}
