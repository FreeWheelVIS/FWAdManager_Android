package tv.freewheel.ad.interfaces;

import java.util.HashMap;

/**
 * IEvent is the value object for carrying out event info:
 */
public interface IEvent {

	/**
	 * Get the type of this event.
	 *
	 * @return type string, can be one of:
	 * 		<br>IConstants.EVENT_REQUEST_COMPLETE
	 * 		<br>IConstants.EVENT_REQUEST_CONTENT_VIDEO_PAUSE
	 * 		<br>IConstants.EVENT_REQUEST_CONTENT_VIDEO_RESUME
	 * 		<br>IConstants.EVENT_SLOT_ENDED
	 * 		<br>IConstants.EVENT_SLOT_STARTED
	 *		<br>IConstants.EVENT_AD_*
	 */
	public String getType();
	
	/**
	 * Get the data information of this event.
	 *
	 * @return data as an {@code HashMap<String, Object>} Object
	 * 
	 * <p>
	 * Note: the key of the data as following:
	 * 		<br>
	 * 		<br>IConstants.INFO_KEY_MESSAGE :all event will contain this
	 * 		<br>IConstants.INFO_KEY_SLOT_CUSTOM_ID :IConstants.EVENT_SLOT_ENDED/IConstants.EVENT_SLOT_STARTED will contain this
	 *		<br>IConstants.INFO_KEY_ADINSTANCE : IConstants.EVENT_AD_* will contain this
	 */
	public HashMap<String, Object> getData();
}
