/*
 * Copyright (c) 2016. All rights Reserved
 */

package tv.freewheel.ad.interfaces;

/**
 * IParameterHolder is an interface to be implemented by all the parameter holders
 */
public interface IParameterHolder {

    /**
     * Retrieves parameter value from the current parameters holder object.
     *
     * @param name name of the parameter need to retrieve
     * @return the value of the parameter
     */
    public Object getParameter(String name);
}
