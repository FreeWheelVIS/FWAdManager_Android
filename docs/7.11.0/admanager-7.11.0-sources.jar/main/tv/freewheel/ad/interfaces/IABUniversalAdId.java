package tv.freewheel.ad.interfaces;

/**
 * Created by ljiao on 8/24/17.
 */

/**
 * An abstraction of the IAB definition of Universal Ad ID. For more details on the IAB Universal Ad ID, please refer to section 3.7.1 in the VAST 4.0 spec: https://www.iab.com/guidelines/digital-video-ad-serving-template-vast-4-0/.
 */

public interface IABUniversalAdId {
	/**
	 *  Get the registry of the universal ad ID, which is a string used to identify the URL for the registry website where the unique
	 *  creative ID is cataloged.
	 *
	 *  @return the registry string.
	 */
	public String getIdRegistry();
	/**
	 *  Get the value of the universal ad ID, which is a string for the unique creative ID.
	 *
	 *  @return the value string.
	 */
	public String getIdValue();
}
