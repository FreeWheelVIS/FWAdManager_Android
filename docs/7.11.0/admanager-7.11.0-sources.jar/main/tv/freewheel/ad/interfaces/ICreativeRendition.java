package tv.freewheel.ad.interfaces;

import java.util.List;

/**
 *	Interface for creative rendition, only for renderer use by now.
 */
public interface ICreativeRendition {
	/**
	 * Get id of the rendition.
	 * @return id of the rendition
	 */
	public int getId();

	/**
	 *	Get content type of the rendition.
	 *
	 *	@return  content type in String
	 */
	public String getContentType();
	
	/**
	 * Set content type of the rendition.
	 *
	 * @param contentType content type of the rendition
	 */
	public void setContentType(String contentType);
	
	/**
	 *	Get width of the rendition.
	 *
	 *	@return width in density-independent pixels for display ads; width in physical pixels for video ads.
	 */
	public int getWidth();
	
	/**
	 * Set the width of the rendition.
	 *
	 * @param width width in density-independent pixels for display ads; width in physical pixels for video ads.
	 */
	public void setWidth(int width);
	
	/**
	 *	Get height of the rendition.
	 *
	 *	@return height in density-independent pixels for display ads; height in physical pixels for video ads.
	 */
	public int getHeight();
	
	/**
	 * Set the height of the rendition.
	 *
	 * @param height height in density-independent pixels for display ads; height in physical pixels for video ads.
	 */
	public void setHeight(int height);
	
	/**
	 *	Get duration of the rendition.
	 *
	 *	@return duration in seconds
	 */
	public double getDuration();
	
	/**
	 * Set the duration of the rendition.
	 *
	 * @param duration duration in seconds
	 */
	public void setDuration(double duration);
	
	/**
	 *	Get preference of the rendition.
	 *
	 *	@return an int value, the higher is preferred among all renditions in the creative
	 */
	public int getPreference();
	
	/**
	 * Set the preference of the duration.
	 *
	 * @param preference integer, the larger the more preferred
	 */
	public void setPreference(int preference);
	
	/**
	 * Get the creative API supported by the rendition.
	 *
	 * @return creative API in a String
	 */
	public String getCreativeAPI();
	
	/**
	 * Set the creative API supported by the rendition.
	 *
	 * @param creativeApi creative API in a String
	 */
	public void setCreativeAPI(String creativeApi);
	
	/**
	 *	Get wrapper type of the rendition.
	 *
	 *	@return  wrapper type in a String
	 */
	public String getWrapperType();
	
	/**
	 * Set the wrapper type of the rendition.
	 *
	 * @param wrapperType wrapper type in a String
	 */
	public void setWrapperType(String wrapperType);
	
	/**
	 *	Get wrapper url of the rendition.
	 *
	 *	@return  wrapper url in a String
	 */
	public String getWrapperURL();
	
	/**
	 * Set the wrapper URL of the rendition.
	 *
	 * @param wrapperURL wrapper URL in a String
	 */
	public void setWrapperURL(String wrapperURL);
	
	/**
	 * Get rendition's base unit.
	 *
	 * @return base unit in String
	 */
	public String getBaseUnit();
	
	/**
	 *	Get primary asset of the rendition.
	 *
	 *	@return an object of ICreativeRenditionAsset
	 */
	public ICreativeRenditionAsset getPrimaryCreativRenditionAsset();
	
	/**
	 *	Get all non-primary assets of the rendition.
	 *
	 *	@return a List of ICreativeRenditionAsset
	 */
	public List<ICreativeRenditionAsset> getOtherRenditionAssets();
	
	/**
	 * Set parameter on the rendition.
	 *
	 * @param name name of the parameter
	 * @param value value of the parameter
	 */
	public void setParameter(String name, Object value);
	
	/**
	 * Create a creative rendition asset and add it to the creative rendition.
	 *
	 * @param name name of the asset
	 * @param isPrimary whether or not to set the created asset as the primary asset
	 * @return the creative rendition asset that has been created
	 */
	public ICreativeRenditionAsset createCreativeRenditionAssetForTranslation(String name, boolean isPrimary);
}
