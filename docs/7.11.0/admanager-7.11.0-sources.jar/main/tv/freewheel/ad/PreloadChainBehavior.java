package tv.freewheel.ad;

import tv.freewheel.ad.state.AdEndedState;
import tv.freewheel.ad.state.AdFailedState;
import tv.freewheel.ad.state.AdLoadedState;
import tv.freewheel.ad.state.AdState;
import tv.freewheel.ad.state.SlotPreloadingState;
import tv.freewheel.ad.state.SlotState;

public class PreloadChainBehavior extends ChainBehavior {
	public String toString() {
		return "PreloadChainBehavior";
	}
	
	public SlotState relatedSlotState() {
		return SlotPreloadingState.Instance();
	}
	
	public boolean isChainStopper(AdInstance adInstance) {
		return adInstance.imprSent || adInstance.isSkipped || (adInstance.state == AdLoadedState.Instance() && !adInstance.scheduledDrivingAd);
	}
	
	public boolean isDestState(AdState adState) {
		return (adState == AdEndedState.Instance() || adState == AdFailedState.Instance() || adState == AdLoadedState.Instance());
	}
}
