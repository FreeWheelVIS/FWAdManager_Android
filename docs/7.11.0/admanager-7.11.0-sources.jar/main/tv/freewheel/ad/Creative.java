package tv.freewheel.ad;

import android.net.Uri;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

import tv.freewheel.utils.StringUtils;

public class Creative extends ParametersHolder {
	public int creativeId;
	public double duration;
	public String baseUnit;
	public List<CreativeRendition> creativeRenditions;

	public Creative cloneForTranslation() {
		Creative ret = new Creative(this.context);
		ret.creativeId = this.creativeId;
		ret.duration = this.duration;
		ret.baseUnit = this.baseUnit;
		ret.parameters.clear();
		ret.parameters.putAll(this.parameters);
		return ret;
	}

	public Creative(AdContext context) {
		super(context);
		this.creativeRenditions = new ArrayList<>();
	}

	public void parseCreativeRenditions(Element node) {
		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_CREATIVE_RENDITION)) {
					CreativeRendition creativeRendition = new CreativeRendition(this);
					creativeRendition.parse((Element) childNode);
					creativeRendition.setDuration(this.duration);
					this.creativeRenditions.add(creativeRendition);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	public void parse(Element node) {
		this.creativeId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_CREATIVE_ID));
		this.duration = StringUtils.parseDouble(node.getAttribute(InternalConstants.ATTR_CREATIVE_DURATION));
		this.baseUnit = node.getAttribute(InternalConstants.ATTR_CREATIVE_BASEUNIT);

		logger.verbose("parse(), creative: " + this.creativeId
				+ ", parsed duration: " + duration);

		NodeList childList = node.getChildNodes();
		for (int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				String name = childNode.getNodeName();
				logger.verbose("parse(), name: " + name);

				if (name.equals(InternalConstants.TAG_CREATIVE_RENDITIONS)) {
					this.parseCreativeRenditions((Element) childNode);
				} else if (name.equals(InternalConstants.TAG_PARAMETERS)) {
					this.parameters = parseParameters((Element) childNode);
				} else {
					logger.warn("ignore node: " + name);
				}
			}
		}
	}

	public CreativeRendition createCreativeRendition() {
		CreativeRendition ret = new CreativeRendition(this);
		this.creativeRenditions.add(ret);
		return ret;
	}

	public CreativeRendition getCreativeRendition(int renditionId) {
		for (CreativeRendition rendition: creativeRenditions) {
			if (rendition.getId() == renditionId) {
				return rendition;
			}
		}
		return null;
	}
}
