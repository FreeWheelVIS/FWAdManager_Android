package tv.freewheel.ad.request.config;

import java.util.Map;
import java.util.TreeMap;

/**
 * Created by xfchen on 4/3/17.
 */

public class VisitorConfiguration {
    private String customId;
    private String ipV4Address;
    private int bandwidth; // in Kilo bits per second
    private String bandwidthSource;
    private TreeMap<String, String> httpHeaders;
    /**
     *  Get the custom ID of the visitor.
     *
     *  @return  custom ID of the visitor
     */
    public String getCustomId() {
        return customId;
    }
    /**
     *  Set the custom ID of the visitor.
     *
     *  @param  customId        custom ID of the visitor
     */
    public void setCustomId(String customId) {
        this.customId = customId;
    }
    /**
     *  Get the IP address of the visitor.
     *
     *  @return   IP address of the visitor
     */
    public String getIPV4Address() {
        return ipV4Address;
    }
    /**
     *  Set the IP address of the visitor.
     *
     *  @param  ipV4Address     IP address of the visitor
     */
    public void setIPV4Address(String ipV4Address) {
        this.ipV4Address = ipV4Address;
    }
    /**
     *  Get the bandwidth of the visitor in Kbps (Kilo bits per second).
     *
     * @return   bandwidth of the visitor
     */
    public int getBandwidth() {
        return bandwidth;
    }
    /**
     *  Set the bandwidth of the visitor in Kbps (Kilo bits per second).
     *
     * @param  bandwidth       bandwidth of the visitor
     */
    public void setBandwidth(int bandwidth) {
        this.bandwidth = bandwidth;
    }
    /**
     *  Get the bandwidth source of the visitor.
     *
     * @return   bandwidth source of the visitor
     */
    public String getBandwidthSource() {
        return bandwidthSource;
    }
    /**
     *  Set the bandwidth source of the visitor.
     *
     * @param  bandwidthSource bandwidth source of the visitor
     */
    public void setBandwidthSource(String bandwidthSource) {
        this.bandwidthSource = bandwidthSource;
    }
    /**
     *  Get the HTTP headers of the visitor.
     *
     *  @return  the httpHeaders
     */
    public Map<String, String> getHttpHeaders() {
        return httpHeaders;
    }
    /**
     *  Add a HTTP header for the visitor.
     *
     *  @param  name    name of the header to be set
     *  @param  value   value of the header to be set, null to remove
     */
    public void addHttpHeader(String name, String value) {
        if (name == null) {
            return;
        }
        if (value == null) {
            this.httpHeaders.remove(name);
        } else {
            this.httpHeaders.put(name, value);
        }
    }
    /**
     *  Create a visitor configuration for the ad request.
     */
    public VisitorConfiguration(){
        this.bandwidth = 0;
        this.httpHeaders = new TreeMap<>();
    }
}
