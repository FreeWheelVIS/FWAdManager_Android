package tv.freewheel.ad.request.config;

import android.content.Context;

import java.util.LinkedList;
import java.util.List;

import tv.freewheel.ad.request.config.ConsentConfiguratons.GDPRConsentConfiguration;
/**
 * A class used to configure privacy consent settings for ad requests.
 */
public class ConsentConfiguration {
	private GDPRConsentConfiguration gdprConsentConfiguration = null;
	/**
	 * Sets the GDPR consent configuration.
	 * @param configuration a GDPRConsentConfiguration object.
	 */
	public void setGDPRConsentConfiguration(GDPRConsentConfiguration configuration){
		this.gdprConsentConfiguration = configuration;
	}
	/**
	 * Gets a list of KeyValueConfiguration objects that represent the consent configurations.
	 * @param context a Context object.
	 * @return a List of KeyValueConfiguration objects that represent GDPR, CCPA, and GPPCMPAPI consent configurations.
	 */
	public List<KeyValueConfiguration> consentConfigurationsToKVConfigurations(Context context){
		List<KeyValueConfiguration> result = new LinkedList<>();
		if(context == null) return result;
		result.addAll(GDPRConsentConfiguration.generateKVConfigurationList(context, gdprConsentConfiguration));
		CCPAConsentConfiguration ccpaConsentConfiguration = new CCPAConsentConfiguration();
		result.addAll(ccpaConsentConfiguration.generateKVConfigurationList(context));
		GPPCMPAPIConsentConfiguration gppCMPAPIConsentConfiguration = new GPPCMPAPIConsentConfiguration();
		result.addAll(gppCMPAPIConsentConfiguration.generateKVConfigurationList(context));
		return result;
	}
}
