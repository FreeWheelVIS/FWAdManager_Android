package tv.freewheel.ad.request.config;

import tv.freewheel.ad.interfaces.IConstants;

/**
 * Created by xfchen on 3/28/17.
 */

public class SiteSectionConfiguration {
    private String siteSectionId;
    private String fallbackId;
    private int networkId;
    private IConstants.IdType idType;
    private int pageViewRandom;

    /**
     *  Get the ID of the site section.
     *  @return  ID of the site section
     */
    public String getSiteSectionId() {
        return siteSectionId;
    }

    /**
     *  Set the ID of the site section.
     *  @param   siteSectionId   ID of the site section
     */
    public void setSiteSectionId(String siteSectionId) {
        this.siteSectionId = siteSectionId;
    }

    /**
     *  Get the fallback ID of the site section.
     *  @return   site section ID to fall back on when the specified site section ID can not be found by the ad server. (0 by default)
     */
    public String getFallbackId() {
        return fallbackId;
    }

    /**
     *  Set the fallback ID of the site section.
     *  @param  fallbackId      site section ID to fall back on when the specified site section ID can not be found by the ad server. (0 by default)
     */
    public void setFallbackId(String fallbackId) {
        this.fallbackId = fallbackId;
    }

    /**
     *  Get the network ID of the site section.
     *  @return  ID of the network the site section belongs to.
     */
    public int getNetworkId() {
        return networkId;
    }

    /**
     *  Set the network ID of the site section.
     *  @param  networkId     ID of the network the site section belongs to.
     */
    public void setNetworkId(int networkId) {
        this.networkId = networkId;
    }

    /**
     *  Get the ID type of the site section.
     *  @return the type of the ID
     */
    public IConstants.IdType getSiteSectionIdType() {
        return idType;
    }

    /**
     * Set the ID type of the site section
     * @param idType ID type to be set
     */
    public void setSiteSectionIdType(IConstants.IdType idType){
        this.idType = idType;
    }

    /**
     *  Get the unique ID that identifies the view of this page.
     *  @return  unique ID for current page view.
     */
    public int getPageViewRandom() {
        return pageViewRandom;
    }

    /**
     *  Set an randomly generated ID that uniquely identifies the view of this page.
     *  @param  pageViewRandom   unique ID for current page view.
     */
    public void setPageViewRandom(int pageViewRandom) {
        this.pageViewRandom = pageViewRandom;
    }

    /**
     * Create a site section configuration for the ad request.
     * @param siteSectionId String ID of the site section
     * @param idType the type of the siteSectionId
     */
    public SiteSectionConfiguration(String siteSectionId, IConstants.IdType idType) {
        this.siteSectionId = siteSectionId;
        this.idType = idType;
        networkId = 0;
        pageViewRandom = (int)Math.floor(Math.random() * Integer.MAX_VALUE);
        fallbackId = "";
    }
}
