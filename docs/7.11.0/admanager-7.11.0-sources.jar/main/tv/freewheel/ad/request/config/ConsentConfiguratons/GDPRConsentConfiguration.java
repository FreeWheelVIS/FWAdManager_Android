package tv.freewheel.ad.request.config.ConsentConfiguratons;

import android.content.Context;
import android.preference.PreferenceManager;
import android.util.Log;

import java.util.LinkedList;
import java.util.List;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.request.config.KeyValueConfiguration;
import tv.freewheel.utils.Logger;

public class GDPRConsentConfiguration {
	private static final IConstants constants = new Constants();

	private static final String TAG = "gdpr";
	private static final String PARAMETER_FW_GDPR = "_fw_gdpr";
	private static final String PARAMETER_FW_GDPR_CONSENT = "_fw_gdpr_consent";

	private static final String EMPTY_DEFAULT_STRING = "";
	private String gdpr;
	private String gdprConsent;
	private static final Logger logger = Logger.getLogger(GDPRConsentConfiguration.class);

	public GDPRConsentConfiguration(boolean isGdprEnabled, String gdprConsent){
		this.gdpr = isGdprEnabled ? "1":"0";
		this.gdprConsent = gdprConsent;
		logger.debug("Set GDPR Configuration, " + this.toString());
	}

	static public List<KeyValueConfiguration> generateKVConfigurationList(Context context, GDPRConsentConfiguration gdprConsentConfiguration) {
		Log.d(TAG, "generateKVConfigurationList: ");
		List<KeyValueConfiguration> kvConfigurations = new LinkedList<>();
		GDPRConsentConfiguration finalGDRPConfig = gdprConsentConfiguration == null ? createConsentConfigurationFromSharedPreference(context):gdprConsentConfiguration;
		if(finalGDRPConfig == null)
			return kvConfigurations;
		kvConfigurations.add(new KeyValueConfiguration(PARAMETER_FW_GDPR, finalGDRPConfig.gdpr));
		kvConfigurations.add(new KeyValueConfiguration(PARAMETER_FW_GDPR_CONSENT, finalGDRPConfig.gdprConsent));
		return kvConfigurations;
	}

	static public GDPRConsentConfiguration createConsentConfigurationFromSharedPreference(Context context) {
		Log.d(TAG, "createConsentConfigurationFromSharedPreference: ");
		if (context == null) {
			Log.d(TAG, "Context was null. Thus, createConsentConfigurationFromSharedPreference will return null.");
			return null;
		}
		if(getGdprFromSharedPreference(context).equals(EMPTY_DEFAULT_STRING)) {
			Log.d(TAG, "getGdprFromSharedPreference returned an empty string. Thus, GDPR consent information could not be returned from SharedPreferences");
			return null;
		}
		String gdpr = getGdprFromSharedPreference(context);
		String gdprConsent = getConsentStringFromSharedPreference(context);
		return new GDPRConsentConfiguration(gdpr.equals("1"), gdprConsent);
	}

	static private String getGdprFromSharedPreference(Context context) {
		Log.d(TAG, "getGdprFromSharedPreference: ");
		if (context == null) {
			Log.d(TAG, "Context was null. Thus, getGdprFromSharedPreference will return an empty string.");
			return EMPTY_DEFAULT_STRING;
		}

		Integer subjectToGdpr = -1;
		try {
			subjectToGdpr = PreferenceManager.getDefaultSharedPreferences(context)
					.getInt(constants.IAB_SUBJECT_TO_GDPR(), -1);
		} catch (ClassCastException e) {
			Log.e(TAG, constants.IAB_SUBJECT_TO_GDPR() + " is not stored as an Integer. Unable to retrieve value.");
		}

		return (subjectToGdpr.equals(0) || subjectToGdpr.equals(1)) ?
				subjectToGdpr.toString() : EMPTY_DEFAULT_STRING;
	}

	static private String getConsentStringFromSharedPreference(Context context) {
		Log.d(TAG, "getConsentStringFromSharedPreference: ");
		return PreferenceManager.getDefaultSharedPreferences(context).getString(constants.IAB_CONSENT_STRING(), EMPTY_DEFAULT_STRING);
	}

	@Override
	public String toString(){
		return String.format("isGdprEnabled: %s, gdprConsent: %s", gdpr, gdprConsent);
	}
}
