package tv.freewheel.ad.request.config;

import android.content.Context;
import android.preference.PreferenceManager;
import android.util.Log;

import java.util.LinkedList;
import java.util.List;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.Logger;

class GPPCMPAPIConsentConfiguration {
	private static final IConstants constants = new Constants();

	private static final String TAG = "GPPCMPAPI";
	private static final String PARAMETER_FW_US_GPP_STRING = "gpp";
	private static final String PARAMETER_FW_US_GPP_SID = "gpp_sid";

	private String gppString;
	private String gppSid;
	private static final Logger logger = Logger.getLogger(GPPCMPAPIConsentConfiguration.class);

	GPPCMPAPIConsentConfiguration(){
		logger.debug("Set GPPCMPAPI Consent Configuration, " + this.toString());
	}

	List<KeyValueConfiguration> generateKVConfigurationList(Context context) {
		Log.d(TAG, "generateKVConfigurationList: ");
		List<KeyValueConfiguration> kvConfigurations = new LinkedList<>();
		this.setGPPCMPAPIConsentInformationFromSharedPreference(context);
		if (this.gppString!=null&&this.gppSid!=null){
			kvConfigurations.add(new KeyValueConfiguration(PARAMETER_FW_US_GPP_STRING, this.gppString));
			kvConfigurations.add(new KeyValueConfiguration(PARAMETER_FW_US_GPP_SID, this.gppSid));
		}
		return kvConfigurations;
	}

	private void setGPPCMPAPIConsentInformationFromSharedPreference(Context context) {
		Log.d(TAG, "setGPPCMPAPIConsentInformationFromSharedPreference: ");
		if (context != null) {
			this.gppString = PreferenceManager.getDefaultSharedPreferences(context).getString(constants.IAB_GPP_CMP_API_GPP_STRING(), null);
			this.gppSid = PreferenceManager.getDefaultSharedPreferences(context).getString(constants.IAB_GPP_CMP_API_GPP_SID(), null);
		}
	}

	@Override
	public String toString() {
		return String.format("gpp: %s, gpp_sid: %s", gppString, gppSid);
	}
}