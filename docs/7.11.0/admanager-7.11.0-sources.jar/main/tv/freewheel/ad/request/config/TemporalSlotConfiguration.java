package tv.freewheel.ad.request.config;

import tv.freewheel.ad.interfaces.IConstants;

/**
 * Created by xfchen on 4/14/17.
 */

public class TemporalSlotConfiguration extends SlotConfiguration {
    private double timePosition;
    private int breakSequence;
    private int cuePointSequence;
    private double maxDuration;
    private double minDuration;
    private int maxAds;
    private String signalId;

    /**
     *  Create a temporal slot configuration for the ad request
     *  @param  customId                     custom ID of the slot. If slot with the same custom ID already exists, the invocation will be ignored.
     *  @param  adUnit                       ad unit of the ads allowed to be delivered into the slot, which can be one of the predefined ad units listed as follows or a custom ad unit defined in MRM.
     *	 	<br> ADUNIT_PREROLL
     *		<br> ADUNIT_MIDROLL
     *		<br> ADUNIT_POSTROLL
     *	    <br> ADUNIT_OVERLAY
     *	    <br> ADUNIT_PAUSE_MIDROLL
     *	    <br> ADUNIT_STREAM_PREROLL (live mode only)
     *	    <br> ADUNIT_STREAM_POSTROLL (live mode only)
     *
     *  @param  timePosition                 time position of the slot
     */
    public TemporalSlotConfiguration(String customId, String adUnit, double timePosition) {
        super(customId, IConstants.SlotType.TEMPORAL, adUnit);
        this.timePosition = timePosition > 0.0 ? timePosition : 0.0;
        this.cuePointSequence = 0;
        this.maxDuration = 0.0;
        this.minDuration = 0.0;
        this.maxAds = 0;
        this.breakSequence = 0;
    }

    /**
     *  Get the sequence number of the cue point the slot is at.
     *  @return  sequence number of the cue point the slot is at.
     */
    public int getCuePointSequence() {
        return cuePointSequence;
    }

    /**
     *  Set the sequence number of the cue point the slot is at.
     *  @param  cuePointSequence            sequence number of the cue point the slot is at.
     */
    public void setCuePointSequence(int cuePointSequence) {
        this.cuePointSequence = cuePointSequence > 0 ? cuePointSequence : 0;
    }

    /**
     *  Get the break sequence.
     *  @return  the break sequence.
     */
    public int getBreakSequence() {return breakSequence; }
    /**
     *  Set the break sequence. This value will not be added to the Ad Request unless the video asset configuration's windowStartTime is also set. Breaksequence is only inteded for Comcast T6 integrations.
     *  @param  breakSequence            the breakSequence.  Must be an integer greater than zero.
     */
    public void setBreakSequence(int breakSequence) {
        this.breakSequence = breakSequence > 0 ? breakSequence : 0;
    }

    /**
     *  Get the maximum duration of the temporal slot.
     *  @return     maximum duration of the slot allowed. 0 by default which will be treated by ad server as unlimited.
     */
    public double getMaxDuration() {
        return maxDuration;
    }

    /**
     *  Set maximum duration of the temporal slot.
     *  @param    maxDuration                 maximum duration of the slot allowed. 0 by default which will be treated by ad server as unlimited.
     */
    public void setMaxDuration(double maxDuration) {
        this.maxDuration = maxDuration > 0 ? maxDuration : 0;
    }

    /**
     *  Get the minimum duration of the temporal slot.
     *  @return  minimum duration of the slot allowed.(0 by default)
     */
    public double getMinDuration() {
        return minDuration;
    }

    /**
     *  Set the minimum duration of the temporal slot.
     *  @param minDuration minimum duration of the slot allowed. (value must be 0+)
     */
    public void setMinDuration(double minDuration) {
        this.minDuration = minDuration > 0 ? minDuration : 0;
    }

    /**
     *  Get the maximum number of ads in the temporal slot.
     *  @return  maximum number of ads allowed in the slot. 0 indicates no limit (0 by default)
     */
    public int getMaxAds() {
        return maxAds;
    }

    /**
     *  Set the maximum number of ads in the temporal slot.
     *  @param maxAds maximum number of ads allowed in the slot. 0 indicates no limit (value must be 0+)
     */
    public void setMaxAds(int maxAds) {
        this.maxAds = maxAds > 0 ? maxAds : 0;
    }

    /**
     *  Get the time position of the temporal slot.
     * @return  time position of the slot
     */
    public double getTimePosition() {
        return timePosition;
    }

    /**
     *  Set the time position of the temporal slot.
     * @param  timePosition                time position of the slot
     */
    public void setTimePosition(double timePosition) {
        this.timePosition = timePosition > 0 ? timePosition : 0;
    }

    /**
     *  Get the signal Id of the break. Only applicable in Linear TV Streams
     * @return  signal Id of the break
     */
    public String getSignalId() {
        return signalId;
    }

    /**
     *  Set the signal Id of the break. Only applicable in Linear TV Streams
     * @param signalId A non null string containing the Linear signal Id
     */
    public void setSignalId(String signalId) {
        this.signalId = signalId;
    }
}
