package tv.freewheel.ad.request.config;

import tv.freewheel.ad.interfaces.IConstants;

/**
 * Created by xfchen on 4/3/17.
 */

public class CapabilityConfiguration {
    private String capability;
    private IConstants.CapabilityStatus status;

    /**
     *  Get the capability name in the capability configuration.
     *
     *  @return  capability the name of the capability, which should be one of:
     *  	<br>
     *  	<br>CAPABILITY_SLOT_TEMPLATE, ON by default
     *  	<br>CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS, ON by default
     *  	<br>CAPABILITY_SLOT_CALLBACK, ON by default
     *  	<br>CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION
     *  	<br>CAPABILITY_SYNC_MULTI_REQUESTS
     *  	<br>CAPABILITY_RESET_EXCLUSIVITY
     *  	<br>CAPABILITY_RECORD_VIDEO_VIEW
     *  	<br>
     */
    public String getCapability() {
        return capability;
    }

    /**
     *  Set the capability name of in the capability configuration.
     *
     *  @param  capability the name of the capability, which should be one of:
     *  	<br>
     *  	<br>CAPABILITY_SLOT_TEMPLATE, ON by default
     *  	<br>CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS, ON by default
     *  	<br>CAPABILITY_SLOT_CALLBACK, ON by default
     *  	<br>CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION
     *  	<br>CAPABILITY_SYNC_MULTI_REQUESTS
     *  	<br>CAPABILITY_RESET_EXCLUSIVITY
     *  	<br>CAPABILITY_RECORD_VIDEO_VIEW
     *  	<br>
     */
    public void setCapability(String capability) {
        this.capability = capability;
    }

    /**
     * Get the status of the capability in the capability configuration.
     * @return the status of the capability
     */
    public IConstants.CapabilityStatus getCapabilityStatus() {
        return status;
    }

    /**
     * Set the status of the capability in the capability configuration.
     * @param status status to be set
     */
    public void setCapabilityStatus(IConstants.CapabilityStatus status) {
        this.status = status;
    }

    /**
     * Create a capability configuration object for the ad request.
     * @param capability the name of the capability, which should be one of:
     *  	<br>
     *  	<br>CAPABILITY_SLOT_TEMPLATE, ON by default
     *  	<br>CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS, ON by default
     *  	<br>CAPABILITY_SLOT_CALLBACK, ON by default
     *  	<br>CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION
     *  	<br>CAPABILITY_SYNC_MULTI_REQUESTS
     *  	<br>CAPABILITY_RESET_EXCLUSIVITY
     *  	<br>CAPABILITY_RECORD_VIDEO_VIEW
     *  	<br>
     *
     * @param status the status of the capability to be set
     */
    public CapabilityConfiguration(String capability, IConstants.CapabilityStatus status) {
        this.capability = capability;
        this.status = status;
    }
}
