package tv.freewheel.ad.request.config;

import tv.freewheel.ad.interfaces.IConstants;

/**
 * Created by xfchen on 4/14/17.
 */

public class NonTemporalSlotConfiguration extends SlotConfiguration {
    private int width;
    private int height;
    private IConstants.SlotInitialAdOption initialAdOption;
    private String compatibleDimensions;
    private boolean acceptCompanion;
    /**
     *  Create a non-temporal slot configuration for the ad request
     *  @param  customId                    custom ID of the slot. If slot with the same custom ID already exists, the invocation will be ignored.
     *  @param  adUnit                      ad unit of the ads allowed to be delivered into the slot. It can be a predefined ad unit like "display" or a custom ad unit defined in MRM.
     *  @param  width                       width of the slot in density-independent pixels
     *  @param  height                      height of the slot in density-independent pixels
     *
     */
    public NonTemporalSlotConfiguration(String customId, String adUnit, int width, int height){
        super(customId, IConstants.SlotType.NON_TEMPORAL, adUnit);
        this.initialAdOption = IConstants.SlotInitialAdOption.STAND_ALONE;
        this.width = width;
        this.height = height;
        this.acceptCompanion = true;
    }

    /**
     * Get the initial ad option of the non-temporal slot.
     *
     * @return choice of the initial ad should be delivered into this slot.
     */
    public IConstants.SlotInitialAdOption getSlotInitialAdOption() {
        return initialAdOption;
    }

    /**
     * Set the initial ad option of the non-temporal slot.
     *  @param   initialAdOption choice of the initial ad should be delivered into this slot.
     */
    public void setSlotInitialAdOption(IConstants.SlotInitialAdOption initialAdOption) {
        this.initialAdOption = initialAdOption;
    }

    /**
     *  Get compatible dimensions of the non-temporal slot.
     *  @return   compatible dimensions in format of "width,height|width,height", like "320,240|480,720" or "320,240|480,720|728,90"
     */
    public String getCompatibleDimensions() {
        return compatibleDimensions;
    }

    /**
     *  Set compatible dimensions of the non-temporal slot.
     *  @param  compatibleDimensions		compatible dimensions in format of "width,height|width,height", like "320,240|480,720" or "320,240|480,720|728,90"
     */
    public void setCompatibleDimensions(String compatibleDimensions) {
        this.compatibleDimensions = compatibleDimensions;
    }

    /**
     *  Get width of the non-temporal slot.
     *  @return  the width of the slot in density-independent pixels
     */
    public int getWidth() {
        return width;
    }

    /**
     *  Set the width of the non-temporal slot.
     *  @param  width                       width of the slot in density-independent pixels
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     *  Get the height of the non-temporal slot.
     *  @return  height of the slot in density-independent pixels
     */
    public int getHeight() {
        return height;
    }

    /**
     *  Set the height of the non-temporal slot.
     *  @param  height                      height of the slot in density-independent pixels
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     *  Get whether the slot accept companion ads.(true by default)
     *  @return  whether the slot accept companion ads.
     */
    public boolean isCompanionAccepted() {
        return acceptCompanion;
    }

    /**
     *  Set whether the slot accept companion ads.(true by default)
     *  @param  acceptCompanion             whether the slot accept companion ads.
     */
    public void setCompanionAcceptance(boolean acceptCompanion) {
        this.acceptCompanion = acceptCompanion;
    }
}
