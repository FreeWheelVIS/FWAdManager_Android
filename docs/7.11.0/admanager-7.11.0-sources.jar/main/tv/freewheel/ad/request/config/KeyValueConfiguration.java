package tv.freewheel.ad.request.config;

/**
 * Created by xfchen on 4/3/17.
 */

public class KeyValueConfiguration {
    private String key;
    private String value;
    /**
     * Get the key in the key-value configuration.
     *
     *  @return   the key in the key-value pair. Required to be a non-empty string.
     */
    public String getKey() {
        return key;
    }
    /**
     * Set the key in the key-value configuration.
     *
     *  @param  key    the key in the key-value pair. Required to be a non-empty string.
     */
    public void setKey(String key) {
        this.key = key;
    }
    /**
     * Get the value in the key-value configuration.
     *
     *  @return   the value in the key-value pair. Required to be a non-empty string.
     */
    public String getValue() {
        return value;
    }
    /**
     * Set the value in the key-value configuration.
     *
     *  @param  value     the value in the key-value pair. Required to be a non-empty string.
     */
    public void setValue(String value) {
        this.value = value;
    }
    /**
     *  Create a key value configuration for the ad request
     *
     *  @param  key     the key in the key-value pair. Required to be a non-empty string.
     *  @param  value   the value in the key-value pair. Required to be a non-empty string.
     */
    public KeyValueConfiguration(String key, String value){
        this.key = key;
        this.value = value;
    }
}
