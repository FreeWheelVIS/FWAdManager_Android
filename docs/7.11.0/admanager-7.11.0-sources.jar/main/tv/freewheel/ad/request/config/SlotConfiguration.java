package tv.freewheel.ad.request.config;

import tv.freewheel.ad.interfaces.IConstants;

/**
 * Created by xfchen on 3/30/17.
 */

public abstract class SlotConfiguration{
    private String customId;
    private String adUnit;
    private String slotProfile;
    private String acceptPrimaryContentType;
    private String acceptContentType;
    private IConstants.SlotType type;

    /**
     *  Get the custom ID of the slot.
     *  @return  custom ID of the slot.
     */
    public String getCustomId() {
        return customId;
    }

    /**
     *  Set the custom ID of the slot.
     *  @param  customId                    custom ID of the slot.
     */
    public void setCustomId(String customId) {
        this.customId = customId;
    }

    /**
     *  Get the ad unit of the slot.
     *  @return   ad unit of the ads allowed to be delivered into the slot.
     */
    public String getAdUnit() {
        return adUnit;
    }

    /**
     *  Set the ad unit of the slot.
     *  @param  adUnit                        ad unit of the ads allowed to be delivered into the slot.
     */
    public void setAdUnit(String adUnit) {
        this.adUnit = adUnit;
    }

    /**
     *  Get the FreeWheel profile for the slot.
     * @return  The FreeWheel profile name.(null by default)
     */
    public String getSlotProfile() {
        return slotProfile;
    }

    /**
     *  Set the FreeWheel profile for the slot.
     * @param  slotProfile                 The FreeWheel profile name.(null by default)
     */
    public void setSlotProfile(String slotProfile) {
        this.slotProfile = slotProfile;
    }

    /**
     *  Get the primary content types of the ads allowed to be delivered into the slots.
     *  @return  the primary content types seprated by "," as delimiter.
     */
    public String getAcceptPrimaryContentType() {
        return acceptPrimaryContentType;
    }

    /**
     *  Set the primary content types of the ads allowed to be delivered into the slots.
     *  @param  acceptPrimaryContentType   the primary content types seprated by "," as delimiter.
     */
    public void setAcceptPrimaryContentType(String acceptPrimaryContentType) {
        this.acceptPrimaryContentType = acceptPrimaryContentType;
    }

    /**
     *  Get the content types of the ads allowed to be delivered into the slots.
     *  @return  the content types seprated by "," as delimiter.
     */
    public String getAcceptContentType() {
        return acceptContentType;
    }

    /**
     *   Set the content types of the ads allowed to be delivered into the slots.
     *  @param  acceptContentType         the content types seprated by "," as delimiter.
     */
    public void setAcceptContentType(String acceptContentType) {
        this.acceptContentType = acceptContentType;
    }

    /**
     * Get type of the slot
     * @return the enum value of the slot type
     */
    public IConstants.SlotType getSlotType() {
        return type;
    }


    /**
     *  Use TemporalSlotConfiguration or NonTemporalSlotConfiguration instead
     */
    SlotConfiguration(String customId, IConstants.SlotType slotType, String adUnit) {
        this.customId = customId;
        this.adUnit = adUnit;
        this.type = slotType;
    }
}
