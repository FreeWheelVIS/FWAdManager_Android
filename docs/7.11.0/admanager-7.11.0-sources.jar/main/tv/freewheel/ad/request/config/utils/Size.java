package tv.freewheel.ad.request.config.utils;

/**
 * Created by xuanwang on 7/24/2018
 */

public class Size {
    private int width;
    private int height;

    /**
     * Create a size object.
     *
     * @param width  int: The width of the size, in density-independent pixels.
     * @param height int: The height of the size, in density-independent pixels.
     */
    public Size(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Create a size object.
     *
     * @param size  A size object.
     */
    public Size(Size size) {
        this.width = size.width;
        this.height = size.height;
    }

    /**
     * Set width of the size object.
     *
     * @param width  int: The width of the size, in density-independent pixels.
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Set height of the size object.
     *
     * @param height int: The height of the size, in density-independent pixels.
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Set width and height of the size object.
     *
     * @param size  A size object.
     */
    public void setSize(Size size) {
        this.width = size.width;
        this.height = size.height;
    }

    /**
     * Get the width of the size (in density-independent pixels).
     *
     * @return width
     */
    public int getWidth(){
        return this.width;
    }

    /**
     * Get the height of the size (in density-independent pixels).
     *
     * @return height
     */
    public int getHeight(){
        return this.height;
    }

    /**
     * Check if this size width and height is equal to another input width and height.
     *
     * @return true if the object width and height equal to input width and height, false otherwise
     */
    public boolean equals(int width, int height) {
        return this.width == width && this.height == height;
    }

    /**
     * Check if this size is equal to another size.
     *
     * @return true if the objects were equal, false otherwise
     */
    public boolean equals(Object o) {
        return o instanceof Size && (o == this || equals(((Size)o).width, ((Size)o).height));
    }

    /**
     *
     * @return the size represented as a string with the format "Width: W, Height: H"
     */
    public String toString() {
        return "Width: " + this.getWidth() + ", Height: " + this.getHeight();
    }
}
