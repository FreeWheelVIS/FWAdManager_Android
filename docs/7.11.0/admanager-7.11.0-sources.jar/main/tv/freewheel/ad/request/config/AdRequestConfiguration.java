package tv.freewheel.ad.request.config;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.ad.request.config.utils.Size;

/**
 * Created by xfchen on 3/28/17.
 */

public class AdRequestConfiguration {
	private String serverURL;
	private IConstants.RequestMode requestMode;
	private int subsessionToken;
	private String playerProfile;
	private String defaultTemporalSlotProfile;
	private String defaultVideoPlayerSlotProfile;
	private String defaultSiteSectionSlotProfile;
	private String defaultNonTemporalSlotProfile;
	private SiteSectionConfiguration siteSectionConfiguration;
	private VideoAssetConfiguration videoAssetConfiguration;
	private VisitorConfiguration visitorConfiguration;
	private ConsentConfiguration consentConfiguration;
	private ArrayList<NonTemporalSlotConfiguration> nonTemporalSlotConfigurations;
	private ArrayList<TemporalSlotConfiguration> temporalSlotConfigurations;
	private ArrayList<KeyValueConfiguration> keyValueConfigurations;
	private HashMap<String, CapabilityConfiguration> capabilityConfigurations;
	private Size playerDimensions;

	/**
	 * @deprecated Please use AdRequestConfiguration(String serverURL, String playerProfile, Size playerDimensions) instead.
	 * @param serverURL     URL of the FreeWheel Ad Server which consists of the protocol and the host, like http://g1.v.fwmrm.net
	 * @param playerProfile Player profile to be used by the ad server for ad decision.
	 */
	@Deprecated
	public AdRequestConfiguration(String serverURL, String playerProfile) {
		this(serverURL, playerProfile, new Size(-1, -1));
	}

	/**
	 * Create an ad request configuration.
	 *
	 * Please consult your FreeWheel solution engineer for the values to be used.
	 *
	 * @param serverURL        URL of the FreeWheel Ad Server which consists of the protocol and the host, like http://g1.v.fwmrm.net
	 * @param playerProfile    Player (global) profile to be used by the ad server for ad decision.
	 * @param playerDimensions Dimensions of the player when playing in its default mode. Please pass in a size object which encapsulates player's width and height, in density-independent pixels. For more details on density-independent pixels, please refer to https://developer.android.com/training/multiscreen/screendensities.
	 */
	public AdRequestConfiguration(String serverURL, String playerProfile, Size playerDimensions) {
		this.serverURL = StringUtils.patchAdRequestServerURL(serverURL);
		this.playerProfile = playerProfile;
		this.requestMode = IConstants.RequestMode.ON_DEMAND;
		this.nonTemporalSlotConfigurations = new ArrayList<>();
		this.temporalSlotConfigurations = new ArrayList<>();
		this.keyValueConfigurations = new ArrayList<>();
		this.capabilityConfigurations = new HashMap<>();
		this.playerDimensions = playerDimensions;
		this.consentConfiguration = new ConsentConfiguration();
	}

	/**
	 * Get the ad server URL.
	 *
	 * @return the FreeWheel ad server URL
	 */
	public String getServerURL() {
		return serverURL;
	}

	/**
	 * Set the ad server URL.
	 *
	 * @param serverURL URL of the FreeWheel Ad Server which should consist of the protocol and the host, like http://g1.v.fwmrm.net.
	 */
	public void setServerURL(String serverURL) {
		this.serverURL = StringUtils.patchAdRequestServerURL(serverURL);
	}

	/**
	 * Get the ad request mode
	 *
	 * @return the request mode setup on the configuration. Please note, the default value is RequestMode.ON_DEMAND
	 */
	public IConstants.RequestMode getAdRequestMode() {
		return requestMode;
	}

	/**
	 * Set the mode of the ad request
	 * <p>
	 * AdManager runs in ON_DEMAND mode by default.
	 * To switch to live mode by invocation of this method right after getting a new AdContext instance.
	 *
	 * @param requestMode the type of request mode
	 */
	public void setAdRequestMode(IConstants.RequestMode requestMode) {
		this.requestMode = requestMode;
	}

	/**
	 * Get the FreeWheel profile for the player.
	 *
	 * @return the FreeWheel profile name
	 */
	public String getPlayerProfile() {
		return playerProfile;
	}

	/**
	 * Set the FreeWheel profile for the player.
	 *
	 * @param playerProfile the FreeWheel profile name
	 */
	public void setPlayerProfile(String playerProfile) {
		this.playerProfile = playerProfile;
	}

	/**
	 * Get the FreeWheel profile for all temporal slots.
	 *
	 * @return the FreeWheel profile name (null by default)
	 */
	public String getDefaultTemporalSlotProfile() {
		return defaultTemporalSlotProfile;
	}

	/**
	 * Set the FreeWheel profile for all temporal slots.
	 *
	 * @param defaultTemporalSlotProfile the FreeWheel profile name (null by default)
	 */
	public void setDefaultTemporalSlotProfile(String defaultTemporalSlotProfile) {
		this.defaultTemporalSlotProfile = defaultTemporalSlotProfile;
	}

	/**
	 * @deprecated Please use getDefaultNonTemporalSlotProfile() instead
	 * @return the default slot profile name (null by default)
	 */
	@Deprecated
	public String getDefaultVideoPlayerSlotProfile() {
		return defaultVideoPlayerSlotProfile;
	}

	/**
	 * @deprecated Please use setDefaultNonTemporalSlotProfile(String defaultNonTemporalSlotProfile) instead
	 * @param defaultVideoPlayerSlotProfile the default non-temporal slot profile name (null by default)
	 */
	@Deprecated
	public void setDefaultVideoPlayerSlotProfile(String defaultVideoPlayerSlotProfile) {
		this.defaultVideoPlayerSlotProfile = defaultVideoPlayerSlotProfile;
	}

	/**
	 * @deprecated Please use getDefaultNonTemporalSlotProfile() instead
	 * @return the default site section slot profile name (null by default)
	 */
	@Deprecated
	public String getDefaultSiteSectionSlotProfile() {
		return defaultSiteSectionSlotProfile;
	}

	/**
	 * @deprecated Please use setDefaultNonTemporalSlotProfile(String defaultNonTemporalSlotProfile) instead
	 * @param defaultSiteSectionSlotProfile the default site section slot profile name (null by default)
	 */
	@Deprecated
	public void setDefaultSiteSectionSlotProfile(String defaultSiteSectionSlotProfile) {
		this.defaultSiteSectionSlotProfile = defaultSiteSectionSlotProfile;
	}

	/**
	 * Get the FreeWheel profile for all Non Temporal slots.
	 *
	 * @return the FreeWheel profile name (null by default)
	 */
	public String getDefaultNonTemporalSlotProfile() {
		return defaultNonTemporalSlotProfile;
	}

	/**
	 * Set the FreeWheel profile for all Non Temporal slots.
	 *
	 * @param defaultNonTemporalSlotProfile the FreeWheel profile name
	 */
	public void setDefaultNonTemporalSlotProfile(String defaultNonTemporalSlotProfile) {
		this.defaultNonTemporalSlotProfile = defaultNonTemporalSlotProfile;
	}

	/**
	 * Set the site section configuration for the ad request. Refer to SiteSectionConfiguration for details.
	 *
	 * @param siteSectionConfiguration site section configuration
	 */
	public void setSiteSectionConfiguration(SiteSectionConfiguration siteSectionConfiguration) {
		this.siteSectionConfiguration = siteSectionConfiguration;
	}

	/**
	 * Get the site section configuration for the ad request. Refer to SiteSectionConfiguration for details.
	 *
	 * @return site section configuration
	 */
	public SiteSectionConfiguration getSiteSectionConfiguration() {
		return siteSectionConfiguration;
	}

	/**
	 * Set the video asset configuration for the ad request. Refer to VideoAssetConfiguration for details.
	 *
	 * @param videoAssetConfiguration video asset configuration
	 */
	public void setVideoAssetConfiguration(VideoAssetConfiguration videoAssetConfiguration) {
		this.videoAssetConfiguration = videoAssetConfiguration;
	}

	/**
	 * Get the video asset configuration for the ad request. Refer to VideoAssetConfiguration for details.
	 *
	 * @return video asset configuration
	 */
	public VideoAssetConfiguration getVideoAssetConfiguration() {
		return videoAssetConfiguration;
	}

	/**
	 * Set the visitor configuration for the ad request. Refer to VisitorConfiguration for details.
	 *
	 * @param visitorConfiguration visitor configuration
	 */
	public void setVisitorConfiguration(VisitorConfiguration visitorConfiguration) {
		this.visitorConfiguration = visitorConfiguration;
	}

	/**
	 * Get the visitor configuration for the ad request. Refer to VisitorConfiguration for details.
	 *
	 * @return visitor configuration
	 */
	public VisitorConfiguration getVisitorConfiguration() {
		return visitorConfiguration;
	}

	/**
	 * Add the configuration of a slot to the ad request. Refer to TemporalSlotConfiguration and NonTemporalSlotConfiguration for details.
	 *
	 * @param slotConfiguration slot configuration
	 */
	public void addSlotConfiguration(SlotConfiguration slotConfiguration) {
		if (slotConfiguration instanceof TemporalSlotConfiguration) {
			this.temporalSlotConfigurations.add((TemporalSlotConfiguration) slotConfiguration);
		} else {
			this.nonTemporalSlotConfigurations.add((NonTemporalSlotConfiguration) slotConfiguration);
		}
	}

	/**
	 * Add a key-value configuration to the ad request. Refer to KeyValueConfiguration for details.
	 *
	 * @param keyValueConfiguration key-value configuration
	 */
	public void addKeyValueConfiguration(KeyValueConfiguration keyValueConfiguration) {
		this.keyValueConfigurations.add(keyValueConfiguration);
	}

	/**
	 * Add a capability configuration to the ad request. Refer to CapabilityConfiguration for details.
	 *
	 * @param capabilityConfiguration capability configuration
	 */
	public void addCapabilityConfiguration(CapabilityConfiguration capabilityConfiguration) {
		this.capabilityConfigurations.put(capabilityConfiguration.getCapability(), capabilityConfiguration);
	}

	/**
	 * Get the configurations of all non-temporal slots from the ad request.
	 *
	 * @return a list of non-temporal slot configurations
	 */
	public Collection<NonTemporalSlotConfiguration> getNonTemporalSlotConfigurations() {
		return nonTemporalSlotConfigurations;
	}

	/**
	 * Get the configurations of all temporal slots from the ad request.
	 *
	 * @return a list of temporal slot configurations
	 */
	public Collection<TemporalSlotConfiguration> getTemporalSlotConfigurations() {
		return temporalSlotConfigurations;
	}

	/**
	 * Get the configurations of all slots from the ad request.
	 *
	 * @return a list of slot configurations
	 */
	public Collection<SlotConfiguration> getSlotConfigurations() {
		ArrayList<SlotConfiguration> result = new ArrayList<>();
		result.addAll(this.temporalSlotConfigurations);
		result.addAll(this.nonTemporalSlotConfigurations);
		return result;
	}

	/**
	 * Get all key-value configurations from the ad request. Refer to KeyValueConfiguration for details.
	 *
	 * @return a list of key-value configurations
	 */
	public Collection<KeyValueConfiguration> getKeyValueConfigurations() {
		return keyValueConfigurations;
	}

	/**
	 * Get all capability configurations from the request. Refer to CapabilityConfiguration for details.
	 *
	 * @return a list of capability configurations
	 */
	public Collection<CapabilityConfiguration> getCapabilityConfigurations() {
		return capabilityConfigurations.values();
	}

	/**
	 * Set the subsession token.
	 * By default if this method is not called by the app, a random number is generated as subsession token when the request mode is live.
	 *
	 * @param subsessionToken the subsession token (greater than 0) that uniquely identifies a subsession
	 */
	public void setSubsessionToken(int subsessionToken) {
		this.subsessionToken = subsessionToken;
	}

	/**
	 * Return the subsession token that will be used by the current ad request.
	 * Note that it only works when the request mode is live.
	 *
	 * @return the subsession token
	 */
	public int getSubsessionToken() {
		return this.subsessionToken;
	}

	/**
	 * Set the player dimensions.
	 *
	 * @param playerDimensions A size object which encapsulates player's width and height, in device-independent pixels.
	 */
	public void setPlayerDimensions(Size playerDimensions) {
		this.playerDimensions = playerDimensions;
	}

	/**
	 * Returns the size object of the player's dimensions set on AdRequestConfiguration.
	 *
	 * @return A size object which encapsulates player's dimension, in device-independent pixels.
	 */
	public Size getPlayerDimensions() {
		return this.playerDimensions;
	}

	/**
	 * Returns the consents' configuration set on AdRequestConfiguration.
	 *
	 * @return An object which encapsulates consent configuration information such as GDPR and CCPA consent.
	 */
	public ConsentConfiguration getConsentConfiguration() {
		return consentConfiguration;
	}
}

