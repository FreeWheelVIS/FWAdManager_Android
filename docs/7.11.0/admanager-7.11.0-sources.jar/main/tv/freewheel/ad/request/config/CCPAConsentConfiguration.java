package tv.freewheel.ad.request.config;

import android.content.Context;
import android.preference.PreferenceManager;
import android.util.Log;

import java.util.LinkedList;
import java.util.List;

import tv.freewheel.ad.Constants;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.Logger;

class CCPAConsentConfiguration {
	private static final IConstants constants = new Constants();

	private static final String TAG = "ccpa";
	private static final String PARAMETER_FW_US_PRIVACY = "_fw_us_privacy";

	private String usPrivacy = null;
	private static final Logger logger = Logger.getLogger(CCPAConsentConfiguration.class);

	CCPAConsentConfiguration(){
		logger.debug("Set CCPA Consent Configuration, " + this.toString());
	}

	List<KeyValueConfiguration> generateKVConfigurationList(Context context) {
		Log.d(TAG, "generateKVConfigurationList: ");
		List<KeyValueConfiguration> kvConfigurations = new LinkedList<>();
		this.setCCPAConsentInformationFromSharedPreference(context);
		if (this.isRequiredCCPAConsentInformationPresent()){
			kvConfigurations.add(new KeyValueConfiguration(PARAMETER_FW_US_PRIVACY, this.usPrivacy));
		}
		return kvConfigurations;
	}

	private void setCCPAConsentInformationFromSharedPreference(Context context) {
		Log.d(TAG, "setCCPAConsentInformationFromSharedPreference: ");
		if (context != null) {
			this.usPrivacy = PreferenceManager.getDefaultSharedPreferences(context).getString(constants.IAB_US_PRIVACY_STRING(), null);
		}
	}

	private boolean isRequiredCCPAConsentInformationPresent() {
		Log.d(TAG, "isRequiredCCPAConsentInformationPresent: ");
		return this.usPrivacy != null;
	}

	@Override
	public String toString() {
		return String.format("usPrivacyString: %s", this.usPrivacy);
	}
}