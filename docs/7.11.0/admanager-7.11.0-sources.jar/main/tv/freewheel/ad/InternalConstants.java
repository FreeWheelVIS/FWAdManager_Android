package tv.freewheel.ad;

import java.util.HashMap;

public final class InternalConstants {
	public static final String XML_REQUEST_VERSION = "1";

	public static final String OMSDK_PARTNER_NAME = "Freewheeltv";

	public static final String TAG_AD_REQUEST = "adRequest";
	public static final String TAG_AD_RESPONSE = "adResponse";
	public static final String ATTR_CUSTOM_ID = "customId";
	public static final String ATTR_VERSION = "version";
	public static final String ATTR_NETWORK_ID = "networkId";
	public static final String ATTR_PROFILE = "profile";
	public static final String ATTR_LIVE = "live";
	public static final String ATTR_MODE = "mode";
	public static final String ATTR_SUBSESSION_TOKEN = "subsessionToken";
	public static final String URL_PARAMETER_KEY_SUBSESSION_TOKEN = "ssto";
	//for hard-coded inner fw renderer content type
	public static final String INNER_FW_RENDERER_MAGIC_CONTENT_TYPE = "<<inner_fw_hard_coded_content_type_from_v2_6>>";
	// global sequences
	public static final String TAG_KEY_VALUES = "keyValues";
	public static final String TAG_KEY_VALUE = "keyValue";
	public static final String TAG_KEY_VALUES_KEY = "key";
	public static final String TAG_KEY_VALUES_VALUE = "value";

	public static final String TAG_CONTENT_TYPES = "contentTypes";
	public static final String TAG_ACCEPT_PRIMARY_CONTENT_TYPE = "acceptPrimaryContentType";
	public static final String TYPEB_QUERY_ACCEPT_PRIMARY_CONTENT_TYPE = "prct";

	public static final String ATTR_ACCEPT_PRIMARY_CONTENT_TYPE_ID = "contentTypeId";
	public static final String TAG_ACCEPT_CONTENT_TYPE = "acceptContentType";
	public static final String ATTR_ACCEPT_CONTENT_TYPE_ID = "contentTypeId";

	public static final String TAG_CANDIDATE_ADS = "ads";
	public static final String TAG_CANDIDATE_AD = "ad";
	public static final String ATTR_CANDIDATE_AD_ID = "adId";

	public static final String TAG_RENDERER_MANIFEST = "rendererManifest";
	public static final String TAG_AD_RENDERERS = "adRenderers";
	public static final String TAG_AD_RENDERER = "adRenderer";
	public static final String ATTR_SLOT_TYPE = "slotType";
	public static final String ATTR_SO_AD_UNIT = "soAdUnit";
	public static final String ATTR_RENDERER_NAME = "name";

	public static final String TAG_VISITOR = "visitor";
	public static final String ATTR_VISITOR_CALLER = "caller";
	public static final String ATTR_VISITOR_CUSTOM_ID = "customId";
	public static final String ATTR_VISITOR_IPV4_ADDRESS = "ipV4Address";
	public static final String TAG_VISITOR_HTTP_HEADERS = "httpHeaders";

	public static final String TAG_HTTP_HEADERS = "httpHeaders";
	public static final String TAG_HTTP_HEADER = "httpHeader";
	public static final String ATTR_HTTP_HEADER_NAME = "name";
	public static final String ATTR_HTTP_HEADER_VALUE = "value";

	public static final String TAG_BANDWIDTH_INFO = "bandwidthInfo";
	public static final String ATTR_BANDWIDTH_INFO_BANDWIDTH = "bandwidth";
	public static final String ATTR_BANDWIDTH_INFO_SOURCE = "source";

	public static final String TAG_PARAMETERS = "parameters";
	public static final String TAG_PARAMETER = "parameter";
	public static final String ATTR_PARAMETER_NAME = "name";

	public static final String TAG_AD_SELECTEDADS = "selectedAds";
	public static final String TAG_AD_REFERENCE = "adReference";
	public static final String ATTR_AD_REFERENCE_AD_ID = "adId";
	public static final String ATTR_AD_REFERENCE_CREATIVE_ID = "creativeId";
	public static final String ATTR_AD_REFERENCE_RENDITION_ID = "creativeRenditionId";
	public static final String ATTR_AD_REFERENCE_REPLICA_ID = "replicaId";
	public static final String ATTR_AD_REFERENCE_EXTERNAL_AD_ID = "externalAdId";
	public static final String ATTR_AD_REFERENCE_DEAL_ID = "dealId";
	public static final String ATTR_AD_REFERENCE_OPEN_EXCHANGE_ID = "openExchangeId";
	public static final String ATTR_AD_REFERENCE_MARKET_UNIFIED_AD_ID = "marketUnifiedAdId";
	public static final String ATTR_AD_REFERENCE_ACTION = "action";
	public static final String ATTR_AD_REFERENCE_UNIVERSAL_AD_ID = "universalAdId";
	public static final String ATTR_AD_REFERENCE_UNIVERSAL_AD_ID_REGISTRY = "universalAdIdRegistry";

	public static final String ATTR_AD_REFERENCE_AD_SLOT_CUSTOM_ID = "adSlotCustomId";
	public static final String ATTR_AD_REFERENCE_AD_SLOT_ENV = "adSlotEnv";
	public static final String ATTR_VALUE_AD_REFERENCE_AD_SLOT_ENV_PAGE = "page";
	public static final String ATTR_VALUE_AD_REFERENCE_AD_SLOT_ENV_PLAYER = "player";
	public static final String ATTR_AD_REFERENCE_REQUIRED = "required";

	public static final String TAG_CAPABILITIES = "capabilities";

	public static final String TAG_EVENT_CALLBACKS = "eventCallbacks";
	public static final String TAG_EVENT_CALLBACK = "eventCallback";
	public static final String ATTR_EVENT_CALLBACK_SHOW_BROWSER = "showBrowser";
	public static final String ATTR_EVENT_CALLBACK_USE = "use";
	public static final String ATTR_EVENT_CALLBACK_TYPE = "type";
	public static final String ATTR_EVENT_CALLBACK_NAME = "name";
	public static final String ATTR_EVENT_CALLBACK_URL = "url";
	public static final String TAG_TRACKING_URLS = "trackingURLs";
	public static final String TAG_TRACKING_URL = "url";
	public static final String ATTR_TRACKING_URL_VALUE = "value";
	public static final String AD_VERIFICATION_EVENT_NOT_EXECUTED = "verificationNotExecuted";

	public static final String ATTR_AD_SLOT_PROFILE = "slotProfile";
	public static final String ATTR_AD_SLOT_WIDTH = "width";
	public static final String TYPEB_QUERY_AD_SLOT_WIDTH = "w";
	public static final String ATTR_AD_SLOT_HEIGHT = "height";
	public static final String TYPEB_QUERY_AD_SLOT_HEIGHT = "h";
	public static final String ATTR_AD_SLOT_AD_UNIT = "adUnit";
	public static final String TYPEB_QUERY_SLOT_ADUNIT = "slau";
	public static final String TYPEB_QUERY_SLOT_CUSTOM_ID = "slid";

	public static final String TAG_NON_TEMPORAL_AD_SLOTS = "adSlots";
	public static final String ATTR_NON_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE = "defaultSlotProfile";
	public static final String TAG_NON_TEMPORAL_AD_SLOT = "adSlot";
	public static final String TYPEB_QUERY_SITE_NON_TEMPORAL_AD_SLOT = "s";
	public static final String TAG_NON_TEMPORAL_AD_SLOT_REQUEST = "nonTemporalAdSlot";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_CUSTOM_ID = "customId";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_AD_UNIT = "adUnit";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_ACCEPT_COMPANION = "acceptCompanion";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_ACCEPT_COMPANION = "cmpn";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_NO_INITIAL = "noInitial";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_INITIAL = "init";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_FIRST_COMPANION_AS_INITIAL = "firstCompanionAsInitial";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_FRIST_COMPANION_AS_INITIAL = "fcai";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_NO_INITIAL_IF_COMPANION = "noInitialIfCompanion";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_INITIAL_IF_COMPANION = "niic";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_NO_STANDALONE = "noStandalone";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_STANDALONE = "nosa";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_NO_STANDALONE_IF_TEMPORAL = "noStandaloneIfTemporal";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOT_NO_STANDALONE_IF_TEMPORAL = "nsit";
	public static final String ATTR_NON_TEMPORAL_AD_SLOT_COMP_DIM = "compatibleDimensions";
	public static final String TYPEB_QUERY_NON_TEMPORAL_AD_SLOTS_COMP_DIM = "cd";

	public static final String TAG_TEMPORAL_AD_SLOTS = "adSlots";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOTS = "ptgt";
	public static final String ATTR_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE = "defaultSlotProfile";
	public static final String ATTR_TEMPORAL_AD_SLOTS_COMP_DIM = "compatibleDimensions";
	public static final String TYPEB_QUERY_AD_SLOTS_COMP_DIM = "cd";
	public static final String TAG_TEMPORAL_AD_SLOT = "temporalAdSlot";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT = "a";
	public static final String ATTR_TEMPORAL_AD_SLOT_CUSTOM_ID = "customId";
	public static final String ATTR_TEMPORAL_AD_SLOT_TIME_POSITION = "timePosition";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_TIME_POSITION = "tpos";
	public static final String ATTR_TEMPORAL_AD_SLOT_TIME_POSITION_CLASS = "timePositionClass";
	public static final String ATTR_TEMPORAL_AD_SLOT_EMBEDDED_ADS_DURATION = "embeddedAdsDuration";
	public static final String ATTR_TEMPORAL_AD_SLOT_END_TIME_POSITION = "endTimePosition";
	public static final String ATTR_TEMPORAL_AD_SLOT_AD_UNIT = "adUnit";
	public static final String ATTR_TEMPORAL_AD_SLOT_CLICK_THROUGH_URL = "clickThroughUrl";
	public static final String ATTR_TEMPORAL_AD_SLOT_MAX_SLOT_DURATION = "maxSlotDuration";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_MAX_SLOT_DURATION = "maxd";
	public static final String ATTR_TEMPORAL_AD_SLOT_CUE_POINT_SEQUENCE = "cuePointSequence";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_CUE_POINT_SEQUENCE = "cpsq";
	public static final String ATTR_TEMPORAL_AD_SLOT_BREAK_SEQUENCE = "breakSequence";
	public static final String ATTR_TEMPORAL_AD_SLOT_MIN_SLOT_DURATION = "minSlotDuration";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_MIN_SLOT_DURATION = "mind";
	public static final String ATTR_TEMPORAL_AD_SLOT_MAX_ADS = "maxAds";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_MAX_ADS = "maxa";

	public static final String TAG_DIAGNOSTIC = "diagnostic";

	public static final String TAG_ERRORS = "errors";
	public static final String TAG_ERROR = "error";
	public static final String TAG_ERROR_ID = "id";
	public static final String TAG_ERROR_NAME = "name";
	public static final String TAG_ERROR_MESSAGE = "message";
	public static final String TAG_ERROR_CONTEXT = "context";
	public static final String TAG_ERROR_SEVERITY = "severity";


	public static final String TAG_COMPANION_ADS = "companionAds";
	public static final String TAG_ADS = "ads";
	public static final String ATTR_ADS_CHECK_COMPANION = "checkCompanion";
	public static final String ATTR_ADS_CHECK_TARGETING = "checkTargeting";
	public static final String TAG_AD = "ad";
	public static final String ATTR_AD_ID = "adId";
	public static final String ATTR_AD_ADUNIT = "adUnit";
	public static final String ATTR_AD_NO_PRELOAD = "noPreload";
	public static final String ATTR_AD_NO_LOAD = "noLoad";
	public static final String ATTR_AD_EXTERNAL_AD_ID = "externalAdId";

	public static final String TAG_CREATIVES = "creatives";
	public static final String TAG_CREATIVE = "creative";
	public static final String ATTR_CREATIVE_ID = "creativeId";
	public static final String ATTR_CREATIVE_DURATION = "duration";
	public static final String ATTR_CREATIVE_BASEUNIT = "baseUnit";
	public static final String ATTR_CREATIVE_REDIRECT_URL = "redirectUrl";

	public static final String TAG_CREATIVE_RENDITIONS = "creativeRenditions";
	public static final String TAG_CREATIVE_RENDITION = "creativeRendition";
	public static final String ATTR_CREATIVE_RENDITION_ID = "creativeRenditionId";
	public static final String ATTR_CREATIVE_RENDITION_REPLICA_ID = "adReplicaId";
	public static final String ATTR_CREATIVE_RENDITION_CONTENT_TYPE = "contentType";
	public static final String ATTR_CREATIVE_RENDITION_PREFERENCE = "preference";
	public static final String ATTR_CREATIVE_RENDITION_HEIGHT = "height";
	public static final String ATTR_CREATIVE_RENDITION_WIDTH = "width";
	public static final String ATTR_CREATIVE_RENDITION_WRAPPER_TYPE = "wrapperType";
	public static final String ATTR_CREATIVE_RENDITION_WRAPPER_URL = "wrapperUrl";
	public static final String ATTR_CREATIVE_RENDITION_CREATIVEAPI = "creativeApi";

	// API Frameworks: https://github.com/InteractiveAdvertisingBureau/AdCOM/blob/master/AdCOM%20v1.0%20FINAL.md#list_apiframeworks
	public static final String IAB_API_FRAMEWORKS_VPAID_2 = "2";
	public static final String IAB_API_FRAMEWORKS_MRAID_1 = "3";
	public static final String IAB_API_FRAMEWORKS_OMID_1 = "7";

	public static final String TAG_OTHER_ASSETS = "otherAssets";
	public static final String TAG_ASSET = "asset";
	public static final String TAG_ASSET_CONTENT = "content";
	public static final String ATTR_ASSET_ID = "id";
	public static final String ATTR_ASSET_CONTENT_TYPE = "contentType";
	public static final String ATTR_ASSET_MIME_TYPE = "mimeType";
	public static final String ATTR_ASSET_NAME = "name";
	public static final String ATTR_ASSET_URL = "url";
	public static final String ATTR_ASSET_BYTES = "bytes";
	public static final String ATTR_ASSET_CREATIVE_API = "creativeApi";

	public static final String TAG_SITE_SECTION = "siteSection";
	public static final String ATTR_SITE_SECTION_ID = "id";
	public static final String URL_PARAMETER_KEY_SITE_SECTION_ID = "ssid";
	public static final String ATTR_SITE_SECTION_CUSTOM_ID = "customId";
	public static final String ATTR_SITE_SECTION_PAGE_VIEW_RANDOM = "pageViewRandom";
	public static final String ATTR_SITE_SECTION_NETWORK_ID = "siteSectionNetworkId";
	public static final String ATTR_SITE_SECTION_FALLBACK_ID = "fallbackId";
	public static final String ATTR_SITE_SECTION_FALLBACK_CUSTOM_ID = "fallbackCustomId";
	public static final String ATTR_SITE_SECTION_AL_AD_SLOTS_DEFAULT_PROFILE = "defaultSlotProfile";
	public static final String URL_PARAMETER_KEY_AD_SLOT_DEFAULT_PROFILE = "vdsp";

	public static final String TAG_VIDEO_PLAYER = "videoPlayer";
	public static final String TAG_VIDEO_ASSET = "videoAsset";
	public static final String ATTR_VIDEO_ASSET_ID = "id";
	public static final String URL_PARAMETER_KEY_VIDEO_ASSET_ID = "asid";
	public static final String ATTR_VIDEO_ASSET_CUSTOM_ID = "customId";
	public static final String ATTR_VIDEO_ASSET_DURATION = "duration";
	public static final String ATTR_VIDEO_ASSET_NETWORK_ID = "videoAssetNetworkId";
	public static final String ATTR_VIDEO_ASSET_VIDEO_PLAY_RANDOM = "videoPlayRandom";
	public static final String ATTR_VIDEO_ASSET_AUTO_PLAY = "autoPlay";
	public static final String ATTR_VIDEO_ASSET_UNATTENDED_PLAY = "unattendedPlay";
	public static final String ATTR_VIDEO_ASSET_CLICK_TO_PLAY = "clickToPlay";

	public static final String ATTR_VIDEO_ASSET_FALLBACK_ID = "fallbackId";
	public static final String ATTR_VIDEO_ASSET_FULLBACK_CUSTOM_ID = "fallbackCustomId";
	public static final String ATTR_VIDEO_ASSET_MEDIA_LOCATION = "mediaLocation";
	public static final String ATTR_VIDEO_ASSET_DURATION_TYPE = "durationType";
	public static final String ATTR_VIDEO_ASSET_CURRENT_TIME_POSITION = "currentTimePosition";
	public static final String ATTR_VIDEO_ASSET_REQUEST_DURATION = "requestDuration";
	public static final String ATTR_VIDEO_ASSET_WINDOW_START_TIME = "windowStartTime";
	public static final String TAG_FALLBACK_ADS = "fallbackAds";
	public static final String TAG_EXTENSIONS = "extensions";
	public static final String TAG_EXTENSION = "extension";
	public static final String TAG_EXTENSION_KEY = "key";
	public static final String TAG_EXTENSION_TYPE = "type";
	public static final String TAG_EVENT = "event";
	public static final String TAG_SKIP_OFFSET = "skipoffset";
	public static final String TAG_OFFSET = "offset";

	public static final String REQUEST_MODE_ON_DEMAND = "ON_DEMAND";
	public static final String REQUEST_MODE_LIVE = "LIVE";

	public static final String VIDEO_ASSET_DURATION_TYPE_EXACT = "EXACT";
	public static final String VIDEO_ASSET_DURATION_TYPE_VARIABLE = "VARIABLE";

	public static final String SHORT_EVENT_TYPE_IMPRESSION = "i";
	public static final String SHORT_EVENT_TYPE_CLICK = "c";
	public static final String SHORT_EVENT_TYPE_STANDARD = "s";
	public static final String SHORT_EVENT_TYPE_ERROR = "e";

	public static final String INFO_KEY_PARAMETERS = "parameters";
	public static final String URL_PARAMETER_KEY_START_TIME_POSITION = "stpos";
	public static final String URL_PARAMETER_KEY_ET = "et";
	public static final String URL_PARAMETER_KEY_CN = "cn";
	public static final String URL_PARAMETER_KEY_KV = "kv";
	public static final String URL_PARAMETER_KEY_INIT = "init";
	public static final String URL_PARAMETER_KEY_CT = "ct";
	public static final String URL_PARAMETER_KEY_METR = "metr";
	public static final String URL_PARAMETER_KEY_CR = "cr";
	public static final String URL_PARAMETER_KEY_REID = "reid";
	public static final String URL_PARAMETER_KEY_CREID = "creid";
	public static final String URL_PARAMETER_KEY_ERROR_INFO = "additional";
	public static final String URL_PARAMETER_KEY_ERROR_MODULE = "renderer";
	public static final String URL_PARAMETER_KEY_PROFILE = "prof";
	public static final String URL_PARAMETER_KEY_RESPONSE_TYPE = "resp";
	public static final String URL_PARAMETER_KEY_REQUEST_MODE = "mode";
	public static final String URL_PARAMETER_VALUE_REQUEST_MODE_VOD = "on-demand";
	public static final String URL_PARAMETER_VALUE_REQUEST_MODE_LIVE = "live";
	public static final String URL_PARAMETER_VALUE_RESPONSE_TYPE_AD = "ad";
	public static final String URL_PARAMETER_VALUE_RESPONSE_TYPE_XML = "xml";
	public static final String URL_PARAMETER_VALUE_RESPONSE_TYPE_VAST2 = "vast2";
	public static final String URL_PARAMETER_VALUE_RESPONSE_TYPE_VMAP1 = "vmap1";
	public static final String URL_PARAMETER_KEY_SCHEMA = "schema";
	public static final String URL_PARAMETER_KEY_SITE_CUSTOM_ID = "csid";
	public static final String URL_PARAMETER_KEY_PAGE_VIEW_RANDOM = "pvrn";
	public static final String URL_PARAMETER_KEY_SITE_FALLBACK_ID = "sfid";
	public static final String URL_PARAMETER_KEY_SITE_NETWORK_ID = "ssnw";
	public static final String URL_PARAMETER_KEY_NON_TEMPORAL_AD_SLOTS_DEFAULT_PROFILE = "envp";
	public static final String URL_PARAMETER_KEY_VIDEO_PLAYER_RANDOM = "vprn";
	public static final String URL_PARAMETER_KEY_VIDEO_TIME_POSITION = "vtpo";
	public static final String URL_PARAMETER_KEY_VIDEO_REQUEST_DURATION = "vrdu";
	public static final String URL_PARAMETER_KEY_VIDEO_DURATION_TYPE = "vdty";
	public static final String URL_PARAMETER_VALUE_VIDEO_DURATION_TYPE_EXACT = "exact";
	public static final String URL_PARAMETER_VALUE_VIDEO_DURATION_TYPE_VARIABLE = "variable";
	public static final String URL_PARAMETER_KEY_VIDEO_CUSTOM_ID= "caid";
	public static final String URL_PARAMETER_KEY_VIDEO_ASSET_FALLBACK_ID= "afid";
	public static final String URL_PARAMETER_KEY_VIDEO_ASSET_DURATION= "vdur";
	public static final String URL_PARAMETER_KEY_VIDEO_ASSET_NETWORK_ID= "asnw";
	public static final String URL_PARAMETER_KEY_NETWORK_ID = "nw";
	public static final String URL_PARAMETER_KEY_VISITOR_CALLER = "vclr";
	public static final String URL_PARAMETER_KEY_VISITOR_ID = "vcid";
	public static final String URL_PARAMETER_KEY_IP_ADDRESS = "vip";
	public static final String URL_PARAMETER_KEY_DATE = "date";
	public static final String URL_PARAMETER_KEY_DEBUG = "debug";
	public static final String URL_PARAMETER_KEY_TRACKING = "tracking";
	public static final String URL_PARAMETER_KEY_FORCE_SERVER_SIDE = "sst";
	public static final String URL_PARAMETER_KEY_SESSION_ID = "sid";
	public static final String URL_PARAMETER_KEY_FW_LPU = "_fw_lpu";
	public static final String URL_PARAMETER_KEY_FW_SLPU = "_fw_slpu";
	public static final String URL_PARAMETER_KEY_SIGNITURE = "signature";
	public static final String URL_PARAMETER_KEY_LIMIT_AD_TRACKING = "_fw_is_lat";
	public static final String EVENT_TYPE_GENERIC = "GENERIC";
	public static final String EVENT_VIDEO_VIEW = "videoView";
	public static final String EVENT_TYPE_ERROR = "ERROR";

	public static final String CAPABILITY_NULL_CREATIVE = "supportNullCreative";
	public static final String CAPABILITY_DISABLE_ADUNIT_IN_MULTIPLE_SLOTS = "disableAdUnitInMultipleSlots";
	public static final String CAPABILITY_SKIP_AD_SELECTION = "skipsAdSelection";
	public static final String CAPABILITY_AUTO_EVENT_TRACKING = "autoEventTracking";
	public static final String CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL = "requiresVideoCallbackUrl";
	public static final String TYPEB_QUERY_CAPABILITY_AUTO_EVENT_TRACKING = "aeti";
	public static final String TYPEB_QUERY_CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL = "vicb";
	public static final String TYPEB_QUERY_CAPABILITY_SLOT_CALLBACK = "slcb";
	public static final String TYPEB_QUERY_CAPABILITY_SKIP_AD_SELECTION = "skas";
	public static final String TYPEB_QUERY_CAPABILITY_SUPPORT_SLOT_TEMPLATE = "sltp";
	public static final String TYPEB_QUERY_CAPABILITY_RECORD_VIDEO_VIEW = "exvt";
	public static final String TYPEB_QUERY_RESET_EXCLUSIVITY = "rste";
	public static final String TYPEB_QUERY_SYNC_MULTI_REQUESTS = "sync";
	public static final String TYPEB_QUERY_CAPABILITY_FALLBACK_ADS = "fbad";
	public static final String TYPEB_QUERY_CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS = "emcr";
	public static final String TYPEB_QUERY_CAPABILITY_SUPPORT_NULL_CREATIVE = "nucr";
	public static final String TYPEB_QUERY_CAPABILITY_REQUIRES_RENDERER_MANIFEST = "rema";
	public static final String TYPEB_QUERY_CAPABILITY_ADUNIT_IN_MULTIPLE_SLOT = "amsl";

	public static final String PINGBACK_MACRO_PARAMETER_PREFIX = "parameter.";
	public static final String PINGBACK_MACRO_CREATIVE_ASSET_LOCATION = "creative.assetLocation";
	public static final String PINGBACK_MACRO_CONTENT_PLAYHEADTIME = "content.playheadTime";
	public static final String PINGBACK_MACRO_AD_PLAYHEADTIME = "ad.playheadTime";
	public static final String PINGBACK_MACRO_COMSCORE_PLATFORM_NAME = "comscore.platformname";
	public static final String PINGBACK_MACRO_COMSCORE_DEVICE_NAME = "comscore.devicename";
	public static final String PINGBACK_MACRO_VAST_ERROR_CODE = "[ERRORCODE]";
	public static final String PINGBACK_MACRO_VAST_APIFRAMEWORKS = "[APIFRAMEWORKS]";
	public static final String PINGBACK_MACRO_VAST_OMIDPARTNER = "[OMIDPARTNER]";
	public static final String PINGBACK_MACRO_VAST_TIMESTAMP = "[TIMESTAMP]";
	public static final String PINGBACK_MACRO_VAST_APPBUNDLE = "[APPBUNDLE]";
	public static final String PINGBACK_MACRO_VAST_CONTENTPLAYHEAD = "[CONTENTPLAYHEAD]";
	public static final String PINGBACK_MACRO_VAST_MEDIAPLAYHEAD = "[MEDIAPLAYHEAD]";
	public static final String PINGBACK_MACRO_VAST_ADPLAYHEAD = "[ADPLAYHEAD]";
	public static final String PINGBACK_MACRO_VAST_LIMIT_AD_TRACKING = "[LIMITADTRACKING]";

	public static final String FW_PLAYER_WIDTH = "_fw_player_width";
	public static final String FW_PLAYER_HEIGHT = "_fw_player_height";

	public static final int METR_MASK_QUARTILE = 0;
	public static final int METR_MASK_MIDPOINT = 1;
	public static final int METR_MASK_COMPLETE = 2;
	public static final int METR_MASK_VOLUME = 3;
	public static final int METR_MASK_SIZE = 4;
	public static final int METR_MASK_CONTROL = 5;
	public static final int METR_MASK_REWIND = 6;
	public static final int METR_MASK_ACCEPT_INVITATION = 7;
	public static final int METR_MASK_CLOSE = 8;
	public static final int METR_MASK_MINIMIZE = 9;
	public static final int METR_MASK_CLICK = 10;
	public static final HashMap<String, Integer> METR_MAP = new HashMap<String, Integer>();
	public static final String ATTR_TEMPORAL_AD_SLOT_SIGNAL_ID = "signalId";
	public static final String TYPEB_QUERY_TEMPORAL_AD_SLOT_SIGNAL_ID = "sgid";

	public static final int VAST_DEFAULT_MAX_WRAPPER_COUNT = 5;
	public static final int VAST_DEFAULT_TIMEOUT = 5000;

    static
	{
		METR_MAP.put(Constants._EVENT_AD_QUARTILE, (1 << METR_MASK_QUARTILE) | (1 << METR_MASK_MIDPOINT) | (1 << METR_MASK_COMPLETE));
		METR_MAP.put(Constants._EVENT_AD_FIRST_QUARTILE, (1 << METR_MASK_QUARTILE) | (1 << METR_MASK_MIDPOINT) | (1 << METR_MASK_COMPLETE));
		METR_MAP.put(Constants._EVENT_AD_THIRD_QUARTILE, (1 << METR_MASK_QUARTILE) | (1 << METR_MASK_MIDPOINT) | (1 << METR_MASK_COMPLETE));
		METR_MAP.put(Constants._EVENT_AD_MIDPOINT, (1 << METR_MASK_MIDPOINT) | (1 << METR_MASK_COMPLETE));
		METR_MAP.put(Constants._EVENT_AD_COMPLETE, (1 << METR_MASK_COMPLETE));
		METR_MAP.put(Constants._EVENT_AD_MUTE, (1 << METR_MASK_VOLUME));
		METR_MAP.put(Constants._EVENT_AD_UNMUTE, (1 << METR_MASK_VOLUME));
		METR_MAP.put(Constants._EVENT_AD_COLLAPSE, (1 << METR_MASK_SIZE));
		METR_MAP.put(Constants._EVENT_AD_EXPAND, (1 << METR_MASK_SIZE));
		METR_MAP.put(Constants._EVENT_AD_PAUSE, (1 << METR_MASK_CONTROL));
		METR_MAP.put(Constants._EVENT_AD_RESUME, (1 << METR_MASK_CONTROL));
		METR_MAP.put(Constants._EVENT_AD_REWIND, (1 << METR_MASK_REWIND));
		METR_MAP.put(Constants._EVENT_AD_ACCEPT_INVITATION, (1 << METR_MASK_ACCEPT_INVITATION));
		METR_MAP.put(Constants._EVENT_AD_CLOSE, (1 << METR_MASK_CLOSE));
		METR_MAP.put(Constants._EVENT_AD_MINIMIZE, (1 << METR_MASK_MINIMIZE));
		METR_MAP.put(Constants._EVENT_AD_CLICK, (1 << METR_MASK_CLICK));
	}

	public static class OpenMeasurementConstants {
		public static final String TAG_AD_VERIFICATIONS = "AdVerifications";
		public static final String TAG_VERIFICATION = "Verification";
		public static final String TAG_VENDOR = "vendor";
		public static final String TAG_JAVASCRIPT_RESOURCE= "JavaScriptResource";
		public static final String TAG_EXECUTABLE_RESOURCE= "ExecutableResource";
		public static final String TAG_API_FRAMEWORK = "apiFramework";
		public static final String TAG_BROWSER_OPTIONAL = "browserOptional";
		public static final String TAG_TYPE = "type";
		public static final String TAG_TRACKING_EVENTS = "TrackingEvents";
		public static final String TAG_TRACKING = "Tracking";
		public static final String TAG_VERIFICATION_PARAMETERS = "VerificationParameters";
	}
}
