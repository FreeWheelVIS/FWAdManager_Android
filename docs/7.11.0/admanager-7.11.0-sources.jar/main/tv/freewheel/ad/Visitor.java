package tv.freewheel.ad;

import org.w3c.dom.Element;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.XMLElement;

public class Visitor implements XMLObject {

	public String customId;
	public String caller;
	public String ipV4Address;
	public int bandwidth;
	public String bandwidthSource;
	public Map<String, String> httpHeaders;

	public Visitor(String version) {
		this.httpHeaders = new TreeMap<>();
		this.caller = "android-" + version;
	}

	public void setVisitorHttpHeader(String name, String value) {
		if (name == null) {
			return;
		}
		if (value == null) {
			this.httpHeaders.remove(name);
		} else {
			this.httpHeaders.put(name, value);
		}
	}

	public XMLElement buildXMLElement() {
		XMLElement visitor = new XMLElement(InternalConstants.TAG_VISITOR);
		visitor.setAttribute(InternalConstants.ATTR_VISITOR_CUSTOM_ID, this.customId);
		visitor.setAttribute(InternalConstants.ATTR_VISITOR_CALLER, this.caller);
		visitor.setAttribute(InternalConstants.ATTR_VISITOR_IPV4_ADDRESS, this.ipV4Address);

		if (!this.httpHeaders.isEmpty()) {
			visitor.appendChild(this.buildHttpHeadersElement());
		}

		if (this.bandwidth > 0) {
			visitor.appendChild(this.buildBandwidthInfoElement());
		}

		return visitor;
	}

	public Map<String, String> toGlobalParametersMapForTypeBRequest() {
		HashMap<String, String> map = new HashMap<>();
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_IP_ADDRESS, this.ipV4Address);
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VISITOR_CALLER, this.caller);
		CommonUtil.appendQueryToMap(map, InternalConstants.URL_PARAMETER_KEY_VISITOR_ID, this.customId);
		return map;
	}

	private XMLElement buildHttpHeadersElement() {
		XMLElement headers = new XMLElement(InternalConstants.TAG_HTTP_HEADERS);
		Iterator<String> iter = httpHeaders.keySet().iterator();
		while (iter.hasNext()) {
			XMLElement httpheader = new XMLElement(InternalConstants.TAG_HTTP_HEADER);
			String key = iter.next();
			httpheader.setAttribute(InternalConstants.ATTR_HTTP_HEADER_NAME, key);
			httpheader.setAttribute(InternalConstants.ATTR_HTTP_HEADER_VALUE, this.httpHeaders.get(key));
			headers.appendChild(httpheader);
		}

		return headers;
	}

	private XMLElement buildBandwidthInfoElement() {
		XMLElement bandwidthInfo = new XMLElement(InternalConstants.TAG_BANDWIDTH_INFO);
		bandwidthInfo.setAttribute(InternalConstants.ATTR_BANDWIDTH_INFO_BANDWIDTH, this.bandwidth);
		bandwidthInfo.setAttribute(InternalConstants.ATTR_BANDWIDTH_INFO_SOURCE, this.bandwidthSource);

		return bandwidthInfo;
	}

	public void parse(Element node) {
		/*
		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
		}
		*/
	}
}
