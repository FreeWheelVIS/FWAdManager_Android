package tv.freewheel.ad;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.utils.CommonUtil;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLElement;

public class Capabilities implements XMLObject {
	public static final List<String> CANDIDATE_ADS_CAPABILITIES;
	public static final List<String> TWO_VALUE_CAPABILITIES;
	public static final List<String> TRI_VALUE_CAPABILITIES;
	private static final HashSet<String> DEFAULT_ON_CAPABILITIES;
	private static final Map<String, String> TYPEC_TO_TYPEB_CAPABILITIES;
	
	private TreeMap<String, IConstants.CapabilityStatus> capabilities;

	static {
		CANDIDATE_ADS_CAPABILITIES = new ArrayList<>();
		CANDIDATE_ADS_CAPABILITIES.add(Constants._CAPABILITY_CHECK_TARGETING);
		
		TWO_VALUE_CAPABILITIES = new ArrayList<>();
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_SLOT_TEMPLATE);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_SLOT_CALLBACK);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_BYPASS_COMMERCIAL_RATIO_RESTRICTION);
		TWO_VALUE_CAPABILITIES.add(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL);
		TWO_VALUE_CAPABILITIES.add(InternalConstants.CAPABILITY_SKIP_AD_SELECTION);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_SYNC_MULTI_REQUESTS);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_RESET_EXCLUSIVITY);
		TWO_VALUE_CAPABILITIES.add(InternalConstants.CAPABILITY_NULL_CREATIVE);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS);
		TWO_VALUE_CAPABILITIES.add(Constants._CAPABILITY_FALLBACK_ADS);
		
		TRI_VALUE_CAPABILITIES = new ArrayList<>();
		TRI_VALUE_CAPABILITIES.add(Constants._CAPABILITY_RECORD_VIDEO_VIEW);
		
		DEFAULT_ON_CAPABILITIES = new HashSet<>();
		DEFAULT_ON_CAPABILITIES.add(Constants._CAPABILITY_SLOT_TEMPLATE);
		DEFAULT_ON_CAPABILITIES.add(Constants._CAPABILITY_SLOT_CALLBACK);
		DEFAULT_ON_CAPABILITIES.add(Constants._CAPABILITY_REQUIRES_RENDERER_MANIFEST);
		DEFAULT_ON_CAPABILITIES.add(InternalConstants.CAPABILITY_NULL_CREATIVE);
		DEFAULT_ON_CAPABILITIES.add(InternalConstants.CAPABILITY_AUTO_EVENT_TRACKING);
		DEFAULT_ON_CAPABILITIES.add(Constants._CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS);
		DEFAULT_ON_CAPABILITIES.add(Constants._CAPABILITY_FALLBACK_ADS);

		TYPEC_TO_TYPEB_CAPABILITIES = new HashMap<>();
		TYPEC_TO_TYPEB_CAPABILITIES.put(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL, InternalConstants.TYPEB_QUERY_CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_SLOT_CALLBACK, InternalConstants.TYPEB_QUERY_CAPABILITY_SLOT_CALLBACK);
		TYPEC_TO_TYPEB_CAPABILITIES.put(InternalConstants.CAPABILITY_SKIP_AD_SELECTION, InternalConstants.TYPEB_QUERY_CAPABILITY_SKIP_AD_SELECTION);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_SLOT_TEMPLATE, InternalConstants.TYPEB_QUERY_CAPABILITY_SUPPORT_SLOT_TEMPLATE);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_RECORD_VIDEO_VIEW, InternalConstants.TYPEB_QUERY_CAPABILITY_RECORD_VIDEO_VIEW);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_RESET_EXCLUSIVITY, InternalConstants.TYPEB_QUERY_RESET_EXCLUSIVITY);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_SYNC_MULTI_REQUESTS, InternalConstants.TYPEB_QUERY_SYNC_MULTI_REQUESTS);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_FALLBACK_ADS, InternalConstants.TYPEB_QUERY_CAPABILITY_FALLBACK_ADS);
		TYPEC_TO_TYPEB_CAPABILITIES.put(InternalConstants.CAPABILITY_AUTO_EVENT_TRACKING , InternalConstants.TYPEB_QUERY_CAPABILITY_AUTO_EVENT_TRACKING);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS, InternalConstants.TYPEB_QUERY_CAPABILITY_MULTIPLE_CREATIVE_RENDITIONS);
		TYPEC_TO_TYPEB_CAPABILITIES.put(InternalConstants.CAPABILITY_NULL_CREATIVE, InternalConstants.TYPEB_QUERY_CAPABILITY_SUPPORT_NULL_CREATIVE);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_REQUIRES_RENDERER_MANIFEST, InternalConstants.TYPEB_QUERY_CAPABILITY_REQUIRES_RENDERER_MANIFEST);
		TYPEC_TO_TYPEB_CAPABILITIES.put(Constants._CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS, InternalConstants.TYPEB_QUERY_CAPABILITY_ADUNIT_IN_MULTIPLE_SLOT);
	}
	
	public Capabilities() {
		this.capabilities = new TreeMap<>();
		Iterator<String> iter = DEFAULT_ON_CAPABILITIES.iterator();
		while (iter.hasNext()) {
			this.capabilities.put(iter.next(), Constants.CapabilityStatus.ON);
		}
		iter = TRI_VALUE_CAPABILITIES.iterator();
		while (iter.hasNext()) {
			this.capabilities.put(iter.next(), Constants.CapabilityStatus.DEFAULT);
		}
	}
	
	public void setCapability(String capability, Constants.CapabilityStatus status) {
		if (capability == null || capability.trim().length() == 0) {
			return;
		}
		this.capabilities.put(capability, status);
	}
	
	public IConstants.CapabilityStatus getCapability(String capability) {
		if (this.capabilities.containsKey(capability)) {
			IConstants.CapabilityStatus status = this.capabilities.get(capability);
			if (TRI_VALUE_CAPABILITIES.contains(capability)) {
				return status;
			}
			if (status == Constants.CapabilityStatus.DEFAULT) {
				return DEFAULT_ON_CAPABILITIES.contains(capability) ? Constants.CapabilityStatus.ON : Constants.CapabilityStatus.OFF;
			} else {
				return status;
			}
		} else {
			return Constants.CapabilityStatus.OFF;
		}
	}
	
	public void setCapabilities(Capabilities cap) {
		this.capabilities.clear();
		this.capabilities.putAll(cap.capabilities);
	}
	
	public Map<String, String> toGlobalParametersMapForTypeBRequest() {
		Iterator<String> iter = this.capabilities.keySet().iterator();
		StringBuilder sb = new StringBuilder("");
		while (iter.hasNext()) {
			String capName = iter.next();
			IConstants.CapabilityStatus status = this.getCapability(capName);
			String typebCapName = Capabilities.TYPEC_TO_TYPEB_CAPABILITIES.get(capName);
			if (StringUtils.isBlank(typebCapName)) {
				continue;
			}
			if (status == Constants.CapabilityStatus.OFF) {
				sb.append("-" + typebCapName);
			} else if (status == Constants.CapabilityStatus.ON) {
				sb.append("+" + typebCapName);
			}
		}
		HashMap<String, String> map = new HashMap<>();
		CommonUtil.appendQueryToMap(map, Constants._AD_REQUEST_FLAG_CAPABILITY, sb.toString());
		return map;
	}
	
	public XMLElement buildXMLElement() {
		XMLElement node = new XMLElement(InternalConstants.TAG_CAPABILITIES);
		for (String capName : this.capabilities.keySet()) {
			IConstants.CapabilityStatus status = this.getCapability(capName);

			if (TRI_VALUE_CAPABILITIES.contains(capName)) {
				XMLElement childNode = new XMLElement(capName);
				if (status == IConstants.CapabilityStatus.ON) {
					childNode.setText("true");
				} else if (status == IConstants.CapabilityStatus.OFF) {
					if (capName.equals(Constants._CAPABILITY_ADUNIT_IN_MULTIPLE_SLOTS)) { // workaround for ad server stupid design
						capName = InternalConstants.CAPABILITY_DISABLE_ADUNIT_IN_MULTIPLE_SLOTS;
						childNode.setText("true");
					} else {
						childNode.setText("false");
					}
				} else {
					continue;
				}
				node.appendChild(childNode);
			} else if (status == IConstants.CapabilityStatus.ON) {
				XMLElement childNode = new XMLElement(capName);
				node.appendChild(childNode);
			}
		}
		
		return node;
	}
}
