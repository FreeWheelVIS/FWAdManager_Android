package tv.freewheel.ad;

import org.w3c.dom.Element;

import java.util.Objects;

import tv.freewheel.ad.interfaces.IABUniversalAdId;

/**
 * Created by ljiao on 8/24/17.
 */

public class UniversalAdId implements IABUniversalAdId {
	private String idRegistry;
	private String idValue;
	
	public UniversalAdId(){
	};
	
	public UniversalAdId(String idRegistry,String idValue) {
		this.idRegistry = idRegistry;
		this.idValue = idValue;
	}
	
	public void setIdRegistry(String idRegistry) {
		this.idRegistry = idRegistry;
	}
	
	public void setIdValue(String idValue) {
		this.idValue = idValue;
	}

	@Override
	public String getIdRegistry() {
		return idRegistry;
	}
	
	@Override
	public String getIdValue() {
		return idValue;
	}
	
	public void parse(Element child) {
		this.idRegistry = child.getAttribute("idRegistry");
		this.idValue = child.getFirstChild().getNodeValue();
		if (Objects.equals(this.idValue, "")) {
			this.idValue = child.getAttribute("idValue");
		}
	}

	@Override
	public String toString() {
		return String.format("[UniversalAdId\n\t\t\t\tidRegistry=%s\n\t\t\t\tidValue=%s\n]", this.idRegistry, this.idValue);
	}
}
