package tv.freewheel.ad;

import java.util.HashMap;
import java.util.Iterator;

import tv.freewheel.ad.handler.AdImpressionCallbackHandler;
import tv.freewheel.ad.handler.AdImpressionEndCallbackHandler;
import tv.freewheel.ad.handler.AdMeasurementCallbackHandler;
import tv.freewheel.ad.handler.ClickCallbackHandler;
import tv.freewheel.ad.handler.ErrorCallbackHandler;
import tv.freewheel.ad.handler.EventCallbackHandler;
import tv.freewheel.ad.handler.ProgressEventCallbackHandler;
import tv.freewheel.ad.handler.QuartileCallbackHandler;
import tv.freewheel.ad.handler.ResellerNoAdCallbackHandler;
import tv.freewheel.ad.handler.StandardCallbackHandler;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.RecordTimer;
import android.os.Bundle;

public class CallbackManager {
	private static final Logger logger = Logger.getLogger(CallbackManager.class);
	private AdInstance adInstance;
	private HashMap<String, EventCallbackHandler> handlers;
	
	public AdImpressionCallbackHandler defaultImpressionHandler;
	public AdImpressionEndCallbackHandler adImpressionEndHandler;
	public ClickCallbackHandler defaultClickHandler;
	public ErrorCallbackHandler errorHandler;
	
	private RecordTimer timer;
	
	public CallbackManager(AdInstance adInstance){
		this.adInstance = adInstance;
		this.handlers = new HashMap<String, EventCallbackHandler>();
	}
	
	public void init(){
		this.errorHandler =
			(ErrorCallbackHandler) this.adInstance.createEventHandler("", InternalConstants.EVENT_TYPE_ERROR, true);
		if (errorHandler != null) {
			this.errorHandler.setAdInstance(this.adInstance);
			this.addEventCallbackHandler("", InternalConstants.EVENT_TYPE_ERROR, this.errorHandler);
		}

		Iterator<EventCallback> iter = this.adInstance.eventCallbacks.iterator();
		
		while (iter.hasNext()){
			EventCallback evtCbk = iter.next();
			
			if (evtCbk.name.equals(Constants._EVENT_AD_IMPRESSION) && evtCbk.type.equals(Constants._EVENT_TYPE_IMPRESSION)){
				this.defaultImpressionHandler =
					(AdImpressionCallbackHandler) this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
				this.defaultImpressionHandler.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(evtCbk.name, evtCbk.type, this.defaultImpressionHandler);
			}
			
			if (evtCbk.name.equals(Constants._EVENT_AD_IMPRESSION_END) && evtCbk.type.equals(Constants._EVENT_TYPE_IMPRESSION)){
				this.adImpressionEndHandler =
						(AdImpressionEndCallbackHandler) this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
				this.adImpressionEndHandler.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(evtCbk.name, evtCbk.type, this.adImpressionEndHandler);
			}
			
			else if (evtCbk.name.equals(Constants._EVENT_AD_CLICK) && evtCbk.type.equals(Constants._EVENT_TYPE_CLICK)){
				this.defaultClickHandler =
					(ClickCallbackHandler) this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
				if (this.adInstance.context.getActivity() != null &&
						this.defaultClickHandler != null){
					this.defaultClickHandler.setAdInstance(this.adInstance);
				}
				this.addEventCallbackHandler(evtCbk.name, evtCbk.type, this.defaultClickHandler);
			}

			else if (evtCbk.type.equals(Constants._EVENT_TYPE_IMPRESSION) && (
					evtCbk.name.equals(Constants._EVENT_AD_FIRST_QUARTILE) ||
					evtCbk.name.equals(Constants._EVENT_AD_MIDPOINT) ||
					evtCbk.name.equals(Constants._EVENT_AD_THIRD_QUARTILE) ||
					evtCbk.name.equals(Constants._EVENT_AD_COMPLETE)
					)){
				QuartileCallbackHandler quartileHandler =
					(QuartileCallbackHandler) this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
				quartileHandler.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(evtCbk.name, evtCbk.type, quartileHandler);
			}
			
			else if (evtCbk.type.equals(Constants._EVENT_TYPE_STANDARD)){
				StandardCallbackHandler standardHandler =
					(StandardCallbackHandler) this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
				standardHandler.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(evtCbk.name, evtCbk.type, standardHandler);
			}
		}
		
		//add adEnd event callback if there isn't one in response xml
		if (adImpressionEndHandler == null) {
			this.adImpressionEndHandler =
					(AdImpressionEndCallbackHandler) this.adInstance.createEventHandler(Constants._EVENT_AD_IMPRESSION_END, Constants._EVENT_TYPE_IMPRESSION, true);
			if (adImpressionEndHandler != null) {
				this.adImpressionEndHandler.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(Constants._EVENT_AD_IMPRESSION_END, Constants._EVENT_TYPE_IMPRESSION, this.adImpressionEndHandler);
			}
		}
	}
	
	public void addEventCallbackHandler(String eventName, String eventType, EventCallbackHandler handler){
		String key = eventName + ":" + eventType;
		if (!this.handlers.containsKey(key))
			this.handlers.put(eventName + ":" + eventType, handler);
	}
	
	private EventCallbackHandler getHandlerFromResponse(String eventName, String eventType) {
		EventCallbackHandler ret = null;
		Iterator<EventCallback> iter = this.adInstance.eventCallbacks.iterator();
		
		while (iter.hasNext()){
			EventCallback evtCbk = iter.next();
			
			if (evtCbk.name.equals(eventName) && evtCbk.type.equals(eventType)) {
				ret = this.adInstance.createEventHandler(evtCbk.name, evtCbk.type, false);
			}
		}
		return ret;
	}
	
	public EventCallbackHandler getEventCallbackHandler(String eventName, String eventType){
		if (eventType.equals(Constants._EVENT_TYPE_CLICK_TRACKING)) {
			eventType = Constants._EVENT_TYPE_CLICK;
		}
		EventCallbackHandler ret = this.handlers.get(eventName + ":" + eventType);
		if (ret == null){
			ret = this.getHandlerFromResponse(eventName, eventType);
			if (ret == null) {
				boolean useGeneric = !(eventName.equals(Constants._EVENT_AD_IMPRESSION) || (eventType.equals(Constants._EVENT_TYPE_CLICK) && eventName.equals(Constants._EVENT_AD_CLICK)));
				ret = this.adInstance.createEventHandler(eventName, eventType, useGeneric);
			}
			if (ret != null) {
				ret.setAdInstance(this.adInstance);
				this.addEventCallbackHandler(eventName, eventType, ret);
			}
		}
		return ret;
	}
	
	public void copyOtherHandlers(CallbackManager sourceObj) {
		logger.debug("copyOtherHandlers()");
		Iterator<String> iter = sourceObj.handlers.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			String[] kv = key.split(":");
			if (kv.length != 2) {
				logger.warn("get invalid event callback name-value pair:" + key);
				continue;
			}
			String name = kv[0];
			String type = kv[1];
			EventCallbackHandler newHandler = this.getEventCallbackHandler(name, type);
			EventCallbackHandler oldHandler = sourceObj.handlers.get(key);
			newHandler.addExternalTrackingURLs(oldHandler.getExternalTrackingURLs());
			if (type.equals(Constants._EVENT_TYPE_CLICK)) {
				newHandler.setParameter(InternalConstants.URL_PARAMETER_KEY_CR, oldHandler.getUrlParameter(InternalConstants.URL_PARAMETER_KEY_CR));
			}
			if (name.equals("") && type.equals(InternalConstants.EVENT_TYPE_ERROR)) {
				this.errorHandler = (ErrorCallbackHandler)newHandler;
			} else if (name.equals(Constants._EVENT_AD_IMPRESSION) && type.equals(Constants._EVENT_TYPE_IMPRESSION)) {
				this.defaultImpressionHandler = (AdImpressionCallbackHandler)newHandler;
			} else if (name.equals(Constants._EVENT_AD_IMPRESSION_END) && type.equals(Constants._EVENT_TYPE_IMPRESSION)) {
				this.adImpressionEndHandler = (AdImpressionEndCallbackHandler) newHandler;
			} else if (name.equals(Constants._EVENT_AD_CLICK) && type.equals(Constants._EVENT_TYPE_CLICK)) {
				this.defaultClickHandler = (ClickCallbackHandler)newHandler;
			}
			newHandler.setAdInstance(this.adInstance);
		}
	}
	
	public void sendDefaultImpression(){
		logger.debug("sendDefaultImpression()");
		Bundle info = new Bundle();
		info.putInt(InternalConstants.URL_PARAMETER_KEY_METR, this.adInstance.getMetrValue());

		this.timer = new RecordTimer();
		long ctValue = this.timer.tick();
		info.putLong(InternalConstants.URL_PARAMETER_KEY_CT, ctValue);

		info.putInt(InternalConstants.URL_PARAMETER_KEY_START_TIME_POSITION, this.adInstance.getStartTimePosition());

		if (this.defaultImpressionHandler != null) {
			this.defaultImpressionHandler.send(info);
		} else {
			logger.warn("no default impression callback url");
		}
	}
	
	public void sendAdImpressionEnd(){
		logger.debug("sendAdImpressionEnd");
		Bundle info = new Bundle();
		info.putInt(InternalConstants.URL_PARAMETER_KEY_METR, this.adInstance.getMetrValue());
		
		if (this.timer == null){
			/**
			 * For TemporalSlot, if not send the start impression,
			 * should not send the end impression either
			 */
			return;
		}
		long ctValue = this.timer.tick();
		info.putLong(InternalConstants.URL_PARAMETER_KEY_CT, ctValue);
		this.timer = null;
		
		if (this.adImpressionEndHandler != null) {
			this.adImpressionEndHandler.send(info);
		} else {
			logger.warn("no ad end callback url");
		}
	}
	
	public void callback(String eventName){
		this.callback(eventName, new Bundle());
	}
	
	public void callback(String eventName, Bundle info){
		logger.debug("callback(" + eventName + "," + info +")");
		String eventType = EventCallback.getEventTypeByName(eventName);
		if (eventType.equals(Constants._EVENT_TYPE_API_ONLY)) {
			return;
		}
		if (eventName.equals(Constants._EVENT_AD_FIRST_QUARTILE)
				|| eventName.equals(Constants._EVENT_AD_MIDPOINT)
				|| eventName.equals(Constants._EVENT_AD_THIRD_QUARTILE)
				|| eventName.equals(Constants._EVENT_AD_COMPLETE)){
			this.sendQuartile(eventName);
		} else if (eventName.equals(Constants._EVENT_RESELLER_NO_AD)) {
			ResellerNoAdCallbackHandler handler = (ResellerNoAdCallbackHandler) this.getEventCallbackHandler(eventName, eventType);
			handler.send();
		} else if (eventName.equals(Constants._EVENT_AD_MEASUREMENT)) {
			AdMeasurementCallbackHandler handler = (AdMeasurementCallbackHandler) this.getEventCallbackHandler(eventName, eventType);
			handler.send(info);
		} else if (eventName.equals(Constants._EVENT_AD_SKIPPED_BY_USER)) {
			EventCallbackHandler handler = this.getEventCallbackHandler(eventName, eventType);
			handler.sendTrackingCallbacks();
		} else if (eventName.equals(Constants._EVENT_AD_PROGRESS)) {
			ProgressEventCallbackHandler handler = (ProgressEventCallbackHandler) this.getEventCallbackHandler(eventName, eventType);
			handler.send(info);
		} else if (eventType.equals(Constants._EVENT_TYPE_STANDARD)){
			StandardCallbackHandler handler = (StandardCallbackHandler) this.getEventCallbackHandler(eventName, eventType);
			handler.send();
		} else if (eventType.equals(Constants._EVENT_TYPE_CLICK_TRACKING)){
			ClickCallbackHandler handler = (ClickCallbackHandler) this.getEventCallbackHandler(eventName, eventType);
			handler.send(info);
		}
	}
	
	public void sendQuartile(String eventName){
		Integer mask = InternalConstants.METR_MAP.get(eventName);
		if (mask == null)
			return;
		
		int metr = this.adInstance.getMetrValue();
		
		if ((metr & mask.intValue()) != 0){
			QuartileCallbackHandler handler =
				(QuartileCallbackHandler) this.getEventCallbackHandler(eventName, Constants._EVENT_TYPE_IMPRESSION);
			boolean enableCountingReplayCallback = (this.adInstance.context.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK) != null) ? Boolean.valueOf(this.adInstance.context.getParameter(Constants._PARAMETER_ENABLE_COUNTING_REPLAY_CALLBACK).toString()) : false;
			if (!handler.imprSent || enableCountingReplayCallback) {
				if (this.timer == null) {
					logger.warn("Quartile should not be sent before impression, do nothing, there must be bug in the renderer!");
					return;
				}
				Bundle info = new Bundle();
				info.putLong(InternalConstants.URL_PARAMETER_KEY_CT, this.timer.tick());
				info.putInt(InternalConstants.URL_PARAMETER_KEY_METR, metr);
				logger.debug("sendQuartile(" + eventName + ")");
				handler.send(info);
			}
		} else{
			logger.error("Renderer does not support sending " + eventName + ", ignore.");
		}
	}
	
	public void pause(){
		if (this.timer != null){
			this.timer.pause();
		}
	}
	
	public void resume(){
		if (this.timer != null){
			this.timer.resume();
		}
	}
}
