package tv.freewheel.ad;

/**
 * A class to obtain the version of the FreeWheel AdManager SDK.
 */
public class FreeWheelVersion {
	/**
	 * A string representing the version of the FreeWheel AdManager SDK.
	 */
	public static final String FW_SDK_INTERFACE_VERSION = "UNKNOWN-rUNKNOWN-1602091918";
}
