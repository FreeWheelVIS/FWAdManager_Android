package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

import tv.freewheel.ad.interfaces.ICreativeRenditionAsset;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.XMLHandler;

public class CreativeRenditionAsset extends AdContextScoped implements ICreativeRenditionAsset {
	public int creativeRenditionAssetId;
	public int bytes;
	public String contentType;
	public String mimeType;
	public String name;
	public String url;
	public String content;

	private static final Logger logger = Logger.getLogger(CreativeRenditionAsset.class, true);

	public CreativeRenditionAsset(AdContext context) {
		super(context);
	}
	
	public void parse(Element node) {
		NodeList childList = node.getChildNodes();
		this.creativeRenditionAssetId = StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_ASSET_ID), 0);
		this.setContentType(node.getAttribute(InternalConstants.ATTR_ASSET_CONTENT_TYPE));
		this.setMimeType(node.getAttribute(InternalConstants.ATTR_ASSET_MIME_TYPE));
		this.name = node.getAttribute(InternalConstants.ATTR_ASSET_NAME);
		this.setURL(node.getAttribute(InternalConstants.ATTR_ASSET_URL));

		if(this.url != null && this.url.contains(" ")) {
			this.url = this.url.replace(" ", "%20");
		}
		
		if (node.hasAttribute(InternalConstants.ATTR_ASSET_BYTES)) {
			this.setBytes(StringUtils.parseInt(node.getAttribute(InternalConstants.ATTR_ASSET_BYTES), 0));
		}
		
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				String nodeName = childNode.getNodeName();
				logger.verbose("parse(), name: " + nodeName);

				if (nodeName.equals(InternalConstants.TAG_ASSET_CONTENT)){
					this.content = XMLHandler.getTextNodeValue(childNode);
				} else {
					logger.warn("ignore node: " + nodeName);
				}
			}
		}
	}

	public int getBytes() {
		return this.bytes;
	}

	public String getContent() {
		return this.content;
	}

	public String getContentType() {
		return this.contentType;
	}

	public String getMimeType() {
		return this.mimeType;
	}

	public String getURL() {
		return this.url;
	}

	public void setBytes(int value) {
		this.bytes = value;
	}

	public void setContent(String value) {
		this.content = value;
	}

	public void setContentType(String value) {
		this.contentType = value;
	}

	public void setMimeType(String value) {
		this.mimeType = value;
	}

	public void setURL(String value) {
		this.url = value;
	}

	@Override
	public String toString() {
		return String.format("[CreativeRenditionAsset hashCode:%s, creativeRenditionAssetId:%s, name:%s, contentType:%s, mimeType:%s, url:%s, bytes:%s]",
				hashCode(), creativeRenditionAssetId, name, contentType, mimeType, url, bytes);
	}
}
