package tv.freewheel.ad;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tv.freewheel.extension.openmeasurement.OpenMeasurementConstants;

public class EventCallback extends AdContextScoped {
	public String usage;
	public String type;
	public String name;
	public String url;
	public boolean showBrowser = false;
	public List<String> trackingURLs;
	
	public EventCallback(AdContext context) {
		super(context);
		this.trackingURLs = new ArrayList<>();
	}
	
	public void parse(Element node) {
		this.usage = node.getAttribute(InternalConstants.ATTR_EVENT_CALLBACK_USE);
		this.type = node.getAttribute(InternalConstants.ATTR_EVENT_CALLBACK_TYPE);
		this.name = node.getAttribute(InternalConstants.ATTR_EVENT_CALLBACK_NAME);
		this.url = node.getAttribute(InternalConstants.ATTR_EVENT_CALLBACK_URL);
		this.showBrowser = Boolean.valueOf(node.getAttribute(InternalConstants.ATTR_EVENT_CALLBACK_SHOW_BROWSER));
 
		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				if (childNode.getNodeName().equals(InternalConstants.TAG_TRACKING_URLS)){
					this.parseTrackingUrl((Element)childNode);
				}
			}
		}
	}

	public EventCallback(AdContext context, String name, String type, String url, String usage, boolean showBrowser, List<String> trackingURLs) {
		this(context);
		this.name = name;
		this.type = type;
		this.url = url;
		this.usage = usage;
		this.showBrowser = showBrowser;
		if (trackingURLs != null) {
			this.trackingURLs = trackingURLs;
		}
	}
	
	private void parseTrackingUrl(Element node) {
		NodeList childList = node.getChildNodes();
		for(int i = 0; i < childList.getLength(); i++) {
			Node childNode = childList.item(i);
			if(childNode.getNodeType() == Node.ELEMENT_NODE) {
				if (childNode.getNodeName().equals(InternalConstants.TAG_TRACKING_URL)){
					Element urlNode = (Element)childNode;
					this.trackingURLs.add(urlNode.getAttribute(InternalConstants.ATTR_TRACKING_URL_VALUE));
				}
			}
		}
	}
	
	public EventCallback cloneForTranslation(){
		EventCallback ret = new EventCallback(this.context);
		ret.usage = this.usage;
		ret.type = this.type;
		ret.name = this.name;
		ret.url = this.url;
		ret.showBrowser = this.showBrowser;
		ret.trackingURLs.addAll(this.trackingURLs);
		return ret;
	}
	
	public static List<String> validate(String eventName, String eventType, List<String> urls){
		ArrayList<String> errors = new ArrayList<>();
		if (eventType == null || eventType.equals("")){
			errors.add("eventType is empty.");
		}
		if (urls == null || urls.isEmpty()){
			errors.add("URLs is empty.");
		}
		String et = EventCallback.getEventTypeByName(eventName);
		if (!et.equals(eventType)){
			errors.add("Not a valid combination: eventName is " + eventName + " and eventType is " + eventType);
		}
		return errors;
	}
	
	public static String getEventTypeByName(String eventName){
		String eventType = Constants._EVENT_TYPE_CLICK_TRACKING;
		if (Arrays.asList(EventCallback.VALID_IMPRESSION_EVENT_NAMES).indexOf(eventName) > -1){
			eventType = Constants._EVENT_TYPE_IMPRESSION;
		} else if (Arrays.asList(EventCallback.VALID_STANDARD_EVENT_NAMES).indexOf(eventName) > -1){
			eventType = Constants._EVENT_TYPE_STANDARD;
		} else if (Arrays.asList(EventCallback.VALID_ERROR_EVENT_NAMES).indexOf(eventName) > -1){
			eventType = InternalConstants.EVENT_TYPE_ERROR;
		} else if (Arrays.asList(EventCallback.VALID_API_ONLY_EVENT_NAMES).indexOf(eventName) > -1) {
			eventType = Constants._EVENT_TYPE_API_ONLY;
		}
		return eventType;
	}
	
	public static final String getShortenedEventType(String eventType){
		int index = Arrays.asList(EventCallback.EVENT_TYPES).indexOf(eventType);
		if (index > -1){
			return EventCallback.SHORT_EVENT_TYPES[index];
		}
		return null;
	}
	
	public final static String[] EVENT_TYPES = {
		Constants._EVENT_TYPE_CLICK,
		Constants._EVENT_TYPE_CLICK_TRACKING,
		Constants._EVENT_TYPE_IMPRESSION,
		Constants._EVENT_TYPE_STANDARD
	};
	
	public final static String[] SHORT_EVENT_TYPES = {
		"c",
		"c",
		"i",
		"s"
	};
	
	public final static String[] VALID_IMPRESSION_EVENT_NAMES = {
		Constants._EVENT_AD_IMPRESSION,
		Constants._EVENT_AD_FIRST_QUARTILE,
		Constants._EVENT_AD_MIDPOINT,
		Constants._EVENT_AD_THIRD_QUARTILE,
		Constants._EVENT_AD_COMPLETE,
		Constants._EVENT_AD_MEASUREMENT,
		Constants._EVENT_RESELLER_NO_AD
	};
	
	public final static String[] VALID_STANDARD_EVENT_NAMES = {
		Constants._EVENT_AD_PAUSE,
		Constants._EVENT_AD_RESUME,
		Constants._EVENT_AD_REWIND,
		Constants._EVENT_AD_MUTE,
		Constants._EVENT_AD_UNMUTE,
		Constants._EVENT_AD_COLLAPSE,
		Constants._EVENT_AD_EXPAND,
		Constants._EVENT_AD_MINIMIZE,
		Constants._EVENT_AD_CLOSE,
		Constants._EVENT_AD_ACCEPT_INVITATION,
		Constants._EVENT_AD_SKIPPED_BY_USER,
		Constants._EVENT_AD_PROGRESS
	};
	
	public final static String[] VALID_ERROR_EVENT_NAMES = {
		Constants._ERROR_ADINSTANCE_UNAVAILABLE,
		Constants._ERROR_INVALID_VALUE,
		Constants._ERROR_IO,
		Constants._ERROR_MISSING_PARAMETER,
		Constants._ERROR_NO_AD_AVAILABLE,
		Constants._ERROR_NO_RENDERER,
		Constants._ERROR_NULL_ASSET,
		Constants._ERROR_PARSE,
		Constants._ERROR_RENDERER_LOAD,
		Constants._ERROR_TIMEOUT,
		Constants._ERROR_UNKNOWN,
		""
	};

	public final static String[] VALID_API_ONLY_EVENT_NAMES = {
			Constants._EVENT_AD_VOLUME_CHANGED,
			Constants._EVENT_AD_PREINIT,
			Constants._EVENT_AD_SKIPPABLE_STATE_CHANGED,
			OpenMeasurementConstants.EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION,
			""
	};

	public List<String> getAllUrls () {
		List<String> ret = new ArrayList<>();
		ret.addAll(trackingURLs);
		ret.add(url);
		return ret;
	}
}
