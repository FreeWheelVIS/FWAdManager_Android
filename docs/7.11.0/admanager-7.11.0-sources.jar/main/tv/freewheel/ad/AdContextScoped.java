package tv.freewheel.ad;

import tv.freewheel.utils.Logger;

public class AdContextScoped {
	protected AdContext context;

	public AdContextScoped(final AdContext context) {
		this.context = context;
	}
	
	public AdRequest getAdRequest() {
		return this.context.adRequest;
	}

	public AdResponse getAdResponse() {
		return this.context.adResponse;
	}
	
	public AdContext getAdContext() {
		return this.context;
	}
}
