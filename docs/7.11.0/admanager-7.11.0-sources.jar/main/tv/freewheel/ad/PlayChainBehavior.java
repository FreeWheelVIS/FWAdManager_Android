package tv.freewheel.ad;

import tv.freewheel.ad.state.AdEndedState;
import tv.freewheel.ad.state.AdFailedState;
import tv.freewheel.ad.state.AdState;
import tv.freewheel.ad.state.SlotPlayingState;
import tv.freewheel.ad.state.SlotState;

public class PlayChainBehavior extends ChainBehavior {
	public String toString() {
		return "PlayChainBehavior";
	}
	
	public SlotState relatedSlotState() {
		return SlotPlayingState.Instance();
	}
	
	public boolean isChainStopper(AdInstance adInstance) {
		return adInstance.imprSent || adInstance.isSkipped;
	}
	
	public boolean isDestState(AdState adState) {
		return (adState == AdEndedState.Instance() || adState == AdFailedState.Instance());
	}
}
