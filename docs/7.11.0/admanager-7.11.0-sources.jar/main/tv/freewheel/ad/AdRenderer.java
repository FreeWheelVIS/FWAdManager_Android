package tv.freewheel.ad;

import org.w3c.dom.Element;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import tv.freewheel.renderers.html.HTMLRenderer;
import tv.freewheel.renderers.interfaces.IRenderer;
import tv.freewheel.renderers.nullnull.NullAdRenderer;
import tv.freewheel.renderers.temporal.CustomPlayerRenderer;
import tv.freewheel.renderers.temporal.VPAIDRenderer;
import tv.freewheel.renderers.temporal.VideoRenderer;
import tv.freewheel.renderers.vast.VastTranslator;
import tv.freewheel.utils.Logger;

public class AdRenderer extends ParametersHolder {
	private static Map<String, Class<? extends IRenderer>> renderers = Collections.synchronizedMap(new HashMap<String, Class<? extends IRenderer> >());
	
	protected HashSet<String> contentType;
	protected HashSet<String> slotType;
	protected HashSet<String> adUnit; // baseUnit
	protected HashSet<String> creativeApi;
	protected HashSet<String> soAdUnit; // adUnit
	public String name;
	public String url;

	private static final Logger logger;

	private Class<?> rendererClass = null;
	
	static {
		logger = Logger.getLogger("AdRenderer");

		//register internal renderers
		renderers.put("null/null", NullAdRenderer.class);
		renderers.put("VideoRenderer", VideoRenderer.class);
		renderers.put("HTMLRenderer", HTMLRenderer.class);
		renderers.put("VastTranslator", VastTranslator.class);
		renderers.put("VPAIDRenderer", VPAIDRenderer.class);
		renderers.put("CustomPlayerRenderer", CustomPlayerRenderer.class);
	}
	
	public static void registerRenderer(String name, Class<? extends IRenderer> cls) {
		renderers.put(name,  cls);
	}
	
	public static IRenderer getRenderer(AdRenderer rendererDescription) throws InstantiationException, IllegalAccessException {
		logger.debug("getRenderer for url " + rendererDescription.url);
		if (rendererDescription.rendererClass != null) {
			return (IRenderer) rendererDescription.rendererClass.newInstance();
		}

		String name = rendererDescription.name;
		String className = null;

		if (rendererDescription.url != null ) {
			if (rendererDescription.url.startsWith("http") || rendererDescription.url.startsWith("https")) {
				// backward compatibility
				int idx = rendererDescription.url.lastIndexOf('/');
				if (idx >= 0) {
					name = rendererDescription.url.substring(idx + 1);

					idx = name.indexOf(".fpk");
					if (idx >= 0) {
						name = name.substring(0, idx);
					}
				}
			} else if (rendererDescription.url.startsWith("class://")) {
				className = rendererDescription.url.substring(8);
				int idx = className.lastIndexOf('.');
				if (idx >= 0) {
					name = className.substring(idx + 1);
				} else {
					name = className;
				}
			}
		}

		if (name == null) { // added by IAdContext.addRenderer()
			logger.error("Unknown renderer URL " + rendererDescription.url
					+ ", should be the format class://com.example.myClassName");
			return null;
		}

		Class<?> cls = renderers.get(name);
		if (cls == null) {
			if (className == null) { // not class://xxx
				logger.error("Can not find registered renderer class for name " + name);
				return null;
			}

			try {
				cls = Class.forName(className);
			} catch (ClassNotFoundException e) {
				logger.error("Failed to load class " + className);
				return null;
			}
		}

		rendererDescription.rendererClass = cls;
		return (IRenderer)cls.newInstance();
	}
	
	public AdRenderer(AdContext context) {
		super(context);
	}
	
	public AdRenderer(AdContext context, String url, String adUnit, String soAdUnit,
			String contentType, String slotType, String creativeAPI,
			String name, Map<String, Object> parameters) {
		this(context);
		this.contentType = this.parseFromCommaString(contentType);
		this.slotType = this.parseFromCommaString(slotType);
		this.adUnit = this.parseFromCommaString(adUnit);
		this.creativeApi = this.parseFromCommaString(creativeAPI);
		this.soAdUnit = this.parseFromCommaString(soAdUnit);
		this.name = name;
		this.url = url;
		if (parameters != null) {
			this.parameters = parameters;
		}
	}

	public void parse(Element node) {
		String contentTypeStr = node.getAttribute(InternalConstants.ATTR_ASSET_CONTENT_TYPE);
		this.contentType = this.parseFromCommaString(contentTypeStr);
		String slotTypeStr = node.getAttribute(InternalConstants.ATTR_SLOT_TYPE);
		this.slotType = this.parseFromCommaString(slotTypeStr);
		String adUnitStr = node.getAttribute(InternalConstants.ATTR_AD_ADUNIT);
		this.adUnit = this.parseFromCommaString(adUnitStr);
		String creativeApiStr = node.getAttribute(InternalConstants.ATTR_CREATIVE_RENDITION_CREATIVEAPI);
		this.creativeApi = this.parseFromCommaString(creativeApiStr);
		String soAdUnitStr = node.getAttribute(InternalConstants.ATTR_SO_AD_UNIT);
		this.soAdUnit = this.parseFromCommaString(soAdUnitStr);
		this.url = node.getAttribute(InternalConstants.ATTR_ASSET_URL);
		this.name = node.getAttribute(InternalConstants.ATTR_RENDERER_NAME);
		
		this.parseRendererParameters(node);
	}
	
	private HashSet<String> parseFromCommaString(String value) {
		HashSet<String> set = new HashSet<>();
		if (value != null && (value.length() > 0)) {
			String[] list = value.toLowerCase().split(",");
			Collections.addAll(set, list);
		}
		return set;
	}
	
	public boolean match(String adUnit, String soAdUnit, String contentType,
			String slotType, String creativeAPI, String wrapperType) {
		
		boolean noWrapperType = ((wrapperType == null) || wrapperType.equals(""));
		String adType = noWrapperType ? contentType : wrapperType;
		
		boolean ret = (this.adUnit.isEmpty()) || this.adUnit.contains(adUnit.toLowerCase());
		ret = ret && ((this.soAdUnit.isEmpty()) || this.soAdUnit.contains(soAdUnit.toLowerCase()));
		ret = ret && ((this.contentType.isEmpty()) || this.contentType.contains(adType.toLowerCase()));
		ret = ret && ((this.slotType.isEmpty()) || this.slotType.contains(slotType.toLowerCase()));
		ret = ret && ((this.creativeApi.isEmpty()) || this.creativeApi.contains(creativeAPI.toLowerCase()));
		
		return ret;
	}
	
	public boolean isTranslator(){
		return this.url != null && this.url.toLowerCase().contains("translator");
	}

	public HashSet<String> getCreativeApi() {
		return this.creativeApi;
	}
}
