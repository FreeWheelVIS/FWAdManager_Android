package tv.freewheel.ad;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.CookieSyncManager;
import android.widget.FrameLayout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.lang.ref.WeakReference;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import tv.freewheel.ad.AdResponse.IllegalAdResponseException;
import tv.freewheel.ad.interfaces.IAdContext;
import tv.freewheel.ad.interfaces.IAdManager;
import tv.freewheel.ad.interfaces.IConstants;
import tv.freewheel.ad.interfaces.IEvent;
import tv.freewheel.ad.interfaces.IEventListener;
import tv.freewheel.ad.interfaces.ISlot;
import tv.freewheel.ad.request.config.AdRequestConfiguration;
import tv.freewheel.ad.request.config.CapabilityConfiguration;
import tv.freewheel.ad.request.config.KeyValueConfiguration;
import tv.freewheel.ad.request.config.NonTemporalSlotConfiguration;
import tv.freewheel.ad.request.config.SiteSectionConfiguration;
import tv.freewheel.ad.request.config.TemporalSlotConfiguration;
import tv.freewheel.ad.request.config.VideoAssetConfiguration;
import tv.freewheel.ad.request.config.VisitorConfiguration;
import tv.freewheel.ad.slot.NonTemporalSlot;
import tv.freewheel.ad.slot.Slot;
import tv.freewheel.ad.slot.TemporalSlot;
import tv.freewheel.extension.ExtensionManager;
import tv.freewheel.extension.IExtension;
import tv.freewheel.extension.openmeasurement.FWOMSDKFriendlyObstructionConfiguration;
import tv.freewheel.extension.openmeasurement.OpenMeasurementConstants;
import tv.freewheel.renderers.interfaces.IActivityStateChangeCallbackListener;
import tv.freewheel.renderers.temporal.CustomPlayer;
import tv.freewheel.utils.DisplayUtils;
import tv.freewheel.utils.Logger;
import tv.freewheel.utils.StringUtils;
import tv.freewheel.utils.URLLoader;
import tv.freewheel.utils.URLRequest;
import tv.freewheel.utils.events.Event;
import tv.freewheel.utils.events.EventDispatcher;

public class AdContext extends EventDispatcher implements IAdContext {

	public final int networkId;
	public final int version;
	public final String adManagerVersion;

	public static final int AD_REQUEST_TIMEOUT_SECONDS = 5;

	private static final Logger logger = Logger.getLogger(AdContext.class, true);
	private String userAgent;
	private FrameLayout temporalSlotBase;
	private Activity hostActivity;
	protected boolean requestSubmitted = false;

	public String serverUrl = AdManager.DEFAULT_SERVER_URL;
	public String playerProfile = null;
	public String defaultTemporalSlotProfile = null;
	public String defaultVideoPlayerSlotProfile = null;
	public String defaultSiteSectionSlotProfile = null;
	public Visitor visitor;
	public Capabilities capabilities;
	public AdRequest adRequest;
	public AdResponse adResponse;
	public List<AdRenderer> adRenderers;
	private List<FWOMSDKFriendlyObstructionConfiguration> friendlyObstructions;
	public List<WeakReference<IActivityStateChangeCallbackListener>> mOnActivityStateChangeCallbackListeners;
	protected URLLoader requestLoader = null;

	private CustomPlayer customPlayer = null;

	private static Constants constants;
	protected Location geoLocation;
	protected String screenDimensionStr;

	public final AdManager adManager;
	public Map<String, IExtension> loadedExtensions;
	private Map<String, String> autoloadExtensions;
	protected AdRequestConfiguration requestConfiguration = null;

	private float adVolume = 1;

	public double contentPlayheadTime = -1;
	private String appPackageName;

	public AdContext(int networkId, String serverUrl, String stringVersion, int version) {
		this.networkId = networkId;
		this.serverUrl = serverUrl;
		this.adManagerVersion = stringVersion;
		this.version = version;
		this.adManager = null;
		this.visitor = new Visitor(this.getVersion());
		this.capabilities = new Capabilities();
		this.adRequest = new AdRequest(this);
		this.adResponse = new AdResponse(this);
		this.adRenderers = new ArrayList<>();
		this.friendlyObstructions = new ArrayList();
		this.userAgent = "Mozilla/5.0 ("
			+ this.getCurrentUserAgent()
			+ ") FreeWheelAdManager/"
			+ this.adManagerVersion;
		this.mOnActivityStateChangeCallbackListeners = new ArrayList<>();

		setUpAdContextListeners();
	}

	public AdContext(AdManager adManager) {
		logger.debug("new " + this.getClass().getName());
		this.adManager = adManager;
		this.serverUrl = adManager.serverUrl;
		this.networkId = adManager.networkId;
		this.adManagerVersion = adManager.getStringVersion();
		this.version = adManager.getVersion();
		this.visitor = new Visitor(this.getVersion());
		this.capabilities = new Capabilities();
		this.adRequest = new AdRequest(this);
		this.adResponse = new AdResponse(this);
		this.adRenderers = new ArrayList<>();
		this.friendlyObstructions = new ArrayList();
		this.userAgent = "Mozilla/5.0 ("
			+ this.getCurrentUserAgent()
			+ ") FreeWheelAdManager/"
			+ this.adManagerVersion;
		this.mOnActivityStateChangeCallbackListeners = new ArrayList<>();
		if (this.adManager.geoLocation != null) {
			/**
			 *  After AdContext constructed,
			 *  AdManager.setLocation() will not affect this adContext's location value
			 */
			this.geoLocation = new Location(this.adManager.geoLocation);
		}else{
			this.geoLocation = null;
		}
		//ExtensionManager.registerAdContext(this);
		this.loadedExtensions = new HashMap<>();

		setUpAdContextListeners();
	}

	/**
	 * Partially copy constructor esp. used in live mode
	 */
	public AdContext(AdContext context){
		this(context.adManager);

		this.adRequest.setAdRequest(context.adRequest);

		this.visitor.customId = context.visitor.customId;
		this.visitor.ipV4Address = context.visitor.ipV4Address;
		this.visitor.bandwidth = context.visitor.bandwidth;
		this.visitor.bandwidthSource = context.visitor.bandwidthSource;
		for (String name:context.visitor.httpHeaders.keySet()) {
			String value = context.visitor.httpHeaders.get(name);
			this.visitor.setVisitorHttpHeader(name , value);
		}

		this.capabilities.setCapabilities(context.capabilities);
		this.capabilities.setCapability(Constants._CAPABILITY_RESET_EXCLUSIVITY, IConstants.CapabilityStatus.DEFAULT);

		this.serverUrl = context.serverUrl;
		this.playerProfile = context.playerProfile;
		this.defaultTemporalSlotProfile = context.defaultTemporalSlotProfile;
		this.defaultVideoPlayerSlotProfile = context.defaultVideoPlayerSlotProfile;
		this.defaultSiteSectionSlotProfile = context.defaultSiteSectionSlotProfile;
		this.friendlyObstructions = new ArrayList<>(context.friendlyObstructions);
		this.screenDimensionStr = context.screenDimensionStr;

		this.temporalSlotBase = context.temporalSlotBase;

		this.setActivity(context.hostActivity);

		this.adResponse.videoAsset.state = context.adResponse.videoAsset.state;
		this.adResponse.videoAsset.timer = context.adResponse.videoAsset.timer;
		this.adResponse.videoAsset.callbackHandler = context.adResponse.videoAsset.callbackHandler;
	}

	public void setServer(String url) {
		this.serverUrl = StringUtils.patchAdRequestServerURL(url);
	}

	private void setUpAdContextListeners(){
		this.addEventListener(Constants._EVENT_AD_VOLUME_CHANGED, new IEventListener() {
			@Override
			public void run(IEvent event) {
				logger.debug("Received volume changed event with data " + event.getData());
				Object volume = event.getData().get(constants.INFO_KEY_VOLUME());
				if (volume != null && volume instanceof Float) {
					AdContext.this.adVolume = (float) volume;
				} else {
					logger.debug("Could not update the volume, got object " + volume);
				}
			}
		});
	}
	/**
	 * from frameworks/base/core/java/android/webkit/WebSettings.java
	 * @return UA String
	 */
	private String getCurrentUserAgent() {
		Locale locale = Locale.getDefault();
		StringBuffer buffer = new StringBuffer();

		// Add version
		final String androidVersion = Build.VERSION.RELEASE;
		if (androidVersion.length() > 0) {
			buffer.append(androidVersion);
		} else {
			// default to "1.0"
			buffer.append("1.0");
		}
		buffer.append("; ");

		final String language = locale.getLanguage();
		if (language != null) {
			buffer.append(language.toLowerCase());
			final String country = locale.getCountry();
			if (country != null) {
				buffer.append("-");
				buffer.append(country.toLowerCase());
			}
		} else {
			// default to "en"
			buffer.append("en");
		}

		// add the model for the release build
		if ("REL".equals(Build.VERSION.CODENAME)) {
			final String model = Build.MODEL;
			if (model.length() > 0) {
				buffer.append("; ");
				buffer.append(model);
			}
		}

		final String id = Build.ID;
		if (id.length() > 0) {
			buffer.append(" Build/");
			buffer.append(id);
		}

		final String base = "Android %s";
		return String.format(base, buffer);
	}

	public IConstants getConstants() {
		if(constants == null) {
			constants = new Constants();
		}

		return constants;
	}

	public String getVersion() {
		return this.adManagerVersion;
	}

	public String getServerUrl() {
		return this.serverUrl;
	}

	public int getNetworkId() {
		return this.networkId;
	}

	public String[] valuesForKey(String key){
		return adRequest.valuesForKey(key);
	}

	private void setProfileWithConfiguration(AdRequestConfiguration config){
		logger.debug("setProfileWithConfiguration " + config.getPlayerProfile() + " " + config.getDefaultSiteSectionSlotProfile() + " " + config.getDefaultVideoPlayerSlotProfile() + " " + config.getDefaultSiteSectionSlotProfile());
		this.playerProfile = config.getPlayerProfile();
		this.defaultTemporalSlotProfile = config.getDefaultTemporalSlotProfile() != null && config.getDefaultTemporalSlotProfile().length() > 0 ? config.getDefaultTemporalSlotProfile() : config.getPlayerProfile();

		this.defaultSiteSectionSlotProfile = config.getDefaultNonTemporalSlotProfile();
		if (!StringUtils.isBlank(config.getDefaultSiteSectionSlotProfile())) {
			this.defaultSiteSectionSlotProfile = config.getDefaultSiteSectionSlotProfile();
		}

		this.defaultVideoPlayerSlotProfile = config.getDefaultNonTemporalSlotProfile();
		if (!StringUtils.isBlank(config.getDefaultVideoPlayerSlotProfile())) {
			this.defaultVideoPlayerSlotProfile = config.getDefaultVideoPlayerSlotProfile();
		}
	}

	private void setVisitorWithConfiguration(VisitorConfiguration v) {
		logger.debug("setVisitor " + v.getCustomId() + " " + v.getIPV4Address() + " " + v.getBandwidth() + "" + v.getBandwidthSource());
		visitor.customId = v.getCustomId();
		visitor.ipV4Address = v.getIPV4Address();
		visitor.bandwidth = v.getBandwidth();
		visitor.bandwidthSource = v.getBandwidthSource();
	}

	private void setSiteSectionWithConfiguration(SiteSectionConfiguration config){
		if(config == null) return;
		logger.debug("setSiteSectionWithConfiguration " + config.getSiteSectionId() + " " + config.getPageViewRandom() + " "
				+ config.getNetworkId() + " " + config.getSiteSectionIdType() + " " + config.getFallbackId());
		this.adRequest.setSiteSection(config.getSiteSectionId(), config.getPageViewRandom(),
				config.getNetworkId(), config.getSiteSectionIdType(), config.getFallbackId() != null? config.getFallbackId().trim():"");
	}

	private void setVideoAssetWithConfiguration(VideoAssetConfiguration config){
		if (config == null) return;
		logger.debug("setVideoAsset " + config.getVideoAssetId() + " " + config.getDuration() + " " + config.getVideoLocation()
				+ " " + config.getVideoAssetAutoPlayType() + " " + config.getVideoPlayRandom() + " " + config.getNetworkId()
				+ " " + config.getVideoAssetIdType() + " " + config.getFallbackId() + " " + config.getVideoAssetDurationType());
		this.adRequest.setVideoAsset(config.getVideoAssetId(), config.getDuration(), config.getVideoLocation(),
				config.getVideoPlayRandom(), config.getNetworkId(),
				config.getVideoAssetIdType(), config.getFallbackId() != null? config.getFallbackId().trim() : "", config.getVideoAssetDurationType(), config.getVideoAssetAutoPlayType(), config.getWindowStartTime());
		if (config.getCurrentTimePosition() > 0) {
			this.adRequest.setVideoAssetCurrentTimePosition(config.getCurrentTimePosition());
		}
	}

	private  void addSlotWithConfiguration(NonTemporalSlotConfiguration config){
		this.adRequest.addSiteSectionNonTemporalSlot(config.getCustomId(), config.getAdUnit(),
				config.getWidth(), config.getHeight(), config.getSlotProfile(), config.isCompanionAccepted(),
				config.getAcceptPrimaryContentType(),
				config.getAcceptContentType(), config.getSlotInitialAdOption(), config.getCompatibleDimensions());
	}

	private  void addSlotWithConfiguration(TemporalSlotConfiguration config){
		this.adRequest.addTemporalSlot(config.getCustomId(), config.getAdUnit(), config.getTimePosition(),
				config.getSlotProfile(), config.getCuePointSequence(), config.getMaxDuration(),
				config.getAcceptPrimaryContentType(), config.getAcceptContentType(), config.getMinDuration(), config.getMaxAds(), config.getSignalId(), config.getBreakSequence());
	}

	@Override
	public void setParameter(String name, Object value, IConstants.ParameterLevel level) {
		this.adRequest.setParameter(name, value, level);
	}

	public ISlot getSlotByCustomId(String customId) {
		return this.adResponse.getSlotByCustomId(customId);
	}

	@Override
	public List<ISlot> getSlotsByTimePositionClass(IConstants.TimePositionClass timePositionClass) {
		List<ISlot> slots = new ArrayList<>();

		if (timePositionClass == IConstants.TimePositionClass.DISPLAY) {
			// add all slots in nonTemporalSlots
			slots.addAll(this.adResponse.nonTemporalSlots);
		} else {
			for (TemporalSlot slot : this.adResponse.temporalSlots) {
				if (timePositionClass == slot.getSlotTimePositionClass()) {
					slots.add(slot);
				}
			}
		}

		return slots;
	}

	protected void notifyRequestComplete() {
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Constants._INFO_KEY_MESSAGE, "request succeeded");
		data.put(Constants._INFO_KEY_SUCCESS, "true");
		dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
	}

	/*
	 * Becasue response data maybe large, according to http://stackoverflow.com/questions/8888654/android-set-max-length-of-logcat-messages
	 * we need split response to many small part
	 */
	private void logResponse(String responseStr) {
		logger.debug("got response: ");
		if (responseStr.length() <= 4000) {
			logger.debug(responseStr);
		} else {
			int chunkCount = responseStr.length() / 4000;     // integer division
			for (int i = 0; i <= chunkCount; i++) {
				int startIndex = 4000 * i;
				int endIndex = Math.min(4000 * (i + 1), responseStr.length());
				logger.debug(responseStr.substring(startIndex, endIndex));
			}
		}
	}

	private IEventListener adLoadCompleteListener = new IEventListener() {
		public void run(IEvent event) {
			String xmldata = (String) event.getData().get(Constants._INFO_KEY_MESSAGE);
			logResponse(xmldata);

			HashMap<String, Object> data = new HashMap<String, Object>();
			try {
				AdContext.this.adResponse.parse(xmldata);
			} catch (Throwable e) {
				AdContext.logger.warn("Ad response parsing failed with message: " + e.getMessage(), e);
				data.put(Constants._INFO_KEY_MESSAGE, "request failed: " + e.toString());
				data.put(Constants._INFO_KEY_SUCCESS, "false");
				dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
				return;
			}
			autoloadExtensions = getNeedLoadedExtensions();
			if (autoloadExtensions.isEmpty()) {
				notifyRequestComplete();
			} else {
				for (String extensionName : autoloadExtensions.keySet()) {
					loadExtension(extensionName);
				}
				notifyRequestComplete();
			}
		}
	};

	private IEventListener adLoadFailedListener = new IEventListener() {
		public void run(IEvent event) {
			String message = (String) event.getData().get(Constants._INFO_KEY_MESSAGE);
			logger.debug("request failed: " + message);
			HashMap<String, Object> data = new HashMap<String, Object>();
			data.put(Constants._INFO_KEY_MESSAGE, "request failed: " + message);
			data.put(Constants._INFO_KEY_SUCCESS, "false");
			dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
		}
	};

	public String getUserAgent() {
		return this.userAgent;
	}

	protected void addDPRToAdRequest() {
		final float scale = this.getActivity().getApplicationContext().getResources().getDisplayMetrics().density;
		DecimalFormat decimalFormat = new DecimalFormat("0.##");
		this.adRequest.addKeyValue("_fw_dpr", decimalFormat.format(scale));
	}

	protected void addLocationToAdRequest() {
		if (this.geoLocation != null) {
			this.adRequest.addKeyValue("ltlg", String.format("%.4f,%.4f", this.geoLocation.getLatitude(), this.geoLocation.getLongitude()));
		}
	}

	protected URLRequest buildRequest() {
		if (this.networkId != -1 && this.serverUrl != null) {
			this.addDPRToAdRequest();
			this.addLocationToAdRequest();
			this.adRequest.removeKey("_fw_omidpn");
			this.adRequest.removeKey("_fw_omidpv");
			this.adRequest.addKeyValue("_fw_omidpn", InternalConstants.OMSDK_PARTNER_NAME);
			this.adRequest.addKeyValue("_fw_omidpv", this.adManager.getOMSDKPartnerVersion());
			String requestStr = "";
			try {
				requestStr = this.adRequest.toXML();
			} catch (Exception e) {
				logger.warn("Ad Request building failed with message: " + e.getMessage(), e);
				HashMap<String, Object> data = new HashMap<>();
				data.put(Constants._INFO_KEY_MESSAGE, "request failed: " + e.toString());
				data.put(Constants._INFO_KEY_SUCCESS, "false");
				dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
				return null;
			}
			logger.debug("request is: " + requestStr);

			logger.debug("submitRequest: " + this.serverUrl);

			URLRequest req = new URLRequest(this.serverUrl, this.userAgent);

			req.method = URLRequest.Method.POST;
			req.contentType = URLRequest.CONTENT_TYPE_TEXT_XML;
			req.data = requestStr;

			return req;
		} else {
			logger.error("invalid networkId or serverUrl");
			return null;
		}
	}

	public void loadExtension(String name) {
		logger.debug("loadExtension: " + name);
		if (!this.loadedExtensions.containsKey(name)) {
			boolean success = true;
			String msg = "load successful";
			try {
				IExtension ext = ExtensionManager.loadExtension(name, this);
				if (ext == null) {
					success = false;
					msg = "can not get a instance for " + name;
				}
			} catch(ClassNotFoundException e) {
				success = false;
				msg = e.getMessage();
				logger.warn("could not load extension "+ name + " , please check package name");
			} catch (IllegalAccessException e) {
				success = false;
				msg = e.getMessage();
			} catch (InstantiationException e) {
				success = false;
				msg = e.getMessage();
			}
			onExtensionLoaded(success, msg, name);
		} else {
			logger.info("already have extension " + name + " loaded before, ignore the action");
		}
	}
	@Override
	public void setAdVolume(float volume) {
		logger.debug("set Ad Volume to " + volume);
		if (volume < 0 || volume > 1) {
			logger.warn("Invalid volume input: " + volume + ". Volume is expected in the range of [0-1]");
			return;
		}
		if (volume == this.adVolume) {
			logger.debug("Volume did not change, ignore");
			return;
		}
		this.adVolume = volume;
		for (ISlot _temporalSlot : this.getTemporalSlots()) {
			Slot temporalSlot = (Slot) _temporalSlot;
			if (temporalSlot.currentPlayingAdInstance != null) {
				temporalSlot.currentPlayingAdInstance.setAdVolume(volume);
				break;
			}
		}
	}
	@Override
	public float getAdVolume() {
		return this.adVolume;
	}

	protected void setupRequestWithConfiguration(AdRequestConfiguration config){
		this.setProfileWithConfiguration(config);
		this.setSiteSectionWithConfiguration(config.getSiteSectionConfiguration());
		this.setVideoAssetWithConfiguration(config.getVideoAssetConfiguration());
		for(NonTemporalSlotConfiguration slot : config.getNonTemporalSlotConfigurations()){
			this.addSlotWithConfiguration(slot);
		}
		for(TemporalSlotConfiguration slot : config.getTemporalSlotConfigurations()){
			this.addSlotWithConfiguration(slot);
		}
		for(KeyValueConfiguration keyValue : config.getKeyValueConfigurations()){
			this.adRequest.addKeyValue(keyValue.getKey(),keyValue.getValue());
		}
		for (KeyValueConfiguration consentKeyValue: config.getConsentConfiguration().consentConfigurationsToKVConfigurations(getActivity())) {
			this.adRequest.removeKey(consentKeyValue.getKey());
			this.adRequest.addKeyValue(consentKeyValue.getKey(), consentKeyValue.getValue());
		}
		// add player width and height
		if (config.getPlayerDimensions().getWidth() > 0 && config.getPlayerDimensions().getHeight() > 0) {
			int player_width_in_pixel = DisplayUtils.dpToPixel(this.getActivity().getApplicationContext(), config.getPlayerDimensions().getWidth());
			int player_height_in_pixel = DisplayUtils.dpToPixel(this.getActivity().getApplicationContext(), config.getPlayerDimensions().getHeight());
			this.adRequest.addKeyValue(InternalConstants.FW_PLAYER_WIDTH, String.valueOf(player_width_in_pixel));
			this.adRequest.addKeyValue(InternalConstants.FW_PLAYER_HEIGHT, String.valueOf(player_height_in_pixel));
		}
		for(CapabilityConfiguration cap : config.getCapabilityConfigurations()){
			this.capabilities.setCapability(cap.getCapability(), cap.getCapabilityStatus());
		}
		if(config.getVisitorConfiguration() != null){
			this.setVisitorWithConfiguration(config.getVisitorConfiguration());
			for (String name:config.getVisitorConfiguration().getHttpHeaders().keySet()) {
				String value = config.getVisitorConfiguration().getHttpHeaders().get(name);
				this.visitor.setVisitorHttpHeader(name, value);
			}
		}
		this.adRequest.setRequestMode(config.getAdRequestMode());
		if (config.getSubsessionToken() > 0) {
			this.adRequest.startSubsession(config.getSubsessionToken());
		}
		if (config.getVideoAssetConfiguration() != null && config.getVideoAssetConfiguration().getRequestDuration() > 0) {
			this.adRequest.setRequestDuration(config.getVideoAssetConfiguration().getRequestDuration());
		}
		if (this.capabilities.getCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION) == Constants.CapabilityStatus.ON) {
			this.capabilities.setCapability(InternalConstants.CAPABILITY_SKIP_AD_SELECTION, Constants.CapabilityStatus.OFF);
		}
		if(this.adRequest.hasVideoAsset() && this.capabilities.getCapability(Constants._CAPABILITY_RECORD_VIDEO_VIEW) != Constants.CapabilityStatus.ON) {
			if (this.adRequest.videoViewCallbackRequested) {
				this.capabilities.setCapability(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL, Constants.CapabilityStatus.OFF);
			} else {
				this.adRequest.videoViewCallbackRequested = true;
				this.capabilities.setCapability(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL, Constants.CapabilityStatus.ON);
			}
		} else {
			this.capabilities.setCapability(InternalConstants.CAPABILITY_REQUIRES_VIDEO_CALLBACK_URL, Constants.CapabilityStatus.OFF);
		}
		if (this.adRequest.valuesForKey(Constants._PARAMETER_FWU_TOPIC) == null && adManager != null && adManager.getTopicsString() != "") {
			this.adRequest.addKeyValue(Constants._PARAMETER_FWU_TOPIC, adManager.getTopicsString());
		}
	}

	public void submitRequestWithConfiguration(AdRequestConfiguration config, double timeoutSeconds){
		if (config == null) {
			logger.info("Request configuration is null. Cannot submit the ad request.");
			return;
		}
		this.serverUrl = config.getServerURL();
		this.requestConfiguration = config;
		this.validateWindowStartTimeAndBreakSequence(config);
		this.setupRequestWithConfiguration(config);
		this.submitRequest(timeoutSeconds, 0);
	}

	private void validateWindowStartTimeAndBreakSequence(AdRequestConfiguration config) {
		boolean isWindowStartTimeSet = false;
		boolean isBreakSequenceSet = false;

		// Need to check if VideoAssetConfiguration is set for AdContextTest
		if (this.requestConfiguration.getVideoAssetConfiguration() != null){
			isWindowStartTimeSet = this.requestConfiguration.getVideoAssetConfiguration().getWindowStartTime() > 0;
		}

		int index = 0;
		ArrayList<TemporalSlotConfiguration> temporalSlots = new ArrayList<>(this.requestConfiguration.getTemporalSlotConfigurations());
		while (!isBreakSequenceSet && index < temporalSlots.size()){
			TemporalSlotConfiguration slot = temporalSlots.get(index);
			isBreakSequenceSet = slot.getBreakSequence() > 0;
			index += 1;
		}

		if (!isBreakSequenceSet || !isWindowStartTimeSet) {
			logger.warn("breakSequence and windowStartTime not set as one or both are invalid.");
			if (this.requestConfiguration.getVideoAssetConfiguration() != null) {
				this.requestConfiguration.getVideoAssetConfiguration().setWindowStartTime(0);
			}
			for (TemporalSlotConfiguration slot: config.getTemporalSlotConfigurations()) {
				slot.setBreakSequence(0);
			}
		}
	}

	private void submitRequest(double timeoutSeconds, double maxDelayBeforeRequest) {
		final long delayMs = (long) (maxDelayBeforeRequest * 1000);
		if (this.requestSubmitted) {
			logger.warn("Each AdContext instance can only submit ad request once.");
			return;
		}
		this.requestSubmitted = true;
		// send Request Initiated event
		dispatchEvent(new Event(Constants._EVENT_REQUEST_INITIATED));

		if (!this.serverUrl.matches("^\\w+:.*")) { // local storage file
			logger.debug("submitRequest to local file: " + this.serverUrl);
			new Thread() {
				@Override
				public void run() {
					HashMap<String, Object> data = new HashMap<>();
					try {
						if (delayMs > 0) {
							Thread.sleep(delayMs);
						}
						FileInputStream fis = new FileInputStream(new File(serverUrl));
						adResponse.parse(fis);
						data.put(Constants._INFO_KEY_MESSAGE, "request succeeded");
						data.put(Constants._INFO_KEY_SUCCESS, "true");
						dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
					} catch (FileNotFoundException | IllegalAdResponseException  e) {
						data.put(Constants._INFO_KEY_MESSAGE, "request failed: " + e.getMessage());
						data.put(Constants._INFO_KEY_SUCCESS, "false");
						dispatchEvent(new Event(Constants._EVENT_REQUEST_COMPLETE, data));
						logger.warn("Ad Request failed while transacting with message: " + e.getMessage(), e);
					} catch (Throwable e) {
						logger.warn("Ad Request failed because of thread interruption: " + e.getMessage(), e);
					}
				}
			}.start();

			return;
		}

		URLRequest req = this.buildRequest();

		if (req != null) {
			req.delayMs = delayMs;
			this.requestLoader = new URLLoader();

			this.requestLoader.addEventListener(URLLoader.EVENT_LOAD_COMPLETE,
					adLoadCompleteListener);
			this.requestLoader.addEventListener(URLLoader.EVENT_LOAD_ERROR,
					adLoadFailedListener);

			if (timeoutSeconds <= 0) {
				this.requestLoader.load(req);
			} else {
				this.requestLoader.load(req, timeoutSeconds);
			}
		}
	}

	@Override
	public void setVideoState(IConstants.VideoState videoState) {
		logger.info("setVideoState " + videoState);
		if (videoState == IConstants.VideoState.PLAYING) {
			this.adResponse.videoAsset.play();
		} else if (videoState == IConstants.VideoState.PAUSED
				|| videoState == IConstants.VideoState.STOPPED) {
			this.adResponse.videoAsset.pause();
		} else if (videoState == IConstants.VideoState.COMPLETED) {
			this.adResponse.videoAsset.complete();
			this.adRequest.videoViewCallbackRequested = false;
			this.adResponse.videoAsset = new VideoAsset(this);
		}
	}

	@Override
	public void setContentVideoPlayheadTime(double playheadTime) {
		this.contentPlayheadTime = playheadTime;
	}

	@Override
	public void registerVideoDisplayBase(FrameLayout videoDisplayBase) {
		this.temporalSlotBase = videoDisplayBase;
		new Handler(Looper.getMainLooper()).post(new Runnable() {
			public void run() {
				Iterator<TemporalSlot> iter = adResponse.temporalSlots.iterator();
				HashMap<String, Object> data = new HashMap<>();
				while (iter.hasNext()) {
					TemporalSlot slot = iter.next();
					if (slot.isPlaying() && slot.currentPlayingAdInstance != null) {
						slot.onUpdatedSlotBase();
						data.put(Constants._INFO_KEY_ADINSTANCE, slot.currentPlayingAdInstance);
						break;
					}
				}
				if (temporalSlotBase != null) {
					logger.info("registerVideoDisplay(" + temporalSlotBase + "), width: " + temporalSlotBase.getWidth() + ", height: " + temporalSlotBase.getHeight());
				} else {
					logger.info("registerVideoDisplay: video display base is null");
				}
				dispatchEvent(new Event(Constants._EVENT_VIDEO_DISPLAY_BASE_CHANGED, data));
			}
		});
	}

	@Override
	public void addFriendlyObstruction(FWOMSDKFriendlyObstructionConfiguration obstructionConfiguration) {
		logger.debug("Adding friendly obstruction configuration: " + obstructionConfiguration);
		if (!this.friendlyObstructions.contains(obstructionConfiguration)) {
			this.friendlyObstructions.add(obstructionConfiguration);
			HashMap<String, Object> map = new HashMap<>();
			map.put(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_CONFIG, obstructionConfiguration);
			map.put(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_REMOVE, false);
			dispatchFriendlyObstructionEvent(map);
		} else {
			logger.debug("The friendly Obstruction view has already been added.");
		}
	}

	public List<FWOMSDKFriendlyObstructionConfiguration> getFriendlyObstructions() {
		return this.friendlyObstructions;
	}

	@Override
	public void removeFriendlyObstruction(FWOMSDKFriendlyObstructionConfiguration obstructionConfiguration) {
		logger.debug("Removing friendly obstruction configuration: " + obstructionConfiguration);
		if (this.friendlyObstructions.contains(obstructionConfiguration)) {
			this.friendlyObstructions.remove(obstructionConfiguration);
			HashMap<String, Object> map = new HashMap<>();
			map.put(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_CONFIG, obstructionConfiguration);
			map.put(OpenMeasurementConstants.INFO_KEY_OMSDK_FRIENDLY_OBSTRUCTION_REMOVE, true);
			dispatchFriendlyObstructionEvent(map);
		} else {
			logger.debug("The friendly Obstruction view does not exist.");
		}
	}

	private void dispatchFriendlyObstructionEvent(HashMap<String, Object> map) {
		for (ISlot _temporalSlot : this.getTemporalSlots()) {
			Slot temporalSlot = (Slot) _temporalSlot;
			if (temporalSlot.currentPlayingAdInstance != null) {
				temporalSlot.currentPlayingAdInstance.dispatchEvent(OpenMeasurementConstants.EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION, map);
			}
		}
		for (ISlot _nonTemporalSlot : this.getNonTemporalSlots()) {
			Slot nonTemporalSlot = (Slot) _nonTemporalSlot;
			if (nonTemporalSlot.currentPlayingAdInstance != null) {
				nonTemporalSlot.currentPlayingAdInstance.dispatchEvent(OpenMeasurementConstants.EVENT_UPDATE_OMSDK_FRIENDLY_OBSTRUCTION, map);
			}
		}
	}

	public FrameLayout getTemporalSlotBase() {
		return this.temporalSlotBase;
	}

	public List<ISlot> getTemporalSlots() {
		ArrayList<ISlot> slots = new ArrayList<>();
		for (TemporalSlot slot : this.adResponse.temporalSlots) {
			if (slot.getSlotTimePositionClass() != IConstants.TimePositionClass.PAUSE_MIDROLL) {
				slots.add(slot);
			}
		}
		return slots;
	}

	/**
	 * @deprecated  Please use getNonTemporalSlots() instead
	 */
	@Deprecated
	public List<ISlot> getSiteSectionNonTemporalSlots() {
		return getNonTemporalSlots();
	}

	@Override
	public List<ISlot> getNonTemporalSlots() {
		ArrayList<ISlot> slots = new ArrayList<>();
		for (NonTemporalSlot nonTemporalSlot : this.adResponse.nonTemporalSlots) {
			if (nonTemporalSlot.getSlotType() == IConstants.SlotType.NON_TEMPORAL) {
				slots.add(nonTemporalSlot);
			}
		}
		return slots;
	}

	@SuppressLint("DefaultLocale")
	protected String getScreenDimensionStr() {
		if (this.screenDimensionStr == null) {
			Display display = ((WindowManager) this.hostActivity.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
			int width = display.getWidth();
			int height = display.getHeight();
			this.screenDimensionStr = String.format("%d,%d", width, height);
		}
		return this.screenDimensionStr;
	}

	public void setActivity(Activity activity) {
		if (activity != null) {
			Logger.overrideLogLevel(activity);
			this.hostActivity = activity;
			String appVersion;
			try {
				appVersion = String.valueOf(activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionCode);
			} catch (NameNotFoundException e) {
				logger.warn("cannot get the appVersion from PackageManager, setting appVersion to unknown");
				appVersion = "unknown";
			}
			appPackageName = activity.getPackageName();
			this.userAgent += ";" + appPackageName + "/" + appVersion;
			logger.debug("UserAgent:" + this.userAgent);
		}
	}

	public Activity getActivity() {
		return this.hostActivity;
	}

	@Override
	public void setActivityState(IConstants.ActivityState state) {
		if (hostActivity == null) {
			logger.debug("setActivityState(" + state + ") dismissed since hostActivity is null");
			return;
		}
		logger.debug("setActivityState(" + state + ")");
		if (state == IConstants.ActivityState.PAUSED || state == IConstants.ActivityState.RESUMED) {
			HashMap<String, Object> data = new HashMap<>();
			data.put(Constants._INFO_KEY_ACTIVITY_STATE, state.state);
			dispatchEvent(new Event(Constants._EVENT_ACTIVITY_STATE_CHANGED, data));
		}
		switch (state) {
			case RESUMED:
				CookieSyncManager.getInstance().startSync();
				for (TemporalSlot slot : this.adResponse.temporalSlots) {
					if (slot.isPlaying() && slot.currentPlayingAdInstance != null) {
						slot.currentPlayingAdInstance.resume();
						break;
					}
				}
				this.notifyActivityCallback(state);
				break;
			case PAUSED:
				CookieSyncManager.getInstance().stopSync();
				if (hostActivity.isFinishing()){
					logger.debug("The activity will be destroyed.");
				} else {
					logger.debug("It is going to pause active ad.");
					for (TemporalSlot slot : this.adResponse.temporalSlots) {
						if (slot.isPlaying() && slot.currentPlayingAdInstance != null) {
							slot.currentPlayingAdInstance.pause();
							break;
						}
					}
				}
				this.notifyActivityCallback(state);
				break;
		}
	}

	void addOnActivityStateChangeCallbackListener(IActivityStateChangeCallbackListener activityStateChangeCallbackListener) {
		this.mOnActivityStateChangeCallbackListeners.add(new WeakReference<>(activityStateChangeCallbackListener));
	}

	private void notifyActivityCallback(IConstants.ActivityState callbackActivityState) {
		for (WeakReference<IActivityStateChangeCallbackListener> mOnActivityStateChangeCallbackListener : this.mOnActivityStateChangeCallbackListeners) {
			IActivityStateChangeCallbackListener l = mOnActivityStateChangeCallbackListener.get();
			if (l != null) {
				l.onActivityStateChanged(callbackActivityState);
			}
		}
	}

	public void dispose() {
		logger.debug("dispose");
		this.removeAllListeners();
		if (this.requestLoader != null) {
			this.requestLoader.removeAllListeners();
			this.requestLoader = null;
		}

		if (this.mOnActivityStateChangeCallbackListeners != null) {
			this.mOnActivityStateChangeCallbackListeners.clear();
		}

		for (NonTemporalSlot n_slot : this.adResponse.nonTemporalSlots) {
			n_slot.stop();
		}

		for (TemporalSlot slot : this.adResponse.temporalSlots) {
			if (slot.isPreloading() || slot.isPlaying() || slot.isPaused()) {
				slot.stop();
			}
		}

		this.friendlyObstructions = null;
		this.hostActivity = null;
		this.temporalSlotBase = null;
		ExtensionManager.unregisterAdContext(this);
	}

	public void registerCustomPlayer(CustomPlayer customPlayer) {
		logger.debug("registerCustomPlayer");
		this.customPlayer =  customPlayer;
	}

	public CustomPlayer getCustomPlayer() {
		return this.customPlayer;
	}

	public void addRenderer(String className, String baseUnit, String soldAsAdUnit, String contentType, String slotType, Map<String, Object> parameters) {
		this.addRenderer(className, baseUnit, soldAsAdUnit, contentType, slotType, null, parameters);
	}

	public String getVideoLocation() {
		return this.adRequest.vaMediaLocation;
	}

	public Object getParameter(String name) {
		Object value = null;
		List<Map<String, Object>> paramArray = new ArrayList<>();
		paramArray.add(this.adRequest.overrideLevelParameters);
		paramArray.add(this.adResponse.profileParameters);
		paramArray.add(this.adRequest.globalLevelParameters);

		for (Map<String, Object> params: paramArray) {
			value = params.get(name);
			if (value != null) {
				break;
			}
		}

		return value;
	}

	public IAdManager getAdManager() {
		return this.adManager;
	}

	public void addRenderer(String className, String baseUnit, String soldAsAdUnit, String contentType, String slotType, String creativeAPI, Map<String, Object> parameters) {
		logger.debug("addRenderer " + className);

		AdRenderer renderer = new AdRenderer(this, className, baseUnit, soldAsAdUnit, contentType, slotType, creativeAPI, null, parameters);
		this.adRenderers.add(0, renderer);
	}

	public void requestTimelineToPauseBySlot(Slot slot) {
		logger.debug("requestTimelineToPauseBySlot(slot=" + slot + ")");
		this.requestContentPause(slot);
		for (ISlot temporalSlot : this.getTemporalSlots()) {
			if (!temporalSlot.getCustomId().equals(slot.getCustomId())) {
				temporalSlot.pause();
			}
		}
		for (ISlot pauseMidrollSlot : this.getSlotsByTimePositionClass(IConstants.TimePositionClass.PAUSE_MIDROLL)) {
			pauseMidrollSlot.pause();
		}
	}

	public void requestTimelineToResumeBySlot(Slot slot) {
		logger.debug("requestTimelineToResumeBySlot(slot=" + slot + ")");
		this.requestContentResume(slot);
		for (ISlot temporalSlot : this.getTemporalSlots()) {
			if (!temporalSlot.getCustomId().equals(slot.getCustomId())) {
				temporalSlot.resume();
			}
		}
		for (ISlot pauseMidrollSlot : this.getSlotsByTimePositionClass(IConstants.TimePositionClass.PAUSE_MIDROLL)) {
			pauseMidrollSlot.resume();
		}
	}

	public void requestContentPause(Slot slot) {
		logger.debug("requestContentPause(slot=" + slot + ")");
		this.adResponse.videoAsset.requestPauseBySlot(slot);
	}

	public void requestContentResume(Slot slot) {
		logger.debug("requestContentResume(slot=" + slot + ")");
		this.adResponse.videoAsset.requestResumeBySlot(slot);
	}

	@Override
	public void dispatchEvent(final IEvent event) {
		if (this.hostActivity == null){
			logger.warn("The activity is not registered yet. The dispatchEvent will be done on current thread.");
			super.dispatchEvent(event);
		} else if (Looper.myLooper() != Looper.getMainLooper()) {
			logger.warn("Need re-dispatchEvent " + event.getType() + " on main UI thread.");
			new Handler(Looper.getMainLooper()).post(new Runnable() {
				public void run() {
					AdContext.super.dispatchEvent(event);
				}
			});
		} else {
			super.dispatchEvent(event);
		}
	}

	@Override
	public void notifyUserAction(IConstants.UserAction userAction) {
		logger.debug("notifyUserAction(userAction=" + userAction + ")");
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Constants._INFO_KEY_USER_TRIGGERED_ACTION, userAction);
		this.dispatchEvent(new Event(Constants._EVENT_USER_ACTION_NOTIFIED, data));
	}

	public void onExtensionLoaded(boolean success, String msg, String moduleName) {
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Constants._INFO_KEY_MODULE_NAME, moduleName);
		if (success) {
			data.put(Constants._INFO_KEY_MESSAGE, "extension loaded");
			data.put(Constants._INFO_KEY_SUCCESS, "true");
		} else {
			data.put(Constants._INFO_KEY_MESSAGE, msg);
			data.put(Constants._INFO_KEY_SUCCESS, "false");
		}
		dispatchEvent(new Event(Constants._EVENT_EXTENSION_LOADED, data));
	}

	private Map<String, String> getNeedLoadedExtensions() {
		Map<String, String> ret = new ConcurrentHashMap<>();
		ret.putAll(this.getAutoLoadExtensionsFromParameter("autoloadExtensions"));
		ret.putAll(this.getAutoLoadExtensionsFromParameter("autoloadExtensionsInternal"));
		for (String name : ExtensionManager.internalExtensions) {
			ret.put(name, "");
		}
		Set<String> autoloadExtensionNames = new HashSet<String>(ret.keySet());
		for (String extensionName : autoloadExtensionNames) {
			if (this.loadedExtensions.containsKey(extensionName)) {
				logger.debug("remove extension(" + extensionName + ") since it has been loaded");
				ret.remove(extensionName);
			}
		}

		return ret;
	}

	protected HashMap<String, String> getAutoLoadExtensionsFromParameter(String parameterName) {
		String extensionUrlSeparator = ",";

		HashMap<String, String> autoLoadExtensions = new HashMap<String, String>();
		Object autoloadExtensionsValue = this.getParameter(parameterName);
		if(autoloadExtensionsValue != null) {
			String[] extensionUrls = autoloadExtensionsValue.toString().split(extensionUrlSeparator);
			for(int i = 0; i < extensionUrls.length; ++i) {
				String extensionUrl = extensionUrls[i].trim();
				if(extensionUrl.equals("")) {
					continue;
				}
				if(!extensionUrl.startsWith("http") && !extensionUrl.startsWith("https")){
					logger.debug("getAutoLoadExtensions() add extension, name: " + extensionUrl);
					autoLoadExtensions.put(extensionUrl, extensionUrl);
					continue;
				}
				String extensionName = null;
				if (extensionUrl.lastIndexOf(".") > -1) {
					extensionName = extensionUrl.substring(extensionUrl.lastIndexOf("/") + 1, extensionUrl.lastIndexOf("."));
				}
				if(extensionName != null) {
					logger.debug("getAutoLoadExtensions() add extension, name:" + extensionName + " url:" + extensionUrl);
					autoLoadExtensions.put(extensionName, extensionUrl);
				}
			}
		}
		return autoLoadExtensions;
	}

	public IConstants.VideoAssetAutoPlayType getAutoplayType() {
		return this.adRequest.getVaAutoplayType();
	}

	@Override
	public String toString() {
		return String.format("[AdContext hashCode:%s, networkId:%s, serverUrl:%s]", this.hashCode(), this.networkId, this.serverUrl);
	}

	public String getAppPackageName() {
		return appPackageName;
	}

	@Override
	public void updateOmidLastActivity() {
		logger.debug("AdContext.updateOmidLastActivity");
		dispatchEvent(new Event(Constants._IAB_OMSDK_UPDATE_LAST_ACTIVITY));
	}

	protected boolean isRecordVideoViewEnabled() {
		return capabilities.getCapability(Constants._CAPABILITY_RECORD_VIDEO_VIEW) == IConstants.CapabilityStatus.ON;
	}
}
