package com.iab.omid.library.freewheeltv.devicevolume;

import static android.content.Context.AUDIO_SERVICE;
import static android.media.AudioManager.STREAM_MUSIC;
import static android.provider.Settings.System.CONTENT_URI;

import android.content.Context;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.os.Handler;

public final class DeviceVolumeObserver extends ContentObserver {

    private final Context context;
    private final AudioManager audioManager;
    private final DeviceVolumeConverter deviceVolumeConverter;
    private final DeviceVolumeListener deviceVolumeListener;

    private float storedDeviceVolume;

    public DeviceVolumeObserver(final Handler handler,
                                final Context context,
                                final DeviceVolumeConverter deviceVolumeConverter,
                                final DeviceVolumeListener deviceVolumeListener) {
        super(handler);

        this.context = context;
        this.audioManager = (AudioManager) context.getSystemService(AUDIO_SERVICE);
        this.deviceVolumeConverter = deviceVolumeConverter;
        this.deviceVolumeListener = deviceVolumeListener;
    }

    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);

        final float currentDeviceVolume = getDeviceVolume();
        if (hasDeviceVolumeChanged(currentDeviceVolume)) {
            storedDeviceVolume = currentDeviceVolume;
            notifyListenerOfDeviceVolume();
        }
    }

    public void start() {
        this.storedDeviceVolume = getDeviceVolume();
        notifyListenerOfDeviceVolume();

        context.getContentResolver().registerContentObserver(CONTENT_URI, true, this);
    }

    public void stop() {
        context.getContentResolver().unregisterContentObserver(this);
    }

    private float getDeviceVolume() {
        final int deviceVolume = audioManager.getStreamVolume(STREAM_MUSIC);
        final int maxVolume = audioManager.getStreamMaxVolume(STREAM_MUSIC);
        return deviceVolumeConverter.convertIntToFloat(deviceVolume, maxVolume);
    }

    private boolean hasDeviceVolumeChanged(final float currentDeviceVolume) {
        return currentDeviceVolume != storedDeviceVolume;
    }

    private void notifyListenerOfDeviceVolume() {
        deviceVolumeListener.onDeviceVolumeChanged(storedDeviceVolume);
    }

}
