package com.iab.omid.library.freewheeltv.adsession;

/**
 * Identifies which integration layer is responsible for sending certain events.
 * <p>
 * Created by pharris on 01/09/2017.
 */
public enum Owner {
    /**
     * The integration will send the event from the native layer.
     * Translates to "native" string when published to the OM SDK JS service.
     */
    NATIVE("native"),
    /**
     * The integration will send the event from a JavaScript session script.
     * Translates to "javascript" string when published to the OM SDK JS service.
     */
    JAVASCRIPT("javascript"),
    /** The integration will not send the event. */
    NONE("none");

    private final String owner;

    Owner(String owner) {
        this.owner = owner;
    }

    @Override
    public String toString() {
        return owner;
    }
}
