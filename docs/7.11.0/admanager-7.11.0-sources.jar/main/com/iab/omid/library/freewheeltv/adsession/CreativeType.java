package com.iab.omid.library.freewheeltv.adsession;

/**
 * List of supported creative types.
 */
public enum CreativeType {
    /**
     * Creative type will be set by JavaScript session script.
     */
    DEFINED_BY_JAVASCRIPT("definedByJavaScript"),
    // The following creative types are set by the native layer
    /**
     * Rendered in webview, verification code can be inside creative or in metadata.
     */
    HTML_DISPLAY("htmlDisplay"),
    /**
     * Rendered by native, verification code provided in metadata only.
     */
    NATIVE_DISPLAY("nativeDisplay"),
    /**
     * Rendered instream or as standalone video, verification code provided in metadata.
     */
    VIDEO("video"),
    /**
     * Similar to video but only contains audio media.
     */
    AUDIO("audio");

    private final String creativeType;

    CreativeType(String creativeType) {
        this.creativeType = creativeType;
    }

    @Override
    public String toString() {
        return creativeType;
    }

}
