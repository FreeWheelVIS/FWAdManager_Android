package com.iab.omid.library.freewheeltv.publisher;

import android.annotation.SuppressLint;
import android.webkit.WebView;

/**
 * Created by Natasha Garner on 16/08/2017.
 */
public class HtmlAdSessionStatePublisher extends AdSessionStatePublisher {

    @SuppressLint("SetJavaScriptEnabled")
    public HtmlAdSessionStatePublisher(String adSessionId, WebView webView) {
        super(adSessionId);
        if(webView != null && !webView.getSettings().getJavaScriptEnabled()) {
            webView.getSettings().setJavaScriptEnabled(true);
        }
        setWebView(webView);
    }
}
