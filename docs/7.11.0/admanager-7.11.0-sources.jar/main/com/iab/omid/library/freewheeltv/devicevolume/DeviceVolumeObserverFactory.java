package com.iab.omid.library.freewheeltv.devicevolume;

import android.content.Context;
import android.os.Handler;

public class DeviceVolumeObserverFactory {

    public DeviceVolumeObserver createNewInstance(final Handler handler,
                                                  final Context context,
                                                  final DeviceVolumeConverter deviceVolumeConverter,
                                                  final DeviceVolumeListener deviceVolumeListener) {
        return new DeviceVolumeObserver(handler, context, deviceVolumeConverter, deviceVolumeListener);
    }

}
