package com.iab.omid.library.freewheeltv.walking.async;

import androidx.annotation.VisibleForTesting;
import java.util.ArrayDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class OmidAsyncTaskQueue implements OmidAsyncTask.OmidAsyncTaskListener {

    private static final int THREAD_COUNT = 1;
    private static final int KEEP_ALIVE_TIME = 1;
    private final BlockingQueue<Runnable> workQueue;
    private final ThreadPoolExecutor threadPoolExecutor;

    private final ArrayDeque<OmidAsyncTask> pendingTasks = new ArrayDeque<>();
    private OmidAsyncTask currentTask = null;

    public OmidAsyncTaskQueue() {
        workQueue = new LinkedBlockingQueue<>();
        threadPoolExecutor = new ThreadPoolExecutor(THREAD_COUNT, THREAD_COUNT, KEEP_ALIVE_TIME, TimeUnit.SECONDS, workQueue);
    }

    public void submitTask(OmidAsyncTask task) {
        task.setListener(this);
        pendingTasks.add(task);
        if(currentTask == null) {
            executeNextTask();
        }
    }

    private void executeNextTask() {
        currentTask = pendingTasks.poll();
        if(currentTask != null) {
            currentTask.start(threadPoolExecutor);
        }
    }

    @Override
    public void onTaskCompleted(OmidAsyncTask task) {
        currentTask = null;
        executeNextTask();
    }

    @VisibleForTesting
    OmidAsyncTask getCurrentTask() {
        return currentTask;
    }

    @VisibleForTesting
    ArrayDeque<OmidAsyncTask> getPendingTasks() {
        return pendingTasks;
    }
}
