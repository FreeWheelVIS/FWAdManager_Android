package com.iab.omid.library.freewheeltv.utils;

import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_DEVICE_TYPE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_OS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_OS_VERSION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VALUE_START_OS;
import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;

import android.os.Build;
import org.json.JSONObject;

/**
 * Created by josevila on 2/26/18.
 */

public final class OmidDeviceInfoUtil {

    private OmidDeviceInfoUtil() {
    }

    public static String getDeviceType() {
        return Build.MANUFACTURER + "; " + Build.MODEL;
    }

    public static String getOsVersion() {
        return Integer.toString(Build.VERSION.SDK_INT);
    }

    public static String getOs() {
        return VALUE_START_OS;
    }

    public static JSONObject toJSON() {
        JSONObject deviceInfo = new JSONObject();
        jsonPut(deviceInfo, KEY_START_DEVICE_TYPE, OmidDeviceInfoUtil.getDeviceType());
        jsonPut(deviceInfo, KEY_START_OS_VERSION, OmidDeviceInfoUtil.getOsVersion());
        jsonPut(deviceInfo, KEY_START_OS, OmidDeviceInfoUtil.getOs());
        return deviceInfo;
    }
}
