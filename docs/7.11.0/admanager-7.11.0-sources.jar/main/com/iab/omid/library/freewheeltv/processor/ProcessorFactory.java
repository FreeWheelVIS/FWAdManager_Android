package com.iab.omid.library.freewheeltv.processor;

public class ProcessorFactory {

    private final ViewProcessor viewProcessor;
    private final ScreenProcessor screenProcessor;

	public ProcessorFactory() {
	    viewProcessor = new ViewProcessor();
        screenProcessor = new ScreenProcessor(viewProcessor);
    }

    public NodeProcessor getRootProcessor() {
        return screenProcessor;
    }
    public NodeProcessor getViewProcessor() { return viewProcessor; }
}
