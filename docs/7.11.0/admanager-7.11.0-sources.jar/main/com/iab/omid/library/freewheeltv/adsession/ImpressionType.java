package com.iab.omid.library.freewheeltv.adsession;

/**
 * The criterion for an ad session's OMID impression event.
 * Declaring an impression type makes it easier to understand discrepancies between measurers
 * of the ad session, since many metrics depend on impressions.
 */
public enum ImpressionType {
  /**
   * Impression type will be set by JavaScript session script.
   */
  DEFINED_BY_JAVASCRIPT("definedByJavaScript"),
  // Remaining values set impression type in native layer.
  /**
   * The integration is not declaring the criteria for the OMID impression. This is the
   * default impression type for OMID 1.2 and for integrations that don't set an impression type.
   */
  UNSPECIFIED("unspecified"),
  /**
   * The integration is using count-on-download criteria for the OMID impression.
   */
  LOADED("loaded"),
  /**
   * The integration is using begin-to-render criteria for the OMID impression.
   */
  BEGIN_TO_RENDER("beginToRender"),
  /**
   * The integration is using one-pixel criteria (when the creative has at least 1 visible
   * pixel on screen) for the OMID impression.
   */
  ONE_PIXEL("onePixel"),
  /**
   * The integration is using viewable criteria (1 second for display, 2 seconds while playing
   * for video, and at least 50% of the creative is visible) for the OMID impression.
   */
  VIEWABLE("viewable"),
  /**
   * The integration is using audible criteria (2 continuous second of media playback with
   * non-zero volume) for the OMID impression.
   */
  AUDIBLE("audible"),
  /**
   * The integration's criteria uses none of the above criteria for the OMID impression.
   */
  OTHER("other");

  private final String impressionType;

  ImpressionType(String impressionType) {
    this.impressionType = impressionType;
  }

  @Override
  public String toString() {
    return impressionType;
  }
}
