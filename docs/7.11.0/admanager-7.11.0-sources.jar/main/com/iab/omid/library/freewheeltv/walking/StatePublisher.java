package com.iab.omid.library.freewheeltv.walking;

import android.util.Log;

import androidx.annotation.VisibleForTesting;
import com.iab.omid.library.freewheeltv.walking.async.OmidAsyncTask;
import com.iab.omid.library.freewheeltv.walking.async.OmidAsyncTaskQueue;
import com.iab.omid.library.freewheeltv.walking.async.OmidCleanupAsyncTask;
import com.iab.omid.library.freewheeltv.walking.async.OmidEmptyPublishAsyncTask;
import com.iab.omid.library.freewheeltv.walking.async.OmidPublishAsyncTask;
import java.util.HashSet;
import org.json.JSONObject;

public class StatePublisher implements OmidAsyncTask.StateProvider {

    private JSONObject previousState;
    private final OmidAsyncTaskQueue taskQueue;


    public StatePublisher(OmidAsyncTaskQueue taskQueue) {
        this.taskQueue = taskQueue;
    }

    public void publishState(JSONObject state, HashSet<String> sessionIds, long timestamp) {
        // Currently only called from TreeWalker.doWalk which is on UI already so new AsyncTask()
        // will be called on UI thread as required
        taskQueue.submitTask(new OmidPublishAsyncTask(this, sessionIds, state, timestamp));
    }

    public void publishEmptyState(JSONObject emptyState, HashSet<String> sessionIds, long timestamp) {
        // Currently only called from TreeWalker.doWalk which is on UI already so new AsyncTask()
        // will be called on UI thread as required
        taskQueue.submitTask(new OmidEmptyPublishAsyncTask(this, sessionIds, emptyState, timestamp));
    }

    public void cleanupCache() {
        // Currently only called from TreeWalker.doWalk which is on UI already and
        // TreeWalker.stop() which puts it onto the UI thread so new AsyncTask()
        // will be called on UI thread as required
        taskQueue.submitTask(new OmidCleanupAsyncTask(this));
    }

    @VisibleForTesting
    public JSONObject getPreviousState() {
        return previousState;
    }

    @VisibleForTesting
    public void setPreviousState(JSONObject previousState) {
        this.previousState = previousState;
    }

}
