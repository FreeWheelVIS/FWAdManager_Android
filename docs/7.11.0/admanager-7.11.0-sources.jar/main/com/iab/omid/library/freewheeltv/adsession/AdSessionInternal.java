package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_FINISHED;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_MESSAGE_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_TYPE_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotEmpty;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.iab.omid.library.freewheeltv.internal.ActivityMonitor;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import com.iab.omid.library.freewheeltv.internal.Errors;
import com.iab.omid.library.freewheeltv.internal.FriendlyObstruction;
import com.iab.omid.library.freewheeltv.internal.FriendlyObstructions;
import com.iab.omid.library.freewheeltv.internal.OmidManager;
import com.iab.omid.library.freewheeltv.publisher.AdSessionStatePublisher;
import com.iab.omid.library.freewheeltv.publisher.HtmlAdSessionStatePublisher;
import com.iab.omid.library.freewheeltv.publisher.NativeAdSessionStatePublisher;
import com.iab.omid.library.freewheeltv.weakreference.WeakView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import org.json.JSONObject;

/**
 * For OM SDK internal use only.
 * <p>
 * Created by Natasha Garner on 03/08/2017.
 */
public class AdSessionInternal extends AdSession {

    private final AdSessionContext adSessionContext;
    private final AdSessionConfiguration adSessionConfiguration;
    private final FriendlyObstructions friendlyObstructions = new FriendlyObstructions();
    private WeakView weakAdView;
    private AdSessionStatePublisher adSessionStatePublisher;

    private boolean isStarted = false;
    private boolean isFinished = false;

    private final String adSessionId;
    private boolean impressionSent;
    private boolean loadedSent;

    private PossibleObstructionListener possibleObstructionListener;

    AdSessionInternal(final AdSessionConfiguration adSessionConfiguration,
                      final AdSessionContext adSessionContext) {
        this(adSessionConfiguration, adSessionContext, UUID.randomUUID().toString());
    }

    AdSessionInternal(final AdSessionConfiguration adSessionConfiguration,
                      final AdSessionContext adSessionContext,
                      final String adSessionId) {
        this.adSessionConfiguration = adSessionConfiguration;
        this.adSessionContext = adSessionContext;
        this.adSessionId = adSessionId;
        setAdView(null);
        if(adSessionContext.getAdSessionContextType() == AdSessionContextType.HTML
            || adSessionContext.getAdSessionContextType() == AdSessionContextType.JAVASCRIPT) {
            adSessionStatePublisher = new HtmlAdSessionStatePublisher(
                adSessionId,
                adSessionContext.getWebView());
        }
        else {
            // Setup for AdSessionContextType.NATIVE
            adSessionStatePublisher = new NativeAdSessionStatePublisher(
                adSessionId,
                adSessionContext.getInjectedResourcesMap(),
                adSessionContext.getOmidJsScriptContent());
        }

        // Call start on the publisher to create the tracking WebView if necessary
        adSessionStatePublisher.start();
        AdSessionRegistry.getInstance().adSessionCreated(this);
        adSessionStatePublisher.publishInitEvent(adSessionConfiguration);
    }

    /**
     * Notify all verification providers that the ad session has started and ad view tracking will
     * begin.
     * This method will have no effect if called after the ad session has finished.
     */
    @Override
    public void start() {
        if(isStarted || adSessionStatePublisher == null) {
            return;
        }
        isStarted = true;

        AdSessionRegistry.getInstance().adSessionStarted(this);

        final float deviceVolume = OmidManager.getInstance().getDeviceVolume();
        adSessionStatePublisher.setDeviceVolume(deviceVolume);
        adSessionStatePublisher.publishLastActivity(ActivityMonitor.getInstance().getLastActivityDate());
        adSessionStatePublisher.publishStartEvent(this, adSessionContext);
    }

    /**
     * Notify all verification providers that an error has occurred on the ad session.
     *
     * @param errorType of the reported error
     * @param message   containing details of the reported error
     * @throws IllegalArgumentException if the supplied error type is either null.
     * @throws IllegalArgumentException if the supplied message is either null or blank.
     * @throws IllegalStateException    if the ad session has finished.
     */
    @Override
    public void error(final ErrorType errorType, final String message) {
        if(isFinished) {
            throw new IllegalStateException(ERROR_ADSESSION_FINISHED);
        }
        confirmNotNull(errorType, ERROR_TYPE_NULL);
        confirmNotEmpty(message, ERROR_MESSAGE_NULL);
        getAdSessionStatePublisher().publishError(errorType, message);
    }

    /**
     * Register ad view to be used for tracking viewability. This method should be called each time
     * the ad view to track changes - i.e. two-part expandable. If an ad view is already registered
     * for the current session, that ad view will be automatically unregistered and the new ad view
     * will be registered in its place.
     * If the ad view being registered has been previously registered with a different ad session,
     * then the ad view will be automatically unregistered from those previously registered ad sessions.
     * This method will have no effect if called after the ad session has finished.
     *
     * @param adView the native view which should be registered for viewability tracking.
     */
    @Override
    public void registerAdView(final @Nullable View adView) {
        if(isFinished) {
            return;
        }
        if(getAdView() == adView) {
            return;
        }

        setAdView(adView);
        getAdSessionStatePublisher().cleanupAdState();
        removeViewFromRegistrySessions(adView);
    }

    /**
     * Notify all verification providers that the ad session has finished and all ad view tracking
     * will stop.
     * This method will have no effect if called after the ad session has finished.
     */
    @Override
    public void finish() {
        if(isFinished) {
            return;
        }
        weakAdView.clear();
        removeAllFriendlyObstructions();
        isFinished = true;
        getAdSessionStatePublisher().publishFinishEvent();
        AdSessionRegistry.getInstance().adSessionFinished(this);
        getAdSessionStatePublisher().finish();
        this.adSessionStatePublisher = null;
        this.possibleObstructionListener = null;
    }

    /**
     * Add friendly obstruction which should then be excluded from all ad session viewability
     * calculations.
     * This method will have no effect if called after the ad session has finished.
     *
     * @param friendlyObstruction to be excluded from all ad session viewability calculations.
     * @param purpose             why this obstruction was necessary
     * @param detailedReason      an explanation for why this obstruction is part of the ad experience if
     *                            not already obvious from the {@link FriendlyObstructionPurpose} selected.
     *                            Must be 50 characters or less and only contain characters `A-z`,`0-9` or space.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     * @throws IllegalArgumentException if the detailedReason is over 50 characters or contains a
     *                                  character that is not in `A-z`,`0-9` or a space.
     */
    @Override
    public void addFriendlyObstruction(final View friendlyObstruction,
                                       final FriendlyObstructionPurpose purpose,
                                       final @Nullable String detailedReason) {
        if (isFinished) {
            return;
        }
        friendlyObstructions.add(friendlyObstruction, purpose, detailedReason);
    }

    /**
     * Remove registered friendly obstruction.
     * This method will have no effect if called after the ad session has finished.
     *
     * @param friendlyObstructionView to be removed from the list of registered friendly obstructions.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     */
    @Override
    public void removeFriendlyObstruction(final View friendlyObstructionView) {
        if(isFinished) {
            return;
        }
        friendlyObstructions.remove(friendlyObstructionView);
    }

    /**
     * Utility method to remove all registered friendly obstructions.
     * This method will have no effect if called after the ad session has finished.
     */
    @Override
    public void removeAllFriendlyObstructions() {
        if(isFinished) {
            return;
        }
        friendlyObstructions.removeAll();
    }

    public List<FriendlyObstruction> getAllFriendlyObstructions() {
        return friendlyObstructions.getAll();
    }

    @Override
    public void setPossibleObstructionListener(PossibleObstructionListener possibleObstructionListener) {
        this.possibleObstructionListener = possibleObstructionListener;
    }

    public boolean hasPossibleObstructionListener() {
        return (this.possibleObstructionListener != null);
    }

    public void reportPossibleObstructions(List<WeakView> possiblyObstructingViews) {
        if (hasPossibleObstructionListener()) {
            List<View> nonNullPossiblyObstructingViews = new ArrayList<>();
            for (WeakView weakView : possiblyObstructingViews) {
                View possiblyObstructingView = weakView.get();
                if (possiblyObstructingView != null) {
                    nonNullPossiblyObstructingViews.add(possiblyObstructingView);
                }
            }
            this.possibleObstructionListener.onPossibleObstructionsDetected(adSessionId, nonNullPossiblyObstructingViews);
        }
    }

    /**
     * Call to send an impression event. Note: package scope, prefer calling {@link AdEvents#impressionOccurred()} instead.
     * @throws IllegalStateException if the impression event has already been published
     */
    void publishImpressionEvent() {
        confirmImpressionNotSent();
        getAdSessionStatePublisher().publishImpressionEvent();
        impressionSent = true;
    }

    private void confirmImpressionNotSent() {
        if (impressionSent) {
            throw new IllegalStateException(Errors.ERROR_IMPRESSION_ALREADY_SENT);
        }
    }

    /**
     * Call to send display loaded event.
     *
     * @throws IllegalStateException if the loaded event has already been published
     * Note: package scope, prefer calling
     * {@link AdEvents#loaded()} instead.
     */
    void publishLoadedEvent() {
        confirmLoadedNotSent();
        getAdSessionStatePublisher().publishLoadedEvent();
        loadedSent = true;
    }

    /**
     * Call to send video/audio loaded event.
     *
     * @param vastData contains static information about video/audio placement.
     * @throws IllegalStateException if the loaded event has already been published
     * Note: package scope, prefer calling
     * {@link AdEvents#loaded(com.iab.omid.library.freewheeltv.adsession.media.VastProperties vastProperties)}
     * instead.
     */
    void publishLoadedEvent(@NonNull final JSONObject vastData) {
        confirmLoadedNotSent();
        getAdSessionStatePublisher().publishLoadedEvent(vastData);
        loadedSent = true;
    }

    private void confirmLoadedNotSent() {
        if (loadedSent) {
            throw new IllegalStateException(Errors.ERROR_LOADED_ALREADY_SENT);
        }
    }

    public AdSessionStatePublisher getAdSessionStatePublisher() {
        return adSessionStatePublisher;
    }

    public String getAdSessionId() {
        return adSessionId;
    }

    public View getAdView() {
        return weakAdView.get();
    }

    // This must remain private to prevent inadvertent use
    private void setAdView(@Nullable View adView) {
        this.weakAdView = new WeakView(adView);
    }

    public boolean isActive() {
        return isStarted && !isFinished;
    }

    public boolean isStarted() {
        return isStarted;
    }

    public boolean isFinished() {
        return isFinished;
    }

    @VisibleForTesting
    boolean impressionSent() {
        return impressionSent;
    }

    private void removeViewFromRegistrySessions(@Nullable View view) {
        Collection<AdSessionInternal> adSessions = AdSessionRegistry.getInstance().getAdSessions();
        if(adSessions != null && !adSessions.isEmpty()) {
            for(AdSessionInternal adSession : adSessions) {
                if(adSession != this && adSession.getAdView() == view) {
                    adSession.weakAdView.clear();
                }
            }
        }
    }

    public boolean isNativeImpressionOwner() {
        return adSessionConfiguration.isNativeImpressionOwner();
    }

    public boolean isNativeMediaEventsOwner() {
        return adSessionConfiguration.isNativeMediaEventsOwner();
    }

    @VisibleForTesting
    AdSessionContext getAdSessionContext() {
        return adSessionContext;
    }
}
