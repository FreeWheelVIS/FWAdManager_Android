package com.iab.omid.library.freewheeltv.internal;

import android.view.View;
import androidx.annotation.Nullable;
import com.iab.omid.library.freewheeltv.adsession.FriendlyObstructionPurpose;
import com.iab.omid.library.freewheeltv.weakreference.WeakView;

/**
 * Friendly obstruction data class. This class does not override the equals and hashCode methods
 * since the obstructionView property is a WeakReference object that can change over time.
 * <p>
 * Created by Noam Schaap on 03/21/2019.
 */
public class FriendlyObstruction {

    private final WeakView obstructionView;
    private final String obstructionViewClass;
    private final FriendlyObstructionPurpose obstructionPurpose;
    private final String obstructionDetailedReason;

    public FriendlyObstruction(final View friendlyObstruction,
                               final FriendlyObstructionPurpose purpose,
                               final @Nullable String detailedReason) {
        this.obstructionView = new WeakView(friendlyObstruction);
        this.obstructionViewClass = friendlyObstruction.getClass().getCanonicalName();
        this.obstructionPurpose = purpose;
        this.obstructionDetailedReason = detailedReason;
    }

    public WeakView getObstructionView() {
        return obstructionView;
    }

    public String getObstructionViewClass() {
        return obstructionViewClass;
    }

    public FriendlyObstructionPurpose getObstructionPurpose() {
        return obstructionPurpose;
    }

    public String getObstructionDetailedReason() {
        return obstructionDetailedReason;
    }

}
