package com.iab.omid.library.freewheeltv.utils;

import static android.content.Context.WINDOW_SERVICE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_AD_SESSION_ID;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_CHILD_VIEWS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_FRIENDLY_OBSTRUCTION_CLASS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_FRIENDLY_OBSTRUCTION_PURPOSE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_FRIENDLY_OBSTRUCTION_REASON;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_HAS_WINDOW_FOCUS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_HEIGHT;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_IS_FRIENDLY_OBSTRUCTION_FOR;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_IS_PICTURE_IN_PICTURE_ACTIVE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NO_OUTPUT_DEVICE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_REASON;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_WIDTH;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_X;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_Y;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Build;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.iab.omid.library.freewheeltv.adsession.OutputDeviceStatus;
import com.iab.omid.library.freewheeltv.internal.FriendlyObstruction;
import com.iab.omid.library.freewheeltv.walking.AdViewCache;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OmidJSONUtil {

    private static WindowManager windowManager = null;

    private static String[] KEYS = {KEY_STATE_X, KEY_STATE_Y, KEY_STATE_WIDTH, KEY_STATE_HEIGHT};

    static float density = Resources.getSystem().getDisplayMetrics().density;

    private static class Size {
        final float width;
        final float height;

        Size(float width, float height) {
            this.width = width;
            this.height = height;
        }
    }

    public static void init(Context context){
        if(context != null){
            density = context.getResources().getDisplayMetrics().density;
            windowManager = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        }
    }

    public static JSONObject createViewState(int x, int y, int width, int height) {
        JSONObject viewStateObject = new JSONObject();
        try {
            viewStateObject.put(KEY_STATE_X, pxToDp(x));
            viewStateObject.put(KEY_STATE_Y, pxToDp(y));
            viewStateObject.put(KEY_STATE_WIDTH, pxToDp(width));
            viewStateObject.put(KEY_STATE_HEIGHT, pxToDp(height));
        } catch (JSONException e) {
            OmidLogs.e("Error with creating viewStateObject", e);
        }
        return viewStateObject;
    }

    static float pxToDp(int px){
        return (px/density);
    }

    public static void jsonPut(JSONObject json, String name, Object value) {
        try {
            json.put(name, value);
        }
        catch(NullPointerException | JSONException e) {
            OmidLogs.e("JSONException during JSONObject.put for name ["+name+"]", e);
        }
    }

    public static void addAdSessionId(JSONObject state, String adSessionId) {
        try {
            state.put(KEY_STATE_AD_SESSION_ID, adSessionId);
        }
        catch(JSONException e) {
            OmidLogs.e("Error with setting ad session id", e);
        }
    }

    public static void addNotVisibleReason(JSONObject state, String notVisibleReason) {
        try {
            state.put(KEY_STATE_NOT_VISIBLE_REASON, notVisibleReason);
        }
        catch(JSONException e) {
            OmidLogs.e("Error with setting not visible reason", e);
        }
    }

    public static void addOutputDeviceStatus(JSONObject state, OutputDeviceStatus status) {
        boolean noOutputDevice = isOutputDeviceNotAttached(status);
        try {
            state.put(KEY_STATE_NO_OUTPUT_DEVICE, noOutputDevice);
        }
        catch(JSONException e) {
            OmidLogs.e("Error with setting output device status", e);
        }
    }

    public static void addHasWindowFocus(JSONObject state, Boolean hasWindowFocus) {
        try {
            state.put(KEY_STATE_HAS_WINDOW_FOCUS, hasWindowFocus);
        }
        catch(JSONException e) {
            OmidLogs.e("Error with setting has window focus", e);
        }
    }

    public static void addPipState(JSONObject state, Boolean isPictureInPictureActive) {
        if (isPictureInPictureActive) {
            try {
                state.put(KEY_STATE_IS_PICTURE_IN_PICTURE_ACTIVE, isPictureInPictureActive);
            }
            catch(JSONException e) {
                OmidLogs.e("Error with setting is picture-in-picture active", e);
            }
        }
    }

    public static void addFriendlyObstruction(JSONObject state, AdViewCache.FriendlyObstructionData friendlyObstructionData) {
        FriendlyObstruction friendlyObstruction = friendlyObstructionData.getFriendlyObstruction();
        JSONArray array = new JSONArray();
        List<String> sessionIds = friendlyObstructionData.getSessionIds();
        for (String sessionId : sessionIds) {
            array.put(sessionId);
        }
        try {
            state.put(KEY_STATE_IS_FRIENDLY_OBSTRUCTION_FOR, array);
            state.put(KEY_STATE_FRIENDLY_OBSTRUCTION_CLASS, friendlyObstruction.getObstructionViewClass());
            state.put(KEY_STATE_FRIENDLY_OBSTRUCTION_PURPOSE, friendlyObstruction.getObstructionPurpose());
            state.put(KEY_STATE_FRIENDLY_OBSTRUCTION_REASON, friendlyObstruction.getObstructionDetailedReason());
        } catch (JSONException e) {
            OmidLogs.e("Error with setting friendly obstruction", e);
        }
    }

    public static void addChildState(JSONObject state, JSONObject childState) {
        try {
            JSONArray children = state.optJSONArray(KEY_STATE_CHILD_VIEWS);
            if (children == null) {
                children = new JSONArray();
                state.put(KEY_STATE_CHILD_VIEWS, children);
            }
            children.put(childState);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to return screen size scaled to standard pixels.
     * Will get the screen size without subtracting any window decor, such as soft buttons.
     * Due to system limitations, this method can't use {@link android.view.Display#getRealSize(Point)}
     * for devices running below API level 17. As a workaround we determine the screen size by getting
     * the max height and width of all top level views. This approach would not work when an app is
     * in a multi-window state, however, since devices below API level 17 can't enter a multi-window state
     * this will not be an issue.
     *
     * @param state the currently calculated view hierarchy state, only needed for devices running
     *              below API level 17
     * @return screen width and screen height, will return Size(0,0) if the WindowManager is null,
     * or device API level is below 17 and there are no views in the current view hierarchy state
     */
    private static Size getScreenSize(JSONObject state) {
        float screenWidth = 0;
        float screenHeight = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            if (windowManager != null) {
                Point screenSize = new Point(0, 0);
                windowManager.getDefaultDisplay().getRealSize(screenSize);
                screenWidth = pxToDp(screenSize.x);
                screenHeight = pxToDp(screenSize.y);
            }
        } else {
            JSONArray children = state.optJSONArray(KEY_STATE_CHILD_VIEWS);
            if (children != null) {
                final int count = children.length();
                for (int i = 0; i < count; i++) {
                    JSONObject child = children.optJSONObject(i);
                    if (child != null) {
                        final double x = child.optDouble(KEY_STATE_X);
                        final double y = child.optDouble(KEY_STATE_Y);
                        final double w = child.optDouble(KEY_STATE_WIDTH);
                        final double h = child.optDouble(KEY_STATE_HEIGHT);
                        screenWidth = Math.max(screenWidth, (float)(x + w));
                        screenHeight = Math.max(screenHeight, (float)(y + h));
                    }
                }
            }
        }
        return new Size(screenWidth, screenHeight);
    }

    public static void setViewport(JSONObject state) {
        Size screenSize = getScreenSize(state);
        try {
            state.put(KEY_STATE_WIDTH, screenSize.width);
            state.put(KEY_STATE_HEIGHT, screenSize.height);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static boolean equalStates(@NonNull JSONObject state1, @Nullable JSONObject state2) {
        if(state1 == null && state2 == null) {
            return true;
        }
        if(state1 == null || state2 == null) {
            return false;
        }
        return compareRequiredDoubles(state1, state2)
                && compareSessionId(state1, state2)
                && compareNoOutputDevice(state1, state2)
                && compareHasWindowFocus(state1, state2)
                && compareFriendlySessionIds(state1, state2)
                && compareChildren(state1, state2);
    }

    private static boolean compareRequiredDoubles(JSONObject state1, JSONObject state2) {
        for(String key : KEYS) {
            if(state1.optDouble(key) != state2.optDouble(key)) {
                return false;
            }
        }
        return true;
    }

    private static boolean compareNoOutputDevice(JSONObject state1, JSONObject state2) {
        Boolean noOutputDevice1 = state1.optBoolean(KEY_STATE_NO_OUTPUT_DEVICE);
        Boolean noOutputDevice2 = state2.optBoolean(KEY_STATE_NO_OUTPUT_DEVICE);
        return noOutputDevice1.equals(noOutputDevice2);
    }

    private static boolean compareHasWindowFocus(JSONObject state1, JSONObject state2) {
        Boolean hasWindowFocus1 = state1.optBoolean(KEY_STATE_HAS_WINDOW_FOCUS);
        Boolean hasWindowFocus2 = state2.optBoolean(KEY_STATE_HAS_WINDOW_FOCUS);
        return hasWindowFocus1.equals(hasWindowFocus2);
    }

    private static boolean compareSessionId(JSONObject state1, JSONObject state2) {
        String id1 = state1.optString(KEY_STATE_AD_SESSION_ID, "");
        String id2 = state2.optString(KEY_STATE_AD_SESSION_ID, "");
        return id1.equals(id2);
    }

    private static boolean compareFriendlySessionIds(JSONObject state1, JSONObject state2) {
        final JSONArray friendlySessionIds1 = state1.optJSONArray(KEY_STATE_IS_FRIENDLY_OBSTRUCTION_FOR);
        final JSONArray friendlySessionIds2 = state2.optJSONArray(KEY_STATE_IS_FRIENDLY_OBSTRUCTION_FOR);
        if(friendlySessionIds1==null && friendlySessionIds2==null) {
            return true;
        }
        if(!compareJSONArrayLengths(friendlySessionIds1, friendlySessionIds2)) {
            return false;
        }
        for(int i = 0; i < friendlySessionIds1.length(); i++) {
            final String sessionId1 = friendlySessionIds1.optString(i, "");
            final String sessionId2 = friendlySessionIds2.optString(i, "");
            if(!sessionId1.equals(sessionId2)) {
                return false;
            }
        }
        return true;
    }

    private static boolean compareChildren(JSONObject state1, JSONObject state2) {
        final JSONArray children1 = state1.optJSONArray(KEY_STATE_CHILD_VIEWS);
        final JSONArray children2 = state2.optJSONArray(KEY_STATE_CHILD_VIEWS);
        if(children1==null && children2==null) {
            return true;
        }
        if(!compareJSONArrayLengths(children1, children2)) {
            return false;
        }
        for (int i = 0; i < children1.length(); i++) {
            JSONObject childState1 = children1.optJSONObject(i);
            JSONObject childState2 = children2.optJSONObject(i);
            if(!equalStates(childState1, childState2)) {
                return false;
            }
        }
        return true;
    }

    private static boolean compareJSONArrayLengths(JSONArray array1, JSONArray array2) {
        if(array1 == null && array2 == null) {
            return true;
        }
        if(array1 == null || array2 == null) {
            return false;
        }
        return array1.length() == array2.length();
    }

    private static boolean isOutputDeviceNotAttached(OutputDeviceStatus status) {
        switch (status) {
            case NOT_DETECTED:
                return true;
            default:
                return false;
        }
    }
}
