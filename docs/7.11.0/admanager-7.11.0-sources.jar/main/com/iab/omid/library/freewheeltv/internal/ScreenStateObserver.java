package com.iab.omid.library.freewheeltv.internal;

import android.annotation.SuppressLint;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;

import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;

import java.lang.ref.WeakReference;

public class ScreenStateObserver {

    @SuppressLint("StaticFieldLeak")	// only holds the app context
    private static ScreenStateObserver instance = new ScreenStateObserver();

    public ScreenStateObserver() {}

    public static ScreenStateObserver getInstance() { return instance; }

    private WeakReference<Context> appContext;
    private boolean isScreenOff = false;
    private boolean isScreenLocked = false;

    public void start(Context context) {
        if (context == null) {
            return;
        }
        appContext = new WeakReference<Context>(context);

        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);

        context.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                    publishScreenStateIfChanged(true, isScreenLocked);
                    isScreenOff = true;
                } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                    publishScreenStateIfChanged(false, isScreenLocked);
                    isScreenOff = false;
                }
            }
        }, intentFilter);
    }

    public void checkLockState() {
        // Listening to KeyguardManager.addKeyguardLockedStateListener requires
        // Manifest.permission.SUBSCRIBE_TO_KEYGUARD_LOCKED_STATE, but just checking on a loop
        // doesn't. So we're querying getApplicationContext.
        Context context = appContext.get();
        if (context == null) {
            return;
        }

        KeyguardManager km = (KeyguardManager)context.getSystemService(Context.KEYGUARD_SERVICE);

        boolean isScreenNowLocked;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            isScreenNowLocked = km.isDeviceLocked();
        } else {
            isScreenNowLocked = km.inKeyguardRestrictedInputMode();
        }

        publishScreenStateIfChanged(isScreenOff, isScreenNowLocked);
        isScreenLocked = isScreenNowLocked;
    }

    public void publishScreenStateIfChanged(boolean isOff, boolean isLocked) {
        // This code is expecting that the updated values for isScreenLocked and isScreenOff are set
        // immediately after this function is called
        if ((isLocked || isOff) == (isScreenLocked || isScreenOff)) {
            return;
        }
        for (final AdSessionInternal adSessionStatePublisher : AdSessionRegistry.getInstance().getAdSessions()) {
            adSessionStatePublisher.getAdSessionStatePublisher().setLockState(isLocked || isOff);
        }
    }
}
