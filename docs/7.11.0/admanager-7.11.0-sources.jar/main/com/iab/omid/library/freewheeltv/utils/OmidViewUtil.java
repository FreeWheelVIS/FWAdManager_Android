package com.iab.omid.library.freewheeltv.utils;


import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_NOT_ATTACHED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_VIEW_ALPHA_ZERO;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_VIEW_GONE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_VIEW_INVISIBLE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_VIEW_NOT_VISIBLE;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;

public final class OmidViewUtil {

    private OmidViewUtil() { }

    public static float getZ(View view) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            return view.getZ();
        }
        return 0.0f;
    }

    public static View getParentView(View view) {
        ViewParent parent = view.getParent();
        if(parent instanceof View) {
            return (View) parent;
        }
        return null;
    }

    public static boolean isViewTreeDisplayed(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && !view.isAttachedToWindow()) {
            return false;
        }
        // Checks visibility of the entire tree
        if(!view.isShown()) {
            return false;
        }

        View current = view;
        while(current != null) {
            if(current.getAlpha() == 0.0f) {
                return false;
            }
            current = getParentView(current);
        }
        return true;
    }

    public static Activity getActivity(View adView) {
        Context context = adView.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity)context;
            }
            context = ((ContextWrapper)context).getBaseContext();
        }
        return null;
    }

    public static boolean isContainingActivityInPiP(View adView) {
        boolean isInPip = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Activity activity = getActivity(adView);
            if (activity != null) {
                isInPip = activity.isInPictureInPictureMode();
            }
        }
        return isInPip;
    }

    public static boolean isViewDisplayed(View view) {
        String viewNotVisibleReason = checkViewNotVisibleReason(view);
        return viewNotVisibleReason == null;
    }

    public static String checkViewNotVisibleReason(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && !view.isAttachedToWindow()) {
            return KEY_STATE_NOT_VISIBLE_NOT_ATTACHED;
        }
        int visibility = view.getVisibility();
        if (visibility == View.GONE) {
            return KEY_STATE_NOT_VISIBLE_VIEW_GONE;
        }
        if (visibility == View.INVISIBLE) {
            return KEY_STATE_NOT_VISIBLE_VIEW_INVISIBLE;
        }
        if (visibility != View.VISIBLE) {
            // A generic reason for an unrecognized visibility value.
            return KEY_STATE_NOT_VISIBLE_VIEW_NOT_VISIBLE;
        }
        if (view.getAlpha() == 0.0f) {
            return KEY_STATE_NOT_VISIBLE_VIEW_ALPHA_ZERO;
        }
        // The view is visible as far as we can tell, so there is no reason.
        return null;
    }
}
