package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_NAME_NULL_OR_EMPTY;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_VERSION_NULL_OR_EMPTY;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotEmpty;

/**
 * Details about the integration partner which will be supplied to the ad session.
 * <p>
 * Created by Natasha Garner on 01/08/2017.
 */
public class Partner {

    private final String name;
    private final String version;

    private Partner(final String name, final String version) {
        this.name = name;
        this.version = version;
    }

    /**
     * Create new partner instance providing both name and version.
     * Both name and version are mandatory.
     *
     * @param name    used to uniquely identify the integration partner.
     * @param version used to uniquely identify the integration partner.
     * @return a new partner instance
     * @throws IllegalArgumentException if any of the parameters are either null or blank.
     */
    public static Partner createPartner(final String name, final String version) {
        confirmNotEmpty(name, ERROR_NAME_NULL_OR_EMPTY);
        confirmNotEmpty(version, ERROR_VERSION_NULL_OR_EMPTY);
        return new Partner(name, version);
    }

    public String getName() {
        return name;
    }

    public String getVersion() {
        return version;
    }
}
