package com.iab.omid.library.freewheeltv;


/**
 * Utility class which enables integration partners to use a standard approach for injecting OM SDK JS
 * into the served tag HTML content.
 * <p>
 */

public final class ScriptInjector {

    private ScriptInjector() { }

    /**
     * Injects the supplied OM SDK JS content into the served HTML.
     *
     * @param scriptContent containing the OM SDK JS service content to be injected into the hidden
     *                      tracking web view.
     * @param html          of the tag content which should be modified to include the downloaded
     *                      OM SDK JS content.
     * @return modified HTML to include the supplied OM SDK JS service.
     * @throws IllegalArgumentException if the supplied HTML is either null or blank.
     * @throws IllegalStateException    if this method has been executed before OM SDK has been
     * activated.
     * @throws IllegalStateException    if this method has been executed before OM SDK JS is available.
     */
    public static String injectScriptContentIntoHtml(final String scriptContent, final String html) {
        return ScriptInjectorInternal.injectScriptContentIntoHtml(scriptContent, html);
    }
}
