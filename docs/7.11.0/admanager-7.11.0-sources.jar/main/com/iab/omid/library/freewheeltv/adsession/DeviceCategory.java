package com.iab.omid.library.freewheeltv.adsession;

/**
 * List of supported device categories.
 */
public enum DeviceCategory {
  CTV("ctv"),
  MOBILE("mobile"),
  OTHER("other");

  private final String deviceCategory;

  DeviceCategory(String deviceCategory) {
    this.deviceCategory = deviceCategory;
  }

  @Override
  public String toString() {
    return deviceCategory;
  }
}
