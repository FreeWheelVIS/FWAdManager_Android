package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_RESOURCE_URL_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_VENDOR_KEY_NULL_OR_EMPTY;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_VERIFICATION_PARAMETERS_NULL_OR_EMPTY;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VERIFICATION_PARAMETERS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VERIFICATION_RESOURCE_URL;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VERIFICATION_VENDOR_KEY;
import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotEmpty;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import java.net.URL;
import org.json.JSONObject;

/**
 * Details about the verification provider which will be supplied to the ad session.
 * <p>
 * Created by Natasha Garner on 02/08/2017.
 */

public final class VerificationScriptResource {

    private final String vendorKey;
    private final URL resourceUrl;
    private final String verificationParameters;

    private VerificationScriptResource(final String vendorKey, final URL resourceUrl,
                                       final String verificationParameters) {
        this.vendorKey = vendorKey;
        this.resourceUrl = resourceUrl;
        this.verificationParameters = verificationParameters;
    }

    /**
     * Create new verification script resource instance which requires vendor specific verification
     * parameters.
     * When calling this method all arguments are mandatory.
     *
     * @param vendorKey              used to uniquely identify the verification provider.
     * @param resourceUrl            to be injected into the OM SDK managed JavaScript execution
     *                               environment.
     * @param verificationParameters which the verification provider script is expecting for the ad
     *                               session.
     * @return a new verification script resource instance
     * @throws IllegalArgumentException if any of the parameters are either null or blank.
     */
    public static VerificationScriptResource createVerificationScriptResourceWithParameters(
        final String vendorKey, final URL resourceUrl, final String verificationParameters) {

        confirmNotEmpty(vendorKey, ERROR_VENDOR_KEY_NULL_OR_EMPTY);
        confirmNotNull(resourceUrl, ERROR_RESOURCE_URL_NULL);
        confirmNotEmpty(verificationParameters, ERROR_VERIFICATION_PARAMETERS_NULL_OR_EMPTY);

        return new VerificationScriptResource(vendorKey, resourceUrl, verificationParameters);
    }

    /**
     * Create new verification script resource instance which does not require any vendor specific
     * verification parameters.
     * When calling this method all arguments are mandatory.
     *
     * @param resourceUrl to be injected into the OM SDK managed JavaScript execution environment.
     * @return a new verification script resource instance
     * @throws IllegalArgumentException if any of the parameters are either null or blank.
     */
    public static VerificationScriptResource createVerificationScriptResourceWithoutParameters(
        final URL resourceUrl) {

        confirmNotNull(resourceUrl, ERROR_RESOURCE_URL_NULL);
        return new VerificationScriptResource(null, resourceUrl, null);
    }

    public String getVendorKey() {
        return vendorKey;
    }

    public URL getResourceUrl() {
        return resourceUrl;
    }

    public String getVerificationParameters() {
        return verificationParameters;
    }

    /**
     * For OM SDK internal use only.
     */
    public JSONObject toJsonObject() {
        JSONObject json = new JSONObject();
        jsonPut(json, VERIFICATION_VENDOR_KEY, vendorKey);
        jsonPut(json, VERIFICATION_RESOURCE_URL, resourceUrl.toString());
        jsonPut(json, VERIFICATION_PARAMETERS, verificationParameters);
        return json;
    }
}
