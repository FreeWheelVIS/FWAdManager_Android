package com.iab.omid.library.freewheeltv.weakreference;

import android.view.View;
import java.lang.ref.WeakReference;

/**
 * Created by Natasha Garner on 18/08/2017.
 */
public class WeakView extends WeakReference<View> {
    public WeakView(View view) {
        super(view);
    }
}
