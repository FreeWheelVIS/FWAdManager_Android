package com.iab.omid.library.freewheeltv.walking.async;

public class OmidCleanupAsyncTask extends OmidAsyncTask {

    public OmidCleanupAsyncTask(StateProvider stateProvider) {
        super(stateProvider);
    }

    @Override
    protected String doInBackground(Object... params) {
        stateProvider.setPreviousState(null);
        return null;
    }
}
