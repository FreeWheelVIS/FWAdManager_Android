package com.iab.omid.library.freewheeltv.walking.async;

import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import java.util.HashSet;
import org.json.JSONObject;

public class OmidEmptyPublishAsyncTask extends AbstractOmidPublishAsyncTask {

    public OmidEmptyPublishAsyncTask(StateProvider stateProvider, HashSet<String> sessionIds,
                                     JSONObject state, long timestamp) {
        super(stateProvider, sessionIds, state, timestamp);
    }

    @Override
    protected String doInBackground(Object... params) {
        return state.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        injectCommand(result);
        super.onPostExecute(result);
    }

    private void injectCommand(String command) {
        AdSessionRegistry registry = AdSessionRegistry.getInstance();
        if(registry!=null) {
            for (AdSessionInternal adSession : registry.getAdSessions()) {
                if (sessionIds.contains(adSession.getAdSessionId())) {
                    adSession.getAdSessionStatePublisher().publishEmptyNativeViewStateCommand(command,
                        timestamp);
                }
            }
        }
    }
}
