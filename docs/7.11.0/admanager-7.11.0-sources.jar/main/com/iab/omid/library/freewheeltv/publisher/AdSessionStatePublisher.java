package com.iab.omid.library.freewheeltv.publisher;

import static com.iab.omid.library.freewheeltv.internal.OmidBridge.APP_STATE_BACKGROUNDED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.APP_STATE_FOREGROUNDED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_AD_SESSION_TYPE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_APP;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_APP_ID;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_APP_LIBRARY_VERSION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_CONTENT_URL;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_CUSTOM_REFERENCE_DATA;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_DEVICE_INFO;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_DEVICE_CATEGORY;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_ENVIRONMENT;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_OMID_NATIVE_INFO;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_OMID_NATIVE_INFO_NAME;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_OMID_NATIVE_INFO_VERSION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_SUPPORTS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_SUPPORTS_CLID;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_START_SUPPORTS_VLID;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_TIMESTAMP;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.LOCK_STATE_LOCKED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.LOCK_STATE_UNLOCKED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VALUE_START_APP;
import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;

import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import tv.freewheel.ad.BuildConfig;
import com.iab.omid.library.freewheeltv.adsession.AdEvents;
import com.iab.omid.library.freewheeltv.adsession.AdSessionConfiguration;
import com.iab.omid.library.freewheeltv.adsession.AdSessionContext;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.adsession.ErrorType;
import com.iab.omid.library.freewheeltv.adsession.VerificationScriptResource;
import com.iab.omid.library.freewheeltv.adsession.media.MediaEvents;
import com.iab.omid.library.freewheeltv.internal.InstanceManager;
import com.iab.omid.library.freewheeltv.internal.OmidBridge;
import com.iab.omid.library.freewheeltv.utils.OmidDeviceCategoryUtil;
import com.iab.omid.library.freewheeltv.utils.OmidDeviceInfoUtil;
import com.iab.omid.library.freewheeltv.utils.OmidTimestamp;
import com.iab.omid.library.freewheeltv.weakreference.WeakWebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Date;

/**
 * Created by Natasha Garner on 16/08/2017.
 */
public abstract class AdSessionStatePublisher {

    enum AdState {
        AD_STATE_IDLE,
        AD_STATE_VISIBLE,
        AD_STATE_NOTVISIBLE
    }

    private String adSessionId;
    private WeakWebView weakWebView;
    private AdEvents adEvents;
    private MediaEvents mediaEvents;

    private AdState adState;
    private long lastUpdated;

    public AdSessionStatePublisher(String adSessionId) {
        cleanupAdState();
        this.adSessionId = adSessionId;
        weakWebView = new WeakWebView(null);
    }

    public void start() { }

    public void finish() {
        weakWebView.clear();
    }

    void setWebView(WebView webView) {
        weakWebView = new WeakWebView(webView);
    }

    public WebView getWebView() {
        return weakWebView.get();
    }

    public AdEvents getAdEvents() {
        return adEvents;
    }

    public void setAdEvents(AdEvents adEvents) {
        this.adEvents = adEvents;
    }

    public MediaEvents getMediaEvents() {
        return mediaEvents;
    }

    public void setMediaEvents(MediaEvents mediaEvents) {
        this.mediaEvents = mediaEvents;
    }

    public boolean isAdViewRegistered() {
        return weakWebView.get() != null;
    }

    public void setAppState(boolean isForegrounded) {
        if(isAdViewRegistered()) {
            final String appState = isForegrounded ? APP_STATE_FOREGROUNDED : APP_STATE_BACKGROUNDED;
            OmidBridge.getInstance().callSetState(getWebView(), adSessionId, appState);
        }
    }

    public void setLockState(boolean isLocked) {
        if (isAdViewRegistered()) {
            final String lockState = isLocked ? LOCK_STATE_LOCKED : LOCK_STATE_UNLOCKED;
            OmidBridge.getInstance().callSetLockState(getWebView(), adSessionId, lockState);
        }
    }

    public void publishNativeViewStateCommand(String viewState, long timestamp) {
        if(timestamp >= lastUpdated) {
            adState = AdState.AD_STATE_VISIBLE;
            OmidBridge.getInstance().callSetNativeViewHierarchy(getWebView(), adSessionId,
                    viewState);
        }
    }

    public void publishEmptyNativeViewStateCommand(String viewState, long timestamp) {
        if(timestamp >= lastUpdated && adState != AdState.AD_STATE_NOTVISIBLE) {
            adState = AdState.AD_STATE_NOTVISIBLE;
            OmidBridge.getInstance().callSetNativeViewHierarchy(getWebView(), adSessionId,
                    viewState);
        }
    }

    public void publishInitEvent(final AdSessionConfiguration adSessionConfiguration) {
        OmidBridge.getInstance().callInit(getWebView(), adSessionId,
                adSessionConfiguration.toJsonObject());
    }

    public void publishStartEvent(AdSessionInternal adSession, AdSessionContext adSessionContext) {
        publishStartEventInternal(adSession, adSessionContext, null);
    }

    protected void publishStartEventInternal(AdSessionInternal adSession,
            AdSessionContext adSessionContext, JSONObject injectedResources) {
        String adSessionId = adSession.getAdSessionId();
        JSONObject nativeContext = new JSONObject();
        jsonPut(nativeContext, KEY_START_ENVIRONMENT, VALUE_START_APP);
        jsonPut(nativeContext, KEY_START_AD_SESSION_TYPE, adSessionContext.getAdSessionContextType());
        jsonPut(nativeContext, KEY_START_DEVICE_INFO, OmidDeviceInfoUtil.toJSON());
        jsonPut(nativeContext, KEY_START_DEVICE_CATEGORY, OmidDeviceCategoryUtil.getDeviceCategory().toString());
        JSONArray supports = new JSONArray();
        supports.put(KEY_START_SUPPORTS_CLID);
        supports.put(KEY_START_SUPPORTS_VLID);
        jsonPut(nativeContext, KEY_START_SUPPORTS, supports);
        JSONObject omidNativeInfo = new JSONObject();
        jsonPut(omidNativeInfo, KEY_START_OMID_NATIVE_INFO_NAME, adSessionContext.getPartner().getName());
        jsonPut(omidNativeInfo, KEY_START_OMID_NATIVE_INFO_VERSION, adSessionContext.getPartner().getVersion());
        jsonPut(nativeContext, KEY_START_OMID_NATIVE_INFO, omidNativeInfo);
        JSONObject app = new JSONObject();
        jsonPut(app, KEY_START_APP_LIBRARY_VERSION, BuildConfig.VERSION_NAME + "-" + BuildConfig.PARTNER_NAME);
        String applicationId =
            InstanceManager.getInstance().getContext().getApplicationContext().getPackageName();
        jsonPut(app, KEY_START_APP_ID, applicationId);
        jsonPut(nativeContext, KEY_START_APP, app);
        if(adSessionContext.getContentUrl() != null) {
            jsonPut(nativeContext, KEY_START_CONTENT_URL, adSessionContext.getContentUrl());
        }
        if(adSessionContext.getCustomReferenceData() != null) {
            jsonPut(nativeContext, KEY_START_CUSTOM_REFERENCE_DATA,
                adSessionContext.getCustomReferenceData());
        }

        JSONObject verificationParameters = new JSONObject();
        for(VerificationScriptResource resource : adSessionContext.getVerificationScriptResources()) {
            jsonPut(verificationParameters, resource.getVendorKey(), resource.getVerificationParameters());
        }
        OmidBridge.getInstance().callStartSession(getWebView(), adSessionId, nativeContext,
                verificationParameters, injectedResources);
    }

    public void publishFinishEvent() {
        OmidBridge.getInstance().callFinishSession(getWebView(), adSessionId);
    }

    public void publishError(ErrorType errorType, String message) {
        OmidBridge.getInstance().callError(getWebView(), adSessionId, errorType, message);
    }

    public void publishImpressionEvent() {
        OmidBridge.getInstance().callPublishImpressionEvent(getWebView(), adSessionId);
    }

    public void publishLoadedEvent() {
        publishLoadedEvent(null);
    }

    public void publishLoadedEvent(@Nullable JSONObject vastData) {
        OmidBridge.getInstance().callPublishLoadedEvent(getWebView(), adSessionId, vastData);
    }

    public void publishMediaEvent(String type) {
        publishMediaEvent(type, null);
    }

    public void publishMediaEvent(String type, @Nullable JSONObject data) {
        OmidBridge.getInstance().callPublishMediaEvent(getWebView(), adSessionId, type, data);
    }

    public void publishLastActivity(@NonNull Date lastActivityDate) {
        if (lastActivityDate == null) { return; }
        JSONObject activityData = new JSONObject();
        jsonPut(activityData, KEY_TIMESTAMP, lastActivityDate.getTime());
        OmidBridge.getInstance().callSetLastActivity(getWebView(), activityData);
    }

    public void setDeviceVolume(final float deviceVolume) {
        OmidBridge.getInstance().callSetDeviceVolume(getWebView(), adSessionId, deviceVolume);
    }

    public void cleanupAdState() {
        lastUpdated = OmidTimestamp.getCurrentTime();
        adState = AdState.AD_STATE_IDLE;
    }

    @VisibleForTesting
    AdState getAdState() {
        return adState;
    }

    @VisibleForTesting
    long getLastUpdated() {
        return lastUpdated;
    }
}
