package com.iab.omid.library.freewheeltv.utils;

import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.webkit.WebViewCompat;

import java.util.Set;

/**
 * Utility class wrapping built-in WebView-related functionality to make it easier to unit test.
 */
public class OmidWebViewUtil {
    public void addWebMessageListener(@NonNull WebView webView, @NonNull String jsObjectName,
                                      @NonNull Set<String> allowedOriginRules,
                                      @NonNull WebViewCompat.WebMessageListener listener) {
        WebViewCompat.addWebMessageListener(webView, jsObjectName, allowedOriginRules, listener);
    }

    public void removeWebMessageListener(@NonNull WebView webView, @NonNull String jsObjectName) {
        WebViewCompat.removeWebMessageListener(webView, jsObjectName);
    }
}
