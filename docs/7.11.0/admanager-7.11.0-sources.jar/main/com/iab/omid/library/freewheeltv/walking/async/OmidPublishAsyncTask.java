package com.iab.omid.library.freewheeltv.walking.async;

import android.text.TextUtils;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import com.iab.omid.library.freewheeltv.utils.OmidJSONUtil;
import java.util.HashSet;
import org.json.JSONObject;

public class OmidPublishAsyncTask extends AbstractOmidPublishAsyncTask {

    public OmidPublishAsyncTask(StateProvider stateProvider, HashSet<String> sessionIds,
                                JSONObject state, long timestamp) {
        super(stateProvider, sessionIds, state, timestamp);
    }

    @Override
    protected String doInBackground(Object... params) {
        if (OmidJSONUtil.equalStates(state, stateProvider.getPreviousState())) {
            return null;
        }
        stateProvider.setPreviousState(state);
        return state.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        if (!TextUtils.isEmpty(result)) {
            injectCommand(result);
        }
        super.onPostExecute(result);
    }

    private void injectCommand(String command) {
        AdSessionRegistry registry = AdSessionRegistry.getInstance();
        if(registry!=null) {
            for (AdSessionInternal adSession : registry.getAdSessions()) {
                if (sessionIds.contains(adSession.getAdSessionId())) {
                    adSession.getAdSessionStatePublisher().publishNativeViewStateCommand(command,
                        timestamp);
                }
            }
        }
    }
}
