package com.iab.omid.library.freewheeltv.adsession;

import android.view.View;
import java.util.List;

public interface PossibleObstructionListener {
    void onPossibleObstructionsDetected(String adSessionId, List<View> possiblyObstructingViews);
}
