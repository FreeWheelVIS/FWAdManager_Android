package com.iab.omid.library.freewheeltv.devicevolume;

public class DeviceVolumeConverter {

    public float convertIntToFloat(final int deviceVolume, final int maxVolume) {
        if(maxVolume <= 0 || deviceVolume <= 0) {
            return 0.0f;
        }

        float volume = ((float) deviceVolume) / maxVolume;
        if(volume > 1.0f) {
            volume = 1.0f;
        }

        return volume;
    }

}
