package com.iab.omid.library.freewheeltv.processor;

import android.annotation.TargetApi;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import com.iab.omid.library.freewheeltv.utils.OmidJSONUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.json.JSONObject;

public class ViewProcessor implements NodeProcessor {

    private final int[] xyAxisCoordinates = new int[2];

    @Override
    public JSONObject getState(View view) {
        if(view == null) {
            return OmidJSONUtil.createViewState(0, 0, 0, 0);
        }
        final int width = view.getWidth();
        final int height = view.getHeight();
        view.getLocationOnScreen(xyAxisCoordinates);
        return OmidJSONUtil.createViewState(xyAxisCoordinates[0], xyAxisCoordinates[1], width,
            height);
    }

    @Override
    public void iterateChildren(View view, JSONObject viewState, ViewWalker walker, boolean sortByZ, boolean hasFriendlyObstructionAncestor) {
        if(!(view instanceof ViewGroup)) {
            return;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        if(!sortByZ || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            iterateChildren(viewGroup, viewState, walker, hasFriendlyObstructionAncestor);
        } else {
            sortAndIterateChildren(viewGroup, viewState, walker, hasFriendlyObstructionAncestor);
        }
    }

    private void iterateChildren(ViewGroup viewGroup, JSONObject viewState, ViewWalker walker, boolean hasFriendlyObstructionAncestor) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View childView = viewGroup.getChildAt(i);
            walker.walkView(childView, this, viewState, hasFriendlyObstructionAncestor);
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void sortAndIterateChildren(ViewGroup viewGroup, JSONObject viewState, ViewWalker walker, boolean hasFriendlyObstructionAncestor) {
        HashMap<Float, ArrayList<View>> map = new HashMap<>();
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View view = viewGroup.getChildAt(i);
            ArrayList<View> list = map.get(view.getZ());
            if(list == null) {
                list = new ArrayList<>();
                map.put(view.getZ(), list);
            }
            list.add(view);
        }
        ArrayList<Float> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        for (Float key : keys) {
            ArrayList<View> children = map.get(key);
            for (View childView : children) {
                walker.walkView(childView, this, viewState, hasFriendlyObstructionAncestor);
            }
        }
    }
}
