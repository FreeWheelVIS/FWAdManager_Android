package com.iab.omid.library.freewheeltv.adsession;

/**
 * For OM SDK internal use only.
 * Status representing whether an output device capable of displaying the application (such as a TV
 * screen) may be connected to the device.
 */
public enum OutputDeviceStatus {
  /**
   * There is no relevant output device connected to the device.
   */
  NOT_DETECTED,
  /**
   * There may be a relevant output device connected to the device.
   */
  UNKNOWN,
}
