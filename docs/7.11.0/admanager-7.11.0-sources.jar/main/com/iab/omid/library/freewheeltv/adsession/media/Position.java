package com.iab.omid.library.freewheeltv.adsession.media;

/**
 * List of supported media player positions.
 * <p>
 * Created by Natasha Garner on 09/09/2017.
 */

public enum Position {
    /**
     * The ad plays preceding video content.
     */
    PREROLL("preroll"),
    /**
     * The ad plays in the middle of video content, or between two separate content videos.
     */
    MIDROLL("midroll"),
    /**
     * The ad plays following video content.
     */
    POSTROLL("postroll"),
    /**
     * The ad plays independently of any video content.
     */
    STANDALONE("standalone");

    private final String position;

    Position(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return position;
    }
}
