package com.iab.omid.library.freewheeltv;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_HTML_NULL_OR_EMPTY;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotEmpty;
import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static java.util.regex.Pattern.compile;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Utility class which enables integration partners to use a standard approach for injecting OM SDK JS
 * into the served tag HTML content.
 * <p>
 *
 * Created by Natasha Garner on 03/07/2017.
 */
class ScriptInjectorInternal {

    // Comment tags
    private static final String COMMENT_TAG_START = "<!--";
    private static final String COMMENT_TAG_END = "-->";

    // <head> tag patterns
    private static final Pattern HEAD_TAG_PATTERN = compile("<(head)( [^>]*)?>",
        CASE_INSENSITIVE);
    private static final Pattern HEAD_CLOSE_TAG_PATTERN = compile("<(head)( [^>]*)?/>",
        CASE_INSENSITIVE);
    // <body> tag patterns
    private static final Pattern BODY_TAG_PATTERN = compile("<(body)( [^>]*?)?>",
        CASE_INSENSITIVE);
    private static final Pattern BODY_CLOSE_TAG_PATTERN = compile("<(body)( [^>]*?)?/>",
        CASE_INSENSITIVE);
    // <html> tag patterns
    private static final Pattern HTML_TAG_PATTERN = compile("<(html)( [^>]*?)?>",
        CASE_INSENSITIVE);
    private static final Pattern HTML_CLOSE_TAG_PATTERN = compile("<(html)( [^>]*?)?/>",
        CASE_INSENSITIVE);
    // <!DOCTYPE> tag pattern
    private static final Pattern DOCTYPE1_TAG_PATTERN = compile("<!DOCTYPE [^>]*>",
        CASE_INSENSITIVE);

    private ScriptInjectorInternal() { }

    static String injectScriptContentIntoHtml(final String scriptContent, final String html) {
        final String javaScriptTag = "<script type=\"text/javascript\">" + scriptContent + "</script>";
        return inject(html, javaScriptTag);
    }

    /**
     * Inject the provided string into the html at the appropriate points.
     *
     * @param html
     * @param inject
     * @return
     */
    static String inject(String html, String inject) {
        confirmNotEmpty(html, ERROR_HTML_NULL_OR_EMPTY);

        int[][] comments = findComments(html);
        int initialCapacity = html.length() + inject.length() + 16;
        StringBuilder htmlBuilder = new StringBuilder(initialCapacity);

        // Inject after <head>
        if(injectIntoClosedTag(html, htmlBuilder, HEAD_CLOSE_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }
        if(injectAfterTag(html, htmlBuilder, HEAD_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }

        // Inject after <body>
        if(injectIntoClosedTag(html, htmlBuilder, BODY_CLOSE_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }
        if(injectAfterTag(html, htmlBuilder, BODY_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }

        // Inject after <html>
        if(injectIntoClosedTag(html, htmlBuilder, HTML_CLOSE_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }
        if(injectAfterTag(html, htmlBuilder, HTML_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }

        // Inject after <!DOCTYPE>
        if(injectAfterTag(html, htmlBuilder, DOCTYPE1_TAG_PATTERN, inject, comments)) {
            return htmlBuilder.toString();
        }

        // If none of the other patterns match, then prepend the script to the html
        return inject + html;
    }

    private static int[][] findComments(String html) {
        ArrayList<int[]> comments = new ArrayList<>();
        int index = 0;
        int htmlLength = html.length();
        while(index < htmlLength) {
            int start = html.indexOf(COMMENT_TAG_START, index);
            index = htmlLength;
            if(start >= 0) {
                int end = html.indexOf(COMMENT_TAG_END, start);
                if(end >= 0) {
                    comments.add(new int[] {start, end});
                    index = end + COMMENT_TAG_END.length();
                }
                else {
                    comments.add(new int[] {start, htmlLength});
                }
            }
        }
        return comments.toArray(new int[0][2]);
    }

    private static boolean withinComments(int index, int[][] comments) {
        if(comments != null) { 
            for(int[] comment : comments) {
                if(index >= comment[0] && index <= comment[1]) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean injectAfterTag(String html, StringBuilder updatedHtml, Pattern location,
            String inject, int[][] comments) {
        final Matcher matcher = location.matcher(html);
        int index = 0;
        while(matcher.find(index)) {
            int start = matcher.start();
            int end = matcher.end();
            if(!withinComments(start, comments)) {
                updatedHtml.append(html.substring(0, matcher.end()));
                updatedHtml.append(inject);
                updatedHtml.append(html.substring(matcher.end()));
                return true;
            }
            index = end;
        }
        return false;
    }

    private static boolean injectIntoClosedTag(String html, StringBuilder updatedHtml,
            Pattern location, String inject, int[][] comments) {
        final Matcher matcher = location.matcher(html);
        int index = 0;
        while(matcher.find(index)) {
            int start = matcher.start();
            int end = matcher.end();
            if(!withinComments(start, comments)) {
                updatedHtml.append(html.substring(0, matcher.end() - 2));
                updatedHtml.append(">");
                updatedHtml.append(inject);
                updatedHtml.append("</");
                updatedHtml.append(matcher.group(1));
                updatedHtml.append(">");
                updatedHtml.append(html.substring(matcher.end()));
                return true;
            }
            index = end;
        }
        return false;
    }
}
