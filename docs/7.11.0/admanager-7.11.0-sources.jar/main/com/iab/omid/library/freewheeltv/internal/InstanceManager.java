package com.iab.omid.library.freewheeltv.internal;

import android.annotation.SuppressLint;
import android.content.Context;

public class InstanceManager {

    @SuppressLint("StaticFieldLeak")	// only holds the app context
    private static InstanceManager instance = new InstanceManager();

    public static InstanceManager getInstance() { return instance; }

    // Note : this method is required by the tests, do not remove
    private static InstanceManager createInstance() { return new InstanceManager(); }

    private Context context;

    private InstanceManager() { }

    public Context getContext(){
        return context;
    }

    public void setContext(Context context){
        this.context = context != null ? context.getApplicationContext() : null;
    }
}
