package com.iab.omid.library.freewheeltv.adsession.media;

/**
 * List of supported media event user interaction types.
 * <p>
 * Created by Natasha Garner on 09/09/2017.
 */
public enum InteractionType {
    /**
     * The user clicked to load the ad's landing page.
     */
    CLICK("click"),
    /**
     * The user engaged with ad content to load a separate experience.
     */
    INVITATION_ACCEPTED("invitationAccept");

    String interactionType;

    InteractionType(String interactionType) {
        this.interactionType = interactionType;
    }

    @Override
    public String toString() {
        return interactionType;
    }
}
