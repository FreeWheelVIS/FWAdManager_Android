package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_VASTPROPERTIES_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmAdSessionActive;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmAdSessionNotFinished;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNativeImpressionOwner;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNullAdEvents;

import androidx.annotation.NonNull;
import com.iab.omid.library.freewheeltv.adsession.media.VastProperties;

/**
 * Ad event API enabling the integration partner to signal to all verification providers when key
 * events have occurred.
 * Only one ad events implementation can be associated with the ad session and any attempt to create
 * multiple instances will result in an exception.
 * <p>
 * Created by Natasha Garner on 04/09/2017.
 */
public final class AdEvents {
    private final AdSessionInternal adSession;

    private AdEvents(final AdSessionInternal adSessionInternal) {
        this.adSession = adSessionInternal;
    }

    /**
     * Create ad events instance associated with the supplied ad session.
     *
     * @param adSession associated with the ad events
     * @return new ad events instance associated with the supplied ad session.
     * @throws IllegalArgumentException if the supplied ad session is null.
     * @throws IllegalStateException    if an ad events instance has already been registered with
     * the ad session.
     */
    public static AdEvents createAdEvents(final AdSession adSession) {
        AdSessionInternal adSessionInternal = (AdSessionInternal)adSession;
        confirmNotNull(adSession, ERROR_ADSESSION_NULL);
        confirmNullAdEvents(adSessionInternal);
        confirmAdSessionNotFinished(adSessionInternal);

        AdEvents adEvents = new AdEvents(adSessionInternal);
        adSessionInternal.getAdSessionStatePublisher().setAdEvents(adEvents);
        return adEvents;
    }

    /**
     * Notify the ad session that an impression event has occurred.
     * When triggered all registered verification providers will be notified of this event.
     *
     * NOTE: the ad session will be automatically started if this method has been called first.
     *
     * @throws IllegalStateException if the ad session configuration identifies JAVASCRIPT as the impression owner
     * @throws IllegalStateException if the impression event has already been published
     * @throws IllegalStateException if the session has already been finished
     */
    public void impressionOccurred() {
        confirmAdSessionNotFinished(adSession);
        confirmNativeImpressionOwner(adSession);
        if(!adSession.isActive()) {
            try {
                adSession.start();
            }
            catch(Exception e) {
                // Silently ignore if there was any problem
            }
        }
        if(adSession.isActive()) {
            adSession.publishImpressionEvent();
        }
    }

    /**
     * Notify the ad session that a display loaded event has occurred.
     * When triggered all registered verification providers will be notified of this event.
     *
     * @throws IllegalStateException if the ad session configuration identifies JAVASCRIPT as the impression owner
     * @throws IllegalStateException if the loaded event has already been published
     * @throws IllegalStateException if the session has not yet started
     * @throws IllegalStateException if the session has already been finished
     */
    public void loaded() {
        confirmAdSessionActive(adSession);
        confirmNativeImpressionOwner(adSession);
        adSession.publishLoadedEvent();
    }

    /**
     * Notify the ad session that a video/audio loaded event has occurred.
     * When triggered all registered verification providers will be notified of this event.
     *
     * @param vastProperties contains static information about the video/audio placement.
     *
     * @throws IllegalArgumentException if the supplied vastProperties is null.
     * @throws IllegalStateException if the ad session configuration identifies JAVASCRIPT as the impression owner
     * @throws IllegalStateException if the loaded event has already been published
     * @throws IllegalStateException if the session has not yet started
     * @throws IllegalStateException if the session has already been finished
     */
    public void loaded(@NonNull final VastProperties vastProperties) {
        confirmNotNull(vastProperties, ERROR_VASTPROPERTIES_NULL);
        confirmAdSessionActive(adSession);
        confirmNativeImpressionOwner(adSession);
        adSession.publishLoadedEvent(vastProperties.toJSON());
    }
    
}
