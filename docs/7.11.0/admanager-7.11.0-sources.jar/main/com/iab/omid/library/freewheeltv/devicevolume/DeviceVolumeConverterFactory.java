package com.iab.omid.library.freewheeltv.devicevolume;

public class DeviceVolumeConverterFactory {

    public DeviceVolumeConverter createNewInstance() {
        return new DeviceVolumeConverter();
    }


}
