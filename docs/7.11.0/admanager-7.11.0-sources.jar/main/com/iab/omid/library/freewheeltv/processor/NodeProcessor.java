package com.iab.omid.library.freewheeltv.processor;

import android.view.View;
import org.json.JSONObject;

public interface NodeProcessor {

    interface ViewWalker {
        void walkView(View view, NodeProcessor processor, JSONObject parentState, boolean hasFriendlyObstructionAncestor);
    }

    JSONObject getState(View view);
    void iterateChildren(View view, JSONObject viewState, ViewWalker walker, boolean sortByZ, boolean hasFriendlyObstructionAncestor);
}
