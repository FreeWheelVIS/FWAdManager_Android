package com.iab.omid.library.freewheeltv.internal;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

public class AppStateObserver implements Application.ActivityLifecycleCallbacks {

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(Activity activity) {
        // If there is any ON_RESUME event, the app should always be foregrounded.
        onAppStateCouldChange(true);
    }

    @Override
    public void onActivityResumed(Activity activity) {}

    @Override
    public void onActivityPaused(Activity activity) {}

    @Override
    public void onActivityStopped(Activity activity) {
        onAppStateCouldChange(getCurrentActiveStatus());
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

    @Override
    public void onActivityDestroyed(Activity activity) {}

    public interface AppStateObserverListener {
        void onAppStateChanged(boolean isActive);
    }

    // When true, AppStateObserver is observing activity lifecycle events and will publish app state
    // and invoke the listener callback.
    private boolean started;

    // Indicates whether the host application state is active or backgrounded.
    protected boolean active;

    private AppStateObserverListener appStateObserverListener;

    public void init(@NonNull Context context) {
        if (context instanceof Application) {
            Application app = (Application) context;
            app.registerActivityLifecycleCallbacks(this);
        }
    }

    public void start() {
        started = true;
        active = getCurrentActiveStatus();
        publishAppStateChanged(active);
    }

    public boolean isActive() {
        return this.active;
    }

    public void stop() {
        started = false;
        appStateObserverListener = null;
    }

    public AppStateObserverListener getAppStateObserverListener() {
        return appStateObserverListener;
    }

    public void setAppStateObserverListener(AppStateObserverListener appStateObserverListener) {
        this.appStateObserverListener = appStateObserverListener;
    }

    protected boolean overrideIsActive() {
        // AppStateObserver is independent of ad sessions.
        // This is overridden in AdSessionAppStateObserver.
        return false;
    }

    protected void publishAppStateChanged(boolean isActive) {
        // AppStateObserver is independent of ad sessions.
        // This is overridden in AdSessionAppStateObserver.
    }

    private boolean getCurrentActiveStatus() {
        RunningAppProcessInfo runningAppProcessInfo = getRunningAppProcessInfo();
        boolean isMemoryActive = runningAppProcessInfo.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND;
        return (isMemoryActive || overrideIsActive());
    }

    private void onAppStateCouldChange(boolean isActive) {
        if (this.active != isActive) {
            this.active = isActive;
            if (started) {
                publishAppStateChanged(isActive);
                if (appStateObserverListener != null) {
                    appStateObserverListener.onAppStateChanged(isActive);
                }
            }
        }
    }

    @VisibleForTesting
    RunningAppProcessInfo getRunningAppProcessInfo() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo;
    }
}
