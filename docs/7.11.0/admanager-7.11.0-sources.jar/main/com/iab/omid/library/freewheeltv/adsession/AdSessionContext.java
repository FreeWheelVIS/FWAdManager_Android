package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_OMID_JS_SCRIPT_CONTENT_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_PARTNER_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_REFERENCE_DATA_GREATER_THAN_256_CHARACTERS;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_VERIFICATION_SCRIPT_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_WEBVIEW_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmValidLength;

import android.webkit.WebView;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * This class will provide the ad session both details of the partner and whether this is considered
 * HTML or native.
 * <p>
 * Created by Natasha Garner on 01/08/2017.
 */
public final class AdSessionContext {
    private final Partner partner;
    private final WebView webView;
    private final List<VerificationScriptResource> verificationScriptResources = new ArrayList<>();
    private final Map<String, VerificationScriptResource> injectedResourcesMap = new HashMap<>();
    private final String omidJsScriptContent;
    @Nullable private final String customReferenceData;
    @Nullable private final String contentUrl;
    private final AdSessionContextType adSessionContextType;

    private AdSessionContext(final Partner partner, final WebView webView, final String omidJsScriptContent,
                             final List<VerificationScriptResource> verificationScriptResources,
                             @Nullable final String contentUrl,
                             @Nullable final String customReferenceData,
                             AdSessionContextType adSessionContextType) {
        this.partner = partner;
        this.webView = webView;
        this.omidJsScriptContent = omidJsScriptContent;
        this.adSessionContextType = adSessionContextType;
        if(verificationScriptResources != null) {
            this.verificationScriptResources.addAll(verificationScriptResources);
            // Create unique injectionIds for each resource for later passing into OMID JS
            for(VerificationScriptResource resource : verificationScriptResources) {
                String injectionId = UUID.randomUUID().toString();
                injectedResourcesMap.put(injectionId, resource);
            }
        }
        this.contentUrl = contentUrl;
        this.customReferenceData = customReferenceData;
    }

    /**
     * Create a new "html" ad session context.
     *
     * @param partner             details of the integration partner responsible for the ad session
     * @param webView             responsible for serving the ad content
     * @param contentUrl          containing the deep link to the ad's screen.
     * @param customReferenceData containing reference data specific to the integration partner.
     * @return a new HTML context instance
     * @throws IllegalArgumentException if the supplied partner is null.
     * @throws IllegalArgumentException if the supplied webView is null.
     * @throws IllegalArgumentException if customReferenceData is greater than 256 characters.
     * @see Partner
     */
    public static AdSessionContext createHtmlAdSessionContext(final Partner partner,
        final WebView webView,
        @Nullable final String contentUrl,
        @Nullable final String customReferenceData) {
      confirmNotNull(partner, ERROR_PARTNER_NULL);
      confirmNotNull(webView, ERROR_WEBVIEW_NULL);
      if(customReferenceData != null) {
        confirmValidLength(customReferenceData, 256,
            ERROR_REFERENCE_DATA_GREATER_THAN_256_CHARACTERS);
      }

      return new AdSessionContext(partner, webView, null, null,
          contentUrl, customReferenceData, AdSessionContextType.HTML);
    }

    /**
     * Create a new "javascript" ad session context. This can be used when the integration renders
     * creatives using native APIs but runs other JavaScript code in a webview, which then can also
     * be provided here to run measurement code in.
     *
     * @param partner             details of the integration partner responsible for the ad session
     * @param webView             will be used for running OMSDK JS service and verification script
     * @param contentUrl          containing the deep link to the ad's screen.
     * @param customReferenceData containing reference data specific to the integration partner.
     * @return a new JAVASCRIPT context instance
     * @throws IllegalArgumentException if the supplied partner is null.
     * @throws IllegalArgumentException if the supplied webView is null.
     * @throws IllegalArgumentException if customReferenceData is greater than 256 characters.
     * @see Partner
     */
    public static AdSessionContext createJavascriptAdSessionContext(final Partner partner,
                                                              final WebView webView,
                                                              @Nullable final String contentUrl,
                                                              @Nullable final String customReferenceData) {
        confirmNotNull(partner, ERROR_PARTNER_NULL);
        confirmNotNull(webView, ERROR_WEBVIEW_NULL);
        if(customReferenceData != null) {
            confirmValidLength(customReferenceData, 256,
                    ERROR_REFERENCE_DATA_GREATER_THAN_256_CHARACTERS);
        }

        return new AdSessionContext(partner, webView, null, null,
                contentUrl, customReferenceData, AdSessionContextType.JAVASCRIPT);
    }

    /**
     * Create a new "native" ad session context.
     *
     * @param partner                     details of the integration partner responsible for the ad
     *                                    session
     * @param omidJsScriptContent         containing the OM SDK JS service content to be injected into
     *                                    the hidden tracking web view
     * @param verificationScriptResources of all verification providers who expect to receive OMID
     *                                    event data.
     * @param contentUrl                  containing the deep link to the ad's screen.
     * @param customReferenceData         containing reference data specific to the integration
     *                                    partner.
     * @return a new native context instance
     * @throws IllegalArgumentException if the supplied partner is null.
     * @throws IllegalArgumentException if the supplied omidJsServiceContent is null or blank.
     * @throws IllegalArgumentException if the supplied verificationScriptResources is null or empty.
     * @throws IllegalArgumentException if customReferenceData is greater than 256 characters.
     * @see Partner
     * @see VerificationScriptResource
     */
    public static AdSessionContext createNativeAdSessionContext(final Partner partner,
        final String omidJsScriptContent,
        final List<VerificationScriptResource> verificationScriptResources,
        @Nullable final String contentUrl,
        @Nullable final String customReferenceData) {
      confirmNotNull(partner, ERROR_PARTNER_NULL);
      confirmNotNull(omidJsScriptContent, ERROR_OMID_JS_SCRIPT_CONTENT_NULL);
      confirmNotNull(verificationScriptResources, ERROR_VERIFICATION_SCRIPT_NULL);
      if(customReferenceData != null) {
        confirmValidLength(customReferenceData, 256,
            ERROR_REFERENCE_DATA_GREATER_THAN_256_CHARACTERS);
      }

      return new AdSessionContext(partner, null, omidJsScriptContent, verificationScriptResources,
          contentUrl, customReferenceData, AdSessionContextType.NATIVE);

    }

    public Partner getPartner() {
        return partner;
    }

    public List<VerificationScriptResource> getVerificationScriptResources() {
        return Collections.unmodifiableList(verificationScriptResources);
    }

    /**
     * For OM SDK internal use only.
     */
    public Map<String, VerificationScriptResource> getInjectedResourcesMap() {
        return Collections.unmodifiableMap(injectedResourcesMap);
    }

    public WebView getWebView() {
        return webView;
    }

    public @Nullable String getContentUrl() {
        return contentUrl;
    }

    public @Nullable String getCustomReferenceData() {
        return customReferenceData;
    }

    public String getOmidJsScriptContent() {
        return omidJsScriptContent;
    }

    /**
     * For OM SDK internal use only.
     */
    public AdSessionContextType getAdSessionContextType() {
        return adSessionContextType;
    }
}

