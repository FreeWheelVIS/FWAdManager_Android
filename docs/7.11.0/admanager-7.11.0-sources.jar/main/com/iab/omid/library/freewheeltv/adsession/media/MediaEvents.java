package com.iab.omid.library.freewheeltv.adsession.media;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_INTERACTIONTYPE_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_INVALID_MEDIA_DURATION;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_INVALID_MEDIA_VOLUME;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_PLAYERSTATE_NULL;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_MEDIA_DEVICE_VOLUME;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_MEDIA_DURATION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_MEDIA_INTERACTION_TYPE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_MEDIA_MEDIA_PLAYER_VOLUME;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_MEDIA_STATE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_AD_USER_INTERACTION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_BUFFER_FINISH;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_BUFFER_START;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_COMPLETE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_FIRST_QUARTILE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_MIDPOINT;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_PAUSE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_PLAYER_STATE_CHANGE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_RESUME;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_SKIPPED;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_START;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_THIRD_QUARTILE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.MEDIA_EVENT_VOLUME_CHANGE;
import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmAdSessionActive;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmAdSessionNotFinished;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmAdSessionNotStarted;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNativeMediaEventsOwner;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNullMediaEvents;

import com.iab.omid.library.freewheeltv.adsession.AdSession;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.OmidManager;
import org.json.JSONObject;

/**
 * This provides a complete list of native media events supported by OM SDK.
 * Using this event API assumes the native-layer audio/video player is fully responsible for
 * communicating all media events at the appropriate times.
 * Only one media events implementation can be associated with the ad session and any attempt to
 * create multiple instances will result in an exception.
 * <p>
 * Created by Natasha Garner on 10/09/2017.
 */
public final class MediaEvents {
    private final AdSessionInternal adSession;

    private MediaEvents(final AdSessionInternal adSession) {
        this.adSession = adSession;
    }

    /**
     * Create media events instance for the associated ad session.
     * Any attempt to create a media events instance will fail if the supplied ad session has
     * already started.
     *
     * @param adSession associated with the ad events.
     * @return new media events instance.
     * @throws IllegalArgumentException if the supplied ad session is null.
     * @throws IllegalStateException    if a media events instance has already been registered with
     * the ad session.
     * @throws IllegalStateException    if a media events instance has been created after the ad
     * session has started.
     * @see AdSession
     */
    public static MediaEvents createMediaEvents(final AdSession adSession) {
        AdSessionInternal adSessionInternal = (AdSessionInternal)adSession;
        confirmNotNull(adSession, ERROR_ADSESSION_NULL);
        confirmNativeMediaEventsOwner(adSessionInternal);
        confirmAdSessionNotStarted(adSessionInternal);
        confirmAdSessionNotFinished(adSessionInternal);
        confirmNullMediaEvents(adSessionInternal);

        MediaEvents mediaEvents = new MediaEvents(adSessionInternal);
        adSessionInternal.getAdSessionStatePublisher().setMediaEvents(mediaEvents);
        return mediaEvents;
    }

    /**
     * Notify all media listeners that media content has started playing.
     *
     * @param duration          of the selected media media (in seconds).
     * @param mediaPlayerVolume from the native media player with a range between 0 and 1.
     * @throws IllegalArgumentException if an invalid duration or mediaPlayerVolume has been supplied.
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void start(final float duration, final float mediaPlayerVolume) {
        confirmValidDuration(duration);
        confirmValidVolume(mediaPlayerVolume);
        confirmAdSessionActive(adSession);

        JSONObject json = new JSONObject();
        jsonPut(json, KEY_MEDIA_DURATION, duration);
        jsonPut(json, KEY_MEDIA_MEDIA_PLAYER_VOLUME, mediaPlayerVolume);

        final float deviceVolume = OmidManager.getInstance().getDeviceVolume();
        jsonPut(json, KEY_MEDIA_DEVICE_VOLUME, deviceVolume);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_START, json);
    }

    /**
     * Notify all media listeners that media playback has reached the first quartile.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void firstQuartile() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_FIRST_QUARTILE);
    }

    /**
     * Notify all media listeners that media playback has reached the midpoint.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void midpoint() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_MIDPOINT);
    }

    /**
     * Notify all media listeners that media playback has reached the third quartile.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void thirdQuartile() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_THIRD_QUARTILE);
    }

    /**
     * Notify all media listeners that media playback is complete.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void complete() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_COMPLETE);
    }

    /**
     * Notify all media listeners that media playback has paused after a user interaction.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void pause() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_PAUSE);
    }

    /**
     * Notify all media listeners that media playback has resumed (after being paused) after a user
     * interaction.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void resume() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_RESUME);
    }

    /**
     * Notify all media listeners that media playback has stopped and started buffering.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void bufferStart() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_BUFFER_START);
    }

    /**
     * Notify all media listeners that buffering has finished and media playback has resumed.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void bufferFinish() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_BUFFER_FINISH);
    }

    /**
     * Notify all media listeners that media playback has stopped as a user skip interaction.
     * Once skipped media it should not be possible for the media to resume playing content.
     *
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void skipped() {
        confirmAdSessionActive(adSession);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_SKIPPED);
    }

    /**
     * Notify all media listeners that the media player volume has changed.
     *
     * @param mediaPlayerVolume from the native media player with a range between 0 and 1.
     * @throws IllegalArgumentException if an invalid mediaPlayerVolume has been supplied.
     * @throws IllegalStateException if the ad session has not been started or has finished.
     */
    public void volumeChange(final float mediaPlayerVolume) {
        confirmValidVolume(mediaPlayerVolume);
        confirmAdSessionActive(adSession);

        JSONObject json = new JSONObject();
        jsonPut(json, KEY_MEDIA_MEDIA_PLAYER_VOLUME, mediaPlayerVolume);

        final float deviceVolume = OmidManager.getInstance().getDeviceVolume();
        jsonPut(json, KEY_MEDIA_DEVICE_VOLUME, deviceVolume);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_VOLUME_CHANGE, json);
    }

    /**
     * Notify all media listeners that media player state has changed. See {@link PlayerState} for
     * list of supported states.
     *
     * @param playerState to signal the latest media player state
     * @throws IllegalArgumentException if the supplied player state is null.
     * @throws IllegalStateException if the ad session has not been started or has finished.
     * @see PlayerState
     */
    public void playerStateChange(final PlayerState playerState) {
        confirmNotNull(playerState, ERROR_PLAYERSTATE_NULL);
        confirmAdSessionActive(adSession);

        JSONObject json = new JSONObject();
        jsonPut(json, KEY_MEDIA_STATE, playerState);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_PLAYER_STATE_CHANGE,
            json);
    }

    /**
     * Notify all media listeners that the user has performed an ad interaction. See
     * {@link InteractionType} for list of supported types.
     *
     * @param interactionType to signal the latest user integration
     * @throws IllegalArgumentException if the supplied interaction type is null.
     * @throws IllegalStateException if the ad session has not been started or has finished.
     * @see InteractionType
     */
    public void adUserInteraction(final InteractionType interactionType) {
        confirmNotNull(interactionType, ERROR_INTERACTIONTYPE_NULL);
        confirmAdSessionActive(adSession);

        JSONObject json = new JSONObject();
        jsonPut(json, KEY_MEDIA_INTERACTION_TYPE, interactionType);
        adSession.getAdSessionStatePublisher().publishMediaEvent(MEDIA_EVENT_AD_USER_INTERACTION,
            json);
    }

    private void confirmValidDuration(float duration) {
        if(duration <= 0) {
            throw new IllegalArgumentException(ERROR_INVALID_MEDIA_DURATION);
        }
    }

    private void confirmValidVolume(float volume) {
        if(volume < 0 || volume > 1) {
            throw new IllegalArgumentException(ERROR_INVALID_MEDIA_VOLUME);
        }
    }
}
