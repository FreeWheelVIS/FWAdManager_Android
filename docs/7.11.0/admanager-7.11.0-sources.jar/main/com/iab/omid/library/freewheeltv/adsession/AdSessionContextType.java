package com.iab.omid.library.freewheeltv.adsession;

/**
 * For OM SDK internal use only.
 * <p>
 * Created by Natasha Garner on 03/08/2017.
 */
public enum AdSessionContextType {
    HTML("html"),
    NATIVE("native"),
    JAVASCRIPT("javascript");

    private final String typeString;

    AdSessionContextType(String typeString) {
        this.typeString = typeString;
    }

    @Override
    public String toString() {
        return typeString;
    }
}
