package com.iab.omid.library.freewheeltv.walking;

import static java.util.concurrent.TimeUnit.NANOSECONDS;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.annotation.VisibleForTesting;

import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import com.iab.omid.library.freewheeltv.internal.ScreenStateObserver;
import com.iab.omid.library.freewheeltv.processor.NodeProcessor;
import com.iab.omid.library.freewheeltv.processor.ProcessorFactory;
import com.iab.omid.library.freewheeltv.utils.OmidJSONUtil;
import com.iab.omid.library.freewheeltv.utils.OmidTimestamp;
import com.iab.omid.library.freewheeltv.utils.OmidViewUtil;
import com.iab.omid.library.freewheeltv.walking.async.OmidAsyncTaskQueue;
import com.iab.omid.library.freewheeltv.weakreference.WeakView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.json.JSONObject;

public class TreeWalker implements NodeProcessor.ViewWalker {

    private static final int UPDATE_TREE_BY_SCHEDULE_PERIOD = 200;


    private static TreeWalker treeWalker = new TreeWalker();
    private static Handler uiHandler = new Handler(Looper.getMainLooper());
    private static Handler treeWalkerHandler = null;

    private List<TreeWalkerTimeLogger> timeLoggers = new ArrayList<>();

    private int objectsCount;
    private boolean foundRegisteredPossibleObstructionListener = false;
    private final List<WeakView> possibleObstructions = new ArrayList<>();
    private ProcessorFactory processorFactory;
    private AdViewCache adViewCache;
    private StatePublisher statePublisher;
    private long startTime;

    TreeWalker() {
        adViewCache = new AdViewCache();
        processorFactory = new ProcessorFactory();
        statePublisher = new StatePublisher(new OmidAsyncTaskQueue());
    }

    public interface TreeWalkerTimeLogger {
        void onTreeProcessed(int walkedObjectsCount, long calculationTime);
    }

    public interface TreeWalkerNanoTimeLogger extends TreeWalkerTimeLogger {
        void onTreeProcessedNano(int walkedObjectsCount, long calculationTime);
    }

    public static TreeWalker getInstance() {
        return treeWalker;
    }

    public void addTimeLogger(TreeWalkerTimeLogger timeLogger) {
        if(!timeLoggers.contains(timeLogger)) {
            timeLoggers.add(timeLogger);
        }
    }
	
	public void removeTimeLogger(TreeWalkerTimeLogger timeLogger) {
        if(timeLoggers.contains(timeLogger)) {
            timeLoggers.remove(timeLogger);
        }
    }

    public void start() {
        startTreeWalkerUpdater();
    }

    public void stop() {
        pause();
        timeLoggers.clear();
        uiHandler.post(new Runnable() {
            @Override
            public void run() {
                statePublisher.cleanupCache();
            }
        });
    }

    public void pause() {
        stopTreeWalkerUpdater();
    }

    private void updateTreeState() {
        beforeWalk();
        doWalk();
        afterWalk();
        ScreenStateObserver.getInstance().checkLockState();
    }

    private void beforeWalk() {
        objectsCount = 0;
        possibleObstructions.clear();
        foundRegisteredPossibleObstructionListener = false;
        AdSessionRegistry registry = AdSessionRegistry.getInstance();
        for (AdSessionInternal adSession : registry.getActiveAdSessions()) {
            if (adSession.hasPossibleObstructionListener()) {
                foundRegisteredPossibleObstructionListener = true;
                break;
            }
        }
        startTime = OmidTimestamp.getCurrentTime();
    }

    private void afterWalk() {
        long endTime = OmidTimestamp.getCurrentTime();
        notifyTimeLogger(endTime - startTime);
    }

    @VisibleForTesting
    void doWalk() {
        adViewCache.prepare();
        long timestamp = OmidTimestamp.getCurrentTime();
        NodeProcessor processor = processorFactory.getRootProcessor();
        if(adViewCache.getNotVisibleSessionIds().size() > 0) {
            for(String notVisibleSessionId : adViewCache.getNotVisibleSessionIds()) {
                JSONObject state = processor.getState(null);
                View adView = adViewCache.getNotVisibleAd(notVisibleSessionId);
                handleNotVisibleAdView(notVisibleSessionId, adView, state);
                OmidJSONUtil.setViewport(state);
                HashSet<String> notVisibleSessionIdSet = new HashSet<>();
                notVisibleSessionIdSet.add(notVisibleSessionId);
                statePublisher.publishEmptyState(state, notVisibleSessionIdSet, timestamp);
            }
        }
        if (adViewCache.getVisibleSessionIds().size() > 0) {
            JSONObject state = processor.getState(null);
            walkViewChildren(null, processor, state, ViewType.PARENT_VIEW, false);
            OmidJSONUtil.setViewport(state);
            statePublisher.publishState(state, adViewCache.getVisibleSessionIds(), timestamp);
            if (foundRegisteredPossibleObstructionListener) {
                AdSessionRegistry registry = AdSessionRegistry.getInstance();
                for (AdSessionInternal adSession : registry.getActiveAdSessions()) {
                    adSession.reportPossibleObstructions(possibleObstructions);
                }
            }
        } else {
            statePublisher.cleanupCache();
        }
        adViewCache.cleanup();
    }

    @Override
    public void walkView(View view, NodeProcessor processor, JSONObject parentState, boolean hasFriendlyObstructionAncestor) {
        if(!OmidViewUtil.isViewDisplayed(view)) {
            return;
        }
        ViewType viewType = adViewCache.getViewType(view);
        if(viewType == ViewType.UNDERLYING_VIEW) {
            return;
        }
        JSONObject state = processor.getState(view);
        OmidJSONUtil.addChildState(parentState, state);
        boolean isAdPlacement = handleAdView(view, state);
        if (!isAdPlacement) {
            boolean isFriendlyObstruction = checkFriendlyObstruction(view, state);
            boolean isFriendlyOrHasFriendlyObstructionAncestor = hasFriendlyObstructionAncestor || isFriendlyObstruction;
            if (foundRegisteredPossibleObstructionListener) {
                if (viewType == ViewType.OBSTRUCTION_VIEW && !isFriendlyOrHasFriendlyObstructionAncestor) {
                    possibleObstructions.add(new WeakView(view));
                }
            }
            walkViewChildren(view, processor, state, viewType, isFriendlyOrHasFriendlyObstructionAncestor);
        }
        objectsCount++;
    }

    private void walkViewChildren(View view, NodeProcessor processor, JSONObject state, ViewType viewType, boolean hasFriendlyObstructionAncestor) {
        processor.iterateChildren(view, state, this, viewType == ViewType.PARENT_VIEW, hasFriendlyObstructionAncestor);
    }

    private boolean handleAdView(View view, JSONObject viewStateObject) {
        String sessionId = adViewCache.getSessionId(view);
        if(sessionId != null) {
            OmidJSONUtil.addAdSessionId(viewStateObject, sessionId);
            OmidJSONUtil.addHasWindowFocus(viewStateObject, adViewCache.onPublishHasWindowFocus(view));
            OmidJSONUtil.addPipState(viewStateObject, adViewCache.isPictureInPictureActiveForSessionId(sessionId));

            adViewCache.onAdViewProcessed();
            return true;
        }
        return false;
    }

    private void handleNotVisibleAdView(String sessionId, View adView, JSONObject viewStateObject) {
        NodeProcessor viewProcessor = processorFactory.getViewProcessor();
        String notVisibleReason = adViewCache.getNotVisibleReason(sessionId);
        if(notVisibleReason != null) {
            JSONObject adState = viewProcessor.getState(adView);
            OmidJSONUtil.addAdSessionId(adState, sessionId);
            OmidJSONUtil.addNotVisibleReason(adState, notVisibleReason);
            OmidJSONUtil.addChildState(viewStateObject, adState);
        }
    }

    private boolean checkFriendlyObstruction(View view, JSONObject viewStateObject) {
        final AdViewCache.FriendlyObstructionData friendlyObstructionData = adViewCache.getFriendlyObstructionData(view);
        if (friendlyObstructionData != null) {
            OmidJSONUtil.addFriendlyObstruction(viewStateObject, friendlyObstructionData);
            return true;
        }
        return false;
    }

    private void notifyTimeLogger(long calculationTime) {
        if(timeLoggers.size() > 0) {
            for(TreeWalkerTimeLogger timeLogger : timeLoggers) {
                timeLogger.onTreeProcessed(objectsCount, NANOSECONDS.toMillis(calculationTime));
                if(timeLogger instanceof TreeWalkerNanoTimeLogger) {
                    TreeWalkerNanoTimeLogger nanoTimeLogger = (TreeWalkerNanoTimeLogger) timeLogger;
                    nanoTimeLogger.onTreeProcessedNano(objectsCount, calculationTime);
                }
            }
        }
    }

    private void startTreeWalkerUpdater() {
        // If TreeWalker isn't started then
        //   create the TreeWalkerHandler on the UI thread and
        //   queue a tree walker update for as soon as possible and
        //   queue the initial periodic tree walk retrigger at the interval defined
        if (treeWalkerHandler == null) {
            treeWalkerHandler = new Handler(Looper.getMainLooper());
            treeWalkerHandler.post(runnableUpdateTreeState);
            treeWalkerHandler.postDelayed(runnableTreeWalkerUpdateTrigger, UPDATE_TREE_BY_SCHEDULE_PERIOD);
        }
    }

    private void stopTreeWalkerUpdater() {
        if(treeWalkerHandler != null) {
            treeWalkerHandler.removeCallbacks(runnableTreeWalkerUpdateTrigger);
            treeWalkerHandler = null;
        }
    }

    @VisibleForTesting
    void setAdViewCache(AdViewCache adViewCache) {
        this.adViewCache = adViewCache;
    }

    @VisibleForTesting
    void setStatePublisher(StatePublisher statePublisher) {
        this.statePublisher = statePublisher;
    }

    @VisibleForTesting
    void setProcessorFactory(ProcessorFactory processorFactory) {
        this.processorFactory = processorFactory;
    }

    private static final Runnable runnableUpdateTreeState = new Runnable() {
        @Override
        public void run() {
            TreeWalker.getInstance().updateTreeState();
        }
    };

    private static final Runnable runnableTreeWalkerUpdateTrigger = new Runnable() {
        @Override
        public void run() {
            // The tree walk as a result of the trigger, and the next trigger
            if(treeWalkerHandler != null) {
                // Queue doing a tree walk
                treeWalkerHandler.post(runnableUpdateTreeState);
                // Queue trigger of next tree walk (200ms delayed)
                treeWalkerHandler.postDelayed(runnableTreeWalkerUpdateTrigger, UPDATE_TREE_BY_SCHEDULE_PERIOD);
            }
        }
    };

}
