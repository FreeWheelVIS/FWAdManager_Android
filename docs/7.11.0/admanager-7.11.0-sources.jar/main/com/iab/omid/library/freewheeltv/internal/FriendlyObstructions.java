package com.iab.omid.library.freewheeltv.internal;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_ILLEGAL_CHARACTERS;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_TOO_LONG;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_FRIENDLY_OBSTRUCTION_NULL;

import android.view.View;

import androidx.annotation.Nullable;

import com.iab.omid.library.freewheeltv.adsession.FriendlyObstructionPurpose;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Collection of friendly obstructions that can be applied to one or more ad sessions.
 * Rejects invalid operations such as adding the same friendly obstruction twice.
 */
public class FriendlyObstructions {
    private static final Pattern PROPERLY_FORMATTED_DETAIL_REASON_PATTERN = Pattern.compile("^[a-zA-Z0-9 ]+$");

    private final List<FriendlyObstruction> friendlyObstructions = new ArrayList<>();

    /**
     * Get a list of all friendly obstructions stored by this instance.
     *
     * @return The list of all friendly obstructions.
     */
    public List<FriendlyObstruction> getAll() {
        return friendlyObstructions;
    }

    /**
     * Add a friendly obstruction which should then be excluded from all ad session viewability
     * calculations.
     *
     * @param friendlyObstructionView to be excluded from all ad session viewability calculations.
     * @param purpose                 why this obstruction was necessary
     * @param detailedReason          an explanation for why this obstruction is part of the ad
     *                                experience if not already obvious from the
     *                                {@link FriendlyObstructionPurpose} selected.
     *                                Must be 50 characters or less and only contain characters
     *                                `A-z`,`0-9` or space.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     * @throws IllegalArgumentException if the detailedReason is over 50 characters or contains a
     *                                  character that is not in `A-z`,`0-9` or a space.
     */
    public void add(final View friendlyObstructionView,
                    final FriendlyObstructionPurpose purpose,
                    final @Nullable String detailedReason) {
        checkFriendlyObstructionNotNull(friendlyObstructionView);
        checkDetailedReasonProperlyFormatted(detailedReason);
        // If a friendly obstruction view is registered multiple times, the purpose and reason
        // fields of only the first registration are used.
        FriendlyObstruction existingFriendlyObstruction = findFriendlyObstruction(
                friendlyObstructionView);
        if (existingFriendlyObstruction == null) {
            friendlyObstructions.add(new FriendlyObstruction(
                    friendlyObstructionView, purpose, detailedReason));
        }
    }

    /**
     * Remove a registered friendly obstruction.
     *
     * @param friendlyObstructionView to be removed from the list of registered friendly
     *                                obstructions.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     */
    public void remove(final View friendlyObstructionView) {
        checkFriendlyObstructionNotNull(friendlyObstructionView);
        FriendlyObstruction friendlyObstruction = findFriendlyObstruction(friendlyObstructionView);
        if (friendlyObstruction != null) {
            friendlyObstructions.remove(friendlyObstruction);
        }
    }

    /**
     * Remove all registered friendly obstructions.
     */
    public void removeAll() {
        friendlyObstructions.clear();
    }

    private void checkFriendlyObstructionNotNull(final View friendlyObstruction) {
        if (friendlyObstruction == null) {
            throw new IllegalArgumentException(ERROR_FRIENDLY_OBSTRUCTION_NULL);
        }
    }

    private void checkDetailedReasonProperlyFormatted(
            final String detailedReason) {
        if (detailedReason != null) {
            if (detailedReason.length() > 50) {
                throw new IllegalArgumentException(
                        ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_TOO_LONG);
            }
            if (!PROPERLY_FORMATTED_DETAIL_REASON_PATTERN.matcher(detailedReason).matches()) {
                throw new IllegalArgumentException(
                        ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_ILLEGAL_CHARACTERS);
            }
        }
    }

    private FriendlyObstruction findFriendlyObstruction(final View newFriendlyObstruction) {
        for (FriendlyObstruction friendlyObstruction : friendlyObstructions) {
            if (friendlyObstruction.getObstructionView().get() == newFriendlyObstruction) {
                return friendlyObstruction;
            }
        }
        return null;
    }
}
