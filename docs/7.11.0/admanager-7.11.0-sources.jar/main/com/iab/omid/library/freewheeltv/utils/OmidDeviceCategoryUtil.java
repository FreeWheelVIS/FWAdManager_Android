package com.iab.omid.library.freewheeltv.utils;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import com.iab.omid.library.freewheeltv.adsession.DeviceCategory;

public final class OmidDeviceCategoryUtil {
  private static UiModeManager uiModeManager = null;

  public static void init(Context context) {
    if (context != null) {
      uiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
    }
  }

  public static DeviceCategory getDeviceCategory() {
    if (uiModeManager != null) {
        switch (uiModeManager.getCurrentModeType()) {
        case Configuration.UI_MODE_TYPE_NORMAL:
          return DeviceCategory.MOBILE;
        case Configuration.UI_MODE_TYPE_TELEVISION:
          return DeviceCategory.CTV;
        default:
          return DeviceCategory.OTHER;
      }
    } else {
      return DeviceCategory.OTHER;
    }
  }
}
