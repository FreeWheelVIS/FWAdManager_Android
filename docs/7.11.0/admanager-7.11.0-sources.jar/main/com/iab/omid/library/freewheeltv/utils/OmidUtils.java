package com.iab.omid.library.freewheeltv.utils;

import static android.text.TextUtils.isEmpty;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADEVENTS_EXISTS;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_FINISHED;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_NOT_STARTED;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_STARTED;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_CANNOT_CREATE_MEDIA_EVENTS_FOR_JAVASCRIPT;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_IMPRESSION_OWNER_MISMATCH;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_IMPRESSION_OWNER_NONE;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_MEDIAEVENTS_EXISTS;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_NOT_EXPECTING_NATIVE_IMPRESSION;
import static com.iab.omid.library.freewheeltv.internal.Errors.METHOD_CALLED_BEFORE_ACTIVATION;

import com.iab.omid.library.freewheeltv.Omid;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.adsession.CreativeType;
import com.iab.omid.library.freewheeltv.adsession.ImpressionType;
import com.iab.omid.library.freewheeltv.adsession.Owner;

/**
 * Created by Natasha Garner on 17/07/2017.
 */
public class OmidUtils {

    /**
     * Check if Omid is active.
     * @throws IllegalStateException if OM SDK is not active yet.
     */
    public static void checkOmidActive() {
        if(!Omid.isActive()) {
            throw new IllegalStateException(METHOD_CALLED_BEFORE_ACTIVATION);
        }
    }

    public static void confirmNotNull(Object object, String message) {
        if(object == null) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void confirmNotEmpty(String object, String message) {
        if(isEmpty(object)) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void confirmValidLength(String object, int length, String message) {
        if(object.length() > length) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void confirmAdSessionNotStarted(AdSessionInternal adSession) {
        if(adSession.isStarted()) {
            throw new IllegalStateException(ERROR_ADSESSION_STARTED);
        }
    }

    private static void confirmAdSessionStarted(AdSessionInternal adSession) {
        if(!adSession.isStarted()) {
            throw new IllegalStateException(ERROR_ADSESSION_NOT_STARTED);
        }
    }

    public static void confirmAdSessionNotFinished(AdSessionInternal adSession) {
        if(adSession.isFinished()) {
            throw new IllegalStateException(ERROR_ADSESSION_FINISHED);
        }
    }

    public static void confirmAdSessionActive(AdSessionInternal adSession) {
        confirmAdSessionStarted(adSession);
        confirmAdSessionNotFinished(adSession);
    }

    public static void confirmNullAdEvents(AdSessionInternal adSession) {
        if(adSession.getAdSessionStatePublisher().getAdEvents() != null) {
            throw new IllegalStateException(ERROR_ADEVENTS_EXISTS);
        }
    }

    public static void confirmNullMediaEvents(AdSessionInternal adSession) {
        if(adSession.getAdSessionStatePublisher().getMediaEvents() != null) {
            throw new IllegalStateException(ERROR_MEDIAEVENTS_EXISTS);
        }
    }

    public static void confirmNativeImpressionOwner(AdSessionInternal adSession) {
        if(!adSession.isNativeImpressionOwner()) {
            throw new IllegalStateException(ERROR_NOT_EXPECTING_NATIVE_IMPRESSION);
        }
    }

    public static void confirmNativeMediaEventsOwner(AdSessionInternal adSession) {
        if(!adSession.isNativeMediaEventsOwner()) {
            throw new IllegalStateException(ERROR_CANNOT_CREATE_MEDIA_EVENTS_FOR_JAVASCRIPT);
        }
    }

    public static void confirmValidImpressionOwner(Owner impressionOwner, CreativeType creativeType,
        ImpressionType impressionType)
    {
        if (impressionOwner == Owner.NONE) {
            throw new IllegalArgumentException(ERROR_IMPRESSION_OWNER_NONE);
        }
        if (creativeType == CreativeType.DEFINED_BY_JAVASCRIPT
            && impressionOwner == Owner.NATIVE) {
            throw new IllegalArgumentException(ERROR_IMPRESSION_OWNER_MISMATCH);
        }
        if (impressionType == ImpressionType.DEFINED_BY_JAVASCRIPT &&
            impressionOwner == Owner.NATIVE) {
            throw new IllegalArgumentException(ERROR_IMPRESSION_OWNER_MISMATCH);
        }
    }
}
