package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.adsession.Owner.NATIVE;
import static com.iab.omid.library.freewheeltv.adsession.Owner.NONE;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_CREATIVE_TYPE_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_IMPRESSION_OWNER_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_IMPRESSION_TYPE_NULL;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_CREATIVE_TYPE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_IMPRESSION_TYPE;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_INIT_IMPRESSION_OWNER;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_INIT_ISOLATE_VERIFICATION_SCRIPTS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_INIT_MEDIA_EVENTS_OWNER;
import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmValidImpressionOwner;

import org.json.JSONObject;

/**
 * Created by pharris on 11/09/2017.
 */

public class AdSessionConfiguration {
    private final Owner impressionOwner;
    private final Owner mediaEventsOwner;
    private final boolean isolateVerificationScripts;
    private final CreativeType creativeType;
    private final ImpressionType impressionType;

    private AdSessionConfiguration(final CreativeType creativeType,
                                   final ImpressionType impressionType,
                                   final Owner impressionOwner,
                                   final Owner mediaEventsOwner,
                                   final boolean isolateVerificationScripts) {
        this.creativeType = creativeType;
        this.impressionType = impressionType;
        this.impressionOwner = impressionOwner;
        if (mediaEventsOwner == null) {
            this.mediaEventsOwner = NONE;
        } else {
            this.mediaEventsOwner = mediaEventsOwner;
        }
        this.isolateVerificationScripts = isolateVerificationScripts;
    }

    /**
     * Create new ad session configuration supplying the owner for both the impression and media
     * events along with the type of creative being rendered/measured
     * The OM SDK JS service will use this information to help identify where the source of these
     * events is expected to be received.
     *
     * @param creativeType               type of creative to be rendered in this session.
     * @param impressionType             type of impression to be triggered in this session.
     * @param impressionOwner            of whether the native or JavaScript layer should be responsible for
     *                                   supplying the impression event.
     * @param mediaEventsOwner           of whether the native or JavaScript layer should be responsible for
     *                                   supplying media events. This needs to be set only for non-display
     *                                   ad sessions and can be set to `Owner.NONE` for display. When
     *                                   the creativeType is DEFINED_BY_JAVASCRIPT then this should be
     *                                   set to JAVASCRIPT
     * @param isolateVerificationScripts When true, verification scripts are in a sandboxed iframe.
     *                                   When false, verification scripts have access to DOM of webview.
     *                                   This setting is only applicable when verification script resources are
     *                                   injected via the javascript session client (typically this would only
     *                                   be relevant for HTML video ad sessions)
     * @return new ad session configuration instance.
     * @throws IllegalArgumentException if the supplied impressionOwner is null.
     */
    public static AdSessionConfiguration createAdSessionConfiguration(final CreativeType creativeType,
                                                                      final ImpressionType impressionType,
                                                                      final Owner impressionOwner,
                                                                      final Owner mediaEventsOwner,
                                                                      final boolean isolateVerificationScripts) {
        confirmNotNull(creativeType, ERROR_CREATIVE_TYPE_NULL);
        confirmNotNull(impressionType, ERROR_IMPRESSION_TYPE_NULL);
        confirmNotNull(impressionOwner, ERROR_IMPRESSION_OWNER_NULL);
        confirmValidImpressionOwner(impressionOwner, creativeType, impressionType);
        return new AdSessionConfiguration(creativeType, impressionType, impressionOwner,
            mediaEventsOwner, isolateVerificationScripts);
    }

    /**
     * For OM SDK internal use only.
     */
    public boolean isNativeImpressionOwner() {
        return NATIVE == impressionOwner;
    }

    /**
     * For OM SDK internal use only.
     */
    public boolean isNativeMediaEventsOwner() { return NATIVE == mediaEventsOwner; }

    /**
     * For OM SDK internal use only.
     */
    public JSONObject toJsonObject() {
        JSONObject json = new JSONObject();
        jsonPut(json, KEY_INIT_IMPRESSION_OWNER, impressionOwner);
        jsonPut(json, KEY_INIT_MEDIA_EVENTS_OWNER, mediaEventsOwner);
        jsonPut(json, KEY_CREATIVE_TYPE, creativeType);
        jsonPut(json, KEY_IMPRESSION_TYPE, impressionType);
        jsonPut(json, KEY_INIT_ISOLATE_VERIFICATION_SCRIPTS, isolateVerificationScripts);
        return json;
    }
}
