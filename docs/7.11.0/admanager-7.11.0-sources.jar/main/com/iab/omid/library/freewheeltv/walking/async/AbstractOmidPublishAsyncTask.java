package com.iab.omid.library.freewheeltv.walking.async;

import java.util.HashSet;
import org.json.JSONObject;

public abstract class AbstractOmidPublishAsyncTask extends OmidAsyncTask {

    protected final HashSet<String> sessionIds;
    protected final JSONObject state;
    protected final long timestamp;

    public HashSet<String> getSessionIds() {
        return sessionIds;
    }

    public JSONObject getState() {
        return state;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public AbstractOmidPublishAsyncTask(StateProvider stateProvider, HashSet<String> sessionIds,
                                        JSONObject state, long timestamp) {
        super(stateProvider);
        this.sessionIds = new HashSet<>(sessionIds);
        this.state = state;
        this.timestamp = timestamp;
    }
}
