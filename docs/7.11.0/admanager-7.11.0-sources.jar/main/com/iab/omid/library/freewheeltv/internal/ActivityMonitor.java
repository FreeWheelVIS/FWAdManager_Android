package com.iab.omid.library.freewheeltv.internal;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import android.content.Context;
import android.util.Log;

import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.utils.OmidTimestamp;
import java.util.Date;

public class ActivityMonitor implements AppStateObserver.AppStateObserverListener {

    private static ActivityMonitor instance = new ActivityMonitor(new AppStateObserver());

    protected OmidTimestamp clock = new OmidTimestamp();

    private ActivityMonitor(AppStateObserver appStateObserver) {
        this.appStateObserver = appStateObserver;
    }

    public static ActivityMonitor getInstance() {
        return instance;
    }

    @VisibleForTesting
    static ActivityMonitor createInstance(AppStateObserver appStateObserver) {
        return new ActivityMonitor(appStateObserver);
    }

    private Date lastActivityDate;

    public Date getLastActivityDate() {
        return lastActivityDate != null ? (Date) lastActivityDate.clone() : null;
    }

    private boolean isStarted;
    private AppStateObserver appStateObserver;
    private boolean appStateActive;

    public void start(@NonNull Context context) {
        if (!isStarted) {
            appStateObserver.init(context);
            appStateObserver.setAppStateObserverListener(this);
            appStateObserver.start();
            appStateActive = appStateObserver.isActive();
            isStarted = true;
        }
    }

    public void onAppStateChanged(boolean isActive) {
        if (!appStateActive && isActive) {
            updateActivity();
        }
        appStateActive = isActive;
    }

    public void updateActivity() {
        Date date = clock.getCurrentDate();
        if (lastActivityDate == null || date.after(lastActivityDate)) {
            lastActivityDate = date;
            publishActivity();
        }
    }

    private void publishActivity() {
        if (!isStarted || lastActivityDate == null) { return; }
        for (final AdSessionInternal adSession : AdSessionRegistry.getInstance().getActiveAdSessions()) {
            adSession.getAdSessionStatePublisher().publishLastActivity(getLastActivityDate());
        }
    }
}
