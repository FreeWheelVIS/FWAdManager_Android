package com.iab.omid.library.freewheeltv.internal;

import android.content.Context;
import android.os.Handler;
import androidx.annotation.VisibleForTesting;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.devicevolume.DeviceVolumeConverter;
import com.iab.omid.library.freewheeltv.devicevolume.DeviceVolumeConverterFactory;
import com.iab.omid.library.freewheeltv.devicevolume.DeviceVolumeListener;
import com.iab.omid.library.freewheeltv.devicevolume.DeviceVolumeObserver;
import com.iab.omid.library.freewheeltv.devicevolume.DeviceVolumeObserverFactory;
import com.iab.omid.library.freewheeltv.walking.TreeWalker;

import java.util.Collection;

public class OmidManager implements AppStateObserver.AppStateObserverListener, DeviceVolumeListener {

    private static OmidManager instance;
    private float deviceVolume = 0f;

    private final DeviceVolumeObserverFactory deviceVolumeObserverFactory;
    private final DeviceVolumeConverterFactory deviceVolumeConverterFactory;

    private DeviceVolumeObserver deviceVolumeObserver;
    private AdSessionRegistry adSessionRegistry;

    public OmidManager(final DeviceVolumeObserverFactory deviceVolumeObserverFactory,
                       final DeviceVolumeConverterFactory deviceVolumeConverterFactory) {
        this.deviceVolumeObserverFactory = deviceVolumeObserverFactory;
        this.deviceVolumeConverterFactory = deviceVolumeConverterFactory;
    }

    // Note : this method is required by the tests, do not remove
    private static OmidManager createInstance() {
        DeviceVolumeConverterFactory deviceVolumeConverterFactory = new DeviceVolumeConverterFactory();
        DeviceVolumeObserverFactory deviceVolumeObserverFactory = new DeviceVolumeObserverFactory();
        return new OmidManager(deviceVolumeObserverFactory, deviceVolumeConverterFactory);
    }

    public static OmidManager getInstance() {
        if(instance == null) {
            final DeviceVolumeConverterFactory deviceVolumeConverterFactory =
                new DeviceVolumeConverterFactory();
            final DeviceVolumeObserverFactory deviceVolumeObserverFactory =
                new DeviceVolumeObserverFactory();
            instance = new OmidManager(deviceVolumeObserverFactory, deviceVolumeConverterFactory);
        }

        return instance;
    }

    public void init(final Context context) {
        final DeviceVolumeConverter deviceVolumeConverter =
            deviceVolumeConverterFactory.createNewInstance();
        deviceVolumeObserver = deviceVolumeObserverFactory.createNewInstance(new Handler(), context,
            deviceVolumeConverter, this);
    }

    // should be called when first session activated (view registered)
    public void start() {
        AdSessionAppStateObserver.getInstance().setAppStateObserverListener(this);
        AdSessionAppStateObserver.getInstance().start();
        TreeWalker.getInstance().start();
        deviceVolumeObserver.start();
    }

    // should be called when all session removed or their views unregistered
    public void stop() {
        TreeWalker.getInstance().stop();
        AdSessionAppStateObserver.getInstance().stop();
        deviceVolumeObserver.stop();
    }

    @Override
    public void onAppStateChanged(boolean isActive) {
        if (isActive) {
            TreeWalker.getInstance().start();
        } else {
            TreeWalker.getInstance().pause();
        }
    }

    @VisibleForTesting
    static void setInstance(OmidManager instance) {
        OmidManager.instance = instance;
    }

    @Override
    public void onDeviceVolumeChanged(final float deviceVolume) {
        this.deviceVolume = deviceVolume;

        final Collection<AdSessionInternal> activeAdSessions =
            getAdSessionRegistryInstance().getActiveAdSessions();
        for(final AdSessionInternal adSession : activeAdSessions) {
            adSession.getAdSessionStatePublisher().setDeviceVolume(deviceVolume);
        }
    }

    private AdSessionRegistry getAdSessionRegistryInstance() {
        if(adSessionRegistry == null) {
            adSessionRegistry = AdSessionRegistry.getInstance();
        }

        return adSessionRegistry;
    }

    @VisibleForTesting
    protected void setAdSessionRegistryInstance(final AdSessionRegistry adSessionRegistry) {
        this.adSessionRegistry = adSessionRegistry;
    }

    public float getDeviceVolume() {
        return deviceVolume;
    }
}