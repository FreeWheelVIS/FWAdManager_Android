package com.iab.omid.library.freewheeltv.processor;

import static com.iab.omid.library.freewheeltv.utils.OmidViewUtil.getZ;

import android.view.View;
import androidx.annotation.NonNull;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import com.iab.omid.library.freewheeltv.utils.OmidJSONUtil;
import com.iab.omid.library.freewheeltv.utils.OmidOutputDeviceUtil;
import com.iab.omid.library.freewheeltv.utils.OmidViewUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.IdentityHashMap;
import org.json.JSONObject;

public class ScreenProcessor implements NodeProcessor {

    private final NodeProcessor childrenProcessor;

    public ScreenProcessor(NodeProcessor childrenProcessor) {
        this.childrenProcessor = childrenProcessor;
    }

    @Override
    public JSONObject getState(View view) {
        JSONObject viewState = OmidJSONUtil.createViewState(0, 0, 0, 0);
        OmidJSONUtil.addOutputDeviceStatus(viewState, OmidOutputDeviceUtil.getOutputDeviceStatus());
        return viewState;
    }

    @Override
    public void iterateChildren(View view, JSONObject viewState, ViewWalker walker, boolean sortByZ, boolean hasFriendlyObstructionAncestor) {
        ArrayList<View> rootViews = buildRootViews();
        for(View rootView : rootViews) {
            walker.walkView(rootView, childrenProcessor, viewState, hasFriendlyObstructionAncestor);
        }
    }

    @NonNull
    ArrayList<View> buildRootViews() {
        ArrayList<View> rootViews = new ArrayList<>();
        AdSessionRegistry registry = AdSessionRegistry.getInstance();
        if(registry != null) {
            Collection<AdSessionInternal> activeAdSessions = registry.getActiveAdSessions();
            int expectedMaxSize = activeAdSessions.size() * 2 + 3;
            IdentityHashMap<View, View> seenRootViews = new IdentityHashMap<>(expectedMaxSize);
            for(AdSessionInternal adSession : activeAdSessions) {
                View adView = adSession.getAdView();
                if(adView != null && OmidViewUtil.isViewTreeDisplayed(adView)) {
                    View rootView = adView.getRootView();
                    if(rootView != null && !seenRootViews.containsKey(rootView)) {
                        seenRootViews.put(rootView, rootView);
                        float childZ = getZ(rootView);
                        int insertIndex = rootViews.size();
                        while(insertIndex > 0 && getZ(rootViews.get(insertIndex-1)) > childZ) {
                            insertIndex--;
                        }
                        rootViews.add(insertIndex, rootView);
                    }
                }
            }
        }
        return rootViews;
    }
}
