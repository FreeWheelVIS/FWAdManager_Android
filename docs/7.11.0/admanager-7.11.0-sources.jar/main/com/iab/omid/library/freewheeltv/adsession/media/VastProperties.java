package com.iab.omid.library.freewheeltv.adsession.media;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_POSITION_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.JSON_ERROR;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VAST_PROPERTIES_AUTOPLAY;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VAST_PROPERTIES_POSITION;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VAST_PROPERTIES_SKIPOFFSET;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.VAST_PROPERTIES_SKIPPABLE;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import com.iab.omid.library.freewheeltv.utils.OmidLogs;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * This object is used to capture key VAST properties so this can be shared with all registered verification providers.
 * <p>
 * Created by Natasha Garner on 09/09/2017.
 *
 */

public final class VastProperties {
    private static final String TAG = "VastProperties: ";

    private final boolean isSkippable;
    private final Float skipOffset;
    private final boolean isAutoPlay;
    private final Position position;

    private VastProperties(final boolean isSkippable, final Float skipOffset,
                           final boolean isAutoPlay, final Position position) {
        this.isSkippable = isSkippable;
        this.skipOffset = skipOffset;
        this.isAutoPlay = isAutoPlay;
        this.position = position;
    }

    /**
     * This method enables the media player to create a new VAST properties instance for skippable media ad placement.
     *
     * @param skipOffset number of seconds before the skip button is presented
     * @param isAutoPlay whether the media will auto-play content
     * @param position of the media in relation to other content
     * @return new instance of VAST properties
     * @throws IllegalArgumentException if the supplied Position is null.
     */
    public static VastProperties createVastPropertiesForSkippableMedia(final float skipOffset,
                                                                       final boolean isAutoPlay,
                                                                       final Position position) {
        confirmNotNull(position, ERROR_POSITION_NULL);
        return new VastProperties(true, skipOffset, isAutoPlay, position);
    }

    /**
     * This method enables the media player to create a new VAST properties instance for non-skippable media ad placement.
     *
     * @param isAutoPlay whether the media will auto-play content
     * @param position of the media in relation to other content
     * @return new instance of VAST properties
     * @throws IllegalArgumentException if the supplied Position is null.
     */
    public static VastProperties createVastPropertiesForNonSkippableMedia(final boolean isAutoPlay,
                                                                          final Position position) {
        confirmNotNull(position, ERROR_POSITION_NULL);
        return new VastProperties(false, null, isAutoPlay, position);
    }

    /**
     * Indicates if these properties are for skippable or non-skippable media.
     *
     * @return whether media is skippable or non-skippable
     */
    public boolean isSkippable() {
        return isSkippable;
    }

    /**
     * Gets the skip offset (number of seconds after which media is skippable).
     *
     * @return number of seconds before the skip button is presented
     */
    public Float getSkipOffset() {
        return skipOffset;
    }

    /**
     * Indicates if these properties are for an auto-play media or not.
     *
     * @return whether the media will auto-play content
     */
    public boolean isAutoPlay() {
        return isAutoPlay;
    }

    /**
     * Gets the player position indicated by these properties.
     *
     * @return position of the media in relation to other content
     */
    public com.iab.omid.library.freewheeltv.adsession.media.Position getPosition() {
        return position;
    }

    /**
     * For OM SDK internal use only.
     */
    public JSONObject toJSON() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(VAST_PROPERTIES_SKIPPABLE, isSkippable);
            if(isSkippable) {
                jsonObject.put(VAST_PROPERTIES_SKIPOFFSET, skipOffset);
            }
            jsonObject.put(VAST_PROPERTIES_AUTOPLAY, isAutoPlay);
            jsonObject.put(VAST_PROPERTIES_POSITION, position);
        } catch (JSONException e) {
            OmidLogs.e(TAG + JSON_ERROR, e);
        }
        return jsonObject;
    }
}
