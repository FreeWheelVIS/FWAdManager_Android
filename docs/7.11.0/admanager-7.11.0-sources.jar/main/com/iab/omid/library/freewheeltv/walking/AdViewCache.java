package com.iab.omid.library.freewheeltv.walking;




import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_HAS_WINDOW_FOCUS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_NO_ADVIEW;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_NO_WINDOW_FOCUS;
import static com.iab.omid.library.freewheeltv.internal.OmidBridge.KEY_STATE_NOT_VISIBLE_NOT_ATTACHED;

import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import androidx.annotation.VisibleForTesting;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.internal.AdSessionRegistry;
import com.iab.omid.library.freewheeltv.internal.FriendlyObstruction;
import com.iab.omid.library.freewheeltv.utils.OmidViewUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public class AdViewCache {

    public static class FriendlyObstructionData {
        private final FriendlyObstruction friendlyObstruction;
        private final ArrayList<String> sessionIds = new ArrayList<>();

        public FriendlyObstructionData(FriendlyObstruction friendlyObstruction, String adSessionId) {
            this.friendlyObstruction = friendlyObstruction;
            addAdSessionId(adSessionId);
        }

        public void addAdSessionId(String adSessionId) {
            sessionIds.add(adSessionId);
        }

        public FriendlyObstruction getFriendlyObstruction() {
            return friendlyObstruction;
        }

        public ArrayList<String> getSessionIds() {
            return sessionIds;
        }
    }

    private final HashMap<View, String> visibleAdViews = new HashMap<>();
    private final HashMap<View, FriendlyObstructionData> friendlyObstructionDataMap = new HashMap<>();
    private final HashMap<String, View> notVisibleAdViews = new HashMap<>();
    private final HashSet<View> parentViews = new HashSet<>();
    private final HashSet<String> visibleSessionIds = new HashSet<>();
    private final HashSet<String> notVisibleSessionIds = new HashSet<>();
    private final HashMap<String, String> notVisibleReason = new HashMap<>();
    private final HashSet<String> pipSessionIds = new HashSet<>();
    /**
     * This map holds ad views (as keys) that do not have window focus.
     * The boolean value of the map represent whether the out-of-focus window state has been
     * published or not. Note that the this map should not be cleared on the end of a poll cycle
     * since it needs to maintain the window focus state of ad views across polls.
     */
    private final Map<View, Boolean> outOfFocusAdViews = new WeakHashMap<>();

    private boolean isAdViewProcessed;

    public AdViewCache() {}

    public HashSet<String> getVisibleSessionIds() {
        return visibleSessionIds;
    }

    public HashSet<String> getNotVisibleSessionIds() {
        return notVisibleSessionIds;
    }

    public String getNotVisibleReason(String sessionId) {
        return notVisibleReason.get(sessionId);
    }

    public void prepare() {
        AdSessionRegistry registry = AdSessionRegistry.getInstance();
        if(registry != null) {
            for(AdSessionInternal adSession : registry.getActiveAdSessions()) {
                View adView = adSession.getAdView();
                if(adSession.isActive()) {
                    String adSessionId = adSession.getAdSessionId();
                    if(adView != null) {
                        boolean isInPip = OmidViewUtil.isContainingActivityInPiP(adView);
                        if (isInPip) {
                            pipSessionIds.add(adSessionId);
                        }
                        String notVisibleReason = buildParentViews(adView, isInPip);

                        if(notVisibleReason == null) {
                            visibleSessionIds.add(adSessionId);
                            visibleAdViews.put(adView, adSessionId);
                            prepareFriendlyObstructions(adSession);
                        } else if (notVisibleReason != KEY_STATE_NOT_VISIBLE_NO_WINDOW_FOCUS) {
                            notVisibleSessionIds.add(adSessionId);
                            notVisibleAdViews.put(adSessionId, adView);
                            this.notVisibleReason.put(adSessionId, notVisibleReason);
                        }
                    } else {
                        notVisibleSessionIds.add(adSessionId);
                        notVisibleReason.put(adSessionId, KEY_STATE_NOT_VISIBLE_NO_ADVIEW);
                    }
                }
            }
        }
    }

    private String buildParentViews(View adView, boolean isInPip) {
        // Builds the full set of parent views for visible ads.
        // Returns null for visible ads, or not visible reason for ads that are not visible.
        if (VERSION.SDK_INT >= VERSION_CODES.KITKAT && !adView.isAttachedToWindow()) {
            return KEY_STATE_NOT_VISIBLE_NOT_ATTACHED;
        }

        if (gateOnWindowFocus(adView) && !isInPip) {
            return KEY_STATE_NOT_VISIBLE_NO_WINDOW_FOCUS;
        }

        HashSet<View> temp = new HashSet<>();
        View view = adView;
        while (view != null) {
            String notVisibleReason = OmidViewUtil.checkViewNotVisibleReason(view);
            if(notVisibleReason != null) {
                return notVisibleReason;
            }
            temp.add(view);
            ViewParent parent = view.getParent();
            view = (parent instanceof View) ? (View) parent : null;
        }
        parentViews.addAll(temp);
        return null;
    }

    // If an ad view does not have window focus, perform a view traversal
    // and publish the view state just once until the window regains focus.
    private Boolean gateOnWindowFocus(View adView) {
        if (adView.hasWindowFocus()) {
            outOfFocusAdViews.remove(adView);
            return false;
        }

        if (outOfFocusAdViews.containsKey(adView)) {
            // Allow traversal to run if the out of focus state has not been published yet.
            return outOfFocusAdViews.get(adView);
        } else {
            // If this is the first time no window has been detected, don't gate and allow the
            // traversal to run.
            outOfFocusAdViews.put(adView, false);
            return false;
        }
    }

    private void prepareFriendlyObstructions(AdSessionInternal adSession) {
        for (FriendlyObstruction friendlyObstruction : adSession.getAllFriendlyObstructions()) {
            addFriendlyObstruction(friendlyObstruction, adSession);
        }
    }

    // If a friendly obstruction view is registered in multiple ad sessions, the purpose and reason
    // fields of only the friendly obstruction in the first registered AdSession are used.
    private void addFriendlyObstruction(FriendlyObstruction friendlyObstruction, AdSessionInternal adSession) {
        View friendlyObstructionView = friendlyObstruction.getObstructionView().get();
        if (friendlyObstructionView == null) return;

        FriendlyObstructionData friendlyObstructionData = friendlyObstructionDataMap.get(friendlyObstructionView);
        if (friendlyObstructionData != null) {
            friendlyObstructionData.addAdSessionId(adSession.getAdSessionId());
        } else {
            friendlyObstructionDataMap.put(friendlyObstructionView,
                    new FriendlyObstructionData(friendlyObstruction, adSession.getAdSessionId()));
        }
    }

    public void cleanup() {
        visibleAdViews.clear();
        friendlyObstructionDataMap.clear();
        notVisibleAdViews.clear();
        parentViews.clear();
        visibleSessionIds.clear();
        notVisibleSessionIds.clear();
        notVisibleReason.clear();
        isAdViewProcessed = false;
        pipSessionIds.clear();
    }

    public void onAdViewProcessed() {
        isAdViewProcessed = true;
    }

    public String getSessionId(View view) {
        if(visibleAdViews.size() == 0) {
            return null;
        }
        String sessionId = visibleAdViews.get(view);
        if(sessionId != null) {
            visibleAdViews.remove(view);
        }
        return sessionId;
    }

    public View getNotVisibleAd(String sessionId) {
        return  notVisibleAdViews.get(sessionId);
    }

    public FriendlyObstructionData getFriendlyObstructionData(View view) {
        FriendlyObstructionData friendlyObstructionData = friendlyObstructionDataMap.get(view);
        if (friendlyObstructionData != null) {
            friendlyObstructionDataMap.remove(view);
        }
        return friendlyObstructionData;
    }


    public ViewType getViewType(View view) {
        if(parentViews.contains(view)) {
            return ViewType.PARENT_VIEW;
        }
        return (isAdViewProcessed) ? ViewType.OBSTRUCTION_VIEW : ViewType.UNDERLYING_VIEW;
    }

    /**
     * Updates the adViewCache when the window focus state is published.
     * @param adView the "visible" ad view to publish the state for.
     * @return true if the ad view has window focus. False otherwise.
     */
    public boolean onPublishHasWindowFocus(View adView) {
        if (outOfFocusAdViews.containsKey(adView)) {
            // If the ad view does not have window focus, signal that the state has been published.
            outOfFocusAdViews.put(adView, true);
            return false;
        } else {
            // If the ad view has window focus, do nothing.
            return true;
        }
    }

    public boolean isPictureInPictureActiveForSessionId(String adSessionId) {
        return pipSessionIds.contains(adSessionId);
    }

    @VisibleForTesting
    HashMap<View, String> getVisibleAdViews() {
        return visibleAdViews;
    }

    @VisibleForTesting
    HashMap<View, FriendlyObstructionData> getFriendlyObstructions() {
        return friendlyObstructionDataMap;
    }

    @VisibleForTesting
    HashSet<View> getParentViews() {
        return parentViews;
    }
}
