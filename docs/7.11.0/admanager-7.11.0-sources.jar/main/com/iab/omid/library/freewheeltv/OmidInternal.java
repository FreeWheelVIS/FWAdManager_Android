package com.iab.omid.library.freewheeltv;

import static com.iab.omid.library.freewheeltv.internal.Errors.APPLICATION_CONTEXT_CANNOT_BE_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.checkOmidActive;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import android.content.Context;
import com.iab.omid.library.freewheeltv.internal.AdSessionAppStateObserver;
import com.iab.omid.library.freewheeltv.internal.InstanceManager;
import com.iab.omid.library.freewheeltv.internal.OmidManager;
import com.iab.omid.library.freewheeltv.internal.ActivityMonitor;
import com.iab.omid.library.freewheeltv.internal.ScreenStateObserver;
import com.iab.omid.library.freewheeltv.utils.OmidDeviceCategoryUtil;
import com.iab.omid.library.freewheeltv.utils.OmidOutputDeviceUtil;
import com.iab.omid.library.freewheeltv.utils.OmidJSONUtil;
import tv.freewheel.ad.BuildConfig;

/**
 * For OM SDK internal use only.
 * <p>
 * Created by Natasha Garner on 22/06/2017.
 */
public class OmidInternal {

    private boolean isActive;

    /**
     * Access the running OM SDK semantic version.
     *
     * @return the current semantic version of the integrated OM SDK.
     */
    String getVersion() {
        return BuildConfig.VERSION_NAME + "-" + BuildConfig.PARTNER_NAME;
    };

    /**
     * Used to determine if the running OM SDK is active before attempting to create any ad
     * sessions.
     *
     * @return true if the OM SDK has already been activated.
     */
    boolean isActive() {
        return isActive;
    }

    void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * Activate OM SDK prior to calling any other API methods. On CTV, should be called on launch.
     * @param applicationContext of the running application.
     * @throws IllegalArgumentException if the supplied application context is null.
     */
    void activate(final Context applicationContext) {
        validateContext(applicationContext);

        if(!isActive()) {
            setActive(true);
            OmidManager.getInstance().init(applicationContext);
            AdSessionAppStateObserver.getInstance().init(applicationContext);
            OmidDeviceCategoryUtil.init(applicationContext);
            OmidJSONUtil.init(applicationContext);
            OmidOutputDeviceUtil.init(applicationContext);
            InstanceManager.getInstance().setContext(applicationContext);
            ActivityMonitor.getInstance().start(applicationContext);
            ScreenStateObserver.getInstance().start(applicationContext);
        }
    }

    /**
     *  Notify OM SDK when the user interacts.
     */
    void updateLastActivity() {
        checkOmidActive();
        ActivityMonitor.getInstance().updateActivity();
    }

    /**
     * Check the validity of the context: it cannot be null.
     * @param applicationContext of the running application.
     * @throws IllegalArgumentException if the supplied application context is null.
     */
    private void validateContext(Context applicationContext) {
        confirmNotNull(applicationContext, APPLICATION_CONTEXT_CANNOT_BE_NULL);
    }
}
