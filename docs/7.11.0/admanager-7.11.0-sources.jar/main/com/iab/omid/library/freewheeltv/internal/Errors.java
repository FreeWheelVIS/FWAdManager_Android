package com.iab.omid.library.freewheeltv.internal;

/**
 * Created by Natasha Garner on 03/07/2017.
 */
public class Errors {

    // Omid errors
    public static final String APPLICATION_CONTEXT_CANNOT_BE_NULL =
        "Application Context cannot be null";

    // ScriptSource errors
    public static final String METHOD_CALLED_BEFORE_ACTIVATION = "Method called before OM SDK " +
        "activation";

    // ScriptInjector errors
    public static final String ERROR_HTML_NULL_OR_EMPTY = "HTML is null or empty";

    // Partner errors
    public static final String ERROR_NAME_NULL_OR_EMPTY = "Name is null or empty";
    public static final String ERROR_VERSION_NULL_OR_EMPTY = "Version is null or empty";

    // VerificationScriptResource errors
    public static final String ERROR_VENDOR_KEY_NULL_OR_EMPTY = "VendorKey is null or empty";
    public static final String ERROR_RESOURCE_URL_NULL = "ResourceURL is null";
    public static final String ERROR_VERIFICATION_PARAMETERS_NULL_OR_EMPTY =
        "VerificationParameters is null or empty";

    // AdSessionContext errors
    public static final String ERROR_PARTNER_NULL = "Partner is null";
    public static final String ERROR_WEBVIEW_NULL = "WebView is null";
    public static final String ERROR_REFERENCE_DATA_GREATER_THAN_256_CHARACTERS =
        "CustomReferenceData is greater than 256 characters";
    public static final String ERROR_VERIFICATION_SCRIPT_NULL =
        "VerificationScriptResources is null";
    public static final String ERROR_OMID_JS_SCRIPT_CONTENT_NULL =
        "OM SDK JS script content is null";

    // AdSession errors
    public static final String ERROR_ADSESSION_CONTEXT_NULL = "AdSessionContext is null";
    public static final String ERROR_ADSESSION_CONFIGURATION_NULL = "AdSessionConfiguration is " +
        "null";
    public static final String ERROR_ADVIEW_NULL = "AdView is null";
    public static final String ERROR_ADSESSION_NOT_STARTED = "AdSession is not started";
    public static final String ERROR_ADVIEW_NOT_SAME = "AdView is not the same";
    public static final String ERROR_FRIENDLY_OBSTRUCTION_NULL = "FriendlyObstruction is null";
    public static final String ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_TOO_LONG =
            "FriendlyObstruction has detailed reason over 50 characters in length";
    public static final String ERROR_FRIENDLY_OBSTRUCTION_DETAILED_REASON_ILLEGAL_CHARACTERS =
            "FriendlyObstruction has detailed reason that contains characters not in "
            + "[a-z][A-Z][0-9] or space";
    public static final String ERROR_TYPE_NULL = "Error type is null";
    public static final String ERROR_MESSAGE_NULL = "Message is null";
    public static final String ERROR_IMPRESSION_ALREADY_SENT = "Impression event can only be sent once";
    public static final String ERROR_LOADED_ALREADY_SENT = "Loaded event can only be sent once";

    // AdSessionConfiguration errors
    public static final String ERROR_IMPRESSION_OWNER_NULL = "Impression owner is null";
    public static final String ERROR_IMPRESSION_OWNER_NONE = "Impression owner is none";
    public static final String ERROR_IMPRESSION_OWNER_MISMATCH = "ImpressionType/CreativeType can "
        + "only be defined as DEFINED_BY_JAVASCRIPT if Impression Owner is JavaScript";
    public static final String ERROR_CREATIVE_TYPE_NULL = "CreativeType is null";
    public static final String ERROR_IMPRESSION_TYPE_NULL = "ImpressionType is null";

    // AdSessionStatePublisher errors
    public static final String JSON_ERROR = "JSON error";

    // AdEvents errors
    public static final String ERROR_ADSESSION_NULL = "AdSession is null";
    public static final String ERROR_ADEVENTS_EXISTS = "AdEvents already exists for AdSession";
    public static final String ERROR_ADSESSION_STARTED = "AdSession is started";
    public static final String ERROR_ADSESSION_FINISHED = "AdSession is finished";
    public static final String ERROR_NOT_EXPECTING_NATIVE_IMPRESSION = "Impression event is not " +
        "expected from the Native AdSession";

    // VastProperties errors
    public static final String ERROR_POSITION_NULL = "Position is null";

    // TOOO: Delete these VideEvents errors once VideoEvents class is removed after deprecation
    public static final String ERROR_CANNOT_CREATE_VIDEO_EVENTS_FOR_JAVASCRIPT = "Cannot create " +
            "VideoEvents for JavaScript AdSession";
    public static final String ERROR_VIDEOEVENTS_EXISTS = "VideoEvents already exists for " +
            "AdSession";

    // MediaEvents errors
    public static final String ERROR_MEDIAEVENTS_EXISTS = "MediaEvents already exists for " +
        "AdSession";
    public static final String ERROR_VASTPROPERTIES_NULL = "VastProperties is null";
    public static final String ERROR_INVALID_MEDIA_DURATION = "Invalid Media duration";
    public static final String ERROR_INVALID_MEDIA_VOLUME = "Invalid Media volume";
    public static final String ERROR_PLAYERSTATE_NULL = "PlayerState is null";
    public static final String ERROR_INTERACTIONTYPE_NULL = "InteractionType is null";
    public static final String ERROR_CANNOT_CREATE_MEDIA_EVENTS_FOR_JAVASCRIPT = "Cannot create " +
        "MediaEvents for JavaScript AdSession";

    // OmidBridge errors
    public static final String ERROR_OMIDBRIDGE_WEBVIEW_NULL = "The WebView is null for ";

    // JavaScriptSessionService errors
    public static final String ERROR_JAVASCRIPT_SESSION_SERVICE_NOT_SUPPORTED =
        "The JavaScriptSessionService cannot be supported in this WebView version.";
}
