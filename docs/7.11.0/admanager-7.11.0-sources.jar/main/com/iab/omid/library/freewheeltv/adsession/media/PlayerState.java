package com.iab.omid.library.freewheeltv.adsession.media;

/**
 * List of supported media event player states.
 * <p>
 * Created by Natasha Garner on 09/09/2017.
 */

public enum PlayerState {
    /**
     * The player is collapsed in such a way that the video is hidden.
     * The video may or may not still be progressing in this state, and sound may be audible.
     * This refers specifically to the video player state on the page, and not the state of
     * the browser window.
     */
    MINIMIZED("minimized"),
    /**
     * The player has been reduced from its original size.
     * The video is still potentially visible.
     */
    COLLAPSED("collapsed"),
    /**
     * The player's default playback size.
     */
    NORMAL("normal"),
    /**
     * The player has expanded from its original size.
     */
    EXPANDED("expanded"),
    /**
     * The player has entered fullscreen mode.
     */
    FULLSCREEN("fullscreen");

    private final String playerState;

    PlayerState(String playerState) {
        this.playerState = playerState;
    }

    @Override
    public String toString() {
        return playerState;
    }
}
