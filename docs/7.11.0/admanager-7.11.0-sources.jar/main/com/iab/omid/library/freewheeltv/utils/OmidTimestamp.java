package com.iab.omid.library.freewheeltv.utils;

import java.util.Date;

public class OmidTimestamp {

    /**
     * System timestamp in nanoseconds with an arbitrary epoch (see System.nanoTime())
     */
    public static long getCurrentTime() {
        return System.nanoTime();
    }

    /**
     * System timestamp in milliseconds since 1970-01-01 UTC (see Date.getTime())
     */
    public Date getCurrentDate() {
        return new Date();
    }
}
