package com.iab.omid.library.freewheeltv.publisher;

import static com.iab.omid.library.freewheeltv.utils.OmidJSONUtil.jsonPut;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.util.Log;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.iab.omid.library.freewheeltv.adsession.AdSessionContext;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import com.iab.omid.library.freewheeltv.adsession.VerificationScriptResource;
import com.iab.omid.library.freewheeltv.internal.InstanceManager;
import com.iab.omid.library.freewheeltv.internal.OmidBridge;
import com.iab.omid.library.freewheeltv.utils.OmidTimestamp;

import org.json.JSONObject;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by Natasha Garner on 16/08/2017.
 */
public class NativeAdSessionStatePublisher extends AdSessionStatePublisher {
    private WebView webView;
    private Long webViewCreated = null;
    private final Map<String, VerificationScriptResource> injectedResourcesMap;
    private final String omidJsScriptContent;

    public NativeAdSessionStatePublisher(String adSessionId, Map<String, VerificationScriptResource> injectedResourcesMap, String omidJsScriptContent) {
        super(adSessionId);
        this.injectedResourcesMap = injectedResourcesMap;
        this.omidJsScriptContent = omidJsScriptContent;
    }

    @Override
    public void start() {
        super.start();
        createTrackingWebView();
    }

    @SuppressLint("SetJavaScriptEnabled")
    void createTrackingWebView() {
        webView = new WebView(InstanceManager.getInstance().getContext());
        webView.getSettings().setJavaScriptEnabled(true);
        // Disable content URL access within WebView
        webView.getSettings().setAllowContentAccess(false);
        // Disable file access
        webView.getSettings().setAllowFileAccess(false);

        // Gracefully manage the WebView renderer crashing or running out of memory.
        webView.setWebViewClient(new WebViewClient() {
            final String TAG = "NativeBridge";

            @Override
            public boolean onRenderProcessGone(final WebView view, RenderProcessGoneDetail detail) {
                Log.w(TAG, "WebView renderer gone: " + detail.toString() + "for WebView: " + view);
                if (getWebView() == view) {
                    Log.w(TAG, "Deallocating the Native bridge as it is unusable. No further events will be generated for this session.");
                    setWebView(null);
                }
                // destroy the view as it is unusable from now on
                view.destroy();
                return true;
            }
        });


        setWebView(webView);
        OmidBridge.getInstance().injectJavaScript(webView, omidJsScriptContent);

        for (String injectionId : injectedResourcesMap.keySet()) {
            VerificationScriptResource javaScriptResource = injectedResourcesMap.get(injectionId);
            String javascriptUrl = javaScriptResource.getResourceUrl().toExternalForm();
            OmidBridge.getInstance().injectJavaScriptResource(webView, javascriptUrl, injectionId);
        }
        webViewCreated = OmidTimestamp.getCurrentTime();
    }

    @Override
    public void publishStartEvent(AdSessionInternal adSession, AdSessionContext adSessionContext) {
        JSONObject injectedResources = new JSONObject();
        // The injectedResourcesMap member object & the one from session context are the same copy
        // but we need both copies due to the early loading of injectionId into the closure in webView
        Map<String, VerificationScriptResource> injectedResourcesMap = adSessionContext.getInjectedResourcesMap();
        for (String injectionId : injectedResourcesMap.keySet()) {
            VerificationScriptResource resource = injectedResourcesMap.get(injectionId);
            jsonPut(injectedResources, injectionId, resource.toJsonObject());
        }

        publishStartEventInternal(adSession, adSessionContext, injectedResources);
    }

    @Override
    public void finish() {
        super.finish();
        // Delay destroying the WebView to ensure the finish event can be processed by Verification
        // Resources. The WebView must be around for a minimum of 4 seconds, and for a minimum of
        // 2 seconds after finish has been called.
        long minDelayAfterFinishInMs = 2000;
        long minWebViewExistenceInMs = 4000;
        long timeSinceWebViewCreationInMS = webViewCreated == null ? minWebViewExistenceInMs : TimeUnit.MILLISECONDS.convert(OmidTimestamp.getCurrentTime() - webViewCreated, TimeUnit.NANOSECONDS);
        long delay = Math.max(minWebViewExistenceInMs - timeSinceWebViewCreationInMS, minDelayAfterFinishInMs);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            private final WebView runnableWebView = webView;

            @Override
            public void run() {
                runnableWebView.destroy();
            }
        }, delay);
        webView = null;
    }
}
