package com.iab.omid.library.freewheeltv.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import androidx.annotation.NonNull;
import com.iab.omid.library.freewheeltv.adsession.DeviceCategory;
import com.iab.omid.library.freewheeltv.adsession.OutputDeviceStatus;

/**
 * Utility class for determining information about the device's connection to an output device.
 */
public class OmidOutputDeviceUtil {
    public static final String ACTION_HDMI_AUDIO_PLUG = AudioManager.ACTION_HDMI_AUDIO_PLUG;
    public static final String EXTRA_AUDIO_PLUG_STATE = AudioManager.EXTRA_AUDIO_PLUG_STATE;
    // For ACTION_HDMI_AUDIO_PLUG, EXTRA_AUDIO_PLUG_STATE will be 0 if unplugged, 1 if plugged.
    // These values are defined by the OS. The default value is user-defined; we use -1.
    public static final int AUDIO_PLUG_STATE_UNPLUGGED = 0;
    public static final int AUDIO_PLUG_STATE_PLUGGED = 1;
    private static final int AUDIO_PLUG_STATE_DEFAULT = -1;

    private static OutputDeviceStatus status = OutputDeviceStatus.UNKNOWN;

    public static void init(@NonNull Context context) {
        IntentFilter intentFilter = new IntentFilter(ACTION_HDMI_AUDIO_PLUG);
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action == ACTION_HDMI_AUDIO_PLUG) {
                    int audioPlugged = intent.getIntExtra(EXTRA_AUDIO_PLUG_STATE, AUDIO_PLUG_STATE_DEFAULT);
                    if (audioPlugged == AUDIO_PLUG_STATE_UNPLUGGED) {
                        status = OutputDeviceStatus.NOT_DETECTED;
                    } else if (audioPlugged == AUDIO_PLUG_STATE_PLUGGED) {
                        status = OutputDeviceStatus.UNKNOWN;
                    }
                }
            }
        };
        // TODO(OMSDK-889): Figure out when if ever we can unregister this receiver.
        context.registerReceiver(broadcastReceiver, intentFilter);
    }

    /**
     * Get the current output device status, which describes whether there may be an output device
     * (such as a TV screen) connected to the device that can display the application.
     * If the device is not a CTV device, it is assumed that there is a display output built into
     * the device, so the result is always UNKNOWN.
     */
    public static OutputDeviceStatus getOutputDeviceStatus() {
        if (OmidDeviceCategoryUtil.getDeviceCategory() != DeviceCategory.CTV) {
            return OutputDeviceStatus.UNKNOWN;
        }
        return status;
    }
}
