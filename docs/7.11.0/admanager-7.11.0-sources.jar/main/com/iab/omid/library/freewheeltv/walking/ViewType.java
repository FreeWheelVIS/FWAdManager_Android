package com.iab.omid.library.freewheeltv.walking;

public enum ViewType {
    PARENT_VIEW,
    OBSTRUCTION_VIEW,
    UNDERLYING_VIEW
}
