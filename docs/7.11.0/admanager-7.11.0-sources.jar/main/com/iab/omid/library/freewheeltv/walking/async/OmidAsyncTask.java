package com.iab.omid.library.freewheeltv.walking.async;

import android.os.AsyncTask;
import androidx.annotation.VisibleForTesting;
import java.util.concurrent.ThreadPoolExecutor;
import org.json.JSONObject;

public abstract class OmidAsyncTask extends AsyncTask<Object, Void, String> {

    public interface OmidAsyncTaskListener {
        void onTaskCompleted(OmidAsyncTask task);
    }

    public interface StateProvider {
        JSONObject getPreviousState();
        void setPreviousState(JSONObject previousState);
    }

    private OmidAsyncTaskListener listener;
    protected final StateProvider stateProvider;

    public OmidAsyncTask(StateProvider stateProvider) {
        this.stateProvider = stateProvider;
    }

    public void setListener(OmidAsyncTaskListener listener) {
        this.listener = listener;
    }

    public OmidAsyncTaskListener getListener() {
        return listener;
    }

    public StateProvider getStateProvider() {
        return stateProvider;
    }

    public void start(ThreadPoolExecutor executor) {
        executeOnExecutor(executor);
    }

    @Override
    protected void onPostExecute(String result) {
        if(listener != null) {
            listener.onTaskCompleted(this);
        }
    }

    @VisibleForTesting
    String invokeDoInBackground() {
        return doInBackground();
    }

    @VisibleForTesting
    void invokeOnPostExecute(String result) {
        onPostExecute(result);
    }
}
