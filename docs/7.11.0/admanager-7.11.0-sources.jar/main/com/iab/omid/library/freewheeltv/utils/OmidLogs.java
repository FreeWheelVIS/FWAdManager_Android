package com.iab.omid.library.freewheeltv.utils;

import android.text.TextUtils;
import android.util.Log;
import tv.freewheel.ad.BuildConfig;

public final class OmidLogs {

    private static final String TAG = "OMIDLIB";

    private OmidLogs() { }

    public static void d(String msg) {
        if(BuildConfig.ENABLE_OMID_LOGS && !TextUtils.isEmpty(msg)) {
            Log.d(TAG, msg);
        }
    }

    public static void w(String msg) {
        if(BuildConfig.ENABLE_OMID_LOGS && !TextUtils.isEmpty(msg)) {
            Log.w(TAG, msg);
        }
    }

    public static void i(String msg) {
        if(BuildConfig.ENABLE_OMID_LOGS && !TextUtils.isEmpty(msg)) {
            Log.i(TAG, msg);
        }
    }

    public static void e(String msg) {
        if(BuildConfig.ENABLE_OMID_LOGS && !TextUtils.isEmpty(msg)) {
            Log.e(TAG, msg);
        }
    }

    public static void e(String msg, Exception e) {
        if(BuildConfig.ENABLE_OMID_LOGS && !TextUtils.isEmpty(msg) || e != null) {
            Log.e(TAG, msg, e);
        }
    }

}
