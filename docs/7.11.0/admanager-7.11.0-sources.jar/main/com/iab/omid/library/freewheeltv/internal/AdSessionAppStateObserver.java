package com.iab.omid.library.freewheeltv.internal;

import android.annotation.SuppressLint;
import android.view.View;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;

import java.util.Collection;

public class AdSessionAppStateObserver extends AppStateObserver {

    @SuppressLint("StaticFieldLeak")	// only holds the app context
    private static AdSessionAppStateObserver instance = new AdSessionAppStateObserver();

    private AdSessionAppStateObserver() {}

    public static AdSessionAppStateObserver getInstance() { return instance; }

    // Note : this method is required by the tests, do not remove
    private static AdSessionAppStateObserver createInstance() { return new AdSessionAppStateObserver(); }

    @Override
    public boolean overrideIsActive() {
        // If there are any active ad sessions, we can leverage `adView.hasWindowFocus()` to derive
        // the app state.
        for (final AdSessionInternal adSession : AdSessionRegistry.getInstance().getActiveAdSessions()) {
            View adView = adSession.getAdView();
            if (adView != null && adView.hasWindowFocus()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void publishAppStateChanged(boolean isActive) {
        for (final AdSessionInternal adSessionStatePublisher : AdSessionRegistry.getInstance().getAdSessions()) {
            adSessionStatePublisher.getAdSessionStatePublisher().setAppState(isActive);
        }
    }
}
