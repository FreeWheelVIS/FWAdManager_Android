package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_JAVASCRIPT_SESSION_SERVICE_NOT_SUPPORTED;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_PARTNER_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_WEBVIEW_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.checkOmidActive;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import com.iab.omid.library.freewheeltv.internal.FriendlyObstruction;
import com.iab.omid.library.freewheeltv.internal.FriendlyObstructions;
import com.iab.omid.library.freewheeltv.utils.OmidLogs;
import com.iab.omid.library.freewheeltv.utils.OmidWebViewUtil;
import com.iab.omid.library.freewheeltv.weakreference.WeakView;

import android.net.Uri;
import android.view.View;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat.WebMessageListener;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Service supporting ad sessions managed (started/finished) via JavaScript Session Client APIs
 * by providing native-layer measurement signals.
 * If the JS Session Client is running in a web view, an instance of this service must be
 * initialized with the web view before starting or finishing ad sessions using JS APIs.
 * Only one instance of this service may be initialized at a time for a given web view; to reuse a
 * web view the current instance must be torn down (see `tearDown`).
 */
public class JavaScriptSessionService {
    public interface TearDownHandler {
        public void onTearDown(boolean success);
    }

    private static String JS_MESSAGE_KEY_METHOD = "method";
    private static String JS_MESSAGE_KEY_DATA = "data";
    private static String JS_MESSAGE_LISTENER_JS_SESSION_SERVICE = "omidJsSessionService";
    private static String JS_MESSAGE_METHOD_START_SESSION = "startSession";
    private static String JS_MESSAGE_METHOD_FINISH_SESSION = "finishSession";
    private static String JS_MESSAGE_DATA_AD_SESSION_ID = "adSessionId";

    private static OmidWebViewUtil webViewUtil = new OmidWebViewUtil();

    private final Partner partner;
    private final WebView webView;
    private final boolean isHtmlAdView;
    private WeakView weakAdView;
    private final HashMap<String, AdSession> adSessions = new HashMap<String, AdSession>();
    private final FriendlyObstructions friendlyObstructions = new FriendlyObstructions();

    /**
     * Create and initialize an instance of the JavaScriptSessionService. Once this method is
     * called, ad sessions can be started and finished from the JS Session Client in the web view.
     *
     * @param partner Details of the integration partner responsible for ad sessions.
     * @param webView The web view responsible for starting/finishing ad sessions via the JS Session
     *                Client.
     * @param isHtmlAdView Whether the ad is rendered in HTML inside of the provided web view.
     * @throws UnsupportedOperationException if WebViewFeature.WEB_MESSAGE_LISTENER not supported;
     *                                       this should only happen for Android versions below 5.0
     *                                       and can be handled by measuring the ad a different way.
     * @throws IllegalArgumentException if the supplied partner or web view is null.
     * @throws IllegalStateException if this method is called before the OM SDK has been activated.
     */
    public static JavaScriptSessionService create(final Partner partner, final WebView webView,
                                                  boolean isHtmlAdView) {
        return new JavaScriptSessionService(partner, webView, isHtmlAdView);
    }

    private JavaScriptSessionService(final Partner partner, final WebView webView,
                                     boolean isHtmlAdView) {
        checkOmidActive();
        confirmNotNull(partner, ERROR_PARTNER_NULL);
        confirmNotNull(webView, ERROR_WEBVIEW_NULL);
        this.partner = partner;
        this.webView = webView;
        this.isHtmlAdView = isHtmlAdView;
        if (isHtmlAdView) {
            setAdView(webView);
        }
        addWebViewListener();
    }

    /**
     * Tear down this instance of the service.
     * Calling this method will cause OM SDK to begin a teardown process including finishing all
     * currently active ad sessions measured by this service instance and tearing down communication
     * with the OM SDK's JavaScript layer running in the web view.
     * This may require up to one second, for example in order to allow verification scripts time to
     * process the `sessionFinish` event.
     * Once this process has completed, the web view may be torn down or reused for another instance
     * of the service without any adverse effects. If there is no need to tear down or reuse the web
     * view, this method is not required.
     *
     * @param tearDownHandler Object whose onTearDown method is invoked by OM SDK after the teardown
     * process has completed, or one second, whichever comes sooner.
     */
    public void tearDown(TearDownHandler tearDownHandler) {
        for (AdSession adSession : adSessions.values()) {
            adSession.finish();
        }
        Timer timer = new Timer();
        timer.schedule(
            new TimerTask() {
                @Override
                public void run() {
                    removeWebViewListener();
                    tearDownHandler.onTearDown(true);
                    timer.cancel();
                }
            },
            1000
        );
    }

    /**
     * Sets the native view that contains the ad and is used for viewability tracking.
     * If `isHtmlAdView` was passed as true in the constructor, this method is
     * not required since the ad view will be set to the web view by default.
     *
     * @param adView The native view.
     */
    public void setAdView(final @Nullable View adView) {
        if (getAdView() == adView) {
            return;
        }
        for (AdSession adSession : adSessions.values()) {
            adSession.registerAdView(adView);
        }
        this.weakAdView = new WeakView(adView);
    }

    /**
     * Get the native view containing the ad, which was set using `setAdView`.
     * If `isHtmlAdView` was passed as true in the constructor, this will equal
     * the web view by default.
     */
    @Nullable View getAdView() {
        return weakAdView == null ? null : weakAdView.get();
    }

    /**
     * Add a friendly obstruction which should then be excluded from all ad session viewability
     * calculations. While this instance of JavaScriptSessionService is running, this friendly
     * obstruction will be added to each ad session started by the integrator via the JS Session
     * Client until the obstruction is removed by calling `removeFriendlyObstruction` or
     * `removeAllFriendlyObstructions`.
     *
     * @param friendlyObstructionView to be excluded from all ad session viewability calculations.
     * @param purpose             why this obstruction was necessary
     * @param detailedReason      an explanation for why this obstruction is part of the ad
     *                            experience if not already obvious from the
     *                            {@link FriendlyObstructionPurpose} selected. Must be 50 characters
     *                            or less and only contain characters `A-z`,`0-9` or space.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     * @throws IllegalArgumentException if the detailedReason is over 50 characters or contains a
     *                                  character that is not in `A-z`,`0-9` or a space.
     */
    public void addFriendlyObstruction(final View friendlyObstructionView,
                                       final FriendlyObstructionPurpose purpose,
                                       final @Nullable String detailedReason) {
        for (AdSession adSession : adSessions.values()) {
            adSession.addFriendlyObstruction(friendlyObstructionView, purpose, detailedReason);
        }
        friendlyObstructions.add(friendlyObstructionView, purpose, detailedReason);
    }

    /**
     * Remove a registered friendly obstruction from any currently running and future ad sessions
     * measured by this instance of JavaScriptSessionService.
     *
     * @param friendlyObstructionView to be removed from the list of registered friendly
     *                                obstructions.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     */
    public void removeFriendlyObstruction(final View friendlyObstructionView) {
        for (AdSession adSession : adSessions.values()) {
            adSession.removeFriendlyObstruction(friendlyObstructionView);
        }
        friendlyObstructions.remove(friendlyObstructionView);
    }

    /**
     * Remove all registered friendly obstructions from any currently running and future ad
     * sessions measured by this instance of JavaScriptSessionService.
     */
    public void removeAllFriendlyObstructions() {
        for (AdSession adSession : adSessions.values()) {
            adSession.removeAllFriendlyObstructions();
        }
        friendlyObstructions.removeAll();
    }

    /**
     * @throws UnsupportedOperationException if WebViewFeature.WEB_MESSAGE_LISTENER not supported.
     */
    private void addWebViewListener() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            throw new UnsupportedOperationException(ERROR_JAVASCRIPT_SESSION_SERVICE_NOT_SUPPORTED);
        }
        // Remove the previous listener in case there still is one.
        removeWebViewListener();
        WebMessageListener webMessageListener = new WebMessageListener() {
            @Override
            public void onPostMessage(
                    WebView view,
                    WebMessageCompat message,
                    Uri sourceOrigin,
                    boolean isMainFrame,
                    JavaScriptReplyProxy replyProxy) {
                String messageData = message.getData();
                try {
                    JSONObject obj = new JSONObject(messageData);
                    String method = obj.getString(JS_MESSAGE_KEY_METHOD);
                    JSONObject data = obj.getJSONObject(JS_MESSAGE_KEY_DATA);
                    String adSessionId = data.getString(JS_MESSAGE_DATA_AD_SESSION_ID);
                    if (method.equals(JS_MESSAGE_METHOD_START_SESSION)) {
                        startSession(adSessionId);
                    } else if (method.equals(JS_MESSAGE_METHOD_FINISH_SESSION)) {
                        finishSession(adSessionId);
                    } else {
                        OmidLogs.w("Unexpected method in JavaScriptSessionService: " + method);
                    }
                } catch (JSONException e) {
                    OmidLogs.e("Error parsing JS message in JavaScriptSessionService.", e);
                }
            }
        };
        webViewUtil.addWebMessageListener(
            webView,
            JS_MESSAGE_LISTENER_JS_SESSION_SERVICE,
            new HashSet<String>(Arrays.asList("*")), // Allow messages from any origin.
            webMessageListener);
    }

    private void removeWebViewListener() {
        webViewUtil.removeWebMessageListener(webView, JS_MESSAGE_LISTENER_JS_SESSION_SERVICE);
    }

    private void startSession(String adSessionId) {
        AdSession adSession = new AdSessionInternal(createAdSessionConfiguration(),
            createAdSessionContext(), adSessionId);
        adSessions.put(adSessionId, adSession);
        adSession.registerAdView(getAdView());
        for (FriendlyObstruction obstruction : friendlyObstructions.getAll()) {
            adSession.addFriendlyObstruction(
                obstruction.getObstructionView().get(),
                obstruction.getObstructionPurpose(),
                obstruction.getObstructionDetailedReason());
        }
        adSession.start();
    }

    private void finishSession(String adSessionId) {
        AdSession adSession = adSessions.get(adSessionId);
        if (adSession != null) {
            adSession.finish();
            adSessions.remove(adSessionId);
        }
    }

    private AdSessionConfiguration createAdSessionConfiguration() {
        return AdSessionConfiguration.createAdSessionConfiguration(
            CreativeType.DEFINED_BY_JAVASCRIPT,
            ImpressionType.DEFINED_BY_JAVASCRIPT,
            Owner.JAVASCRIPT,
            Owner.JAVASCRIPT,
            false);
    }

    private AdSessionContext createAdSessionContext() {
        if (isHtmlAdView) {
            return AdSessionContext.createHtmlAdSessionContext(partner, webView, null, null);
        } else {
            return AdSessionContext.createJavascriptAdSessionContext(partner, webView, null, null);
        }
    }
}
