package com.iab.omid.library.freewheeltv.weakreference;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

/**
 * Created by Natasha Garner on 09/09/2017.
 */
public class WeakWebView extends WeakReference<WebView> {
    public WeakWebView(WebView webView) {
        super(webView);
    }
}
