package com.iab.omid.library.freewheeltv.adsession;

import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_CONFIGURATION_NULL;
import static com.iab.omid.library.freewheeltv.internal.Errors.ERROR_ADSESSION_CONTEXT_NULL;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.checkOmidActive;
import static com.iab.omid.library.freewheeltv.utils.OmidUtils.confirmNotNull;

import android.view.View;
import androidx.annotation.Nullable;
import com.iab.omid.library.freewheeltv.publisher.AdSessionStatePublisher;

/**
 * Ad session API enabling the integration partner to notify OM SDK of key state relating to
 * viewability calculations.
 * In addition to viewability this API will also notify all verification providers of key ad session
 * lifecycle events.
 */
public abstract class AdSession {

    /**
     * Notify all verification providers that the ad session has started and ad view tracking will
     * begin.
     * This method will have no effect if called after the ad session has finished.
     */
    public abstract void start();

    /**
     * Notify all verification providers that an error has occurred on the ad session.
     *
     * @param errorType of the reported error
     * @param message   containing details of the reported error
     * @throws IllegalArgumentException if the supplied error type is null.
     * @throws IllegalArgumentException if the supplied message is either null or blank.
     * @throws IllegalStateException if the ad session has finished.
     */
    public abstract void error(ErrorType errorType, String message);

    /**
     * Register ad view to be used for tracking viewability. This method should be called each time
     * the ad view to track changes - i.e. two-part expandable. If an ad view is already registered
     * for the current session, that ad view will be automatically unregistered and the new ad view
     * will be registered in its place.
     * If the ad view being registered has been previously registered with a different ad session,
     * then the ad view will be automatically unregistered from those previously registered ad sessions.
     * This method will have no effect if called after the ad session has finished.
     *
     * @param adView the native view which should be registered for viewability tracking.
     */
    public abstract void registerAdView(@Nullable View adView);

    /**
     * Notify all verification providers that the ad session has finished and all ad view tracking
     * will stop.
     * This method will have no effect if called after the ad session has finished.
     *
     * Note that ending an OMID ad session sends a message to the verification scripts running inside
     * the webview supplied by the integration.  So that the verification scripts have enough time to
     * handle the 'sessionFinish' event, the integration must maintain a strong reference to the webview
     * for at least 1.0 seconds after ending the session.
     */
    public abstract void finish();

    /**
     * Add friendly obstruction which should then be excluded from all ad session viewability
     * calculations.
     * This method will have no effect if called after the ad session has finished. If the same
     * friendly obstruction view is added multiple times in a session, the purpose and
     * detailedReason parameters of only the first addition are used.
     *
     * @param friendlyObstruction to be excluded from all ad session viewability calculations.
     * @param purpose             why this obstruction was necessary
     * @param detailedReason      an explanation for why this obstruction is part of the ad experience if
     *                            not already obvious from the {@link FriendlyObstructionPurpose} selected.
     *                            Must be 50 characters or less and only contain characters `A-z`,`0-9` or space.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     * @throws IllegalArgumentException if the detailedReason is over 50 characters or contains a
     *                                  character that is not in `A-z`,`0-9` or a space.
     */
    public abstract void addFriendlyObstruction(final View friendlyObstruction,
                                                final FriendlyObstructionPurpose purpose,
                                                final @Nullable String detailedReason
    );

    /**
     * Remove registered friendly obstruction.
     * This method will have no effect if called after the ad session has finished.
     *
     * @param friendlyObstruction to be removed from the list of registered friendly obstructions.
     * @throws IllegalArgumentException if the supplied friendly obstruction is null.
     */
    public abstract void removeFriendlyObstruction(View friendlyObstruction);

    /**
     * Utility method to remove all registered friendly obstructions.
     * This method will have no effect if called after the ad session has finished.
     */
    public abstract void removeAllFriendlyObstructions();

    /**
     * For debugging purposes only.
     * Sets a PossibleObstructionListener on the AdSession that will listen for views that could be
     * obstructing the ad view. Only meant to be used by integrators who are having trouble
     * determining which views are obstructing their ad views. Passing in a value of null will unset
     * a previously set obstruction listener.
     */
    public abstract void setPossibleObstructionListener(PossibleObstructionListener possibleObstructionListener);

    /**
     * Create new ad session supplying the adSessionConfiguration and adSessionContext.
     *
     * Note that creating an AdSession sends a message to the OM SDK JS Service running in the
     * webview.  If the OM SDK JS Service has not loaded before the ad session is created, the
     * message is lost, and the verification scripts will not receive any events.
     *
     * To prevent this, the implementation must wait until the webview finishes loading OM SDK
     * JavaScript before creating the AdSession.  The easiest way is to create the AdSession in a
     * webview callback WebViewClient.onPageFinished().  Alternatively, if an implementation can
     * receive an HTML5 DOMContentLoaded event from the webview, it can create the OMIDAdSession in
     * a message handler for that event.
     *
     * @param adSessionContext that provides the required information for initialising the ad session.
     * @return new AdSession instance
     * @throws IllegalArgumentException if the supplied adSessionContext is null.
     * @throws IllegalStateException if this method has been executed before OM SDK has been
     *     activated.
     */
    public static AdSession createAdSession(final AdSessionConfiguration adSessionConfiguration,
                                            final AdSessionContext adSessionContext) {
        checkOmidActive();
        confirmNotNull(adSessionConfiguration, ERROR_ADSESSION_CONFIGURATION_NULL);
        confirmNotNull(adSessionContext, ERROR_ADSESSION_CONTEXT_NULL);
        return new AdSessionInternal(adSessionConfiguration, adSessionContext);
    }

    /**
     * For OM SDK internal use only.
     * Use of getAdSessionStatePublisher() and getAdSessionId() is highly discouraged.
     * These are undocumented calls that will be removed in future version.
     */
    public abstract AdSessionStatePublisher getAdSessionStatePublisher();

    /**
     * For OM SDK internal use only.
     */
    public abstract String getAdSessionId();
}
