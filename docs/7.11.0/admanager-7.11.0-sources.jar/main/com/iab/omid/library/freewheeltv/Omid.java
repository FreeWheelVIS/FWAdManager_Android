package com.iab.omid.library.freewheeltv;

import android.content.Context;

/**
 * This application level class will be called by all integration partners to ensure OM SDK has <br>
 * been activated before calling any other API methods. <br>
 * Any attempt to use other API methods prior to activation will result in an exception.
 * <p>
 *
 * Note that OM SDK may only be used on the main UI thread.  
 * Make sure you are on the main thread when you initialize the SDK, create its
 * objects, and invoke its methods.
 * <p>
 *
 * Created by Natasha Garner on 20/06/2017.
 */

public final class Omid {

    private static OmidInternal INSTANCE = new OmidInternal();

    private Omid() { }

    /**
     * Activate OM SDK prior to calling any other API methods. On CTV, should be called on launch.
     *
     * @param applicationContext of the running application.
     * @throws IllegalArgumentException if the supplied application context is null.
     */
    public static void activate(final Context applicationContext) {
        INSTANCE.activate(applicationContext.getApplicationContext());
    }

    /**
     *  Notify OM SDK to update last activity time when users interact on CTV devices.
     * @throws IllegalStateException if this method has been executed before OM SDK has been
     *     activated.
     */
     public static void updateLastActivity() {
         INSTANCE.updateLastActivity();
     }

    /**
     * Access the running OM SDK semantic version.
     *
     * @return the current semantic version of the integrated OM SDK.
     */
    public static String getVersion() {
        return INSTANCE.getVersion();
    }

    /**
     * Determine if the running OM SDK is active before attempting to create any ad sessions.
     *
     * @return true if the OM SDK has already been activated.
     */
    public static boolean isActive() {
        return INSTANCE.isActive();
    }
}