package com.iab.omid.library.freewheeltv.devicevolume;

public interface DeviceVolumeListener {

    void onDeviceVolumeChanged(final float deviceVolume);

}
