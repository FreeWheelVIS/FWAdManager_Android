package com.iab.omid.library.freewheeltv.adsession;

/**
 * List of supported error types.
 * <p>
 * Created by pharris on 01/09/2017.
 */
public enum ErrorType {
    /**
     * The integration is publishing a "generic" error to verification scripts.
     */
    GENERIC("generic"),
    /**
     * The integration is publishing a "video" error to verification scripts.
     */
    VIDEO("video");

    private final String errorType;

    ErrorType(String errorType) {
        this.errorType = errorType;
    }

    @Override
    public String toString() {
        return errorType;
    }
}
