package com.iab.omid.library.freewheeltv.internal;

import android.view.View;
import com.iab.omid.library.freewheeltv.adsession.AdSessionInternal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * AdSessionRegistry
 *
 * <p>
 * Created by Natasha Garner on 08/08/2017.
 */

public class AdSessionRegistry {

    private static AdSessionRegistry instance = new AdSessionRegistry();

    private final ArrayList<AdSessionInternal> adSessions = new ArrayList<>();
    private final ArrayList<AdSessionInternal> activeAdSessions = new ArrayList<>();

    private AdSessionRegistry() {}

    public static AdSessionRegistry getInstance() {
        return instance;
    }

    // Note : this method is required by the tests, do not remove
    private static AdSessionRegistry createInstance() {
        return new AdSessionRegistry();
    }

    public void adSessionCreated(AdSessionInternal adSession) {
        adSessions.add(adSession);
    }

    public void adSessionStarted(AdSessionInternal adSession) {
        boolean wasActive = isActive();
        activeAdSessions.add(adSession);
        if(wasActive == false) {
            OmidManager.getInstance().start();
        }
    }

    public void adSessionFinished(AdSessionInternal adSession) {
        boolean wasActive = isActive();
        adSessions.remove(adSession);
        activeAdSessions.remove(adSession);
        // Stop the OmidManager if there were active AdSessions and there are none after removal
        if(wasActive && isActive() == false) {
            OmidManager.getInstance().stop();
        }
    }

    public Collection<AdSessionInternal> getAdSessions() {
        return Collections.unmodifiableCollection(adSessions);
    }

    public Collection<AdSessionInternal> getActiveAdSessions() {
        return Collections.unmodifiableCollection(activeAdSessions);
    }

    public boolean isActive() {
        return activeAdSessions.size() > 0;
    }

    public AdSessionInternal getAdSessionById(String adSessionId) {
        if(adSessionId != null && adSessions.size() > 0) {
            for(AdSessionInternal adSession : adSessions) {
                if(adSessionId.equals(adSession.getAdSessionId())) {
                    return adSession;
                }
            }
        }
        return null;
    }

    public AdSessionInternal getAdSessionByView(View view) {
        if(view != null && adSessions.size() > 0) {
            for(AdSessionInternal adSession : adSessions) {
                if(adSession.getAdView() == view) {
                    return adSession;
                }
            }
        }
        return null;
    }
}
