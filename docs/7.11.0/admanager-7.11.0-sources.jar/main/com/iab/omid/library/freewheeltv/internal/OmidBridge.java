package com.iab.omid.library.freewheeltv.internal;

import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.iab.omid.library.freewheeltv.adsession.ErrorType;
import com.iab.omid.library.freewheeltv.utils.OmidLogs;
import org.json.JSONObject;

/**
 * This class is the bridge between the native library and the OM SDK JS.
 * Created by Natasha Garner on 31/08/2017.
 */
public class OmidBridge {

    public static final String METHOD_INIT = "init";
    public static final String METHOD_START_SESSION = "startSession";
    public static final String METHOD_FINISH_SESSION = "finishSession";
    public static final String METHOD_SET_NATIVE_VIEW_HIERARCHY = "setNativeViewHierarchy";
    public static final String METHOD_SET_STATE = "setState";
    public static final String METHOD_SET_LOCK_STATE = "setDeviceLockState";
    public static final String METHOD_ERROR = "error";
    public static final String METHOD_PUBLISH_IMPRESSION_EVENT = "publishImpressionEvent";
    public static final String METHOD_PUBLISH_LOADED_EVENT = "publishLoadedEvent";
    public static final String METHOD_PUBLISH_MEDIA_EVENT = "publishMediaEvent";
    public static final String METHOD_SET_DEVICE_VOLUME = "setDeviceVolume";
    public static final String METHOD_SET_LAST_ACTIVITY = "setLastActivity";

    public static final String APP_STATE_BACKGROUNDED = "backgrounded";
    public static final String APP_STATE_FOREGROUNDED = "foregrounded";

    public static final String LOCK_STATE_LOCKED = "locked";
    public static final String LOCK_STATE_UNLOCKED = "unlocked";

    public static final String MEDIA_EVENT_START = "start";
    public static final String MEDIA_EVENT_FIRST_QUARTILE = "firstQuartile";
    public static final String MEDIA_EVENT_MIDPOINT = "midpoint";
    public static final String MEDIA_EVENT_THIRD_QUARTILE = "thirdQuartile";
    public static final String MEDIA_EVENT_COMPLETE = "complete";
    public static final String MEDIA_EVENT_PAUSE = "pause";
    public static final String MEDIA_EVENT_RESUME = "resume";
    public static final String MEDIA_EVENT_BUFFER_START = "bufferStart";
    public static final String MEDIA_EVENT_BUFFER_FINISH = "bufferFinish";
    public static final String MEDIA_EVENT_SKIPPED = "skipped";
    public static final String MEDIA_EVENT_VOLUME_CHANGE = "volumeChange";
    public static final String MEDIA_EVENT_PLAYER_STATE_CHANGE = "playerStateChange";
    public static final String MEDIA_EVENT_AD_USER_INTERACTION = "adUserInteraction";

    public static final String VERIFICATION_PARAMETERS = "verificationParameters";
    public static final String VERIFICATION_RESOURCE_URL = "resourceUrl";
    public static final String VERIFICATION_VENDOR_KEY = "vendorKey";

    public static final String VAST_PROPERTIES_SKIPPABLE = "skippable";
    public static final String VAST_PROPERTIES_SKIPOFFSET = "skipOffset";
    public static final String VAST_PROPERTIES_AUTOPLAY = "autoPlay";
    public static final String VAST_PROPERTIES_POSITION = "position";

    public static final String KEY_MEDIA_DURATION = "duration";
    public static final String KEY_MEDIA_MEDIA_PLAYER_VOLUME = "mediaPlayerVolume";
    public static final String KEY_MEDIA_DEVICE_VOLUME = "deviceVolume";
    public static final String KEY_MEDIA_STATE = "state";
    public static final String KEY_MEDIA_INTERACTION_TYPE = "interactionType";

    public static final String KEY_INIT_IMPRESSION_OWNER = "impressionOwner";
    public static final String KEY_INIT_MEDIA_EVENTS_OWNER = "mediaEventsOwner";
    public static final String KEY_INIT_ISOLATE_VERIFICATION_SCRIPTS = "isolateVerificationScripts";
    public static final String KEY_CREATIVE_TYPE = "creativeType";
    public static final String KEY_IMPRESSION_TYPE = "impressionType";

    public static final String KEY_START_ENVIRONMENT = "environment";
    public static final String KEY_START_AD_SESSION_TYPE = "adSessionType";
    public static final String KEY_START_SUPPORTS = "supports";
    public static final String KEY_START_SUPPORTS_CLID = "clid";
    public static final String KEY_START_SUPPORTS_VLID = "vlid";
    public static final String KEY_START_OMID_NATIVE_INFO = "omidNativeInfo";
    public static final String KEY_START_OMID_NATIVE_INFO_NAME = "partnerName";
    public static final String KEY_START_OMID_NATIVE_INFO_VERSION = "partnerVersion";
    public static final String KEY_START_APP = "app";
    public static final String KEY_START_APP_ID = "appId";
    public static final String KEY_START_APP_LIBRARY_VERSION = "libraryVersion";
    public static final String KEY_START_CONTENT_URL = "contentUrl";
    public static final String KEY_START_CUSTOM_REFERENCE_DATA = "customReferenceData";
    public static final String KEY_START_DEVICE_CATEGORY = "deviceCategory";

    public static final String KEY_START_DEVICE_INFO = "deviceInfo";
    public static final String KEY_START_DEVICE_TYPE = "deviceType";
    public static final String KEY_START_OS_VERSION = "osVersion";
    public static final String KEY_START_OS = "os";
    public static final String VALUE_START_OS = "Android";

    public static final String VALUE_START_APP = "app";

    public static final String KEY_STATE_AD_SESSION_ID = "adSessionId";
    public static final String KEY_STATE_X = "x";
    public static final String KEY_STATE_Y = "y";
    public static final String KEY_STATE_WIDTH = "width";
    public static final String KEY_STATE_HEIGHT = "height";
    public static final String KEY_STATE_NOT_VISIBLE_REASON = "notVisibleReason";
    public static final String KEY_STATE_HAS_WINDOW_FOCUS = "hasWindowFocus";
    public static final String KEY_STATE_IS_PICTURE_IN_PICTURE_ACTIVE = "isPipActive";
    public static final String KEY_STATE_CHILD_VIEWS = "childViews";
    public static final String KEY_STATE_IS_FRIENDLY_OBSTRUCTION_FOR = "isFriendlyObstructionFor";
    public static final String KEY_STATE_FRIENDLY_OBSTRUCTION_CLASS = "friendlyObstructionClass";
    public static final String KEY_STATE_FRIENDLY_OBSTRUCTION_PURPOSE = "friendlyObstructionPurpose";
    public static final String KEY_STATE_FRIENDLY_OBSTRUCTION_REASON = "friendlyObstructionReason";
    public static final String KEY_STATE_NO_OUTPUT_DEVICE = "noOutputDevice";

    public static final String KEY_STATE_NOT_VISIBLE_NO_WINDOW_FOCUS = "noWindowFocus";
    public static final String KEY_STATE_NOT_VISIBLE_NOT_ATTACHED = "notAttached";
    public static final String KEY_STATE_NOT_VISIBLE_VIEW_INVISIBLE = "viewInvisible";
    public static final String KEY_STATE_NOT_VISIBLE_VIEW_GONE = "viewGone";
    public static final String KEY_STATE_NOT_VISIBLE_VIEW_NOT_VISIBLE = "viewNotVisible";
    public static final String KEY_STATE_NOT_VISIBLE_VIEW_ALPHA_ZERO = "viewAlphaZero";
    public static final String KEY_STATE_NOT_VISIBLE_NO_ADVIEW = "noAdView";

    public static final String KEY_TIMESTAMP = "timestamp";

    private static OmidBridge instance = new OmidBridge();

    private OmidBridge() {}

    public static final OmidBridge getInstance() {
        return instance;
    }

    // Note : this method is required by the tests, do not remove
    private static OmidBridge createInstance() { return new OmidBridge(); }

    private static final String SCRIPT_SRC_PLACEHOLDER = "%SCRIPT_SRC%";
    private static final String INJECTIONID_PLACEHOLDER = "%INJECTION_ID%";

    private static final String JAVASCRIPT_RESOURCE =
        "this.omidVerificationProperties = this.omidVerificationProperties || {};" +
        "Object.defineProperty(this.omidVerificationProperties, 'injectionId', {" +
            "get: function() {" +
                "var currentScript = document && document.currentScript;" +
                "return currentScript && currentScript.getAttribute('data-injection-id');" +
            "}, configurable: true});" +
        "var script = document.createElement('script');" +
        "script.setAttribute(\"type\",\"text/javascript\");" +
        "script.setAttribute(\"src\",\"" + SCRIPT_SRC_PLACEHOLDER + "\");" +
        "script.setAttribute(\"data-injection-id\",\"" + INJECTIONID_PLACEHOLDER + "\");" +
        "document.body.appendChild(script);";

    private static final String JAVASCRIPT_RESOURCE_CLOSURE =
        "(function() {" + JAVASCRIPT_RESOURCE + "})();";

    public boolean injectJavaScript(WebView webView, String javascriptContent) {
        if(webView != null && !TextUtils.isEmpty(javascriptContent)) {
            if (VERSION.SDK_INT >= VERSION_CODES.KITKAT) {
                try {
                    // Prefer evaluateJavascript since it is a newer API and fixes some bugs in
                    // loadUrl such as decoding %22 to ", causing a syntax error (OMSS-1898).
                    webView.evaluateJavascript(javascriptContent, null);
                } catch (IllegalStateException e) {
                    // In case the OS version is misreported, fall back to loadUrl.
                    webView.loadUrl("javascript: " + javascriptContent);
                }
            } else {
                webView.loadUrl("javascript: " + javascriptContent);
            }
            return true;
        }
        return false;
    }

    public void injectJavaScriptResource(WebView webView, String javascriptResource,
                    String injectionId) {
        if(javascriptResource != null && !TextUtils.isEmpty(injectionId)) {
            String javascript = JAVASCRIPT_RESOURCE_CLOSURE.replace(SCRIPT_SRC_PLACEHOLDER,
                    javascriptResource);
            javascript = javascript.replace(INJECTIONID_PLACEHOLDER, injectionId);
            injectJavaScript(webView, javascript);
        }
    }

    public void callInit(WebView jsExec, String adSessionId, JSONObject adSessionConfiguration) {
        callCommand(jsExec, METHOD_INIT, adSessionConfiguration, adSessionId);
    }

    public void callStartSession(WebView jsExec, String adSessionId, JSONObject nativeContext,
                                 JSONObject verificationParameters, JSONObject injectedResources) {
        callCommand(jsExec, METHOD_START_SESSION, adSessionId, nativeContext,
                verificationParameters, injectedResources);
    }

    public void callFinishSession(WebView jsExec, String adSessionId) {
        callCommand(jsExec, METHOD_FINISH_SESSION, adSessionId);
    }

    public void callSetNativeViewHierarchy(WebView jsExec, String adSessionId, String viewState) {
        callCommand(jsExec, METHOD_SET_NATIVE_VIEW_HIERARCHY, viewState, adSessionId);
    }

    public void callSetState(WebView jsExec, String adSessionId, String state) {
        callCommand(jsExec, METHOD_SET_STATE, state, adSessionId);
    }

    public void callPublishImpressionEvent(WebView jsExec, String adSessionId) {
        callCommand(jsExec, METHOD_PUBLISH_IMPRESSION_EVENT, adSessionId);
    }

    public void callSetLockState(WebView jsExec, String adSessionId, String state) {
        callCommand(jsExec, METHOD_SET_LOCK_STATE, state);
    }

    public void callPublishLoadedEvent(WebView jsExec, String adSessionId,
                                       @Nullable JSONObject data) {
        callCommand(jsExec, METHOD_PUBLISH_LOADED_EVENT, data, adSessionId);
    }

    public void callError(WebView jsExec, String adSessionId, ErrorType errorType, String message) {
        callCommand(jsExec, METHOD_ERROR, errorType.toString(), message, adSessionId);
    }

    public void callPublishMediaEvent(WebView jsExec, String adSessionId, String eventType,
                                      @Nullable JSONObject data) {
        callCommand(jsExec, METHOD_PUBLISH_MEDIA_EVENT, eventType, data, adSessionId);
    }

    public void callSetDeviceVolume(WebView jsExec, String adSessionId, float deviceVolume) {
        callCommand(jsExec, METHOD_SET_DEVICE_VOLUME, deviceVolume, adSessionId);
    }

    public void callSetLastActivity(WebView jsExec, @NonNull JSONObject activityData) {
        callCommand(jsExec, METHOD_SET_LAST_ACTIVITY, activityData);
    }

    @VisibleForTesting
    void callCommand(final WebView jsExec, String method, Object... parameters) {
        if(jsExec != null) {
            final int initialCapacity = 128;
            StringBuilder command = new StringBuilder(initialCapacity);
            command.append("if(window.omidBridge!==undefined){omidBridge.");
            command.append(method);
            command.append("(");
            appendParameters(command, parameters);
            command.append(")}");
            executeCommandAgainstWebViewThread(jsExec, command);
        }
        else {
            OmidLogs.i(Errors.ERROR_OMIDBRIDGE_WEBVIEW_NULL + method);
        }
    }

    @VisibleForTesting
    void executeCommandAgainstWebViewThread(final WebView jsExec, StringBuilder command) {
        final String finalCommand = command.toString();
        final Handler handler = jsExec.getHandler();
        // The WebView thread must be used to execute tasks
        // See {@link android.webkit.WebView#checkThread() checkThread()}
        // Call method on WebViews handler if our thread isn't the WebViews thread
        if(handler == null || Looper.myLooper() == handler.getLooper()) {
            // Use the WebView thread as it needs to be single threaded, and the WebView will
            // handle the queueing onto the UI thread
            injectJavaScript(jsExec, finalCommand);
        }
        else {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    injectJavaScript(jsExec, finalCommand);
                }
            });
        }
    }

    @VisibleForTesting
    void appendParameters(StringBuilder command, Object[] parameters) {
        if(parameters != null && parameters.length > 0) {
            for(Object parameter : parameters) {
                if(parameter == null) {
                    command.append("null");
                }
                else if(parameter instanceof String) {
                    String data = parameter.toString();
                    if(data.startsWith("{")) {
                        command.append(data);
                    }
                    else {
                        command.append('"').append(data).append('"');
                    }
                }
                else {
                    command.append(parameter);
                }
                command.append(",");
            }
            // Remove last ,
            command.setLength(command.length() -1);
        }
    }
}
