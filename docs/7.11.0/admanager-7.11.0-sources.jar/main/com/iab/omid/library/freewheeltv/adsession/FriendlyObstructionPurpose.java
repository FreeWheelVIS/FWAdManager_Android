package com.iab.omid.library.freewheeltv.adsession;

/**
 * List of allowed friendly obstruction purposes.
 * <p>
 * Created by Noam Schaap on 03/21/2019.
 */
public enum FriendlyObstructionPurpose {
    /**
     * The friendly obstruction relates to interacting with a video (such as play/pause buttons).
     */
    VIDEO_CONTROLS,
    /**
     * The friendly obstruction relates to closing an ad (such as a close button).
     */
    CLOSE_AD,
    /**
     * The friendly obstruction is not visibly obstructing the ad but may seem so due to technical
     * limitations.
     */
    NOT_VISIBLE,
    /**
     * The friendly obstruction is obstructing for any purpose not already described.
     */
    OTHER
}
